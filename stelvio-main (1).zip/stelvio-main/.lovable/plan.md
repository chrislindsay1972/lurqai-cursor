
# Fix CV Upload/Download Insufficient Permission Error

## Problem Summary

The CV upload and download functionality fails with "Insufficient permission" errors. After thorough investigation, I've identified the root cause:

**The storage bucket policies reference `has_role()` without the `public.` schema prefix.** When these policies execute in the storage schema context, PostgreSQL cannot locate the function, causing all permission checks to fail.

### Evidence

| Check | Result |
|-------|--------|
| Bucket exists | Yes - `cv-files` (private) |
| User role | Admin (`c5bf2c04...` has admin role) |
| Function works | Yes - `public.has_role()` returns `true` for admin |
| Migration applied | **No** - not in migration history |
| Policy definitions | Using unqualified `has_role()` (broken) |

---

## Solution

Apply the storage policy fix migration that was created but never executed. This will:

1. Drop the broken policies that use unqualified `has_role()`
2. Recreate them with properly qualified `public.has_role()` calls

### Policy Changes

```text
BEFORE (broken):
┌──────────────────────────────────────────────────────────┐
│ has_role(auth.uid(), 'admin'::app_role)                  │
│        ↑                           ↑                     │
│   No schema prefix             No schema prefix          │
│   (Function not found)         (Type not found)          │
└──────────────────────────────────────────────────────────┘

AFTER (fixed):
┌──────────────────────────────────────────────────────────┐
│ public.has_role(auth.uid(), 'admin'::public.app_role)    │
│    ↑                                    ↑                │
│ Schema prefix                     Schema prefix          │
│ (Function found!)                 (Type found!)          │
└──────────────────────────────────────────────────────────┘
```

---

## Implementation Steps

### Step 1: Apply Storage Policy Migration

Create and execute a new migration (since the previous one wasn't applied):

```sql
-- Drop existing broken CV storage policies
DROP POLICY IF EXISTS "Recruiters and admins can view CVs" ON storage.objects;
DROP POLICY IF EXISTS "Recruiters and admins can upload CVs" ON storage.objects;
DROP POLICY IF EXISTS "Recruiters and admins can update CVs" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete CVs" ON storage.objects;

-- Recreate with properly qualified public.has_role function
CREATE POLICY "Recruiters and admins can view CVs"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'cv-files' 
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role) 
    OR public.has_role(auth.uid(), 'recruiter'::public.app_role)
  )
);

CREATE POLICY "Recruiters and admins can upload CVs"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'cv-files' 
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role) 
    OR public.has_role(auth.uid(), 'recruiter'::public.app_role)
  )
);

CREATE POLICY "Recruiters and admins can update CVs"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'cv-files' 
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role) 
    OR public.has_role(auth.uid(), 'recruiter'::public.app_role)
  )
);

CREATE POLICY "Admins can delete CVs"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'cv-files' 
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);
```

### Step 2: Verify Fix

After migration is applied, confirm the policies now use qualified references.

---

## Technical Details

### Why This Happens

Storage policies execute in a different schema context than the `public` schema. When PostgreSQL evaluates:

```sql
has_role(auth.uid(), 'admin'::app_role)
```

It searches for `has_role` in the current search path. Since storage operates under `supabase_admin` ownership with a potentially different search path, it cannot find the function in `public` schema.

### Affected Operations

| Operation | Policy | Status |
|-----------|--------|--------|
| Download CV | `FOR SELECT` | Broken - function not found |
| Upload CV | `FOR INSERT` | Broken - function not found |
| Update CV | `FOR UPDATE` | Broken - function not found |
| Delete CV | `FOR DELETE` | Broken - function not found |

### Users Affected

All authenticated users (Admin, Recruiter) are affected because the permission check fails before role evaluation.

---

## Expected Outcome

After applying this fix:
- Admins and Recruiters can upload CVs
- Admins and Recruiters can download CVs  
- Admins and Recruiters can update CVs
- Only Admins can delete CVs
