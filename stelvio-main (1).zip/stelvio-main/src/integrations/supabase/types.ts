export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      ai_instructions: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          instruction_key: string
          instruction_name: string
          instruction_prompt: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          instruction_key: string
          instruction_name: string
          instruction_prompt: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          instruction_key?: string
          instruction_name?: string
          instruction_prompt?: string
          updated_at?: string
        }
        Relationships: []
      }
      ai_profiles: {
        Row: {
          base_instruction: string
          compliance_rules: Json | null
          created_at: string
          created_by: string | null
          disallowed_phrases: string[] | null
          id: string
          language_style: string | null
          primary_cta: string | null
          profile_name: string
          secondary_cta: string | null
          tone_tags: string[] | null
          updated_at: string
          voice: string | null
        }
        Insert: {
          base_instruction?: string
          compliance_rules?: Json | null
          created_at?: string
          created_by?: string | null
          disallowed_phrases?: string[] | null
          id?: string
          language_style?: string | null
          primary_cta?: string | null
          profile_name: string
          secondary_cta?: string | null
          tone_tags?: string[] | null
          updated_at?: string
          voice?: string | null
        }
        Update: {
          base_instruction?: string
          compliance_rules?: Json | null
          created_at?: string
          created_by?: string | null
          disallowed_phrases?: string[] | null
          id?: string
          language_style?: string | null
          primary_cta?: string | null
          profile_name?: string
          secondary_cta?: string | null
          tone_tags?: string[] | null
          updated_at?: string
          voice?: string | null
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          created_at: string
          description: string | null
          id: string
          setting_key: string
          setting_type: string
          setting_value: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          setting_key: string
          setting_type?: string
          setting_value: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          setting_key?: string
          setting_type?: string
          setting_value?: string
          updated_at?: string
        }
        Relationships: []
      }
      builtin_job_categories: {
        Row: {
          created_at: string
          examples: Json | null
          is_active: boolean
          label: string
          last_seen_at: string
          parent_slug: string | null
          slug: string
        }
        Insert: {
          created_at?: string
          examples?: Json | null
          is_active?: boolean
          label: string
          last_seen_at?: string
          parent_slug?: string | null
          slug: string
        }
        Update: {
          created_at?: string
          examples?: Json | null
          is_active?: boolean
          label?: string
          last_seen_at?: string
          parent_slug?: string | null
          slug?: string
        }
        Relationships: []
      }
      bulk_enrichment_items: {
        Row: {
          company_id: string
          company_name: string
          created_at: string
          domain: string | null
          domain_status: string
          enrich_status: string
          error: string | null
          id: string
          processing_order: number
          run_id: string
          stakeholder_status: string
          stakeholders_found: number | null
          updated_at: string
        }
        Insert: {
          company_id: string
          company_name: string
          created_at?: string
          domain?: string | null
          domain_status?: string
          enrich_status?: string
          error?: string | null
          id?: string
          processing_order?: number
          run_id: string
          stakeholder_status?: string
          stakeholders_found?: number | null
          updated_at?: string
        }
        Update: {
          company_id?: string
          company_name?: string
          created_at?: string
          domain?: string | null
          domain_status?: string
          enrich_status?: string
          error?: string | null
          id?: string
          processing_order?: number
          run_id?: string
          stakeholder_status?: string
          stakeholders_found?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bulk_enrichment_items_run_id_fkey"
            columns: ["run_id"]
            isOneToOne: false
            referencedRelation: "bulk_enrichment_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      bulk_enrichment_runs: {
        Row: {
          completed: number
          created_at: string
          created_by: string | null
          failed: number
          id: string
          status: string
          succeeded: number
          total: number
          updated_at: string
        }
        Insert: {
          completed?: number
          created_at?: string
          created_by?: string | null
          failed?: number
          id?: string
          status?: string
          succeeded?: number
          total?: number
          updated_at?: string
        }
        Update: {
          completed?: number
          created_at?: string
          created_by?: string | null
          failed?: number
          id?: string
          status?: string
          succeeded?: number
          total?: number
          updated_at?: string
        }
        Relationships: []
      }
      campaign_metrics: {
        Row: {
          campaign_id: string
          created_at: string
          email_address: string
          event_at: string
          event_data: Json | null
          event_type: string
          id: string
          stakeholder_id: string
          step_id: string | null
        }
        Insert: {
          campaign_id: string
          created_at?: string
          email_address: string
          event_at?: string
          event_data?: Json | null
          event_type: string
          id?: string
          stakeholder_id: string
          step_id?: string | null
        }
        Update: {
          campaign_id?: string
          created_at?: string
          email_address?: string
          event_at?: string
          event_data?: Json | null
          event_type?: string
          id?: string
          stakeholder_id?: string
          step_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "campaign_metrics_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaign_metrics_stakeholder_id_fkey"
            columns: ["stakeholder_id"]
            isOneToOne: false
            referencedRelation: "stakeholders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaign_metrics_step_id_fkey"
            columns: ["step_id"]
            isOneToOne: false
            referencedRelation: "campaign_steps"
            referencedColumns: ["id"]
          },
        ]
      }
      campaign_steps: {
        Row: {
          campaign_id: string
          condition_type: string | null
          created_at: string
          delay_minutes: number
          id: string
          step_order: number
          step_type: string
          template_id: string | null
          updated_at: string
        }
        Insert: {
          campaign_id: string
          condition_type?: string | null
          created_at?: string
          delay_minutes?: number
          id?: string
          step_order: number
          step_type: string
          template_id?: string | null
          updated_at?: string
        }
        Update: {
          campaign_id?: string
          condition_type?: string | null
          created_at?: string
          delay_minutes?: number
          id?: string
          step_order?: number
          step_type?: string
          template_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "campaign_steps_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaign_steps_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "email_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      campaigns: {
        Row: {
          ai_profile_id: string | null
          campaign_type: string | null
          candidate_id: string | null
          completed_at: string | null
          created_at: string
          created_by: string | null
          description: string | null
          end_date: string | null
          id: string
          name: string
          rules_json: Json | null
          send_time_hour: number | null
          send_time_minute: number | null
          send_time_period: string | null
          start_date: string | null
          started_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          ai_profile_id?: string | null
          campaign_type?: string | null
          candidate_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          name: string
          rules_json?: Json | null
          send_time_hour?: number | null
          send_time_minute?: number | null
          send_time_period?: string | null
          start_date?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          ai_profile_id?: string | null
          campaign_type?: string | null
          candidate_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          name?: string
          rules_json?: Json | null
          send_time_hour?: number | null
          send_time_minute?: number | null
          send_time_period?: string | null
          start_date?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "campaigns_ai_profile_id_fkey"
            columns: ["ai_profile_id"]
            isOneToOne: false
            referencedRelation: "ai_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaigns_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
        ]
      }
      candidate_pre_search_answers: {
        Row: {
          answer_value: string | null
          candidate_id: string
          created_at: string
          id: string
          question_id: string
          updated_at: string
        }
        Insert: {
          answer_value?: string | null
          candidate_id: string
          created_at?: string
          id?: string
          question_id: string
          updated_at?: string
        }
        Update: {
          answer_value?: string | null
          candidate_id?: string
          created_at?: string
          id?: string
          question_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "candidate_pre_search_answers_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "candidate_pre_search_answers_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "pre_search_questions"
            referencedColumns: ["id"]
          },
        ]
      }
      candidates: {
        Row: {
          address: string | null
          ai_summary: string | null
          career_goals: string | null
          career_highlights: string[] | null
          certifications: string | null
          created_at: string
          created_by: string | null
          current_title: string | null
          cv_file_url: string | null
          cv_raw_text: string | null
          desired_location: string | null
          desired_salary: string | null
          education: string | null
          email: string | null
          experience_years: number | null
          id: string
          ideal_company_size: string | null
          ideal_role: string | null
          industries_of_interest: string[] | null
          is_remote_worker: boolean | null
          languages: string[] | null
          mobile: string | null
          name: string
          notice_period: string | null
          parsed_at: string | null
          pre_search_completed: boolean | null
          reason_for_looking: string | null
          relocation_willingness: string | null
          salary_expectation: string | null
          search_city: string | null
          search_country: string | null
          search_distance_km: number | null
          search_keywords: string[] | null
          search_notes: string | null
          skills: string[] | null
          soft_skills: string[] | null
          sponsorship_requirements: string | null
          status: string
          technical_proficiency: Json | null
          updated_at: string
          work_style_preference: string | null
        }
        Insert: {
          address?: string | null
          ai_summary?: string | null
          career_goals?: string | null
          career_highlights?: string[] | null
          certifications?: string | null
          created_at?: string
          created_by?: string | null
          current_title?: string | null
          cv_file_url?: string | null
          cv_raw_text?: string | null
          desired_location?: string | null
          desired_salary?: string | null
          education?: string | null
          email?: string | null
          experience_years?: number | null
          id?: string
          ideal_company_size?: string | null
          ideal_role?: string | null
          industries_of_interest?: string[] | null
          is_remote_worker?: boolean | null
          languages?: string[] | null
          mobile?: string | null
          name: string
          notice_period?: string | null
          parsed_at?: string | null
          pre_search_completed?: boolean | null
          reason_for_looking?: string | null
          relocation_willingness?: string | null
          salary_expectation?: string | null
          search_city?: string | null
          search_country?: string | null
          search_distance_km?: number | null
          search_keywords?: string[] | null
          search_notes?: string | null
          skills?: string[] | null
          soft_skills?: string[] | null
          sponsorship_requirements?: string | null
          status?: string
          technical_proficiency?: Json | null
          updated_at?: string
          work_style_preference?: string | null
        }
        Update: {
          address?: string | null
          ai_summary?: string | null
          career_goals?: string | null
          career_highlights?: string[] | null
          certifications?: string | null
          created_at?: string
          created_by?: string | null
          current_title?: string | null
          cv_file_url?: string | null
          cv_raw_text?: string | null
          desired_location?: string | null
          desired_salary?: string | null
          education?: string | null
          email?: string | null
          experience_years?: number | null
          id?: string
          ideal_company_size?: string | null
          ideal_role?: string | null
          industries_of_interest?: string[] | null
          is_remote_worker?: boolean | null
          languages?: string[] | null
          mobile?: string | null
          name?: string
          notice_period?: string | null
          parsed_at?: string | null
          pre_search_completed?: boolean | null
          reason_for_looking?: string | null
          relocation_willingness?: string | null
          salary_expectation?: string | null
          search_city?: string | null
          search_country?: string | null
          search_distance_km?: number | null
          search_keywords?: string[] | null
          search_notes?: string | null
          skills?: string[] | null
          soft_skills?: string[] | null
          sponsorship_requirements?: string | null
          status?: string
          technical_proficiency?: Json | null
          updated_at?: string
          work_style_preference?: string | null
        }
        Relationships: []
      }
      companies: {
        Row: {
          address: string | null
          alexa_ranking: number | null
          angellist_url: string | null
          annual_revenue: number | null
          annual_revenue_printed: string | null
          apollo_data: Json | null
          blog_url: string | null
          city: string | null
          clay_data: Json | null
          country: string | null
          created_at: string
          created_by: string | null
          crunchbase_url: string | null
          description: string | null
          domain: string | null
          domain_candidates: Json | null
          domain_quality_reasons: Json | null
          domain_quality_score: number | null
          domain_status: string | null
          employee_count: number | null
          enriched_at: string | null
          enrichment_source: string | null
          enrichment_status: string
          facebook_url: string | null
          founded_year: number | null
          funding_status: string | null
          glassdoor_rating: number | null
          id: string
          industries: string[] | null
          industry: string | null
          keywords: string[] | null
          languages: string[] | null
          latest_funding_round_date: string | null
          latest_funding_stage: string | null
          linkedin_url: string | null
          logo_url: string | null
          name: string
          num_suborganizations: number | null
          phone: string | null
          postal_code: string | null
          publicly_traded_exchange: string | null
          publicly_traded_symbol: string | null
          quality_enriched_at: string | null
          quality_signals: Json | null
          recent_news: string[] | null
          retail_location_count: number | null
          seo_description: string | null
          short_description: string | null
          state: string | null
          street_address: string | null
          technology_names: string[] | null
          total_funding: number | null
          total_funding_printed: string | null
          twitter_url: string | null
          updated_at: string
          website_url: string | null
        }
        Insert: {
          address?: string | null
          alexa_ranking?: number | null
          angellist_url?: string | null
          annual_revenue?: number | null
          annual_revenue_printed?: string | null
          apollo_data?: Json | null
          blog_url?: string | null
          city?: string | null
          clay_data?: Json | null
          country?: string | null
          created_at?: string
          created_by?: string | null
          crunchbase_url?: string | null
          description?: string | null
          domain?: string | null
          domain_candidates?: Json | null
          domain_quality_reasons?: Json | null
          domain_quality_score?: number | null
          domain_status?: string | null
          employee_count?: number | null
          enriched_at?: string | null
          enrichment_source?: string | null
          enrichment_status?: string
          facebook_url?: string | null
          founded_year?: number | null
          funding_status?: string | null
          glassdoor_rating?: number | null
          id?: string
          industries?: string[] | null
          industry?: string | null
          keywords?: string[] | null
          languages?: string[] | null
          latest_funding_round_date?: string | null
          latest_funding_stage?: string | null
          linkedin_url?: string | null
          logo_url?: string | null
          name: string
          num_suborganizations?: number | null
          phone?: string | null
          postal_code?: string | null
          publicly_traded_exchange?: string | null
          publicly_traded_symbol?: string | null
          quality_enriched_at?: string | null
          quality_signals?: Json | null
          recent_news?: string[] | null
          retail_location_count?: number | null
          seo_description?: string | null
          short_description?: string | null
          state?: string | null
          street_address?: string | null
          technology_names?: string[] | null
          total_funding?: number | null
          total_funding_printed?: string | null
          twitter_url?: string | null
          updated_at?: string
          website_url?: string | null
        }
        Update: {
          address?: string | null
          alexa_ranking?: number | null
          angellist_url?: string | null
          annual_revenue?: number | null
          annual_revenue_printed?: string | null
          apollo_data?: Json | null
          blog_url?: string | null
          city?: string | null
          clay_data?: Json | null
          country?: string | null
          created_at?: string
          created_by?: string | null
          crunchbase_url?: string | null
          description?: string | null
          domain?: string | null
          domain_candidates?: Json | null
          domain_quality_reasons?: Json | null
          domain_quality_score?: number | null
          domain_status?: string | null
          employee_count?: number | null
          enriched_at?: string | null
          enrichment_source?: string | null
          enrichment_status?: string
          facebook_url?: string | null
          founded_year?: number | null
          funding_status?: string | null
          glassdoor_rating?: number | null
          id?: string
          industries?: string[] | null
          industry?: string | null
          keywords?: string[] | null
          languages?: string[] | null
          latest_funding_round_date?: string | null
          latest_funding_stage?: string | null
          linkedin_url?: string | null
          logo_url?: string | null
          name?: string
          num_suborganizations?: number | null
          phone?: string | null
          postal_code?: string | null
          publicly_traded_exchange?: string | null
          publicly_traded_symbol?: string | null
          quality_enriched_at?: string | null
          quality_signals?: Json | null
          recent_news?: string[] | null
          retail_location_count?: number | null
          seo_description?: string | null
          short_description?: string | null
          state?: string | null
          street_address?: string | null
          technology_names?: string[] | null
          total_funding?: number | null
          total_funding_printed?: string | null
          twitter_url?: string | null
          updated_at?: string
          website_url?: string | null
        }
        Relationships: []
      }
      company_domain_aliases: {
        Row: {
          company_name_alias: string
          confidence: number
          created_at: string
          domain: string
          id: string
          locked: boolean
        }
        Insert: {
          company_name_alias: string
          confidence?: number
          created_at?: string
          domain: string
          id?: string
          locked?: boolean
        }
        Update: {
          company_name_alias?: string
          confidence?: number
          created_at?: string
          domain?: string
          id?: string
          locked?: boolean
        }
        Relationships: []
      }
      company_email_intel: {
        Row: {
          company_id: string
          created_at: string
          domain: string | null
          examples: Json | null
          mx_valid: boolean | null
          pattern: string | null
          pattern_confidence: number | null
          sources: Json | null
          updated_at: string
        }
        Insert: {
          company_id: string
          created_at?: string
          domain?: string | null
          examples?: Json | null
          mx_valid?: boolean | null
          pattern?: string | null
          pattern_confidence?: number | null
          sources?: Json | null
          updated_at?: string
        }
        Update: {
          company_id?: string
          created_at?: string
          domain?: string | null
          examples?: Json | null
          mx_valid?: boolean | null
          pattern?: string | null
          pattern_confidence?: number | null
          sources?: Json | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_email_intel_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      custom_field_definitions: {
        Row: {
          created_at: string
          created_by: string | null
          display_order: number
          field_label: string
          field_name: string
          field_options: Json | null
          field_type: string
          id: string
          is_required: boolean
          module: string
          show_in_detail: boolean
          show_in_list: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          display_order?: number
          field_label: string
          field_name: string
          field_options?: Json | null
          field_type: string
          id?: string
          is_required?: boolean
          module: string
          show_in_detail?: boolean
          show_in_list?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          display_order?: number
          field_label?: string
          field_name?: string
          field_options?: Json | null
          field_type?: string
          id?: string
          is_required?: boolean
          module?: string
          show_in_detail?: boolean
          show_in_list?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      custom_field_values: {
        Row: {
          created_at: string
          created_by: string | null
          entity_id: string
          field_definition_id: string
          id: string
          updated_at: string
          value: Json
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          entity_id: string
          field_definition_id: string
          id?: string
          updated_at?: string
          value?: Json
        }
        Update: {
          created_at?: string
          created_by?: string | null
          entity_id?: string
          field_definition_id?: string
          id?: string
          updated_at?: string
          value?: Json
        }
        Relationships: [
          {
            foreignKeyName: "custom_field_values_field_definition_id_fkey"
            columns: ["field_definition_id"]
            isOneToOne: false
            referencedRelation: "custom_field_definitions"
            referencedColumns: ["id"]
          },
        ]
      }
      deleted_records: {
        Row: {
          created_at: string
          deleted_at: string
          deleted_by: string
          entity_data: Json
          entity_id: string
          entity_type: string
          expires_at: string
          id: string
        }
        Insert: {
          created_at?: string
          deleted_at?: string
          deleted_by: string
          entity_data: Json
          entity_id: string
          entity_type: string
          expires_at?: string
          id?: string
        }
        Update: {
          created_at?: string
          deleted_at?: string
          deleted_by?: string
          entity_data?: Json
          entity_id?: string
          entity_type?: string
          expires_at?: string
          id?: string
        }
        Relationships: []
      }
      email_attachments: {
        Row: {
          content_type: string | null
          created_at: string
          email_id: string
          filename: string
          id: string
          size_bytes: number | null
          storage_path: string | null
        }
        Insert: {
          content_type?: string | null
          created_at?: string
          email_id: string
          filename: string
          id?: string
          size_bytes?: number | null
          storage_path?: string | null
        }
        Update: {
          content_type?: string | null
          created_at?: string
          email_id?: string
          filename?: string
          id?: string
          size_bytes?: number | null
          storage_path?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "email_attachments_email_id_fkey"
            columns: ["email_id"]
            isOneToOne: false
            referencedRelation: "emails"
            referencedColumns: ["id"]
          },
        ]
      }
      email_connections: {
        Row: {
          app_password: string | null
          connection_name: string
          created_at: string
          created_by: string | null
          email_address: string
          id: string
          imap_host: string
          imap_port: number
          is_active: boolean
          last_sync_at: string | null
          last_sync_status: string | null
          oauth_refresh_token: string | null
          sync_interval_minutes: number
          updated_at: string
          use_oauth: boolean
        }
        Insert: {
          app_password?: string | null
          connection_name: string
          created_at?: string
          created_by?: string | null
          email_address: string
          id?: string
          imap_host?: string
          imap_port?: number
          is_active?: boolean
          last_sync_at?: string | null
          last_sync_status?: string | null
          oauth_refresh_token?: string | null
          sync_interval_minutes?: number
          updated_at?: string
          use_oauth?: boolean
        }
        Update: {
          app_password?: string | null
          connection_name?: string
          created_at?: string
          created_by?: string | null
          email_address?: string
          id?: string
          imap_host?: string
          imap_port?: number
          is_active?: boolean
          last_sync_at?: string | null
          last_sync_status?: string | null
          oauth_refresh_token?: string | null
          sync_interval_minutes?: number
          updated_at?: string
          use_oauth?: boolean
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          body_html: string
          created_at: string
          created_by: string | null
          id: string
          include_cv_attachment: boolean
          include_unsubscribe_link: boolean
          name: string
          placeholders: Json | null
          role_variants: Json | null
          subject: string
          updated_at: string
        }
        Insert: {
          body_html: string
          created_at?: string
          created_by?: string | null
          id?: string
          include_cv_attachment?: boolean
          include_unsubscribe_link?: boolean
          name: string
          placeholders?: Json | null
          role_variants?: Json | null
          subject: string
          updated_at?: string
        }
        Update: {
          body_html?: string
          created_at?: string
          created_by?: string | null
          id?: string
          include_cv_attachment?: boolean
          include_unsubscribe_link?: boolean
          name?: string
          placeholders?: Json | null
          role_variants?: Json | null
          subject?: string
          updated_at?: string
        }
        Relationships: []
      }
      emails: {
        Row: {
          bcc_addresses: string[] | null
          body_html: string | null
          body_text: string | null
          cc_addresses: string[] | null
          company_id: string | null
          connection_id: string
          created_at: string
          folder: string
          from_address: string
          from_name: string | null
          has_attachments: boolean
          id: string
          is_read: boolean
          message_id: string
          received_at: string | null
          sent_at: string
          stakeholder_id: string | null
          subject: string | null
          to_addresses: string[]
          updated_at: string
        }
        Insert: {
          bcc_addresses?: string[] | null
          body_html?: string | null
          body_text?: string | null
          cc_addresses?: string[] | null
          company_id?: string | null
          connection_id: string
          created_at?: string
          folder: string
          from_address: string
          from_name?: string | null
          has_attachments?: boolean
          id?: string
          is_read?: boolean
          message_id: string
          received_at?: string | null
          sent_at: string
          stakeholder_id?: string | null
          subject?: string | null
          to_addresses?: string[]
          updated_at?: string
        }
        Update: {
          bcc_addresses?: string[] | null
          body_html?: string | null
          body_text?: string | null
          cc_addresses?: string[] | null
          company_id?: string | null
          connection_id?: string
          created_at?: string
          folder?: string
          from_address?: string
          from_name?: string | null
          has_attachments?: boolean
          id?: string
          is_read?: boolean
          message_id?: string
          received_at?: string | null
          sent_at?: string
          stakeholder_id?: string | null
          subject?: string | null
          to_addresses?: string[]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "emails_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "emails_connection_id_fkey"
            columns: ["connection_id"]
            isOneToOne: false
            referencedRelation: "email_connections"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "emails_stakeholder_id_fkey"
            columns: ["stakeholder_id"]
            isOneToOne: false
            referencedRelation: "stakeholders"
            referencedColumns: ["id"]
          },
        ]
      }
      field_ordering: {
        Row: {
          created_at: string
          display_order: number
          field_name: string
          id: string
          is_system_field: boolean
          module: string
          show_in_detail: boolean
          show_in_list: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          field_name: string
          id?: string
          is_system_field?: boolean
          module: string
          show_in_detail?: boolean
          show_in_list?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          field_name?: string
          id?: string
          is_system_field?: boolean
          module?: string
          show_in_detail?: boolean
          show_in_list?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      issues: {
        Row: {
          assigned_to: string | null
          category: string
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          module: string | null
          priority: string
          resolution_comment: string | null
          resolved_at: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          module?: string | null
          priority?: string
          resolution_comment?: string | null
          resolved_at?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          module?: string | null
          priority?: string
          resolution_comment?: string | null
          resolved_at?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      job_board_candidates: {
        Row: {
          candidate_id: string
          created_at: string
          created_by: string | null
          id: string
          job_board_id: string
        }
        Insert: {
          candidate_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          job_board_id: string
        }
        Update: {
          candidate_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          job_board_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_board_candidates_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_board_candidates_job_board_id_fkey"
            columns: ["job_board_id"]
            isOneToOne: false
            referencedRelation: "job_boards"
            referencedColumns: ["id"]
          },
        ]
      }
      job_board_jobs: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          job_board_id: string
          job_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          job_board_id: string
          job_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          job_board_id?: string
          job_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_board_jobs_job_board_id_fkey"
            columns: ["job_board_id"]
            isOneToOne: false
            referencedRelation: "job_boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_board_jobs_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      job_board_performance: {
        Row: {
          accepted_count: number | null
          avg_match_score: number | null
          candidate_id: string | null
          conversion_rate: number | null
          created_at: string
          high_score_count: number | null
          id: string
          job_board_id: string
          jobs_found: number
          jobs_matched: number
          jobs_saved: number
          search_date: string
          searches_performed: number
          success_rate: number | null
          updated_at: string
        }
        Insert: {
          accepted_count?: number | null
          avg_match_score?: number | null
          candidate_id?: string | null
          conversion_rate?: number | null
          created_at?: string
          high_score_count?: number | null
          id?: string
          job_board_id: string
          jobs_found?: number
          jobs_matched?: number
          jobs_saved?: number
          search_date?: string
          searches_performed?: number
          success_rate?: number | null
          updated_at?: string
        }
        Update: {
          accepted_count?: number | null
          avg_match_score?: number | null
          candidate_id?: string | null
          conversion_rate?: number | null
          created_at?: string
          high_score_count?: number | null
          id?: string
          job_board_id?: string
          jobs_found?: number
          jobs_matched?: number
          jobs_saved?: number
          search_date?: string
          searches_performed?: number
          success_rate?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_board_performance_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_board_performance_job_board_id_fkey"
            columns: ["job_board_id"]
            isOneToOne: false
            referencedRelation: "job_boards"
            referencedColumns: ["id"]
          },
        ]
      }
      job_boards: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean | null
          job_id_pattern: string | null
          last_successful_search: string | null
          lifetime_conversion_rate: number | null
          lifetime_success_rate: number | null
          max_employee_count: number | null
          min_content_length: number | null
          name: string
          performance_score: number | null
          role_tags: string[] | null
          search_url_template: string | null
          status: string
          target_countries: string[] | null
          template_verified: boolean
          total_jobs_found: number | null
          total_jobs_matched: number | null
          total_jobs_saved: number | null
          total_searches: number | null
          updated_at: string
          url: string
          url_allow_patterns: string[] | null
          url_deny_patterns: string[] | null
          url_pattern: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          job_id_pattern?: string | null
          last_successful_search?: string | null
          lifetime_conversion_rate?: number | null
          lifetime_success_rate?: number | null
          max_employee_count?: number | null
          min_content_length?: number | null
          name: string
          performance_score?: number | null
          role_tags?: string[] | null
          search_url_template?: string | null
          status?: string
          target_countries?: string[] | null
          template_verified?: boolean
          total_jobs_found?: number | null
          total_jobs_matched?: number | null
          total_jobs_saved?: number | null
          total_searches?: number | null
          updated_at?: string
          url: string
          url_allow_patterns?: string[] | null
          url_deny_patterns?: string[] | null
          url_pattern?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          job_id_pattern?: string | null
          last_successful_search?: string | null
          lifetime_conversion_rate?: number | null
          lifetime_success_rate?: number | null
          max_employee_count?: number | null
          min_content_length?: number | null
          name?: string
          performance_score?: number | null
          role_tags?: string[] | null
          search_url_template?: string | null
          status?: string
          target_countries?: string[] | null
          template_verified?: boolean
          total_jobs_found?: number | null
          total_jobs_matched?: number | null
          total_jobs_saved?: number | null
          total_searches?: number | null
          updated_at?: string
          url?: string
          url_allow_patterns?: string[] | null
          url_deny_patterns?: string[] | null
          url_pattern?: string | null
        }
        Relationships: []
      }
      jobs: {
        Row: {
          company_id: string | null
          created_at: string
          created_by: string | null
          description: string | null
          experience_level: string | null
          id: string
          job_type: string | null
          location: string | null
          posted_at: string | null
          requirements: string | null
          salary_range: string | null
          skills_required: string[] | null
          source_url: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          company_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          experience_level?: string | null
          id?: string
          job_type?: string | null
          location?: string | null
          posted_at?: string | null
          requirements?: string | null
          salary_range?: string | null
          skills_required?: string[] | null
          source_url?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          company_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          experience_level?: string | null
          id?: string
          job_type?: string | null
          location?: string | null
          posted_at?: string | null
          requirements?: string | null
          salary_range?: string | null
          skills_required?: string[] | null
          source_url?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "jobs_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      keyword_performance: {
        Row: {
          avg_match_score: number | null
          candidate_id: string
          created_at: string
          effectiveness_score: number | null
          id: string
          jobs_found: number
          keyword: string
          last_used_at: string | null
          matches_accepted: number
          matches_produced: number
          matches_rejected: number
          times_used: number
          updated_at: string
        }
        Insert: {
          avg_match_score?: number | null
          candidate_id: string
          created_at?: string
          effectiveness_score?: number | null
          id?: string
          jobs_found?: number
          keyword: string
          last_used_at?: string | null
          matches_accepted?: number
          matches_produced?: number
          matches_rejected?: number
          times_used?: number
          updated_at?: string
        }
        Update: {
          avg_match_score?: number | null
          candidate_id?: string
          created_at?: string
          effectiveness_score?: number | null
          id?: string
          jobs_found?: number
          keyword?: string
          last_used_at?: string | null
          matches_accepted?: number
          matches_produced?: number
          matches_rejected?: number
          times_used?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "keyword_performance_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
        ]
      }
      matches: {
        Row: {
          candidate_id: string
          created_at: string
          created_by: string | null
          id: string
          job_id: string
          match_reason: string | null
          match_score: number
          salary_benchmark: Json | null
          salary_percentile: number | null
          skills_matched: string[] | null
          skills_missing: string[] | null
          status: string
          updated_at: string
        }
        Insert: {
          candidate_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          job_id: string
          match_reason?: string | null
          match_score: number
          salary_benchmark?: Json | null
          salary_percentile?: number | null
          skills_matched?: string[] | null
          skills_missing?: string[] | null
          status?: string
          updated_at?: string
        }
        Update: {
          candidate_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          job_id?: string
          match_reason?: string | null
          match_score?: number
          salary_benchmark?: Json | null
          salary_percentile?: number | null
          skills_matched?: string[] | null
          skills_missing?: string[] | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "matches_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "matches_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      notes: {
        Row: {
          content: string
          created_at: string
          created_by: string | null
          entity_id: string
          entity_type: string
          id: string
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          created_by?: string | null
          entity_id: string
          entity_type: string
          id?: string
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string | null
          entity_id?: string
          entity_type?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      opt_out_records: {
        Row: {
          campaign_id: string | null
          created_at: string
          email_address: string
          id: string
          opt_out_reason: string | null
          opted_out_at: string
          stakeholder_id: string | null
        }
        Insert: {
          campaign_id?: string | null
          created_at?: string
          email_address: string
          id?: string
          opt_out_reason?: string | null
          opted_out_at?: string
          stakeholder_id?: string | null
        }
        Update: {
          campaign_id?: string | null
          created_at?: string
          email_address?: string
          id?: string
          opt_out_reason?: string | null
          opted_out_at?: string
          stakeholder_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "opt_out_records_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opt_out_records_stakeholder_id_fkey"
            columns: ["stakeholder_id"]
            isOneToOne: false
            referencedRelation: "stakeholders"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_events: {
        Row: {
          candidate_id: string
          created_at: string
          created_by: string
          event_type: string
          id: string
          message: string
        }
        Insert: {
          candidate_id: string
          created_at?: string
          created_by: string
          event_type?: string
          id?: string
          message: string
        }
        Update: {
          candidate_id?: string
          created_at?: string
          created_by?: string
          event_type?: string
          id?: string
          message?: string
        }
        Relationships: []
      }
      pipeline_pending_jobs: {
        Row: {
          candidate_id: string
          company_name: string | null
          created_at: string
          discovered_at: string
          id: string
          job_content: string | null
          job_title: string | null
          job_url: string
          location: string | null
          rejection_reason: string | null
          run_id: string
          score: number | null
          scored_at: string | null
          source_board: string | null
          source_query: string | null
          status: string
        }
        Insert: {
          candidate_id: string
          company_name?: string | null
          created_at?: string
          discovered_at?: string
          id?: string
          job_content?: string | null
          job_title?: string | null
          job_url: string
          location?: string | null
          rejection_reason?: string | null
          run_id: string
          score?: number | null
          scored_at?: string | null
          source_board?: string | null
          source_query?: string | null
          status?: string
        }
        Update: {
          candidate_id?: string
          company_name?: string | null
          created_at?: string
          discovered_at?: string
          id?: string
          job_content?: string | null
          job_title?: string | null
          job_url?: string
          location?: string | null
          rejection_reason?: string | null
          run_id?: string
          score?: number | null
          scored_at?: string | null
          source_board?: string | null
          source_query?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "pipeline_pending_jobs_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
        ]
      }
      pre_search_options: {
        Row: {
          created_at: string
          created_by: string | null
          display_order: number
          id: string
          is_default: boolean
          option_value: string
          question_key: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          display_order?: number
          id?: string
          is_default?: boolean
          option_value: string
          question_key: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          display_order?: number
          id?: string
          is_default?: boolean
          option_value?: string
          question_key?: string
          updated_at?: string
        }
        Relationships: []
      }
      pre_search_questions: {
        Row: {
          created_at: string
          created_by: string | null
          display_order: number | null
          id: string
          is_active: boolean | null
          options: Json | null
          question_label: string
          question_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          display_order?: number | null
          id?: string
          is_active?: boolean | null
          options?: Json | null
          question_label: string
          question_type?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          display_order?: number | null
          id?: string
          is_active?: boolean | null
          options?: Json | null
          question_label?: string
          question_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      role_module_permissions: {
        Row: {
          created_at: string
          has_access: boolean
          id: string
          module: string
          role: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          has_access?: boolean
          id?: string
          module: string
          role: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          has_access?: boolean
          id?: string
          module?: string
          role?: string
          updated_at?: string
        }
        Relationships: []
      }
      search_feedback: {
        Row: {
          avg_score: number | null
          best_score: number | null
          board_id: string | null
          board_name: string | null
          candidate_id: string
          created_at: string
          id: string
          jobs_discovered: number
          jobs_matched: number
          jobs_scored: number
          query_text: string
          updated_at: string
        }
        Insert: {
          avg_score?: number | null
          best_score?: number | null
          board_id?: string | null
          board_name?: string | null
          candidate_id: string
          created_at?: string
          id?: string
          jobs_discovered?: number
          jobs_matched?: number
          jobs_scored?: number
          query_text: string
          updated_at?: string
        }
        Update: {
          avg_score?: number | null
          best_score?: number | null
          board_id?: string | null
          board_name?: string | null
          candidate_id?: string
          created_at?: string
          id?: string
          jobs_discovered?: number
          jobs_matched?: number
          jobs_scored?: number
          query_text?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "search_feedback_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "job_boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "search_feedback_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
        ]
      }
      stakeholder_campaign_states: {
        Row: {
          blocked_reason_code: string | null
          blocked_reason_text: string | null
          campaign_id: string
          completed_at: string | null
          created_at: string
          current_step_order: number
          id: string
          last_action_at: string | null
          next_step_scheduled_at: string | null
          stakeholder_id: string
          started_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          blocked_reason_code?: string | null
          blocked_reason_text?: string | null
          campaign_id: string
          completed_at?: string | null
          created_at?: string
          current_step_order?: number
          id?: string
          last_action_at?: string | null
          next_step_scheduled_at?: string | null
          stakeholder_id: string
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          blocked_reason_code?: string | null
          blocked_reason_text?: string | null
          campaign_id?: string
          completed_at?: string | null
          created_at?: string
          current_step_order?: number
          id?: string
          last_action_at?: string | null
          next_step_scheduled_at?: string | null
          stakeholder_id?: string
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "stakeholder_campaign_states_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stakeholder_campaign_states_stakeholder_id_fkey"
            columns: ["stakeholder_id"]
            isOneToOne: false
            referencedRelation: "stakeholders"
            referencedColumns: ["id"]
          },
        ]
      }
      stakeholder_enrichment_attempts: {
        Row: {
          attempt_type: string
          company_id: string | null
          created_at: string
          error: string | null
          final_email: string | null
          final_email_status: string | null
          final_source: string | null
          finished_at: string | null
          id: string
          stakeholder_id: string
          started_at: string
          status: string
          trace: Json
        }
        Insert: {
          attempt_type?: string
          company_id?: string | null
          created_at?: string
          error?: string | null
          final_email?: string | null
          final_email_status?: string | null
          final_source?: string | null
          finished_at?: string | null
          id?: string
          stakeholder_id: string
          started_at?: string
          status?: string
          trace?: Json
        }
        Update: {
          attempt_type?: string
          company_id?: string | null
          created_at?: string
          error?: string | null
          final_email?: string | null
          final_email_status?: string | null
          final_source?: string | null
          finished_at?: string | null
          id?: string
          stakeholder_id?: string
          started_at?: string
          status?: string
          trace?: Json
        }
        Relationships: [
          {
            foreignKeyName: "stakeholder_enrichment_attempts_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stakeholder_enrichment_attempts_stakeholder_id_fkey"
            columns: ["stakeholder_id"]
            isOneToOne: false
            referencedRelation: "stakeholders"
            referencedColumns: ["id"]
          },
        ]
      }
      stakeholder_targeting_rules: {
        Row: {
          created_at: string
          created_by: string | null
          display_order: number
          id: string
          max_employees: number | null
          min_employees: number
          target_titles: string[]
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          display_order?: number
          id?: string
          max_employees?: number | null
          min_employees?: number
          target_titles?: string[]
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          display_order?: number
          id?: string
          max_employees?: number | null
          min_employees?: number
          target_titles?: string[]
          updated_at?: string
        }
        Relationships: []
      }
      stakeholders: {
        Row: {
          bettercontact_data: Json | null
          bettercontact_last_polled_at: string | null
          bettercontact_status: string | null
          bettercontact_submitted_at: string | null
          bettercontact_task_id: string | null
          company_id: string | null
          contacted: boolean
          created_at: string
          created_by: string | null
          email: string | null
          email_confidence: number | null
          email_provider: string | null
          email_status: string | null
          enriched_at: string | null
          enrichment_source: string | null
          gender: string | null
          id: string
          job_board_id: string | null
          linkedin_url: string | null
          location: string | null
          name: string
          notes: string | null
          phone: string | null
          source: string | null
          title: string | null
          updated_at: string
        }
        Insert: {
          bettercontact_data?: Json | null
          bettercontact_last_polled_at?: string | null
          bettercontact_status?: string | null
          bettercontact_submitted_at?: string | null
          bettercontact_task_id?: string | null
          company_id?: string | null
          contacted?: boolean
          created_at?: string
          created_by?: string | null
          email?: string | null
          email_confidence?: number | null
          email_provider?: string | null
          email_status?: string | null
          enriched_at?: string | null
          enrichment_source?: string | null
          gender?: string | null
          id?: string
          job_board_id?: string | null
          linkedin_url?: string | null
          location?: string | null
          name: string
          notes?: string | null
          phone?: string | null
          source?: string | null
          title?: string | null
          updated_at?: string
        }
        Update: {
          bettercontact_data?: Json | null
          bettercontact_last_polled_at?: string | null
          bettercontact_status?: string | null
          bettercontact_submitted_at?: string | null
          bettercontact_task_id?: string | null
          company_id?: string | null
          contacted?: boolean
          created_at?: string
          created_by?: string | null
          email?: string | null
          email_confidence?: number | null
          email_provider?: string | null
          email_status?: string | null
          enriched_at?: string | null
          enrichment_source?: string | null
          gender?: string | null
          id?: string
          job_board_id?: string | null
          linkedin_url?: string | null
          location?: string | null
          name?: string
          notes?: string | null
          phone?: string | null
          source?: string | null
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "stakeholders_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stakeholders_job_board_id_fkey"
            columns: ["job_board_id"]
            isOneToOne: false
            referencedRelation: "job_boards"
            referencedColumns: ["id"]
          },
        ]
      }
      system_alerts: {
        Row: {
          alert_type: string
          created_at: string
          id: string
          message: string
          metric_name: string | null
          metric_value: number | null
          resolved: boolean
          resolved_at: string | null
          severity: string
          threshold: number | null
        }
        Insert: {
          alert_type: string
          created_at?: string
          id?: string
          message: string
          metric_name?: string | null
          metric_value?: number | null
          resolved?: boolean
          resolved_at?: string | null
          severity?: string
          threshold?: number | null
        }
        Update: {
          alert_type?: string
          created_at?: string
          id?: string
          message?: string
          metric_name?: string | null
          metric_value?: number | null
          resolved?: boolean
          resolved_at?: string | null
          severity?: string
          threshold?: number | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_enrichment_drift: { Args: never; Returns: undefined }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role:
        | {
            Args: {
              _role: Database["public"]["Enums"]["app_role"]
              _user_id: string
            }
            Returns: boolean
          }
        | {
            Args: {
              _role: Database["public"]["Enums"]["app_role"]
              _user_id: string
            }
            Returns: boolean
          }
      purge_expired_deleted_records: { Args: never; Returns: number }
      update_job_board_lifetime_stats: {
        Args: { board_id: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "recruiter" | "viewer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "recruiter", "viewer"],
    },
  },
} as const
