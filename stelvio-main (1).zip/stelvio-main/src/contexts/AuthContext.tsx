import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';


export type AppRole = 'admin' | 'recruiter' | 'viewer';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  role: AppRole | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, fullName?: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  hasRole: (requiredRole: AppRole) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Prevent a race where `getSession()` resolves with `null` after an auth event
  // has already provided a valid session, which can cause rapid route bouncing.
  const hasSeenAuthEventRef = useRef(false);

  const fetchUserRole = async (userId: string) => {
    try {
      // Use a SECURITY DEFINER DB function to avoid RLS/recursion issues and
      // to prevent `.single()` failures if a user ever ends up with multiple roles.
      const { data, error } = await supabase.rpc('get_user_role', {
        _user_id: userId,
      });

      if (error) {
        console.error('Error fetching user role (rpc get_user_role):', error);
        return null;
      }

      return (data as AppRole) ?? null;
    } catch (error) {
      console.error('Error fetching user role:', error);
      return null;
    }
  };

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        hasSeenAuthEventRef.current = true;
        setSession(session);
        setUser(session?.user ?? null);

        // Keep the auth gate stable: if we have a user, wait for role then drop loading.
        if (session?.user) {
          setIsLoading(true);
          setTimeout(() => {
            fetchUserRole(session.user.id).then((userRole) => {
              setRole(userRole);
              setIsLoading(false);
            });
          }, 0);
        } else {
          setRole(null);
          setIsLoading(false);
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session: initialSession } }) => {
      // If an auth event already fired (SIGNED_IN/TOKEN_REFRESHED/etc) and we currently
      // have a session, do NOT allow a late `null` here to wipe it out.
      if (hasSeenAuthEventRef.current && !initialSession) {
        setIsLoading(false);
        return;
      }

      setSession(initialSession);
      setUser(initialSession?.user ?? null);

      if (initialSession?.user) {
        fetchUserRole(initialSession.user.id).then((userRole) => {
          setRole(userRole);
          setIsLoading(false);
        });
      } else {
        setIsLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { error };
  };

  const signUp = async (email: string, password: string, fullName?: string) => {
    const redirectUrl = `${window.location.origin}/`;

    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          full_name: fullName,
        },
      },
    });
    return { error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setRole(null);
  };

  /**
   * Client-side role check - USE FOR UI/UX PURPOSES ONLY!
   * 
   * ⚠️ SECURITY WARNING: This check is NOT sufficient for security.
   * Always enforce authorization server-side via:
   * - Row Level Security (RLS) policies on database tables
   * - Role checks in Edge Functions (already implemented)
   * - JWT verification in config.toml (verify_jwt = true)
   * 
   * This function should only be used to:
   * - Show/hide UI elements for better user experience
   * - Prevent unnecessary API calls to protected endpoints
   * - Display role-appropriate navigation menus
   * 
   * NEVER rely on this for security-critical decisions.
   * Client-side role state can be manipulated via browser DevTools,
   * but database access will still be blocked by RLS policies.
   */
  const hasRole = (requiredRole: AppRole): boolean => {
    if (!role) return false;
    
    // Role hierarchy: admin > recruiter > viewer
    const roleHierarchy: Record<AppRole, number> = {
      admin: 3,
      recruiter: 2,
      viewer: 1,
    };

    return roleHierarchy[role] >= roleHierarchy[requiredRole];
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        role,
        isLoading,
        signIn,
        signUp,
        signOut,
        hasRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
