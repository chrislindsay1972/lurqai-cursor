import DOMPurify from 'dompurify';

/**
 * Sanitizes HTML content to prevent XSS attacks.
 * Safe for rendering email content and user-generated HTML.
 */
export function sanitizeEmailHtml(html: string): string {
  return DOMPurify.sanitize(html, {
    // Allow common email HTML tags
    ALLOWED_TAGS: [
      'p', 'br', 'strong', 'b', 'em', 'i', 'u', 's', 'a', 'img', 'div', 'span',
      'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
      'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption', 'colgroup', 'col',
      'blockquote', 'pre', 'code', 'hr', 'center', 'font', 'sub', 'sup',
    ],
    // Allow safe attributes
    ALLOWED_ATTR: [
      'href', 'src', 'alt', 'title', 'width', 'height', 'style', 'class', 'id',
      'target', 'rel', 'colspan', 'rowspan', 'align', 'valign', 'bgcolor', 'border',
      'cellpadding', 'cellspacing', 'color', 'face', 'size',
    ],
    // Only allow safe URI schemes
    ALLOWED_URI_REGEXP: /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
    // Disable data attributes
    ALLOW_DATA_ATTR: false,
    // Ensure body context
    FORCE_BODY: true,
    // Enable DOM sanitization
    SANITIZE_DOM: true,
    // Explicitly forbid dangerous tags
    FORBID_TAGS: ['script', 'iframe', 'object', 'embed', 'link', 'meta', 'base', 'form', 'input', 'button', 'select', 'textarea'],
    // Forbid all event handlers
    FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'onmouseout', 'onmouseenter', 'onmouseleave', 'onfocus', 'onblur', 'onsubmit', 'onreset', 'onchange', 'oninput', 'onkeydown', 'onkeyup', 'onkeypress'],
  });
}

/**
 * Sanitizes signature HTML (typically more trusted but still sanitized for safety)
 */
export function sanitizeSignatureHtml(html: string): string {
  // Signature preview HTML is rendered inside an existing <div> via dangerouslySetInnerHTML.
  // Using FORCE_BODY here can inject <body> tags into the fragment, which can break layout
  // (tables/images shifting or disappearing). For signature previews we sanitize as a fragment.
  return DOMPurify.sanitize(html, {
    // Start from the email allowlist...
    ALLOWED_TAGS: [
      'p', 'br', 'strong', 'b', 'em', 'i', 'u', 's', 'a', 'img', 'div', 'span',
      'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
      'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption', 'colgroup', 'col',
      'blockquote', 'pre', 'code', 'hr', 'center', 'font', 'sub', 'sup',

      // ...and additionally allow the small inline SVG icons used in signature previews.
      'svg', 'g', 'path', 'circle', 'rect', 'line', 'polyline', 'polygon',
    ],
    ALLOWED_ATTR: [
      'href', 'src', 'alt', 'title', 'width', 'height', 'style', 'class', 'id',
      'target', 'rel', 'colspan', 'rowspan', 'align', 'valign', 'bgcolor', 'border',
      'cellpadding', 'cellspacing', 'color', 'face', 'size',

      // SVG presentation + geometry attributes
      'xmlns', 'viewBox', 'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin',
      'd', 'cx', 'cy', 'r', 'x', 'y', 'rx', 'ry', 'points', 'transform',
    ],
    ALLOWED_URI_REGEXP: /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
    ALLOW_DATA_ATTR: false,

    // IMPORTANT: sanitize as a fragment (no <body> injection)
    FORCE_BODY: false,
    SANITIZE_DOM: true,
    FORBID_TAGS: [
      'script', 'iframe', 'object', 'embed', 'link', 'meta', 'base',
      'form', 'input', 'button', 'select', 'textarea',

      // Avoid advanced SVG vectors that can increase attack surface
      'foreignObject',
    ],
    FORBID_ATTR: [
      'onerror', 'onload', 'onclick', 'onmouseover', 'onmouseout', 'onmouseenter', 'onmouseleave',
      'onfocus', 'onblur', 'onsubmit', 'onreset', 'onchange', 'oninput', 'onkeydown', 'onkeyup',
      'onkeypress',
    ],
  });
}
