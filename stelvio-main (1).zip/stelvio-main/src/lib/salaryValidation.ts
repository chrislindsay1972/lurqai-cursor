/**
 * Guard against salary values that are actually dates, truncated hourly rates,
 * nonsensical ranges, or other junk scraped from job boards.
 */
export function isValidSalaryDisplay(value: string | null | undefined): boolean {
  if (!value || value.trim().length < 3) return false;
  const v = value.trim();

  // Reject ISO dates, MM/DD/YYYY, YYYY-MM, month names at start, "not specified"
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  if (/^\d{4}-\d{4}$/.test(v)) return false;
  if (/^\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}$/.test(v)) return false;
  if (/^\d{4}[\/\-]\d{1,2}$/.test(v)) return false;
  if (/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i.test(v)) return false;
  if (/not\s+specified/i.test(v)) return false;

  // Must contain a currency symbol or 'k' with a number, or a numeric range, or rate keyword
  const hasCurrency = /[\$£€¥]\s*\d/i.test(v);
  const hasKSuffix = /\d+\s*k/i.test(v);
  const hasNumericRange = /\d+\s*[-–—]\s*\d+/i.test(v);
  const hasRateKeyword = /\d+.*(?:per\s*(?:hour|annum|year|month)|\/\s*(?:hr|hour|yr|year)|p\.?a\.?|ote|annually)/i.test(v);
  if (!hasCurrency && !hasKSuffix && !hasNumericRange && !hasRateKeyword) return false;

  // Extract all numbers from the string to validate magnitudes
  const allNumbers = v.match(/\d[\d,]*\.?\d*/g)?.map(n => parseFloat(n.replace(/,/g, ''))) ?? [];

  // Reject if the largest number is below 1,000 and there's no explicit hourly/rate context
  const maxNum = Math.max(...allNumbers, 0);
  const hasHourlyContext = /per\s*hour|\/\s*h(?:ou)?r|hourly/i.test(v);
  if (maxNum < 1000 && !hasHourlyContext) return false;

  // Reject if max exceeds $2,000,000 (likely junk)
  if (maxNum > 2_000_000) return false;

  // Reject ranges where min-max ratio is absurdly wide (> 10x)
  if (hasNumericRange && allNumbers.length >= 2) {
    const sorted = [...allNumbers].sort((a, b) => a - b);
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    if (min > 0 && max / min > 10) return false;
  }

  // Reject bare currency amounts under $1,000 without range or rate context
  if (hasCurrency && !hasNumericRange && !hasKSuffix && !hasRateKeyword && !hasHourlyContext) {
    const numMatch = v.match(/[\$£€¥]\s*(\d+(?:,\d{3})*(?:\.\d+)?)/);
    if (numMatch) {
      const amount = parseFloat(numMatch[1].replace(/,/g, ''));
      if (amount < 1000) return false;
    }
  }

  return true;
}
