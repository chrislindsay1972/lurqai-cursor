// Centralized theme helpers (used by Settings > Theme Customizer and app bootstrap)

export type ThemeColors = {
  fontColor: string; // hex
  backgroundColor: string; // hex
  ctaButtonColor: string; // hex
};

const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n));

const hexToRgb = (hex: string) => {
  const raw = hex.replace("#", "").trim();
  const normalized = raw.length === 3 ? raw.split("").map((c) => c + c).join("") : raw;
  const int = Number.parseInt(normalized, 16);
  return {
    r: (int >> 16) & 255,
    g: (int >> 8) & 255,
    b: int & 255,
  };
};

// Returns HSL triplet string compatible with shadcn tokens, e.g. "67 95% 57%"
export const hexToHslTriplet = (hex: string) => {
  const { r, g, b } = hexToRgb(hex);
  const rN = r / 255;
  const gN = g / 255;
  const bN = b / 255;

  const max = Math.max(rN, gN, bN);
  const min = Math.min(rN, gN, bN);
  const delta = max - min;

  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (delta !== 0) {
    s = delta / (1 - Math.abs(2 * l - 1));

    switch (max) {
      case rN:
        h = ((gN - bN) / delta) % 6;
        break;
      case gN:
        h = (bN - rN) / delta + 2;
        break;
      default:
        h = (rN - gN) / delta + 4;
        break;
    }

    h = h * 60;
    if (h < 0) h += 360;
  }

  const hRounded = Math.round(h);
  const sRounded = Math.round(clamp(s * 100, 0, 100));
  const lRounded = Math.round(clamp(l * 100, 0, 100));

  return `${hRounded} ${sRounded}% ${lRounded}%`;
};

// Simple relative luminance check to pick readable black/white text.
const getContrastForegroundTriplet = (hex: string) => {
  const { r, g, b } = hexToRgb(hex);
  // YIQ perceived brightness
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;
  return yiq >= 140 ? "0 0% 0%" : "0 0% 100%";
};

export const applyThemeToDocument = (theme: ThemeColors) => {
  const root = document.documentElement;

  // Background color triplet (for cards, accent areas)
  const bgTriplet = hexToHslTriplet(theme.backgroundColor);
  // Font color triplet (for text on those backgrounds)
  const fontTriplet = hexToHslTriplet(theme.fontColor);
  // CTA color triplet
  const ctaTriplet = hexToHslTriplet(theme.ctaButtonColor);
  const ctaForeground = getContrastForegroundTriplet(theme.ctaButtonColor);

  // Map theme colors into the design system tokens used across the app.
  // Card surfaces (TopMatches, RecentActivity, Pipeline, etc.)
  root.style.setProperty("--card", bgTriplet);
  root.style.setProperty("--card-foreground", fontTriplet);

  // Accent (stat-card, badges, highlights)
  root.style.setProperty("--accent", bgTriplet);
  root.style.setProperty("--accent-foreground", fontTriplet);

  // Primary (CTA buttons)
  root.style.setProperty("--primary", ctaTriplet);
  root.style.setProperty("--primary-foreground", ctaForeground);

  // Ring (focus outlines)
  root.style.setProperty("--ring", ctaTriplet);

  // Backwards-compat (in case any legacy CSS still references these)
  root.style.setProperty("--theme-font-color", theme.fontColor);
  root.style.setProperty("--theme-bg-color", theme.backgroundColor);
  root.style.setProperty("--theme-cta-color", theme.ctaButtonColor);
};

export const loadSavedTheme = (): ThemeColors | null => {
  const saved = localStorage.getItem("stelvio-theme");
  if (!saved) return null;
  try {
    return JSON.parse(saved) as ThemeColors;
  } catch {
    return null;
  }
};

export const applySavedTheme = () => {
  const theme = loadSavedTheme();
  if (theme) applyThemeToDocument(theme);
};
