import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  Briefcase,
  Building2,
  UserCheck,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Trash2,
  UsersRound,
  ClipboardList,
  Megaphone,
  Workflow,
  BarChart2,
  Wrench,
  Stethoscope,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { LurqLogo } from "@/components/LurqLogo";
import { useAuth } from "@/contexts/AuthContext";
import { useIsMobile } from "@/hooks/use-mobile";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: Users, label: "Candidates", path: "/candidates" },
  { icon: Briefcase, label: "Job Vacancies", path: "/jobs" },
  { icon: Building2, label: "Companies", path: "/companies" },
  { icon: UserCheck, label: "Stakeholders", path: "/stakeholders" },
  { icon: Megaphone, label: "Campaigns", path: "/campaigns" },
  { icon: Workflow, label: "Pipeline", path: "/pipeline" },
  { icon: BarChart2, label: "Pipeline Analytics", path: "/pipeline-analytics" },
  { icon: Stethoscope, label: "Diagnostics", path: "/pipeline-diagnostics" },
  { icon: Wrench, label: "Enrichment", path: "/enrichment/inbox" },
];

const bottomNavItems = [
  { icon: ClipboardList, label: "Issue Log", path: "/issues" },
  { icon: Trash2, label: "Recycle Bin", path: "/recycle-bin" },
  { icon: UsersRound, label: "Users", path: "/users", adminOnly: true },
  { icon: Settings, label: "Settings", path: "/settings" }, // Accessible to all authenticated users
];

export function Sidebar() {
  const isMobile = useIsMobile();
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const { role } = useAuth();

  // Auto-collapse on mobile
  useEffect(() => {
    setCollapsed(isMobile);
  }, [isMobile]);
  const isAdmin = role === "admin";

  return (
    <aside
      className={cn(
        "sidebar-gradient h-screen flex flex-col transition-all duration-300 ease-in-out border-r border-sidebar-border",
        collapsed ? "w-[72px]" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="p-4 flex items-center gap-3 border-b border-sidebar-border">
        <LurqLogo 
          showText={!collapsed} 
          size="md"
          className="text-accent"
          textClassName="text-accent"
        />
        {!collapsed && (
          <p className="text-xs text-sidebar-foreground/60 -mt-3 ml-auto">Portal</p>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = item.path === "/" ? location.pathname === "/" : location.pathname.startsWith(item.path);
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group",
                isActive
                  ? "bg-accent text-primary font-semibold"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-accent"
              )}
            >
              <item.icon
                className={cn(
                  "w-5 h-5 flex-shrink-0 transition-colors",
                  isActive ? "text-primary" : "group-hover:text-accent"
                )}
              />
              {!collapsed && (
                <span className="text-sm animate-fade-in">{item.label}</span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Bottom Navigation */}
      <div className="p-3 space-y-1 border-t border-sidebar-border">
        {bottomNavItems
          .filter((item) => !item.adminOnly || isAdmin)
          .map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group",
                  isActive
                    ? "bg-accent text-primary font-semibold"
                    : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-accent"
                )}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {!collapsed && (
                  <span className="text-sm">{item.label}</span>
                )}
              </Link>
            );
          })}

        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sidebar-foreground hover:bg-destructive/20 hover:text-destructive transition-all duration-200 group">
          <LogOut className="w-5 h-5 flex-shrink-0" />
          {!collapsed && <span className="text-sm">Sign Out</span>}
        </button>
      </div>

      {/* Collapse Toggle */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setCollapsed(!collapsed)}
        className="absolute top-1/2 -right-3 w-6 h-6 p-0 rounded-full bg-accent border-0 shadow-md hover:bg-accent/80 text-primary"
      >
        {collapsed ? (
          <ChevronRight className="w-3 h-3" />
        ) : (
          <ChevronLeft className="w-3 h-3" />
        )}
      </Button>
    </aside>
  );
}