import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Target, Loader2, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export function TargetMatchesSetting() {
  const [targetMatches, setTargetMatches] = useState<number>(20);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchSetting();
  }, []);

  const fetchSetting = async () => {
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'target_matches')
        .maybeSingle();

      if (error) throw error;
      
      if (data?.setting_value) {
        setTargetMatches(parseInt(data.setting_value, 10));
      }
    } catch (error) {
      console.error('Error fetching target matches setting:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveSetting = async () => {
    setIsSaving(true);
    try {
      // Upsert the setting
      const { error } = await supabase
        .from('app_settings')
        .upsert(
          {
            setting_key: 'target_matches',
            setting_value: targetMatches.toString(),
            setting_type: 'number',
            description: 'Target number of job matches to find per pipeline run',
          },
          { onConflict: 'setting_key' }
        );

      if (error) throw error;

      toast({
        title: "Setting Saved",
        description: `Target matches set to ${targetMatches}`,
      });
      setHasChanges(false);
    } catch (error) {
      console.error('Error saving target matches setting:', error);
      toast({
        title: "Error",
        description: "Failed to save setting",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleChange = (value: string) => {
    const num = parseInt(value, 10);
    if (!isNaN(num) && num >= 1 && num <= 100) {
      setTargetMatches(num);
      setHasChanges(true);
    } else if (value === '') {
      setTargetMatches(1);
      setHasChanges(true);
    }
  };

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-border/50">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-foreground" />
          <CardTitle className="font-display text-foreground">Target Matches</CardTitle>
        </div>
        <CardDescription className="text-muted-foreground">
          Set the minimum number of job matches to find per search run. The pipeline will continue searching until this target is met or all boards are exhausted.
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="space-y-2 flex-1 max-w-xs">
                <Label htmlFor="target-matches" className="text-sm font-medium text-foreground">
                  Number of matches (1-100)
                </Label>
                <Input
                  id="target-matches"
                  type="number"
                  min={1}
                  max={100}
                  value={targetMatches}
                  onChange={(e) => handleChange(e.target.value)}
                  className="w-40 bg-background text-foreground border-border"
                />
              </div>
            </div>

            <div className="bg-muted/30 rounded-lg p-4 text-sm text-foreground">
              <p>
                <strong>How it works:</strong> The search will continue until{" "}
                <span className="font-semibold">{targetMatches}</span> matching jobs are found
                or all job boards have been searched.
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                Higher values mean longer search times but more job options for candidates.
              </p>
            </div>

            <Button
              onClick={saveSetting}
              disabled={isSaving || !hasChanges}
              className="accent-gradient border-0"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : hasChanges ? (
                "Save Changes"
              ) : (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Saved
                </>
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
