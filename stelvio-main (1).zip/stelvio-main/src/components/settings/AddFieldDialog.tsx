import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { ModuleType, FieldType, useCreateCustomField } from "@/hooks/useCustomFields";
import { X, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const FIELD_TYPES: { value: FieldType; label: string; description: string }[] = [
  { value: 'text', label: 'Text', description: 'Single line text input' },
  { value: 'textarea', label: 'Text Area', description: 'Multi-line text input' },
  { value: 'number', label: 'Number', description: 'Numeric input' },
  { value: 'date', label: 'Date', description: 'Date picker' },
  { value: 'select', label: 'Dropdown', description: 'Single selection from options' },
  { value: 'checkbox', label: 'Checkbox', description: 'True/false toggle' },
  { value: 'multi_select', label: 'Multi-Select', description: 'Multiple selections from options' },
];

const formSchema = z.object({
  field_label: z.string().min(1, "Label is required").max(100),
  field_name: z.string().min(1, "Field name is required").max(50).regex(/^[a-z][a-z0-9_]*$/, "Must start with letter, only lowercase letters, numbers, underscores"),
  field_type: z.enum(['text', 'textarea', 'number', 'date', 'select', 'checkbox', 'multi_select']),
  is_required: z.boolean(),
  show_in_list: z.boolean(),
  show_in_detail: z.boolean(),
});

type FormValues = z.infer<typeof formSchema>;

interface AddFieldDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  module: ModuleType;
  existingFieldCount: number;
}

export function AddFieldDialog({ open, onOpenChange, module, existingFieldCount }: AddFieldDialogProps) {
  const [options, setOptions] = useState<string[]>([]);
  const [newOption, setNewOption] = useState("");
  
  const createField = useCreateCustomField();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      field_label: "",
      field_name: "",
      field_type: "text",
      is_required: false,
      show_in_list: false,
      show_in_detail: true,
    },
  });
  
  const fieldType = form.watch("field_type");
  const needsOptions = fieldType === 'select' || fieldType === 'multi_select';
  
  const handleLabelChange = (label: string) => {
    form.setValue("field_label", label);
    // Auto-generate field name from label
    const fieldName = label
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, '_')
      .replace(/^[0-9]/, 'f$&');
    form.setValue("field_name", fieldName);
  };
  
  const addOption = () => {
    if (newOption.trim() && !options.includes(newOption.trim())) {
      setOptions([...options, newOption.trim()]);
      setNewOption("");
    }
  };
  
  const removeOption = (option: string) => {
    setOptions(options.filter(o => o !== option));
  };
  
  const onSubmit = (values: FormValues) => {
    createField.mutate({
      module,
      field_name: values.field_name,
      field_label: values.field_label,
      field_type: values.field_type,
      field_options: needsOptions ? options : null,
      is_required: values.is_required,
      display_order: existingFieldCount,
      show_in_list: values.show_in_list,
      show_in_detail: values.show_in_detail,
    }, {
      onSuccess: () => {
        form.reset();
        setOptions([]);
        onOpenChange(false);
      },
    });
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Custom Field</DialogTitle>
          <DialogDescription>
            Create a new custom field for the {module.replace('_', ' ')} module.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="field_label"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Field Label</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g., LinkedIn Profile"
                      {...field}
                      onChange={(e) => handleLabelChange(e.target.value)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="field_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Field Name (Internal)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g., linkedin_profile"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Lowercase letters, numbers, and underscores only
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="field_type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Field Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a field type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {FIELD_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div>
                            <span className="font-medium">{type.label}</span>
                            <span className="text-muted-foreground ml-2 text-xs">
                              - {type.description}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {needsOptions && (
              <div className="space-y-2">
                <Label>Options</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add an option"
                    value={newOption}
                    onChange={(e) => setNewOption(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addOption();
                      }
                    }}
                  />
                  <Button type="button" variant="outline" size="icon" onClick={addOption}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {options.map((option) => (
                    <Badge key={option} variant="secondary" className="pr-1">
                      {option}
                      <button
                        type="button"
                        onClick={() => removeOption(option)}
                        className="ml-1 hover:bg-muted-foreground/20 rounded-full p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
                {options.length === 0 && (
                  <p className="text-xs text-muted-foreground">
                    Add at least one option for this field
                  </p>
                )}
              </div>
            )}
            
            <div className="grid grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="is_required"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-2 space-y-0">
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <FormLabel className="font-normal">Required</FormLabel>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="show_in_list"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-2 space-y-0">
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <FormLabel className="font-normal">Show in List</FormLabel>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="show_in_detail"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-2 space-y-0">
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <FormLabel className="font-normal">Show in Detail</FormLabel>
                  </FormItem>
                )}
              />
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createField.isPending || (needsOptions && options.length === 0)}
              >
                {createField.isPending ? "Creating..." : "Create Field"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
