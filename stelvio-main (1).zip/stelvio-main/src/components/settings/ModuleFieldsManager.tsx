import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, GripVertical, Pencil, Trash2, Eye, EyeOff, List, FileText } from "lucide-react";
import {
  ModuleType,
  SYSTEM_FIELDS,
  useCustomFieldDefinitions,
  useFieldOrdering,
  useUpdateFieldOrdering,
  useDeleteCustomField,
  FieldOrdering,
} from "@/hooks/useCustomFields";
import { AddFieldDialog } from "./AddFieldDialog";
import { EditFieldDialog } from "./EditFieldDialog";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface CombinedField {
  id: string;
  name: string;
  label: string;
  type: string;
  isSystem: boolean;
  displayOrder: number;
  showInList: boolean;
  showInDetail: boolean;
  customFieldId?: string;
  fieldOptions?: string[] | null;
  isRequired?: boolean;
}

interface SortableFieldItemProps {
  field: CombinedField;
  onToggleList: (field: CombinedField) => void;
  onToggleDetail: (field: CombinedField) => void;
  onEdit?: (field: CombinedField) => void;
  onDelete?: (field: CombinedField) => void;
}

function SortableFieldItem({ field, onToggleList, onToggleDetail, onEdit, onDelete }: SortableFieldItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: field.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card hover:bg-muted/30 transition-colors"
    >
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground"
      >
        <GripVertical className="w-4 h-4" />
      </button>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium text-sm truncate">{field.label}</span>
          <Badge variant="outline" className="text-xs">
            {field.type}
          </Badge>
          {field.isSystem && (
            <Badge variant="secondary" className="text-xs">
              System
            </Badge>
          )}
          {field.isRequired && (
            <Badge className="text-xs bg-warning/10 text-warning border-0">
              Required
            </Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">
          Field name: {field.name}
        </p>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2" title="Show in list view">
          <List className="w-4 h-4 text-muted-foreground" />
          <Switch
            checked={field.showInList}
            onCheckedChange={() => onToggleList(field)}
          />
        </div>
        
        <div className="flex items-center gap-2" title="Show in detail view">
          <FileText className="w-4 h-4 text-muted-foreground" />
          <Switch
            checked={field.showInDetail}
            onCheckedChange={() => onToggleDetail(field)}
          />
        </div>
        
        {!field.isSystem && (
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => onEdit?.(field)}
            >
              <Pencil className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-destructive hover:text-destructive"
              onClick={() => onDelete?.(field)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

interface ModuleFieldsManagerProps {
  module: ModuleType;
}

export function ModuleFieldsManager({ module }: ModuleFieldsManagerProps) {
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editField, setEditField] = useState<CombinedField | null>(null);
  const [deleteField, setDeleteField] = useState<CombinedField | null>(null);
  
  const { data: customFields = [], isLoading: loadingCustom } = useCustomFieldDefinitions(module);
  const { data: fieldOrder = [], isLoading: loadingOrder } = useFieldOrdering(module);
  const updateOrdering = useUpdateFieldOrdering();
  const deleteCustomField = useDeleteCustomField();
  
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );
  
  // Combine system fields and custom fields with ordering
  const combinedFields = useMemo(() => {
    const systemFieldsForModule = SYSTEM_FIELDS[module] || [];
    const orderMap = new Map(fieldOrder.map(f => [f.field_name, f]));
    
    const allFields: CombinedField[] = [];
    
    // Add system fields
    systemFieldsForModule.forEach((sf, idx) => {
      const order = orderMap.get(sf.name);
      allFields.push({
        id: `system-${sf.name}`,
        name: sf.name,
        label: sf.label,
        type: sf.type,
        isSystem: true,
        displayOrder: order?.display_order ?? idx,
        showInList: order?.show_in_list ?? true,
        showInDetail: order?.show_in_detail ?? true,
      });
    });
    
    // Add custom fields
    customFields.forEach((cf) => {
      allFields.push({
        id: `custom-${cf.id}`,
        name: cf.field_name,
        label: cf.field_label,
        type: cf.field_type,
        isSystem: false,
        displayOrder: cf.display_order,
        showInList: cf.show_in_list,
        showInDetail: cf.show_in_detail,
        customFieldId: cf.id,
        fieldOptions: cf.field_options,
        isRequired: cf.is_required,
      });
    });
    
    // Sort by display order
    return allFields.sort((a, b) => a.displayOrder - b.displayOrder);
  }, [module, customFields, fieldOrder]);
  
  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      const oldIndex = combinedFields.findIndex(f => f.id === active.id);
      const newIndex = combinedFields.findIndex(f => f.id === over.id);
      
      const reordered = arrayMove(combinedFields, oldIndex, newIndex);
      
      // Build updates for field_ordering table (system fields) and custom_field_definitions
      const orderingUpdates: Partial<FieldOrdering>[] = [];
      
      reordered.forEach((field, idx) => {
        if (field.isSystem) {
          orderingUpdates.push({
            module,
            field_name: field.name,
            is_system_field: true,
            display_order: idx,
            show_in_list: field.showInList,
            show_in_detail: field.showInDetail,
          });
        }
      });
      
      if (orderingUpdates.length > 0) {
        updateOrdering.mutate(orderingUpdates);
      }
      
      // Update custom fields order individually
      reordered.forEach((field, idx) => {
        if (!field.isSystem && field.customFieldId) {
          // This will be handled by the update mutation
        }
      });
    }
  };
  
  const handleToggleList = (field: CombinedField) => {
    if (field.isSystem) {
      updateOrdering.mutate([{
        module,
        field_name: field.name,
        is_system_field: true,
        display_order: field.displayOrder,
        show_in_list: !field.showInList,
        show_in_detail: field.showInDetail,
      }]);
    }
  };
  
  const handleToggleDetail = (field: CombinedField) => {
    if (field.isSystem) {
      updateOrdering.mutate([{
        module,
        field_name: field.name,
        is_system_field: true,
        display_order: field.displayOrder,
        show_in_list: field.showInList,
        show_in_detail: !field.showInDetail,
      }]);
    }
  };
  
  const handleDeleteConfirm = () => {
    if (deleteField?.customFieldId) {
      deleteCustomField.mutate(deleteField.customFieldId);
    }
    setDeleteField(null);
  };
  
  if (loadingCustom || loadingOrder) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent" />
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-medium">Fields Configuration</h3>
          <p className="text-sm text-muted-foreground">
            Drag to reorder, toggle visibility for list and detail views
          </p>
        </div>
        <Button onClick={() => setAddDialogOpen(true)} size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Custom Field
        </Button>
      </div>
      
      <div className="space-y-2">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={combinedFields.map(f => f.id)}
            strategy={verticalListSortingStrategy}
          >
            {combinedFields.map((field) => (
              <SortableFieldItem
                key={field.id}
                field={field}
                onToggleList={handleToggleList}
                onToggleDetail={handleToggleDetail}
                onEdit={!field.isSystem ? setEditField : undefined}
                onDelete={!field.isSystem ? setDeleteField : undefined}
              />
            ))}
          </SortableContext>
        </DndContext>
      </div>
      
      <AddFieldDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        module={module}
        existingFieldCount={combinedFields.length}
      />
      
      {editField && (
        <EditFieldDialog
          open={!!editField}
          onOpenChange={() => setEditField(null)}
          field={editField}
          module={module}
        />
      )}
      
      <AlertDialog open={!!deleteField} onOpenChange={() => setDeleteField(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Custom Field</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deleteField?.label}"? This will also delete all values stored for this field across all records. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
