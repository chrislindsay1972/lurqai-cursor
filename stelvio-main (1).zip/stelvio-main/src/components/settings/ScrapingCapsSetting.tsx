import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Gauge, Save, RotateCcw, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const DEFAULTS = { perBoard: 40, global: 250 };

export function ScrapingCapsSetting() {
  const [perBoard, setPerBoard] = useState(DEFAULTS.perBoard);
  const [globalMax, setGlobalMax] = useState(DEFAULTS.global);
  const [origPerBoard, setOrigPerBoard] = useState(DEFAULTS.perBoard);
  const [origGlobal, setOrigGlobal] = useState(DEFAULTS.global);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => { fetchSettings(); }, []);

  const fetchSettings = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('setting_key, setting_value')
        .in('setting_key', ['per_board_max_urls', 'global_max_urls']);

      if (error) throw error;

      for (const row of data || []) {
        const val = parseInt(row.setting_value, 10);
        if (row.setting_key === 'per_board_max_urls') { setPerBoard(val); setOrigPerBoard(val); }
        if (row.setting_key === 'global_max_urls') { setGlobalMax(val); setOrigGlobal(val); }
      }
    } catch (err) {
      console.error('Error fetching scraping caps:', err);
      toast.error('Failed to load scraping cap settings');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const now = new Date().toISOString();
      const updates = [
        supabase.from('app_settings').update({ setting_value: perBoard.toString(), updated_at: now }).eq('setting_key', 'per_board_max_urls'),
        supabase.from('app_settings').update({ setting_value: globalMax.toString(), updated_at: now }).eq('setting_key', 'global_max_urls'),
      ];
      const results = await Promise.all(updates);
      const firstError = results.find(r => r.error);
      if (firstError?.error) throw firstError.error;

      setOrigPerBoard(perBoard);
      setOrigGlobal(globalMax);
      toast.success(`Scraping caps updated: ${perBoard}/board, ${globalMax}/run`);
    } catch (err) {
      console.error('Error saving scraping caps:', err);
      toast.error('Failed to save scraping caps');
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setPerBoard(DEFAULTS.perBoard);
    setGlobalMax(DEFAULTS.global);
  };

  const hasChanges = perBoard !== origPerBoard || globalMax !== origGlobal;
  const isDefault = perBoard === DEFAULTS.perBoard && globalMax === DEFAULTS.global;

  const getIntensityLabel = () => {
    const total = perBoard + globalMax;
    if (total <= 100) return { text: 'Conservative', color: 'bg-blue-100 text-blue-700 border-blue-200' };
    if (total <= 200) return { text: 'Moderate', color: 'bg-green-100 text-green-700 border-green-200' };
    if (total <= 350) return { text: 'Standard', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' };
    if (total <= 500) return { text: 'Aggressive', color: 'bg-orange-100 text-orange-700 border-orange-200' };
    return { text: 'Maximum', color: 'bg-red-100 text-red-700 border-red-200' };
  };

  const label = getIntensityLabel();

  if (isLoading) {
    return (
      <Card className="overflow-hidden">
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-black/10">
        <div className="flex items-center gap-2">
          <Gauge className="w-5 h-5 text-black" />
          <CardTitle className="font-display text-black">Scraping Caps</CardTitle>
          <Badge className={label.color}>{label.text}</Badge>
        </div>
        <CardDescription className="text-black/60">
          Control how many job URLs are processed per search run — affects coverage and credit usage
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-black">Per Board Limit</label>
            <div className="flex items-center gap-3">
              <Input
                type="number"
                value={perBoard}
                onChange={(e) => setPerBoard(Math.max(5, parseInt(e.target.value) || 5))}
                min={5}
                max={100}
                className="w-28 bg-white border-black/20 text-black focus:border-purple-500 focus:ring-purple-500/20"
              />
              <span className="text-sm text-black/60">URLs / board</span>
            </div>
            <p className="text-xs text-black/50">Max URLs extracted from each individual job board</p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-black">Global Run Limit</label>
            <div className="flex items-center gap-3">
              <Input
                type="number"
                value={globalMax}
                onChange={(e) => setGlobalMax(Math.max(10, parseInt(e.target.value) || 10))}
                min={10}
                max={1000}
                className="w-28 bg-white border-black/20 text-black focus:border-purple-500 focus:ring-purple-500/20"
              />
              <span className="text-sm text-black/60">URLs / run</span>
            </div>
            <p className="text-xs text-black/50">Max total URLs across all boards in a single search run</p>
          </div>
        </div>

        <div className="bg-black/5 rounded-lg p-4 text-sm text-black/70">
          <p>
            <strong>Cost impact:</strong> Each URL costs ~1 Firecrawl credit to scrape + 1 AI scoring call.
            At current settings, a full run could use up to <strong>{globalMax}</strong> credits.
          </p>
          <p className="mt-1 text-xs">
            Higher caps = better coverage but more credits consumed. Lower caps = faster, cheaper runs.
          </p>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Save Changes
          </Button>
          <Button
            variant="outline"
            onClick={handleReset}
            disabled={isDefault}
            className="border-black/20 text-black hover:bg-black/5"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset Defaults
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
