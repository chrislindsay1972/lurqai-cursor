import { useState, useEffect } from "react";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { TrendingUp, TrendingDown, Minus, Search, Target, CheckCircle } from "lucide-react";

interface JobBoardStats {
  id: string;
  name: string;
  url: string;
  status: string;
  total_searches: number | null;
  total_jobs_found: number | null;
  total_jobs_matched: number | null;
  total_jobs_saved: number | null;
  lifetime_success_rate: number | null;
  lifetime_conversion_rate: number | null;
  performance_score: number | null;
  last_successful_search: string | null;
}

export function JobBoardPerformance() {
  const { formatDate: localeFormatDate } = useLocaleFormat();
  const [boards, setBoards] = useState<JobBoardStats[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBoardPerformance();
  }, []);

  const fetchBoardPerformance = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('job_boards')
        .select('id, name, url, status, total_searches, total_jobs_found, total_jobs_matched, total_jobs_saved, lifetime_success_rate, lifetime_conversion_rate, performance_score, last_successful_search')
        .order('performance_score', { ascending: false, nullsFirst: false });

      if (error) throw error;
      setBoards((data || []) as JobBoardStats[]);
    } catch (err) {
      console.error('Error fetching board performance:', err);
    } finally {
      setLoading(false);
    }
  };

  const getPerformanceBadge = (score: number | null) => {
    if (score === null || score === 0) {
      return <Badge variant="secondary" className="text-xs">No data</Badge>;
    }
    if (score >= 70) {
      return <Badge className="bg-green-500/20 text-green-600 dark:text-green-400 hover:bg-green-500/30">{score}%</Badge>;
    }
    if (score >= 40) {
      return <Badge className="bg-yellow-500/20 text-yellow-600 dark:text-yellow-400 hover:bg-yellow-500/30">{score}%</Badge>;
    }
    return <Badge className="bg-red-500/20 text-red-600 dark:text-red-400 hover:bg-red-500/30">{score}%</Badge>;
  };

  const getTrendIcon = (rate: number | null) => {
    if (rate === null || rate === 0) {
      return <Minus className="h-4 w-4 text-muted-foreground" />;
    }
    if (rate >= 50) {
      return <TrendingUp className="h-4 w-4 text-green-500" />;
    }
    if (rate >= 20) {
      return <Minus className="h-4 w-4 text-yellow-500" />;
    }
    return <TrendingDown className="h-4 w-4 text-red-500" />;
  };

  const formatDate = (date: string | null) => {
    if (!date) return 'Never';
    const d = new Date(date);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    return localeFormatDate(date);
  };

  // Summary stats
  const totalSearches = boards.reduce((sum, b) => sum + (b.total_searches || 0), 0);
  const totalJobsFound = boards.reduce((sum, b) => sum + (b.total_jobs_found || 0), 0);
  const totalJobsSaved = boards.reduce((sum, b) => sum + (b.total_jobs_saved || 0), 0);
  const avgPerformance = boards.length > 0 
    ? Math.round(boards.reduce((sum, b) => sum + (b.performance_score || 0), 0) / boards.length)
    : 0;

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Job Board Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Job Board Performance Analytics
        </CardTitle>
        <CardDescription>
          Track which job boards yield the best matching results. The AI uses this data to prioritize high-performing boards.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-lg bg-muted/50">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <Search className="h-4 w-4" />
              Total Searches
            </div>
            <div className="text-2xl font-semibold">{totalSearches}</div>
          </div>
          <div className="p-4 rounded-lg bg-muted/50">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <Target className="h-4 w-4" />
              Jobs Found
            </div>
            <div className="text-2xl font-semibold">{totalJobsFound}</div>
          </div>
          <div className="p-4 rounded-lg bg-muted/50">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <CheckCircle className="h-4 w-4" />
              Jobs Saved
            </div>
            <div className="text-2xl font-semibold">{totalJobsSaved}</div>
          </div>
          <div className="p-4 rounded-lg bg-muted/50">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <TrendingUp className="h-4 w-4" />
              Avg Performance
            </div>
            <div className="text-2xl font-semibold">{avgPerformance}%</div>
          </div>
        </div>

        {/* Board Performance Table */}
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Job Board</TableHead>
                <TableHead className="text-center">Score</TableHead>
                <TableHead className="text-center">Searches</TableHead>
                <TableHead className="text-center">Found</TableHead>
                <TableHead className="text-center">Matched</TableHead>
                <TableHead className="text-center">Saved</TableHead>
                <TableHead className="text-center">Success Rate</TableHead>
                <TableHead className="text-right">Last Success</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {boards.map((board) => (
                <TableRow key={board.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{board.name}</div>
                      <div className="text-xs text-muted-foreground truncate max-w-[200px]">
                        {board.url}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    {getPerformanceBadge(board.performance_score)}
                  </TableCell>
                  <TableCell className="text-center text-muted-foreground">
                    {board.total_searches || 0}
                  </TableCell>
                  <TableCell className="text-center">
                    {board.total_jobs_found || 0}
                  </TableCell>
                  <TableCell className="text-center">
                    {board.total_jobs_matched || 0}
                  </TableCell>
                  <TableCell className="text-center font-medium">
                    {board.total_jobs_saved || 0}
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-2">
                      {getTrendIcon(board.lifetime_success_rate)}
                      <span className="text-sm">
                        {board.lifetime_success_rate ? `${Math.round(board.lifetime_success_rate)}%` : '-'}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right text-sm text-muted-foreground">
                    {formatDate(board.last_successful_search)}
                  </TableCell>
                </TableRow>
              ))}
              {boards.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    No performance data yet. Run a job search to start tracking.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        <p className="text-xs text-muted-foreground">
          <strong>Performance Score</strong> is calculated based on success rate (jobs that meet match threshold), 
          conversion rate (jobs actually saved), and recency of last successful search.
        </p>
      </CardContent>
    </Card>
  );
}