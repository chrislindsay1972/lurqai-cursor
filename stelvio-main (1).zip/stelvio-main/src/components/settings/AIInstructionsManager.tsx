import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Brain, Save, Loader2, RotateCcw, Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface AIInstruction {
  id: string;
  instruction_key: string;
  instruction_name: string;
  instruction_prompt: string;
  description: string | null;
  updated_at: string;
}

const DEFAULT_PROMPTS: Record<string, string> = {
  job_match_scoring: `Analyze job posting for candidate with skills: {{candidate_skills}}
{{#candidate_title}}Role: {{candidate_title}}{{/candidate_title}}

SCORING CRITERIA:
- 90-100%: Perfect match - all required skills present, matching seniority level, same job family
- 70-89%: Strong match - most skills present (80%+), related job title, minor gaps
- 50-69%: Moderate match - core skills present (60%+), transferable experience
- 30-49%: Weak match - some relevant skills, significant gaps
- 0-29%: Poor match - minimal skill overlap, different specialization

Consider:
1. Direct skill matches (exact technology/tool)
2. Related skills (e.g., React experience counts for JavaScript roles)
3. Seniority alignment (Senior vs Junior roles)
4. Domain relevance (e.g., Healthcare IT experience for Healthcare jobs)

Return JSON:
- job_title: string
- match_score: number 0-100
- match_reason: string (explain the score with specific skill analysis)
- skills_matched: string[]
- skills_missing: string[]
- is_job_posting: boolean

Only valid JSON.`,

  company_domain_lookup: `Find the official website domain for the company "{{company_name}}".
{{#job_description}}

Job Description context:
{{job_description}}
{{/job_description}}

Return ONLY a JSON object with these exact fields:
{
  "domain": "example.com",
  "website_url": "https://www.example.com",
  "confidence": "high" | "medium" | "low"
}

Rules:
- The domain should be the primary corporate domain (e.g., "microsoft.com" not "azure.microsoft.com")
- Do not include "www." in the domain field
- Include the full URL with https:// in website_url
- If you cannot find a reliable domain, set domain and website_url to null
- Set confidence to "high" if you're certain, "medium" if likely correct, "low" if uncertain

Only respond with valid JSON, no other text.`,

  engagement_email_generation: `You are an expert recruitment copywriter. You are writing an email sequence FROM a recruitment consultant TO a stakeholder (hiring manager / decision-maker) ABOUT a candidate.

The RECIPIENT of these emails is a stakeholder. The SUBJECT being discussed is a candidate.

Candidate context (for YOUR reference only — do NOT reveal the candidate's name to the recipient):
- Title: {{candidate_current_title}}

CRITICAL RULE: NEVER mention the candidate's name in any email. Instead, refer to them generically as "a strong candidate", "an experienced professional", "a talented {{candidate_current_title}}", etc. The candidate's identity must remain confidential until the stakeholder expresses interest.

Rules:
- Voice: {{voice}}
- Language style: {{language_style}} English spelling and phrasing
- Tone: {{tone_chips}}
- Primary CTA: "{{primary_cta}}"
- Secondary CTA: "{{secondary_cta}}"
{{#never_mention_salary}}- NEVER mention salary, compensation, or pay{{/never_mention_salary}}
{{#linkedin_brevity}}- Keep emails very short, like LinkedIn DMs — 3-5 sentences max{{/linkedin_brevity}}
{{^linkedin_brevity}}- Keep emails concise but professional — 4-8 sentences{{/linkedin_brevity}}
- Address the stakeholder using {{stakeholder_first_name}} or {{stakeholder_name}}
- NEVER use {{candidate_name}} or {{candidate_first_name}} — the candidate's name must stay confidential
- You may use {{candidate_current_title}} to describe the candidate's role/seniority
- Use {{consultant_name}} for the sender's name
- Use {{stakeholder_company}} for the stakeholder's company name
- Do NOT fabricate specific job details, salary figures, or company-specific facts
- Each email must have ONE clear primary call-to-action
- Write the body as PLAIN TEXT only — no HTML tags. Use blank lines to separate paragraphs.
- The emails should position the candidate as a strong talent the stakeholder should consider, without revealing their identity`,

  notes_keyword_extraction: `You are a recruitment search optimizer. Extract key job search terms from candidate notes.

Return ONLY a JSON array of 1-5 keywords/phrases that should be used to filter or prioritize job searches.

Focus on:
- Industries (e.g., "healthcare", "fintech", "retail")
- Company types (e.g., "startup", "enterprise", "agency")
- Specific technologies or tools mentioned
- Work preferences (e.g., "no travel", "hybrid only")
- Deal-breakers or must-haves

Example output: ["healthcare", "startup", "no travel required"]

Return only the JSON array, nothing else. If no clear preferences can be extracted, return an empty array [].`,

  stakeholder_identification: `Analyze this company to identify the 2 best decision-makers to contact regarding the job role.

COMPANY INFORMATION:
- Name: {{company_name}}
- Domain: {{company_domain}}
- Employee Count: {{employee_count}}
- Industry: {{industry}}
- LinkedIn URL: {{linkedin_url}}

JOB CONTEXT:
- Job Title: {{job_title}}
- Job Description: {{job_description}}

ANALYSIS CRITERIA:
1. Company Size Assessment:
   - Small (1-50 employees): Target Owner, CEO, Founder, or direct department head
   - Medium (51-200 employees): Target HR Manager, Department Director, or VP
   - Large (200+ employees): Target Talent Acquisition Manager, HR Director, or Recruiting Lead

2. Role Relevance:
   - Consider who would be the hiring manager for this specific role
   - Technical roles: May need Engineering Manager or CTO alongside HR
   - Sales roles: Sales Director or VP Sales alongside HR
   - General roles: HR Director or People Operations

3. Decision-Making Authority:
   - Prioritize those with hiring authority for the specific role
   - Consider budget holders and final decision makers

Return JSON array of exactly 2 contacts with format:
[
  {
    "first_name": "likely first name or common name for title",
    "last_name": "likely last name based on research",
    "title": "Job Title",
    "reasoning": "Why this person is ideal to contact"
  }
]

If company is very small (<10 employees), only return 1 contact (the founder/CEO).
Only return valid JSON array, no other text.`,
};

export function AIInstructionsManager() {
  const { toast } = useToast();
  const [instructions, setInstructions] = useState<AIInstruction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);
  const [editedPrompts, setEditedPrompts] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchInstructions();
  }, []);

  const fetchInstructions = async () => {
    try {
      const { data, error } = await supabase
        .from("ai_instructions")
        .select("*")
        .order("instruction_name");

      if (error) throw error;
      
      // Cast the data to our interface type
      const typedData = (data || []) as unknown as AIInstruction[];
      setInstructions(typedData);
      
      // Initialize edited prompts
      const prompts: Record<string, string> = {};
      typedData.forEach((inst) => {
        prompts[inst.id] = inst.instruction_prompt;
      });
      setEditedPrompts(prompts);
    } catch (error) {
      console.error("Error fetching AI instructions:", error);
      toast({
        title: "Error",
        description: "Failed to load AI instructions",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async (instruction: AIInstruction) => {
    setSavingId(instruction.id);
    try {
      const { error } = await supabase
        .from("ai_instructions")
        .update({
          instruction_prompt: editedPrompts[instruction.id],
        })
        .eq("id", instruction.id);

      if (error) throw error;

      toast({
        title: "Saved",
        description: `${instruction.instruction_name} instruction updated`,
      });
      
      fetchInstructions();
    } catch (error) {
      console.error("Error saving instruction:", error);
      toast({
        title: "Error",
        description: "Failed to save instruction",
        variant: "destructive",
      });
    } finally {
      setSavingId(null);
    }
  };

  const handleReset = (instruction: AIInstruction) => {
    const defaultPrompt = DEFAULT_PROMPTS[instruction.instruction_key];
    if (defaultPrompt) {
      setEditedPrompts((prev) => ({
        ...prev,
        [instruction.id]: defaultPrompt,
      }));
    }
  };

  const hasChanges = (instruction: AIInstruction) => {
    return editedPrompts[instruction.id] !== instruction.instruction_prompt;
  };

  if (isLoading) {
    return (
      <Card className="bg-accent border-black">
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-black/50" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-accent border-black">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-black">
          <Brain className="w-5 h-5" />
          AI Instructions
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger>
                <Info className="w-4 h-4 text-black/50" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm bg-black text-white border-black">
                <p>
                  Configure the prompts used by the AI to analyze and score job matches.
                  Use placeholders like {"{{candidate_skills}}"} and {"{{candidate_title}}"} 
                  which will be replaced with actual candidate data.
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {instructions.length === 0 ? (
          <p className="text-black/70 text-center py-4">
            No AI instructions configured
          </p>
        ) : (
          <Accordion type="single" collapsible className="w-full">
            {instructions.map((instruction) => (
              <AccordionItem key={instruction.id} value={instruction.id}>
                <AccordionTrigger className="hover:no-underline text-black">
                  <div className="flex items-center gap-3">
                    <span className="font-medium text-black">{instruction.instruction_name}</span>
                    <Badge variant="outline" className="text-xs border-black text-black">
                      {instruction.instruction_key}
                    </Badge>
                    {hasChanges(instruction) && (
                      <Badge className="bg-purple-600 text-white text-xs">
                        Unsaved
                      </Badge>
                    )}
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4 pt-2">
                    {instruction.description && (
                      <p className="text-sm text-black/70">
                        {instruction.description}
                      </p>
                    )}
                    
                    <div className="space-y-2">
                      <Label className="text-black">Prompt Template</Label>
                      <Textarea
                        value={editedPrompts[instruction.id] || ""}
                        onChange={(e) =>
                          setEditedPrompts((prev) => ({
                            ...prev,
                            [instruction.id]: e.target.value,
                          }))
                        }
                        className="min-h-[300px] font-mono text-sm bg-white border-black text-black"
                        placeholder="Enter the AI instruction prompt..."
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="text-xs text-black/60">
                        Last updated: {new Date(instruction.updated_at).toLocaleString()}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleReset(instruction)}
                          disabled={savingId === instruction.id}
                          className="border-black text-black hover:bg-black/10"
                        >
                          <RotateCcw className="w-4 h-4 mr-1" />
                          Reset to Default
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleSave(instruction)}
                          disabled={savingId === instruction.id || !hasChanges(instruction)}
                          className="bg-purple-600 text-white hover:bg-purple-700"
                        >
                          {savingId === instruction.id ? (
                            <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                          ) : (
                            <Save className="w-4 h-4 mr-1" />
                          )}
                          Save Changes
                        </Button>
                      </div>
                    </div>

                    {/* Placeholders reference */}
                    <div className="bg-black/10 rounded-lg p-3 mt-4">
                      <p className="text-xs font-medium mb-2 text-black">Available Placeholders:</p>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="secondary" className="text-xs font-mono bg-white text-black border-black">
                          {"{{candidate_skills}}"}
                        </Badge>
                        <Badge variant="secondary" className="text-xs font-mono bg-white text-black border-black">
                          {"{{candidate_title}}"}
                        </Badge>
                        <Badge variant="secondary" className="text-xs font-mono bg-white text-black border-black">
                          {"{{#candidate_title}}...{{/candidate_title}}"}
                        </Badge>
                      </div>
                      <p className="text-xs text-black/60 mt-2">
                        Use {"{{#...}}...{{/...}}"} for conditional sections that only appear when the value exists.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        )}
      </CardContent>
    </Card>
  );
}
