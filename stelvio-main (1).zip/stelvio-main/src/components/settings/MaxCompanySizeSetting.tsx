import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building2, Save, RotateCcw, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function MaxCompanySizeSetting() {
  const [maxEmployees, setMaxEmployees] = useState(500);
  const [originalValue, setOriginalValue] = useState(500);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchSetting();
  }, []);

  const fetchSetting = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'max_company_employees')
        .single();

      if (error) throw error;
      
      const value = parseInt(data?.setting_value || '500', 10);
      setMaxEmployees(value);
      setOriginalValue(value);
    } catch (err) {
      console.error('Error fetching max company size:', err);
      toast.error('Failed to load max company size setting');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('app_settings')
        .update({ 
          setting_value: maxEmployees.toString(),
          updated_at: new Date().toISOString()
        })
        .eq('setting_key', 'max_company_employees');

      if (error) throw error;
      
      setOriginalValue(maxEmployees);
      toast.success(`Max company size updated to ${maxEmployees.toLocaleString()} employees`);
    } catch (err) {
      console.error('Error saving max company size:', err);
      toast.error('Failed to save max company size');
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setMaxEmployees(500);
  };

  const hasChanges = maxEmployees !== originalValue;

  const getSizeLabel = (value: number) => {
    if (value <= 50) return { text: 'Micro', color: 'bg-blue-100 text-blue-700 border-blue-200' };
    if (value <= 200) return { text: 'Small', color: 'bg-green-100 text-green-700 border-green-200' };
    if (value <= 500) return { text: 'Medium', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' };
    if (value <= 1000) return { text: 'Large', color: 'bg-orange-100 text-orange-700 border-orange-200' };
    return { text: 'Enterprise', color: 'bg-red-100 text-red-700 border-red-200' };
  };

  const label = getSizeLabel(maxEmployees);

  if (isLoading) {
    return (
      <Card className="overflow-hidden">
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-black/10">
        <div className="flex items-center gap-2">
          <Building2 className="w-5 h-5 text-black" />
          <CardTitle className="font-display text-black">Max Company Size</CardTitle>
        </div>
        <CardDescription className="text-black/60">
          Exclude large companies from job searches - they're harder to sell to
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-black">Maximum Employees</span>
            <Badge className={label.color}>{label.text}</Badge>
          </div>
          
          <div className="flex items-center gap-4">
            <Input
              type="number"
              value={maxEmployees}
              onChange={(e) => setMaxEmployees(Math.max(1, parseInt(e.target.value) || 1))}
              min={1}
              className="w-40 bg-white border-black/20 text-black focus:border-purple-500 focus:ring-purple-500/20"
            />
            <span className="text-sm text-black/60">employees</span>
          </div>
        </div>

        <div className="bg-black/5 rounded-lg p-4 text-sm text-black/70">
          <p>
            <strong>How it works:</strong> During job searches, companies with more than{" "}
            <span className="font-semibold">{maxEmployees.toLocaleString()}</span> employees 
            will be filtered out. This helps focus on smaller, more accessible companies.
          </p>
          <ul className="mt-2 space-y-1 list-disc list-inside text-xs">
            <li><strong>1-50:</strong> Startups and micro businesses</li>
            <li><strong>51-200:</strong> Small businesses - often easier to reach decision makers</li>
            <li><strong>201-500:</strong> Medium companies - good balance of opportunity and accessibility</li>
            <li><strong>501-1000:</strong> Large companies - harder to navigate</li>
            <li><strong>1000+:</strong> Enterprise - complex sales cycles</li>
          </ul>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Save Changes
          </Button>
          <Button
            variant="outline"
            onClick={handleReset}
            disabled={maxEmployees === 500}
            className="border-black/20 text-black hover:bg-black/5"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset to Default (500)
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
