import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { ModuleType, useUpdateCustomField } from "@/hooks/useCustomFields";
import { X, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface CombinedField {
  id: string;
  name: string;
  label: string;
  type: string;
  isSystem: boolean;
  displayOrder: number;
  showInList: boolean;
  showInDetail: boolean;
  customFieldId?: string;
  fieldOptions?: string[] | null;
  isRequired?: boolean;
}

const formSchema = z.object({
  field_label: z.string().min(1, "Label is required").max(100),
  is_required: z.boolean(),
  show_in_list: z.boolean(),
  show_in_detail: z.boolean(),
});

type FormValues = z.infer<typeof formSchema>;

interface EditFieldDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  field: CombinedField;
  module: ModuleType;
}

export function EditFieldDialog({ open, onOpenChange, field, module }: EditFieldDialogProps) {
  const [options, setOptions] = useState<string[]>(field.fieldOptions || []);
  const [newOption, setNewOption] = useState("");
  
  const updateField = useUpdateCustomField();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      field_label: field.label,
      is_required: field.isRequired || false,
      show_in_list: field.showInList,
      show_in_detail: field.showInDetail,
    },
  });
  
  useEffect(() => {
    form.reset({
      field_label: field.label,
      is_required: field.isRequired || false,
      show_in_list: field.showInList,
      show_in_detail: field.showInDetail,
    });
    setOptions(field.fieldOptions || []);
  }, [field, form]);
  
  const needsOptions = field.type === 'select' || field.type === 'multi_select';
  
  const addOption = () => {
    if (newOption.trim() && !options.includes(newOption.trim())) {
      setOptions([...options, newOption.trim()]);
      setNewOption("");
    }
  };
  
  const removeOption = (option: string) => {
    setOptions(options.filter(o => o !== option));
  };
  
  const onSubmit = (values: FormValues) => {
    if (!field.customFieldId) return;
    
    updateField.mutate({
      id: field.customFieldId,
      field_label: values.field_label,
      field_options: needsOptions ? options : null,
      is_required: values.is_required,
      show_in_list: values.show_in_list,
      show_in_detail: values.show_in_detail,
    }, {
      onSuccess: () => {
        onOpenChange(false);
      },
    });
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit Custom Field</DialogTitle>
          <DialogDescription>
            Update the "{field.label}" field configuration.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="field_label"
              render={({ field: formField }) => (
                <FormItem>
                  <FormLabel>Field Label</FormLabel>
                  <FormControl>
                    <Input {...formField} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="space-y-2">
              <Label className="text-muted-foreground">Field Name (Read-only)</Label>
              <Input value={field.name} disabled />
            </div>
            
            <div className="space-y-2">
              <Label className="text-muted-foreground">Field Type (Read-only)</Label>
              <Input value={field.type} disabled />
            </div>
            
            {needsOptions && (
              <div className="space-y-2">
                <Label>Options</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add an option"
                    value={newOption}
                    onChange={(e) => setNewOption(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addOption();
                      }
                    }}
                  />
                  <Button type="button" variant="outline" size="icon" onClick={addOption}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {options.map((option) => (
                    <Badge key={option} variant="secondary" className="pr-1">
                      {option}
                      <button
                        type="button"
                        onClick={() => removeOption(option)}
                        className="ml-1 hover:bg-muted-foreground/20 rounded-full p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            
            <div className="grid grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="is_required"
                render={({ field: formField }) => (
                  <FormItem className="flex items-center gap-2 space-y-0">
                    <FormControl>
                      <Switch checked={formField.value} onCheckedChange={formField.onChange} />
                    </FormControl>
                    <FormLabel className="font-normal">Required</FormLabel>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="show_in_list"
                render={({ field: formField }) => (
                  <FormItem className="flex items-center gap-2 space-y-0">
                    <FormControl>
                      <Switch checked={formField.value} onCheckedChange={formField.onChange} />
                    </FormControl>
                    <FormLabel className="font-normal">Show in List</FormLabel>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="show_in_detail"
                render={({ field: formField }) => (
                  <FormItem className="flex items-center gap-2 space-y-0">
                    <FormControl>
                      <Switch checked={formField.value} onCheckedChange={formField.onChange} />
                    </FormControl>
                    <FormLabel className="font-normal">Show in Detail</FormLabel>
                  </FormItem>
                )}
              />
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={updateField.isPending || (needsOptions && options.length === 0)}
              >
                {updateField.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
