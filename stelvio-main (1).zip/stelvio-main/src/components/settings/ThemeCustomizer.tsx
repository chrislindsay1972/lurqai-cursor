import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Palette, RotateCcw, Check } from "lucide-react";
import { toast } from "sonner";
import { applyThemeToDocument, type ThemeColors } from "@/lib/theme";

// Research-backed default: soft blue-gray palette reduces eye strain
// Based on UX studies recommending neutral blue-gray backgrounds with muted accents
const defaultTheme: ThemeColors = {
  fontColor: "#1F2937",      // Slate-800: easier than pure black
  backgroundColor: "#F1F5F9", // Slate-100: soft, easy on eyes
  ctaButtonColor: "#3B82F6", // Blue-500: calming, professional
};

const colorPresets = [
  { name: "Eye Comfort", font: "#1F2937", bg: "#F1F5F9", cta: "#3B82F6" }, // Research-backed default
  { name: "Warm Neutral", font: "#292524", bg: "#FAF5F0", cta: "#D97706" }, // Warm stone tones
  { name: "Cool Gray", font: "#374151", bg: "#F9FAFB", cta: "#6366F1" },   // Clean minimal
  { name: "Dark Mode", font: "#E5E7EB", bg: "#1F2937", cta: "#10B981" },   // Dark pro
  { name: "Ocean", font: "#1E3A5F", bg: "#E0F2FE", cta: "#0EA5E9" },       // Blue tones
  { name: "Neon Brand", font: "#000000", bg: "#E0FA29", cta: "#8B5CF6" },  // Original LurqAI
];

export function ThemeCustomizer() {
  const [colors, setColors] = useState<ThemeColors>(() => {
    const saved = localStorage.getItem("stelvio-theme");
    return saved ? JSON.parse(saved) : defaultTheme;
  });
  const [savedColors, setSavedColors] = useState<ThemeColors>(() => {
    const saved = localStorage.getItem("stelvio-theme");
    return saved ? JSON.parse(saved) : defaultTheme;
  });

  // Apply saved theme on mount (so the UI matches what the app is using)
  useEffect(() => {
    const saved = localStorage.getItem("stelvio-theme");
    if (saved) {
      const themeColors = JSON.parse(saved) as ThemeColors;
      applyThemeToDocument(themeColors);
    }
  }, []);

  const hasChanges = JSON.stringify(colors) !== JSON.stringify(savedColors);

  const applyTheme = () => {
    localStorage.setItem("stelvio-theme", JSON.stringify(colors));
    applyThemeToDocument(colors);
    setSavedColors(colors);
    toast.success("Theme applied successfully!");
  };

  const resetTheme = () => {
    setColors(defaultTheme);
    localStorage.setItem("stelvio-theme", JSON.stringify(defaultTheme));
    applyThemeToDocument(defaultTheme);
    setSavedColors(defaultTheme);
    toast.success("Theme reset to default!");
  };

  const applyPreset = (preset: typeof colorPresets[0]) => {
    setColors({
      fontColor: preset.font,
      backgroundColor: preset.bg,
      ctaButtonColor: preset.cta,
    });
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="border-b border-black/10">
        <div className="flex items-center gap-2">
          <Palette className="w-5 h-5 text-black" />
          <CardTitle className="font-display text-black">Theme Customization</CardTitle>
        </div>
        <CardDescription className="text-black/60">
          Customize the look and feel of your application
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        {/* Color Presets */}
        <div className="space-y-3">
          <Label className="text-sm font-semibold text-black">Quick Presets</Label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {colorPresets.map((preset) => (
              <button
                key={preset.name}
                onClick={() => applyPreset(preset)}
                className="group relative p-4 rounded-xl border-2 border-black/10 hover:border-black/30 transition-all duration-200 hover:shadow-lg"
                style={{ backgroundColor: preset.bg }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span 
                    className="text-xs font-semibold"
                    style={{ color: preset.font }}
                  >
                    {preset.name}
                  </span>
                  <div 
                    className="w-4 h-4 rounded-full border border-black/20"
                    style={{ backgroundColor: preset.cta }}
                  />
                </div>
                <div className="flex gap-1">
                  <div 
                    className="w-4 h-4 rounded border border-black/20"
                    style={{ backgroundColor: preset.font }}
                  />
                  <div 
                    className="w-4 h-4 rounded border border-black/20"
                    style={{ backgroundColor: preset.bg }}
                  />
                  <div 
                    className="w-4 h-4 rounded border border-black/20"
                    style={{ backgroundColor: preset.cta }}
                  />
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Custom Colors */}
        <div className="grid gap-6 sm:grid-cols-3">
          <div className="space-y-3">
            <Label htmlFor="fontColor" className="text-sm font-semibold text-black">
              Font Color
            </Label>
            <div className="relative group">
              <input
                type="color"
                id="fontColor"
                value={colors.fontColor}
                onChange={(e) => setColors({ ...colors, fontColor: e.target.value })}
                className="w-full h-14 rounded-xl cursor-pointer border-2 border-black/10 hover:border-black/30 transition-all duration-200"
                style={{ backgroundColor: colors.fontColor }}
              />
              <div className="absolute inset-x-0 -bottom-6 text-center">
                <span className="text-xs font-mono text-black/60">{colors.fontColor.toUpperCase()}</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Label htmlFor="backgroundColor" className="text-sm font-semibold text-black">
              Background Color
            </Label>
            <div className="relative group">
              <input
                type="color"
                id="backgroundColor"
                value={colors.backgroundColor}
                onChange={(e) => setColors({ ...colors, backgroundColor: e.target.value })}
                className="w-full h-14 rounded-xl cursor-pointer border-2 border-black/10 hover:border-black/30 transition-all duration-200"
                style={{ backgroundColor: colors.backgroundColor }}
              />
              <div className="absolute inset-x-0 -bottom-6 text-center">
                <span className="text-xs font-mono text-black/60">{colors.backgroundColor.toUpperCase()}</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Label htmlFor="ctaButtonColor" className="text-sm font-semibold text-black">
              CTA Button Color
            </Label>
            <div className="relative group">
              <input
                type="color"
                id="ctaButtonColor"
                value={colors.ctaButtonColor}
                onChange={(e) => setColors({ ...colors, ctaButtonColor: e.target.value })}
                className="w-full h-14 rounded-xl cursor-pointer border-2 border-black/10 hover:border-black/30 transition-all duration-200"
                style={{ backgroundColor: colors.ctaButtonColor }}
              />
              <div className="absolute inset-x-0 -bottom-6 text-center">
                <span className="text-xs font-mono text-black/60">{colors.ctaButtonColor.toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Preview */}
        <div className="mt-10 space-y-3">
          <Label className="text-sm font-semibold text-black">Live Preview</Label>
          <div 
            className="p-6 rounded-xl border-2 border-black/10 transition-all duration-300"
            style={{ backgroundColor: colors.backgroundColor }}
          >
            <h3 
              className="text-lg font-semibold mb-2"
              style={{ color: colors.fontColor }}
            >
              Sample Heading
            </h3>
            <p 
              className="text-sm mb-4 opacity-80"
              style={{ color: colors.fontColor }}
            >
              This is how your content will appear with the selected colors.
            </p>
            <button
              className="px-6 py-2.5 rounded-lg font-semibold text-white transition-all duration-200 hover:opacity-90 hover:shadow-lg"
              style={{ backgroundColor: colors.ctaButtonColor }}
            >
              Action Button
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 pt-4 border-t border-black/10">
          <Button 
            onClick={applyTheme}
            disabled={!hasChanges}
            className="bg-primary hover:bg-primary/90 text-primary-foreground border-0 transition-all duration-200"
          >
            <Check className="w-4 h-4 mr-2" />
            Apply Theme
          </Button>
          <Button 
            variant="outline" 
            onClick={resetTheme}
            className="border-black/20 text-black hover:bg-black/5 transition-all duration-200"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset to Default
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
