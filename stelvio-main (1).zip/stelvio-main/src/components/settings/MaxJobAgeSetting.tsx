import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Save, RotateCcw, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function MaxJobAgeSetting() {
  const [maxDays, setMaxDays] = useState(14);
  const [originalValue, setOriginalValue] = useState(14);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchSetting();
  }, []);

  const fetchSetting = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'max_job_age_days')
        .single();

      if (error) throw error;
      
      const value = parseInt(data?.setting_value || '14', 10);
      setMaxDays(value);
      setOriginalValue(value);
    } catch (err) {
      console.error('Error fetching max job age:', err);
      toast.error('Failed to load max job age setting');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('app_settings')
        .update({ 
          setting_value: maxDays.toString(),
          updated_at: new Date().toISOString()
        })
        .eq('setting_key', 'max_job_age_days');

      if (error) throw error;
      
      setOriginalValue(maxDays);
      toast.success(`Max job age updated to ${maxDays} days`);
    } catch (err) {
      console.error('Error saving max job age:', err);
      toast.error('Failed to save max job age');
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setMaxDays(14);
  };

  const hasChanges = maxDays !== originalValue;

  const getAgeLabel = (value: number) => {
    if (value <= 3) return { text: 'Very Fresh', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' };
    if (value <= 7) return { text: 'Fresh', color: 'bg-green-100 text-green-700 border-green-200' };
    if (value <= 14) return { text: 'Recent', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' };
    if (value <= 30) return { text: 'Standard', color: 'bg-orange-100 text-orange-700 border-orange-200' };
    return { text: 'Extended', color: 'bg-red-100 text-red-700 border-red-200' };
  };

  const label = getAgeLabel(maxDays);

  if (isLoading) {
    return (
      <Card className="overflow-hidden">
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-black/10">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-black" />
          <CardTitle className="font-display text-black">Max Job Age</CardTitle>
        </div>
        <CardDescription className="text-black/60">
          Filter out old job postings that may no longer be active
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-black">Maximum Days Since Posted</span>
            <Badge className={label.color}>{label.text}</Badge>
          </div>
          
          <div className="flex items-center gap-4">
            <Input
              type="number"
              value={maxDays}
              onChange={(e) => setMaxDays(Math.max(1, parseInt(e.target.value) || 1))}
              min={1}
              max={90}
              className="w-40 bg-white border-black/20 text-black focus:border-purple-500 focus:ring-purple-500/20"
            />
            <span className="text-sm text-black/60">days</span>
          </div>
        </div>

        <div className="bg-black/5 rounded-lg p-4 text-sm text-black/70">
          <p>
            <strong>How it works:</strong> Jobs posted more than{" "}
            <span className="font-semibold">{maxDays}</span> days ago 
            will be filtered out during searches. This helps ensure you're only seeing active opportunities.
          </p>
          <ul className="mt-2 space-y-1 list-disc list-inside text-xs">
            <li><strong>1-3 days:</strong> Very fresh - only the newest postings</li>
            <li><strong>4-7 days:</strong> Fresh - recent postings, high chance of being active</li>
            <li><strong>8-14 days:</strong> Recent - good balance of volume and freshness</li>
            <li><strong>15-30 days:</strong> Standard - wider net, some may be filled</li>
            <li><strong>30+ days:</strong> Extended - maximum coverage, higher stale rate</li>
          </ul>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Save Changes
          </Button>
          <Button
            variant="outline"
            onClick={handleReset}
            disabled={maxDays === 14}
            className="border-black/20 text-black hover:bg-black/5"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset to Default (14)
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}