import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Plus,
  Search,
  Globe,
  ExternalLink,
  Pencil,
  Trash2,
  Wand2,
  Loader2,
} from "lucide-react";

interface JobBoard {
  id: string;
  name: string;
  url: string;
  description: string | null;
  status: string;
  is_active: boolean | null;
  max_employee_count: number | null;
  search_url_template: string | null;
  url_allow_patterns: string[] | null;
  url_deny_patterns: string[] | null;
  job_id_pattern: string | null;
  min_content_length: number | null;
  created_at: string;
  created_by: string | null;
}

export function JobBoardsManager() {
  const { user, role } = useAuth();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingBoard, setEditingBoard] = useState<JobBoard | null>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    url: "",
    description: "",
    status: "active",
    max_employee_count: "500",
    search_url_template: "",
    url_allow_patterns: "",
    url_deny_patterns: "",
    job_id_pattern: "",
    min_content_length: "200",
  });
  const [showUrlProfile, setShowUrlProfile] = useState(false);

  const handleAutoDetect = async () => {
    if (!formData.url) {
      toast.error("Please enter a URL first");
      return;
    }
    setIsDetecting(true);
    try {
      const { data, error } = await supabase.functions.invoke('detect-search-template', {
        body: { url: formData.url, name: formData.name },
      });
      if (error) throw error;
      if (data?.success && data?.template) {
        setFormData(prev => ({ ...prev, search_url_template: data.template }));
        toast.success("Search template detected!");
      } else {
        toast.error(data?.error || "Could not detect search template");
      }
    } catch (err: any) {
      toast.error("Detection failed: " + (err.message || "Unknown error"));
    } finally {
      setIsDetecting(false);
    }
  };

  const { data: jobBoards = [], isLoading } = useQuery({
    queryKey: ["job-boards"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("job_boards")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as JobBoard[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const { error } = await supabase.from("job_boards").insert({
        name: data.name,
        url: data.url,
        description: data.description || null,
        status: data.status,
        max_employee_count: parseInt(data.max_employee_count) || 500,
        search_url_template: data.search_url_template || null,
        url_allow_patterns: data.url_allow_patterns ? data.url_allow_patterns.split('\n').filter(Boolean) : [],
        url_deny_patterns: data.url_deny_patterns ? data.url_deny_patterns.split('\n').filter(Boolean) : [],
        job_id_pattern: data.job_id_pattern || null,
        min_content_length: parseInt(data.min_content_length) || 200,
        created_by: user?.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-boards"] });
      toast.success("Job board added successfully");
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error) => {
      toast.error("Failed to add job board: " + error.message);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const { error } = await supabase
        .from("job_boards")
        .update({
          name: data.name,
          url: data.url,
          description: data.description || null,
          status: data.status,
          max_employee_count: parseInt(data.max_employee_count) || 500,
          search_url_template: data.search_url_template || null,
          url_allow_patterns: data.url_allow_patterns ? data.url_allow_patterns.split('\n').filter(Boolean) : [],
          url_deny_patterns: data.url_deny_patterns ? data.url_deny_patterns.split('\n').filter(Boolean) : [],
          job_id_pattern: data.job_id_pattern || null,
          min_content_length: parseInt(data.min_content_length) || 200,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-boards"] });
      toast.success("Job board updated successfully");
      resetForm();
      setEditingBoard(null);
    },
    onError: (error) => {
      toast.error("Failed to update job board: " + error.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("job_boards").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-boards"] });
      toast.success("Job board deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete job board: " + error.message);
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase
        .from("job_boards")
        .update({ is_active })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-boards"] });
    },
    onError: (error) => {
      toast.error("Failed to update: " + error.message);
    },
  });

  const resetForm = () => {
    setFormData({ name: "", url: "", description: "", status: "active", max_employee_count: "500", search_url_template: "", url_allow_patterns: "", url_deny_patterns: "", job_id_pattern: "", min_content_length: "200" });
    setShowUrlProfile(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.url) {
      toast.error("Name and URL are required");
      return;
    }
    if (editingBoard) {
      updateMutation.mutate({ id: editingBoard.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (board: JobBoard) => {
    setEditingBoard(board);
    setFormData({
      name: board.name,
      url: board.url,
      description: board.description || "",
      status: board.status,
      max_employee_count: String(board.max_employee_count ?? 500),
      search_url_template: board.search_url_template || "",
      url_allow_patterns: (board.url_allow_patterns || []).join('\n'),
      url_deny_patterns: (board.url_deny_patterns || []).join('\n'),
      job_id_pattern: board.job_id_pattern || "",
      min_content_length: String(board.min_content_length ?? 200),
    });
    setShowUrlProfile((board.url_allow_patterns?.length ?? 0) > 0 || (board.url_deny_patterns?.length ?? 0) > 0);
  };

  const filteredBoards = jobBoards.filter(
    (board) =>
      board.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      board.url.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const canDelete = role === "admin";

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-black/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-black" />
            <CardTitle className="font-display text-black">Job Boards</CardTitle>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="accent-gradient" size="sm" onClick={resetForm}>
                <Plus className="w-4 h-4 mr-2" />
                Add Job Board
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Job Board</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="e.g., LinkedIn Jobs"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="url">URL *</Label>
                  <Input
                    id="url"
                    type="url"
                    value={formData.url}
                    onChange={(e) =>
                      setFormData({ ...formData, url: e.target.value })
                    }
                    placeholder="https://..."
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    placeholder="Optional description..."
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_employee_count">Max Employee Count</Label>
                  <Input
                    id="max_employee_count"
                    type="number"
                    value={formData.max_employee_count}
                    onChange={(e) =>
                      setFormData({ ...formData, max_employee_count: e.target.value })
                    }
                    placeholder="500"
                  />
                  <p className="text-xs text-muted-foreground">
                    Only match jobs from companies with fewer than this many employees
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="search_url_template">Search URL Template</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleAutoDetect}
                      disabled={isDetecting || !formData.url}
                    >
                      {isDetecting ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Wand2 className="w-3 h-3 mr-1" />}
                      {isDetecting ? "Detecting..." : "Auto-detect"}
                    </Button>
                  </div>
                  <Textarea
                    id="search_url_template"
                    value={formData.search_url_template}
                    onChange={(e) =>
                      setFormData({ ...formData, search_url_template: e.target.value })
                    }
                    placeholder="https://example.com/jobs?search={query}&location={location}"
                    rows={2}
                  />
                   <p className="text-xs text-muted-foreground">
                    Use placeholders: {"{query}"}, {"{title}"}, {"{location}"}, {"{employee_segments}"}
                  </p>
                </div>
                <div className="space-y-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="w-full"
                    onClick={() => setShowUrlProfile(!showUrlProfile)}
                  >
                    {showUrlProfile ? "Hide" : "Show"} URL Profile (Advanced)
                  </Button>
                  {showUrlProfile && (
                    <div className="space-y-3 p-3 bg-muted/50 rounded-md">
                      <div className="space-y-1">
                        <Label htmlFor="url_allow_patterns" className="text-xs">Allow Patterns (regex, one per line)</Label>
                        <Textarea
                          id="url_allow_patterns"
                          value={formData.url_allow_patterns}
                          onChange={(e) => setFormData({ ...formData, url_allow_patterns: e.target.value })}
                          placeholder={`/job-detail/[a-f0-9-]+\n/job/[\\w-]+/\\d+`}
                          rows={2}
                          className="text-xs font-mono"
                        />
                        <p className="text-xs text-muted-foreground">Only URLs matching these pass. Leave empty to allow all.</p>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="url_deny_patterns" className="text-xs">Deny Patterns (regex, one per line)</Label>
                        <Textarea
                          id="url_deny_patterns"
                          value={formData.url_deny_patterns}
                          onChange={(e) => setFormData({ ...formData, url_deny_patterns: e.target.value })}
                          placeholder={`/jobs\\?.*page=\n/categories/\n/search\\?`}
                          rows={2}
                          className="text-xs font-mono"
                        />
                        <p className="text-xs text-muted-foreground">URLs matching any of these are rejected.</p>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label htmlFor="job_id_pattern" className="text-xs">Job ID Pattern</Label>
                          <Input
                            id="job_id_pattern"
                            value={formData.job_id_pattern}
                            onChange={(e) => setFormData({ ...formData, job_id_pattern: e.target.value })}
                            placeholder="/job/([a-f0-9-]+)"
                            className="text-xs font-mono"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="min_content_length" className="text-xs">Min Content Length</Label>
                          <Input
                            id="min_content_length"
                            type="number"
                            value={formData.min_content_length}
                            onChange={(e) => setFormData({ ...formData, min_content_length: e.target.value })}
                            placeholder="200"
                            className="text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Adding..." : "Add Job Board"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
        <CardDescription className="text-black/60">
          Manage job board URLs for resume matching and job scraping
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        {/* Search */}
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black" />
            <Input
              placeholder="Search job boards..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-accent text-accent-foreground placeholder:text-black/50 border-accent"
            />
          </div>
        </div>

        {/* Table */}
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">
            Loading...
          </div>
        ) : filteredBoards.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No job boards found. Add your first one!
          </div>
        ) : (
          <Table>
             <TableHeader>
              <TableRow className="bg-accent text-black">
                <TableHead className="w-16 text-center">Active</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>URL</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBoards.map((board) => (
                <TableRow key={board.id}>
                  <TableCell className="text-center">
                    <Checkbox
                      checked={board.is_active === true}
                      onCheckedChange={(checked) =>
                        toggleActiveMutation.mutate({ id: board.id, is_active: checked === true })
                      }
                    />
                  </TableCell>
                  <TableCell className="font-medium text-black">{board.name}</TableCell>
                  <TableCell>
                    <a
                      href={board.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 hover:underline"
                      style={{ color: 'hsl(270 60% 50%)' }}
                    >
                      {new URL(board.url).hostname}
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </TableCell>
                  <TableCell className="text-black max-w-xs truncate">
                    {board.description || "-"}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Dialog
                        open={editingBoard?.id === board.id}
                        onOpenChange={(open) => {
                          if (!open) {
                            setEditingBoard(null);
                            resetForm();
                          }
                        }}
                      >
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(board)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Edit Job Board</DialogTitle>
                          </DialogHeader>
                          <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="edit-name">Name *</Label>
                              <Input
                                id="edit-name"
                                value={formData.name}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    name: e.target.value,
                                  })
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="edit-url">URL *</Label>
                              <Input
                                id="edit-url"
                                type="url"
                                value={formData.url}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    url: e.target.value,
                                  })
                                }
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="edit-description">
                                Description
                              </Label>
                              <Textarea
                                id="edit-description"
                                value={formData.description}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    description: e.target.value,
                                  })
                                }
                                rows={3}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="edit-max_employee_count">Max Employee Count</Label>
                              <Input
                                id="edit-max_employee_count"
                                type="number"
                                value={formData.max_employee_count}
                                onChange={(e) =>
                                  setFormData({ ...formData, max_employee_count: e.target.value })
                                }
                              />
                              <p className="text-xs text-muted-foreground">
                                Only match jobs from companies with fewer than this many employees
                              </p>
                            </div>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <Label htmlFor="edit-search_url_template">Search URL Template</Label>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={handleAutoDetect}
                                  disabled={isDetecting || !formData.url}
                                >
                                  {isDetecting ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Wand2 className="w-3 h-3 mr-1" />}
                                  {isDetecting ? "Detecting..." : "Auto-detect"}
                                </Button>
                              </div>
                              <Textarea
                                id="edit-search_url_template"
                                value={formData.search_url_template}
                                onChange={(e) =>
                                  setFormData({ ...formData, search_url_template: e.target.value })
                                }
                                rows={2}
                              />
                              <p className="text-xs text-muted-foreground">
                                Use placeholders: {"{query}"}, {"{title}"}, {"{location}"}, {"{employee_segments}"}
                              </p>
                            </div>
                            <div className="space-y-2">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                className="w-full"
                                onClick={() => setShowUrlProfile(!showUrlProfile)}
                              >
                                {showUrlProfile ? "Hide" : "Show"} URL Profile (Advanced)
                              </Button>
                              {showUrlProfile && (
                                <div className="space-y-3 p-3 bg-muted/50 rounded-md">
                                  <div className="space-y-1">
                                    <Label className="text-xs">Allow Patterns (regex, one per line)</Label>
                                    <Textarea
                                      value={formData.url_allow_patterns}
                                      onChange={(e) => setFormData({ ...formData, url_allow_patterns: e.target.value })}
                                      placeholder={`/job-detail/[a-f0-9-]+`}
                                      rows={2}
                                      className="text-xs font-mono"
                                    />
                                  </div>
                                  <div className="space-y-1">
                                    <Label className="text-xs">Deny Patterns (regex, one per line)</Label>
                                    <Textarea
                                      value={formData.url_deny_patterns}
                                      onChange={(e) => setFormData({ ...formData, url_deny_patterns: e.target.value })}
                                      placeholder={`/jobs\\?.*page=`}
                                      rows={2}
                                      className="text-xs font-mono"
                                    />
                                  </div>
                                  <div className="grid grid-cols-2 gap-2">
                                    <div className="space-y-1">
                                      <Label className="text-xs">Job ID Pattern</Label>
                                      <Input
                                        value={formData.job_id_pattern}
                                        onChange={(e) => setFormData({ ...formData, job_id_pattern: e.target.value })}
                                        placeholder="/job/([a-f0-9-]+)"
                                        className="text-xs font-mono"
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-xs">Min Content Length</Label>
                                      <Input
                                        type="number"
                                        value={formData.min_content_length}
                                        onChange={(e) => setFormData({ ...formData, min_content_length: e.target.value })}
                                        placeholder="200"
                                        className="text-xs"
                                      />
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                            <div className="flex justify-end gap-2">
                              <Button
                                type="button"
                                variant="outline"
                                onClick={() => {
                                  setEditingBoard(null);
                                  resetForm();
                                }}
                              >
                                Cancel
                              </Button>
                              <Button
                                type="submit"
                                disabled={updateMutation.isPending}
                              >
                                {updateMutation.isPending
                                  ? "Saving..."
                                  : "Save Changes"}
                              </Button>
                            </div>
                          </form>
                        </DialogContent>
                      </Dialog>
                      {canDelete && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive"
                          onClick={() => deleteMutation.mutate(board.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
