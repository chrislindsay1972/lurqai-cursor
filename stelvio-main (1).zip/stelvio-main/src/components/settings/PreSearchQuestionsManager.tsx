import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, GripVertical, Loader2, X, Pencil, Check, ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface PreSearchQuestion {
  id: string;
  question_label: string;
  question_type: string;
  is_active: boolean;
  display_order: number;
  options: string[];
}

export function PreSearchQuestionsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newQuestionLabel, setNewQuestionLabel] = useState("");
  const [newQuestionType, setNewQuestionType] = useState("text");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingLabel, setEditingLabel] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [newOptionValue, setNewOptionValue] = useState("");
  const [isAdding, setIsAdding] = useState(false);

  const { data: questions = [], isLoading } = useQuery({
    queryKey: ["pre-search-questions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pre_search_questions")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data.map((q) => ({
        ...q,
        options: Array.isArray(q.options) ? q.options : [],
      })) as PreSearchQuestion[];
    },
  });

  const addMutation = useMutation({
    mutationFn: async ({ label, type }: { label: string; type: string }) => {
      const maxOrder = questions.reduce((max, q) => Math.max(max, q.display_order), 0);
      const { error } = await supabase.from("pre_search_questions").insert({
        question_label: label,
        question_type: type,
        display_order: maxOrder + 1,
        options: [],
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pre-search-questions"] });
      setNewQuestionLabel("");
      setNewQuestionType("text");
      setIsAdding(false);
      toast({ title: "Question added successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<PreSearchQuestion> }) => {
      const { error } = await supabase
        .from("pre_search_questions")
        .update(updates)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pre-search-questions"] });
      setEditingId(null);
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("pre_search_questions").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pre-search-questions"] });
      toast({ title: "Question deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleAddQuestion = () => {
    if (!newQuestionLabel.trim()) return;
    addMutation.mutate({ label: newQuestionLabel.trim(), type: newQuestionType });
  };

  const handleStartEdit = (question: PreSearchQuestion) => {
    setEditingId(question.id);
    setEditingLabel(question.question_label);
  };

  const handleSaveEdit = (question: PreSearchQuestion) => {
    if (!editingLabel.trim()) return;
    updateMutation.mutate({
      id: question.id,
      updates: { question_label: editingLabel.trim() },
    });
  };

  const handleToggleActive = (question: PreSearchQuestion) => {
    updateMutation.mutate({
      id: question.id,
      updates: { is_active: !question.is_active },
    });
  };

  const handleUpdateType = (question: PreSearchQuestion, newType: string) => {
    updateMutation.mutate({
      id: question.id,
      updates: { question_type: newType, options: newType === "select" ? question.options : [] },
    });
  };

  const handleAddOption = (question: PreSearchQuestion) => {
    if (!newOptionValue.trim()) return;
    const updatedOptions = [...question.options, newOptionValue.trim()];
    updateMutation.mutate({
      id: question.id,
      updates: { options: updatedOptions },
    });
    setNewOptionValue("");
  };

  const handleRemoveOption = (question: PreSearchQuestion, optionIndex: number) => {
    const updatedOptions = question.options.filter((_, idx) => idx !== optionIndex);
    updateMutation.mutate({
      id: question.id,
      updates: { options: updatedOptions },
    });
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "text": return "Aa";
      case "number": return "123";
      case "select": return "▼";
      default: return "?";
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <Card className="bg-card border-border overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold">Pre-Search Questions</CardTitle>
            <CardDescription className="mt-1">
              Customize the questions shown before job matching. Core fields (Location, Distance, Remote) are always included.
            </CardDescription>
          </div>
          {!isAdding && (
            <Button
              onClick={() => setIsAdding(true)}
              size="sm"
              className="bg-primary hover:bg-primary/90 gap-1"
            >
              <Plus className="w-4 h-4" />
              Add Question
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4 pt-0">
        {/* Add new question form */}
        {isAdding && (
          <div className="p-4 rounded-xl bg-primary/5 border-2 border-dashed border-primary/30 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
            <Input
              placeholder="Enter your question..."
              value={newQuestionLabel}
              onChange={(e) => setNewQuestionLabel(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddQuestion()}
              className="bg-background border-border font-medium"
              autoFocus
            />
            <div className="flex items-center gap-3">
              <Select value={newQuestionType} onValueChange={setNewQuestionType}>
                <SelectTrigger className="w-40 bg-background border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="text">Text Input</SelectItem>
                  <SelectItem value="select">Dropdown</SelectItem>
                  <SelectItem value="number">Number</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex-1" />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setIsAdding(false);
                  setNewQuestionLabel("");
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddQuestion}
                disabled={!newQuestionLabel.trim() || addMutation.isPending}
                size="sm"
                className="bg-primary hover:bg-primary/90 gap-1"
              >
                {addMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Check className="w-4 h-4" />
                )}
                Save
              </Button>
            </div>
          </div>
        )}

        {/* Questions list */}
        <div className="space-y-2">
          {questions.length === 0 && !isAdding ? (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-sm">No custom questions yet.</p>
              <Button
                variant="link"
                size="sm"
                onClick={() => setIsAdding(true)}
                className="mt-2 text-primary"
              >
                Add your first question
              </Button>
            </div>
          ) : (
            questions.map((question) => (
              <Collapsible
                key={question.id}
                open={expandedId === question.id}
                onOpenChange={(open) => setExpandedId(open ? question.id : null)}
              >
                <div
                  className={cn(
                    "rounded-xl border transition-all duration-200",
                    expandedId === question.id
                      ? "bg-muted/50 border-primary/30 shadow-sm"
                      : "bg-background border-border hover:border-primary/20"
                  )}
                >
                  {/* Main row */}
                  <div className="flex items-center gap-3 p-4">
                    <GripVertical className="w-4 h-4 text-muted-foreground/50 cursor-grab flex-shrink-0" />
                    
                    {/* Type indicator */}
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-xs font-bold text-primary flex-shrink-0">
                      {getTypeIcon(question.question_type)}
                    </div>
                    
                    {/* Question label - editable */}
                    <div className="flex-1 min-w-0">
                      {editingId === question.id ? (
                        <div className="flex items-center gap-2">
                          <Input
                            value={editingLabel}
                            onChange={(e) => setEditingLabel(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") handleSaveEdit(question);
                              if (e.key === "Escape") setEditingId(null);
                            }}
                            className="h-8 text-sm font-medium bg-background"
                            autoFocus
                          />
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-primary hover:text-primary"
                            onClick={() => handleSaveEdit(question)}
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8"
                            onClick={() => setEditingId(null)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 group">
                          <span className={cn(
                            "font-medium truncate",
                            !question.is_active && "text-muted-foreground line-through"
                          )}>
                            {question.question_label}
                          </span>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleStartEdit(question)}
                          >
                            <Pencil className="w-3 h-3" />
                          </Button>
                        </div>
                      )}
                    </div>

                    {/* Active toggle */}
                    <div className="flex items-center gap-2">
                      <span className={cn(
                        "text-xs font-medium transition-colors",
                        question.is_active ? "text-emerald-600" : "text-muted-foreground"
                      )}>
                        {question.is_active ? "Active" : "Inactive"}
                      </span>
                      <Switch
                        checked={question.is_active}
                        onCheckedChange={() => handleToggleActive(question)}
                        className="data-[state=checked]:bg-emerald-500"
                      />
                    </div>

                    {/* Expand/Delete buttons */}
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                      >
                        {expandedId === question.id ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </Button>
                    </CollapsibleTrigger>

                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(question.id)}
                      disabled={deleteMutation.isPending}
                      className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Expanded content */}
                  <CollapsibleContent>
                    <div className="px-4 pb-4 pt-0 space-y-4 border-t border-border/50 mt-0">
                      <div className="pt-4 grid gap-4 sm:grid-cols-2">
                        {/* Type selector */}
                        <div className="space-y-2">
                          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                            Field Type
                          </label>
                          <Select
                            value={question.question_type}
                            onValueChange={(type) => handleUpdateType(question, type)}
                          >
                            <SelectTrigger className="bg-background border-border">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-white">
                              <SelectItem value="text">Text Input</SelectItem>
                              <SelectItem value="select">Dropdown</SelectItem>
                              <SelectItem value="number">Number</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Options for select type */}
                        {question.question_type === "select" && (
                          <div className="space-y-2 sm:col-span-2">
                            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                              Dropdown Options
                            </label>
                            <div className="flex flex-wrap gap-2">
                              {question.options.map((opt, idx) => (
                                <Badge
                                  key={idx}
                                  variant="secondary"
                                  className="bg-primary/10 text-foreground pl-3 pr-1 py-1.5 gap-1"
                                >
                                  {opt}
                                  <button
                                    type="button"
                                    className="ml-1 p-0.5 rounded hover:bg-destructive/20 hover:text-destructive transition-colors"
                                    onClick={() => handleRemoveOption(question, idx)}
                                  >
                                    <X className="h-3 w-3" />
                                  </button>
                                </Badge>
                              ))}
                              <div className="flex gap-2 flex-1 min-w-[200px]">
                                <Input
                                  placeholder="Add option..."
                                  value={expandedId === question.id ? newOptionValue : ""}
                                  onChange={(e) => setNewOptionValue(e.target.value)}
                                  onKeyDown={(e) => e.key === "Enter" && handleAddOption(question)}
                                  className="h-8 text-sm bg-background flex-1"
                                />
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleAddOption(question)}
                                  disabled={!newOptionValue.trim()}
                                  className="h-8 px-3"
                                >
                                  <Plus className="w-3 h-3 mr-1" />
                                  Add
                                </Button>
                              </div>
                            </div>
                            {question.options.length === 0 && (
                              <p className="text-xs text-muted-foreground">
                                Add at least one option for the dropdown.
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </CollapsibleContent>
                </div>
              </Collapsible>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
