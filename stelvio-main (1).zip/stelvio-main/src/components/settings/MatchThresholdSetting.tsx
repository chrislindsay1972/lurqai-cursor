import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Target, Save, RotateCcw, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function MatchThresholdSetting() {
  const [threshold, setThreshold] = useState(85);
  const [originalThreshold, setOriginalThreshold] = useState(85);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchThreshold();
  }, []);

  const fetchThreshold = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'match_threshold_percent')
        .single();

      if (error) throw error;
      
      const value = parseInt(data?.setting_value || '85', 10);
      setThreshold(value);
      setOriginalThreshold(value);
    } catch (err) {
      console.error('Error fetching threshold:', err);
      toast.error('Failed to load match threshold setting');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('app_settings')
        .update({ 
          setting_value: threshold.toString(),
          updated_at: new Date().toISOString()
        })
        .eq('setting_key', 'match_threshold_percent');

      if (error) throw error;
      
      setOriginalThreshold(threshold);
      toast.success(`Match threshold updated to ${threshold}%`);
    } catch (err) {
      console.error('Error saving threshold:', err);
      toast.error('Failed to save match threshold');
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setThreshold(85);
  };

  const hasChanges = threshold !== originalThreshold;

  const getThresholdLabel = (value: number) => {
    if (value >= 90) return { text: 'Very Strict', color: 'bg-red-100 text-red-700 border-red-200' };
    if (value >= 75) return { text: 'Strict', color: 'bg-orange-100 text-orange-700 border-orange-200' };
    if (value >= 60) return { text: 'Moderate', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' };
    if (value >= 40) return { text: 'Relaxed', color: 'bg-green-100 text-green-700 border-green-200' };
    return { text: 'Very Relaxed', color: 'bg-blue-100 text-blue-700 border-blue-200' };
  };

  const label = getThresholdLabel(threshold);

  if (isLoading) {
    return (
      <Card className="overflow-hidden">
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-black/10">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-black" />
          <CardTitle className="font-display text-black">Match Threshold</CardTitle>
        </div>
        <CardDescription className="text-black/60">
          Set the minimum match score required for jobs to be saved during candidate searches
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-black">Minimum Match Score</span>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-black">{threshold}%</span>
              <Badge className={label.color}>{label.text}</Badge>
            </div>
          </div>
          
          <Slider
            value={[threshold]}
            onValueChange={(values) => setThreshold(values[0])}
            min={0}
            max={100}
            step={5}
            className="w-full"
          />
          
          <div className="flex justify-between text-xs text-black/50">
            <span>More Results</span>
            <span>Higher Quality</span>
          </div>
        </div>

        <div className="bg-black/5 rounded-lg p-4 text-sm text-black/70">
          <p>
            <strong>How it works:</strong> During job searches, AI scores each job based on skill match, 
            seniority alignment, and domain relevance. Only jobs scoring at or above this threshold will be saved.
          </p>
          <ul className="mt-2 space-y-1 list-disc list-inside text-xs">
            <li><strong>90%+:</strong> Nearly perfect matches only - may result in fewer jobs</li>
            <li><strong>75-89%:</strong> Strong matches with most skills present</li>
            <li><strong>60-74%:</strong> Good matches with core skills and transferable experience</li>
            <li><strong>Below 60%:</strong> Broader search, more results but lower relevance</li>
          </ul>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Save Changes
          </Button>
          <Button
            variant="outline"
            onClick={handleReset}
            disabled={threshold === 85}
            className="border-black/20 text-black hover:bg-black/5"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset to Default (85%)
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
