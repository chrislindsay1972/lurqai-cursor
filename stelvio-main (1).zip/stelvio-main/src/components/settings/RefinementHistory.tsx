import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { History, ChevronDown, ChevronUp, Sparkles, RefreshCw } from "lucide-react";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";

interface RefinementEvent {
  id: string;
  created_at: string;
  message: string;
  candidate_id: string;
  candidate_name?: string;
}

export function RefinementHistory() {
  const { formatDateTime } = useLocaleFormat();
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const { data: refinements, isLoading, refetch, isRefetching } = useQuery({
    queryKey: ["refinement-history"],
    queryFn: async () => {
      // Fetch refinement events
      const { data: events, error } = await supabase
        .from("pipeline_events")
        .select("id, created_at, message, candidate_id")
        .eq("event_type", "criteria_refinement")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;

      // Get unique candidate IDs
      const candidateIds = [...new Set(events?.map(e => e.candidate_id) || [])];
      
      // Fetch candidate names
      let candidateMap: Record<string, string> = {};
      if (candidateIds.length > 0) {
        const { data: candidates } = await supabase
          .from("candidates")
          .select("id, name")
          .in("id", candidateIds);
        
        candidateMap = (candidates || []).reduce((acc, c) => {
          acc[c.id] = c.name;
          return acc;
        }, {} as Record<string, string>);
      }

      return (events || []).map(event => ({
        ...event,
        candidate_name: candidateMap[event.candidate_id] || "Unknown Candidate",
      })) as RefinementEvent[];
    },
  });

  const parseMessage = (message: string) => {
    // Message format: "AI refined matching criteria: [analysis]. Changes: [changes]"
    const analysisMatch = message.match(/AI refined matching criteria: (.+?)\. Changes:/);
    const changesMatch = message.match(/Changes: (.+)$/);
    
    return {
      analysis: analysisMatch?.[1] || message,
      changes: changesMatch?.[1]?.split(", ") || [],
    };
  };

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-black/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-black" />
            <CardTitle className="font-display text-black">Refinement History</CardTitle>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => refetch()}
            disabled={isRefetching}
            className="text-black/60 hover:text-black"
          >
            <RefreshCw className={`w-4 h-4 ${isRefetching ? 'animate-spin' : ''}`} />
          </Button>
        </div>
        <CardDescription className="text-black/60">
          Track when and how the AI has automatically refined matching criteria
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        ) : refinements && refinements.length > 0 ? (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {refinements.map((event) => {
                const { analysis, changes } = parseMessage(event.message);
                const isExpanded = expandedId === event.id;

                return (
                  <div
                    key={event.id}
                    className="p-4 rounded-xl border border-black/10 bg-white/50 transition-all duration-200 hover:shadow-md"
                  >
                    <div 
                      className="flex items-start justify-between cursor-pointer"
                      onClick={() => setExpandedId(isExpanded ? null : event.id)}
                    >
                      <div className="flex items-start gap-3 flex-1">
                        <div className="p-2 rounded-lg bg-purple-100">
                          <Sparkles className="w-4 h-4 text-purple-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium text-sm text-black">
                              Criteria Refined
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {event.candidate_name}
                            </Badge>
                          </div>
                          <p className="text-xs text-black/60 mt-1">
                            {formatDateTime(event.created_at)}
                          </p>
                          <p className={`text-sm text-black/80 mt-2 ${isExpanded ? '' : 'line-clamp-2'}`}>
                            {analysis}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="ml-2 shrink-0">
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </Button>
                    </div>

                    {isExpanded && changes.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-black/10">
                        <p className="text-xs font-medium text-black/60 mb-2">Changes Made:</p>
                        <ul className="space-y-1">
                          {changes.map((change, idx) => (
                            <li key={idx} className="text-sm text-black/80 flex items-start gap-2">
                              <span className="text-purple-600 mt-1">•</span>
                              <span>{change.trim()}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        ) : (
          <div className="text-center py-8">
            <History className="w-12 h-12 text-black/20 mx-auto mb-3" />
            <p className="text-sm text-black/60">No refinements yet</p>
            <p className="text-xs text-black/40 mt-1">
              The AI will automatically refine matching criteria after job searches
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
