import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Trash2, GripVertical, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PreSearchOption {
  id: string;
  question_key: string;
  option_value: string;
  is_default: boolean;
  display_order: number;
}

const QUESTION_LABELS: Record<string, string> = {
  desired_location: "Desired Location",
  desired_salary: "Desired Salary",
  reason_for_looking: "Reason for Looking",
  sponsorship_requirements: "Sponsorship Requirements",
  education: "Education",
  certifications: "Certifications",
};

const QUESTION_KEYS = Object.keys(QUESTION_LABELS);

export function PreSearchOptionsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState(QUESTION_KEYS[0]);
  const [newOptionValue, setNewOptionValue] = useState("");

  const { data: options = [], isLoading } = useQuery({
    queryKey: ["pre-search-options"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pre_search_options")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as PreSearchOption[];
    },
  });

  const addMutation = useMutation({
    mutationFn: async ({ questionKey, value }: { questionKey: string; value: string }) => {
      const maxOrder = options
        .filter((o) => o.question_key === questionKey)
        .reduce((max, o) => Math.max(max, o.display_order), 0);
      
      const { error } = await supabase.from("pre_search_options").insert({
        question_key: questionKey,
        option_value: value,
        display_order: maxOrder + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pre-search-options"] });
      setNewOptionValue("");
      toast({ title: "Option added" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<PreSearchOption> }) => {
      const { error } = await supabase
        .from("pre_search_options")
        .update(updates)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pre-search-options"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("pre_search_options").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pre-search-options"] });
      toast({ title: "Option deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleAddOption = () => {
    if (!newOptionValue.trim()) return;
    addMutation.mutate({ questionKey: activeTab, value: newOptionValue.trim() });
  };

  const handleToggleDefault = (option: PreSearchOption) => {
    updateMutation.mutate({
      id: option.id,
      updates: { is_default: !option.is_default },
    });
  };

  const filteredOptions = options.filter((o) => o.question_key === activeTab);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Pre-Search Question Options</CardTitle>
        <p className="text-sm text-muted-foreground">
          Configure dropdown options for each pre-search question. Users can multi-select from these options.
        </p>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="flex flex-wrap h-auto gap-1 bg-muted/50 p-1">
            {QUESTION_KEYS.map((key) => (
              <TabsTrigger
                key={key}
                value={key}
                className="text-xs px-3 py-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                {QUESTION_LABELS[key]}
              </TabsTrigger>
            ))}
          </TabsList>

          {QUESTION_KEYS.map((key) => (
            <TabsContent key={key} value={key} className="mt-4 space-y-4">
              {/* Add new option */}
              <div className="flex gap-2">
                <Input
                  placeholder={`Add new ${QUESTION_LABELS[key].toLowerCase()} option...`}
                  value={activeTab === key ? newOptionValue : ""}
                  onChange={(e) => setNewOptionValue(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAddOption()}
                  className="flex-1 bg-background border-border"
                />
                <Button
                  onClick={handleAddOption}
                  disabled={!newOptionValue.trim() || addMutation.isPending}
                  size="sm"
                  className="bg-primary hover:bg-primary/90"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add
                </Button>
              </div>

              {/* Options list */}
              <div className="space-y-2">
                {filteredOptions.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No options configured. Add some above.
                  </p>
                ) : (
                  filteredOptions.map((option) => (
                    <div
                      key={option.id}
                      className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 border border-border hover:bg-muted/50 transition-colors"
                    >
                      <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
                      <span className="flex-1 text-sm font-medium">{option.option_value}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">Default</span>
                        <Switch
                          checked={option.is_default}
                          onCheckedChange={() => handleToggleDefault(option)}
                          className="data-[state=checked]:bg-accent"
                        />
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteMutation.mutate(option.id)}
                        disabled={deleteMutation.isPending}
                        className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}
