import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Key,
  AlertTriangle,
  Eye,
  EyeOff,
  Save,
  RefreshCw,
  ExternalLink,
  Shield,
  CheckCircle2,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface ApiKeyField {
  id: string;
  label: string;
  secretName: string;
  placeholder: string;
  type: "password" | "text";
  description?: string;
  connectorManaged?: boolean;
  connectorUrl?: string;
}

const apiKeyFields: ApiKeyField[] = [
  {
    id: "firecrawl",
    label: "Firecrawl API Key",
    secretName: "FIRECRAWL_API_KEY",
    placeholder: "fc-xxxxxxxxxxxxxxxx",
    type: "password",
    description: "Used for job board scraping and search",
    connectorUrl: "https://www.firecrawl.dev/",
  },
  // Contact enrichment now uses Apollo (same as company enrichment) - no separate key needed
  {
    id: "ms365_host",
    label: "Microsoft 365 SMTP Host",
    secretName: "MS365_SMTP_HOST",
    placeholder: "smtp.office365.com",
    type: "text",
    description: "SMTP server for sending emails",
  },
  {
    id: "ms365_user",
    label: "Microsoft 365 SMTP User",
    secretName: "MS365_SMTP_USER",
    placeholder: "user@company.com",
    type: "text",
    description: "Email account for sending",
  },
  {
    id: "ms365_password",
    label: "Microsoft 365 SMTP Password",
    secretName: "MS365_SMTP_PASSWORD",
    placeholder: "••••••••••••",
    type: "password",
    description: "App password for SMTP authentication",
  },
  {
    id: "lovable",
    label: "Lovable API Key",
    secretName: "LOVABLE_API_KEY",
    placeholder: "lv-xxxxxxxxxxxxxxxx",
    type: "password",
    description: "Used for CV parsing and job matching AI",
    connectorManaged: true,
  },
];

interface ApiKeyInputProps {
  field: ApiKeyField;
  isAdmin: boolean;
}

function ApiKeyInput({ field, isAdmin }: ApiKeyInputProps) {
  const [value, setValue] = useState("");
  const [showValue, setShowValue] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [hasValue, setHasValue] = useState(true); // Assume all have values initially

  const handleSave = async () => {
    if (!value.trim()) {
      toast.error("Please enter a value");
      return;
    }

    setIsSaving(true);
    
    try {
      const { data, error } = await supabase.functions.invoke("update-secret", {
        body: { secretName: field.secretName, secretValue: value.trim() },
      });

      if (error) throw error;
      
      toast.success(`${field.label} updated successfully`);
      setIsEditing(false);
      setValue("");
      setHasValue(true);
    } catch (err) {
      console.error("Failed to update secret:", err);
      toast.error(`Failed to update ${field.label}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setValue("");
  };

  return (
    <div className="p-4 rounded-xl border-2 border-black/10 bg-white/50 transition-all duration-200 hover:border-black/15 hover:bg-white/70">
      <div className="flex items-start justify-between gap-4 mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <Label className="text-black font-semibold">{field.label}</Label>
            {field.connectorManaged && (
              <Badge className="bg-blue-100 text-blue-700 border-blue-200 text-xs hover:bg-blue-100">
                <Shield className="w-3 h-3 mr-1" />
                Connector
              </Badge>
            )}
          </div>
          {field.description && (
            <p className="text-xs text-black/60">{field.description}</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          {hasValue && !isEditing && (
            <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Set
            </Badge>
          )}
          {field.connectorUrl && (
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 text-black/50 hover:text-black hover:bg-black/5"
              onClick={() => window.open(field.connectorUrl, "_blank")}
              title="Open service website"
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {isEditing ? (
        <div className="space-y-3">
          <div className="relative">
            <Input
              type={showValue ? "text" : "password"}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder={field.placeholder}
              className="pr-10 bg-white border-black/20 text-black font-mono text-sm"
              disabled={field.connectorManaged}
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0 text-black/50 hover:text-black hover:bg-black/5"
              onClick={() => setShowValue(!showValue)}
            >
              {showValue ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </div>
          
          {field.connectorManaged ? (
            <div className="flex items-center gap-2 p-2 rounded-lg bg-blue-50 text-blue-700 text-xs">
              <Shield className="w-4 h-4 flex-shrink-0" />
              <span>This key is managed by a connector. Edit via Settings → Connectors.</span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                onClick={handleSave}
                disabled={isSaving || !value.trim()}
                className="bg-purple-600 hover:bg-purple-700 text-white border-0"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-1 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-1" />
                    Save
                  </>
                )}
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCancel}
                className="border-black/20 text-black hover:bg-black/5"
              >
                Cancel
              </Button>
            </div>
          )}
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <Input
            type="password"
            value="••••••••••••••••"
            readOnly
            className="bg-white/80 border-black/10 text-black font-mono text-sm cursor-default"
          />
          {isAdmin && !field.connectorManaged && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsEditing(true)}
              className="border-black/20 text-black hover:bg-black/5 whitespace-nowrap"
            >
              Edit
            </Button>
          )}
          {field.connectorManaged && isAdmin && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsEditing(true)}
              className="border-blue-200 text-blue-700 hover:bg-blue-50 whitespace-nowrap"
            >
              View
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

export function ApiKeysManager() {
  const { hasRole } = useAuth();
  const isAdmin = hasRole("admin");

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-black/10">
        <div className="flex items-center gap-2">
          <Key className="w-5 h-5 text-black" />
          <CardTitle className="font-display text-black">API Configuration</CardTitle>
        </div>
        <CardDescription className="text-black/60">
          Manage API keys for external services. {!isAdmin && "Contact an admin to make changes."}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 pt-6">
        {/* Security Warning */}
        <div className="p-4 rounded-xl bg-amber-50 border-2 border-amber-200 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-sm text-amber-800">API keys are sensitive</p>
            <p className="text-xs text-amber-700/80 mt-1">
              Never share your API keys. They provide access to third-party services and are stored securely encrypted.
            </p>
          </div>
        </div>

        {/* API Key Fields */}
        <div className="grid gap-4">
          {apiKeyFields.map((field) => (
            <ApiKeyInput key={field.id} field={field} isAdmin={isAdmin} />
          ))}
        </div>

        {/* Admin Note */}
        {isAdmin && (
          <div className="p-4 rounded-xl bg-purple-50 border-2 border-purple-200 flex items-start gap-3">
            <Shield className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-sm text-purple-800">Admin Access</p>
              <p className="text-xs text-purple-700/80 mt-1">
                You can edit API keys directly. Connector-managed keys (like Firecrawl) must be updated through the Lovable Settings → Connectors panel.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
