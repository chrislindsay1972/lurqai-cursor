import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Shield, Lock } from "lucide-react";
import { useModulePermissions, MODULES, ROLES } from "@/hooks/useModulePermissions";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export function ModuleAccessControl() {
  const { permissions, isLoading, updatePermission, getPermission } = useModulePermissions();

  const handleToggle = (role: string, module: string, currentValue: boolean) => {
    // Prevent disabling admin access to settings (they need it to manage permissions)
    if (role === 'admin' && module === 'settings') {
      return;
    }
    updatePermission.mutate({ role, module, hasAccess: !currentValue });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-accent" />
            <CardTitle className="font-display">Module Access Control</CardTitle>
          </div>
          <CardDescription>Loading permissions...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-accent" />
          <CardTitle className="font-display">Module Access Control</CardTitle>
        </div>
        <CardDescription>
          Configure which user roles can access each module in the system
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="font-semibold">Module</TableHead>
                {ROLES.map((role) => (
                  <TableHead key={role.key} className="text-center font-semibold">
                    <Badge 
                      variant={role.key === 'admin' ? 'default' : 'secondary'}
                      className={role.key === 'admin' ? 'bg-accent/10 text-accent border-0' : ''}
                    >
                      {role.label}
                    </Badge>
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {MODULES.map((module) => (
                <TableRow key={module.key} className="hover:bg-muted/30">
                  <TableCell>
                    <div>
                      <p className="font-medium text-sm">{module.label}</p>
                      <p className="text-xs text-muted-foreground">{module.description}</p>
                    </div>
                  </TableCell>
                  {ROLES.map((role) => {
                    const hasAccess = getPermission(role.key, module.key);
                    const isLocked = role.key === 'admin' && module.key === 'settings';
                    
                    return (
                      <TableCell key={role.key} className="text-center">
                        <div className="flex items-center justify-center">
                          {isLocked ? (
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <Lock className="w-3 h-3" />
                              <Switch checked={true} disabled className="opacity-50" />
                            </div>
                          ) : (
                            <Switch
                              checked={hasAccess}
                              onCheckedChange={() => handleToggle(role.key, module.key, hasAccess)}
                              disabled={updatePermission.isPending}
                            />
                          )}
                        </div>
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <p className="text-xs text-muted-foreground mt-3">
          <Lock className="w-3 h-3 inline mr-1" />
          Admin access to Settings is always enabled to ensure administrators can manage permissions.
        </p>
      </CardContent>
    </Card>
  );
}
