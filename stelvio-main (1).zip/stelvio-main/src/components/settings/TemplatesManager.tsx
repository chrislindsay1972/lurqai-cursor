import { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Plus,
  FileText,
  Loader2,
  Pencil,
  Copy,
  Trash2,
} from "lucide-react";
import { EmailTemplateEditor } from "@/components/campaigns/EmailTemplateEditor";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body_html: string;
  placeholders: string[] | null;
  include_unsubscribe_link: boolean;
  include_cv_attachment: boolean;
  created_at: string;
  created_by: string | null;
}

export function TemplatesManager() {
  const { formatShortDate } = useLocaleFormat();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [deleteTarget, setDeleteTarget] = useState<EmailTemplate | null>(null);

  const { data: templates = [], isLoading, isFetching } = useQuery({
    queryKey: ["email-templates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_templates")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as EmailTemplate[];
    },
    placeholderData: (prev) => prev,
  });

  // Derive editor state from URL param "editTemplate"
  const editTemplateId = searchParams.get("editTemplate");
  const isTemplateOpen = editTemplateId !== null;
  const editingTemplate = editTemplateId && editTemplateId !== "new"
    ? (templates.find(t => t.id === editTemplateId) || null)
    : null;

  const setIsTemplateOpen = useCallback((open: boolean) => {
    setSearchParams(prev => {
      const next = new URLSearchParams(prev);
      if (!open) {
        next.delete("editTemplate");
      }
      return next;
    }, { replace: true });
  }, [setSearchParams]);

  const openTemplateEditor = useCallback((template?: EmailTemplate) => {
    setSearchParams(prev => {
      const next = new URLSearchParams(prev);
      next.set("editTemplate", template?.id || "new");
      return next;
    }, { replace: true });
  }, [setSearchParams]);

  const cloneMutation = useMutation({
    mutationFn: async (template: EmailTemplate) => {
      const { error } = await supabase.from("email_templates").insert({
        name: `${template.name} (Copy)`,
        subject: template.subject,
        body_html: template.body_html,
        placeholders: template.placeholders,
        include_unsubscribe_link: template.include_unsubscribe_link,
        created_by: user?.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-templates"] });
      toast.success("Template cloned");
    },
    onError: (error: any) => toast.error("Failed to clone: " + error.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      // Check if template is used in any campaign steps
      const { data: usages, error: usageError } = await supabase
        .from("campaign_steps")
        .select("id, campaign_id")
        .eq("template_id", id);
      if (usageError) throw usageError;
      if (usages && usages.length > 0) {
        throw new Error(`This template is used in ${usages.length} campaign step(s). Remove it from campaigns first before deleting.`);
      }
      const { error } = await supabase.from("email_templates").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-templates"] });
      toast.success("Template deleted");
      setDeleteTarget(null);
    },
    onError: (error: any) => {
      const msg = error.message || "";
      if (msg.includes("foreign key constraint") || msg.includes("campaign_steps")) {
        toast.error("This template is used in one or more campaign steps. Remove it from campaigns first before deleting.");
      } else {
        toast.error("Failed to delete: " + msg);
      }
    },
  });


  return (
    <>
      <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
        <CardHeader className="border-b border-black/10">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="font-display text-card-foreground">Email Templates</CardTitle>
              <CardDescription className="text-muted-foreground">
                Create and manage reusable email templates for campaigns
              </CardDescription>
            </div>
            <Button size="sm" onClick={() => openTemplateEditor()}>
              <Plus className="w-4 h-4 mr-2" />
              New Template
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : templates.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8">
              <FileText className="w-12 h-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground text-center mb-4">
                No email templates yet. Create your first template to get started.
              </p>
              <Button onClick={() => openTemplateEditor()}>
                <Plus className="w-4 h-4 mr-2" />
                Create Template
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {templates.map((template, index) => (
                <Card
                  key={template.id}
                  className="hover:shadow-md transition-all duration-300 animate-scale-in cursor-pointer group"
                  style={{ animationDelay: `${index * 50}ms` }}
                  onClick={() => openTemplateEditor(template)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-base font-display">
                        {template.name}
                      </CardTitle>
                      <div className="flex opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          title="Edit"
                          onClick={(e) => {
                            e.stopPropagation();
                            openTemplateEditor(template);
                          }}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          title="Clone"
                          onClick={(e) => {
                            e.stopPropagation();
                            cloneMutation.mutate(template);
                          }}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          title="Delete"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDeleteTarget(template);
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="text-xs truncate">
                      {template.subject}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {template.body_html.replace(/<[^>]*>/g, "").slice(0, 100)}
                      {template.body_html.length > 100 ? "..." : ""}
                    </p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {template.placeholders?.length || 0} placeholders
                      </span>
                      <Badge variant="secondary">
                        {formatShortDate(template.created_at)}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <EmailTemplateEditor
        template={editingTemplate}
        open={isTemplateOpen}
        onOpenChange={setIsTemplateOpen}
        onSaved={() => {}}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Template</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deleteTarget?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
