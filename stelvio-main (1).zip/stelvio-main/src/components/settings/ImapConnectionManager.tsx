import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Mail, Plus, Trash2, RefreshCw, CheckCircle, XCircle, Loader2, Settings2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";

interface EmailConnection {
  id: string;
  connection_name: string;
  email_address: string;
  imap_host: string;
  imap_port: number;
  use_oauth: boolean;
  is_active: boolean;
  last_sync_at: string | null;
  last_sync_status: string | null;
  sync_interval_minutes: number;
  created_at: string;
}

export function ImapConnectionManager() {
  const { formatDateTime } = useLocaleFormat();
  const queryClient = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [deleteConnectionId, setDeleteConnectionId] = useState<string | null>(null);
  const [syncingConnectionId, setSyncingConnectionId] = useState<string | null>(null);
  const [isConnectingOAuth, setIsConnectingOAuth] = useState(false);
  
  // Form state
  const [connectionName, setConnectionName] = useState("");

  // Handle OAuth callback params
  useEffect(() => {
    const success = searchParams.get("success");
    const error = searchParams.get("error");
    const tab = searchParams.get("tab");

    if (tab === "email") {
      if (success === "true") {
        toast.success("Office 365 account connected successfully!");
        queryClient.invalidateQueries({ queryKey: ["email-connections"] });
      } else if (error) {
        toast.error(`OAuth error: ${error}`);
      }
      // Clean up URL params
      setSearchParams({});
    }
  }, [searchParams, setSearchParams, queryClient]);

  // Fetch connections
  const { data: connections, isLoading } = useQuery({
    queryKey: ["email-connections"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_connections")
        .select("*")
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      return data as EmailConnection[];
    },
  });

  // Delete connection mutation
  const deleteConnectionMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("email_connections")
        .delete()
        .eq("id", id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-connections"] });
      setDeleteConnectionId(null);
      toast.success("Email connection deleted");
    },
    onError: (error) => {
      toast.error(`Failed to delete connection: ${error.message}`);
    },
  });

  // Toggle active status mutation
  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase
        .from("email_connections")
        .update({ is_active })
        .eq("id", id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-connections"] });
    },
    onError: (error) => {
      toast.error(`Failed to update connection: ${error.message}`);
    },
  });

  // Start OAuth flow
  const handleConnectOAuth = async () => {
    if (!connectionName.trim()) {
      toast.error("Please enter a connection name");
      return;
    }

    setIsConnectingOAuth(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Please sign in to connect your email");
        return;
      }

      const response = await supabase.functions.invoke("ms365-oauth-start", {
        body: { connectionName: connectionName.trim() },
      });

      if (response.error) {
        throw new Error(response.error.message);
      }

      // Redirect to Microsoft OAuth
      window.location.href = response.data.authUrl;
    } catch (error: any) {
      toast.error(`Failed to start OAuth: ${error.message}`);
      setIsConnectingOAuth(false);
    }
  };

  // Manual sync trigger
  const handleSyncNow = async (connectionId: string) => {
    setSyncingConnectionId(connectionId);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Please sign in to sync emails");
        return;
      }

      const response = await supabase.functions.invoke("sync-emails", {
        body: { connectionId },
      });

      if (response.error) {
        throw new Error(response.error.message);
      }

      if (response.data.error) {
        throw new Error(response.data.message || response.data.error);
      }

      toast.success(response.data.message || `Synced ${response.data.syncedCount || 0} emails`);
      queryClient.invalidateQueries({ queryKey: ["email-connections"] });
    } catch (error: any) {
      toast.error(`Sync failed: ${error.message}`);
    } finally {
      setSyncingConnectionId(null);
    }
  };

  const getStatusBadge = (connection: EmailConnection) => {
    if (!connection.use_oauth) {
      return (
        <Badge variant="outline" className="text-amber-600 border-amber-300 bg-amber-50">
          Needs OAuth
        </Badge>
      );
    }
    if (connection.last_sync_status === "token_expired") {
      return (
        <Badge variant="outline" className="text-red-600 border-red-300 bg-red-50">
          Reconnect Required
        </Badge>
      );
    }
    if (connection.last_sync_status === "oauth_connected") {
      return (
        <Badge className="bg-blue-100 text-blue-700 border-blue-200">
          Ready to Sync
        </Badge>
      );
    }
    if (connection.is_active) {
      return (
        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">
          Active
        </Badge>
      );
    }
    return (
      <Badge variant="outline" className="text-muted-foreground">
        Paused
      </Badge>
    );
  };

  return (
    <>
      <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
        <CardHeader className="border-b border-black/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-black" />
              <CardTitle className="font-display text-black">Office 365 Email Connections</CardTitle>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Connect Account
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[450px]">
                <DialogHeader>
                  <DialogTitle>Connect Office 365 Email</DialogTitle>
                  <DialogDescription>
                    Sign in with your Microsoft account to sync emails. We'll use OAuth for secure access.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="connection_name">Connection Name *</Label>
                    <Input
                      id="connection_name"
                      placeholder="e.g., Main Office Email"
                      value={connectionName}
                      onChange={(e) => setConnectionName(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      A friendly name to identify this email connection
                    </p>
                  </div>
                  <div className="rounded-lg bg-blue-50 p-4 text-sm text-blue-800">
                    <div className="flex items-start gap-2">
                      <ExternalLink className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Secure OAuth Authentication</p>
                        <p className="mt-1 text-blue-700">
                          You'll be redirected to Microsoft to sign in. We only request read access to your Inbox and Sent folders.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleConnectOAuth}
                    disabled={isConnectingOAuth || !connectionName.trim()}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    {isConnectingOAuth ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Connecting...
                      </>
                    ) : (
                      <>
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Sign in with Microsoft
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <CardDescription className="text-black/60">
            Connect to Office 365 via Microsoft Graph API to sync and view emails linked to companies and stakeholders
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
            </div>
          ) : connections && connections.length > 0 ? (
            <div className="space-y-3">
              {connections.map((connection) => (
                <div
                  key={connection.id}
                  className="flex items-center justify-between p-4 rounded-xl bg-white/50 border border-black/10 transition-all duration-200 hover:bg-white/80 hover:shadow-md"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <Mail className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm text-black">
                          {connection.connection_name}
                        </p>
                        {getStatusBadge(connection)}
                      </div>
                      <p className="text-xs text-black/60">
                        {connection.email_address === "pending@oauth" 
                          ? "OAuth pending..." 
                          : connection.email_address}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        {connection.last_sync_at && (
                          <span className="text-xs text-muted-foreground">
                            Last sync: {formatDateTime(connection.last_sync_at)}
                          </span>
                        )}
                        {connection.last_sync_status === "success" && (
                          <CheckCircle className="w-3 h-3 text-emerald-500" />
                        )}
                        {connection.last_sync_status === "partial" && (
                          <XCircle className="w-3 h-3 text-amber-500" />
                        )}
                        {(connection.last_sync_status === "token_expired" || connection.last_sync_status === "error") && (
                          <XCircle className="w-3 h-3 text-red-500" />
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {connection.use_oauth && connection.last_sync_status !== "token_expired" && (
                      <Switch
                        checked={connection.is_active}
                        onCheckedChange={(checked) =>
                          toggleActiveMutation.mutate({ id: connection.id, is_active: checked })
                        }
                      />
                    )}
                    {connection.use_oauth && connection.email_address !== "pending@oauth" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleSyncNow(connection.id)}
                        disabled={syncingConnectionId === connection.id}
                        title="Sync now"
                      >
                        {syncingConnectionId === connection.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <RefreshCw className="w-4 h-4" />
                        )}
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-red-500 hover:text-red-600 hover:bg-red-50"
                      onClick={() => setDeleteConnectionId(connection.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Settings2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No email connections configured</p>
              <p className="text-sm">Connect your Office 365 account to start syncing emails</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteConnectionId} onOpenChange={() => setDeleteConnectionId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Email Connection?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the connection and all synced emails. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-500 hover:bg-red-600"
              onClick={() => deleteConnectionId && deleteConnectionMutation.mutate(deleteConnectionId)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
