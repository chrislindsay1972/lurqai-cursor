import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings2 } from "lucide-react";
import { ModuleType } from "@/hooks/useCustomFields";
import { ModuleFieldsManager } from "./ModuleFieldsManager";

const MODULES: { id: ModuleType; label: string; icon: string }[] = [
  { id: 'candidates', label: 'Candidates', icon: '👤' },
  { id: 'jobs', label: 'Jobs', icon: '💼' },
  { id: 'companies', label: 'Companies', icon: '🏢' },
  { id: 'stakeholders', label: 'Stakeholders', icon: '🤝' },
  { id: 'job_boards', label: 'Job Boards', icon: '📋' },
];

export function FieldManagement() {
  const [activeModule, setActiveModule] = useState<ModuleType>('candidates');

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Settings2 className="w-5 h-5 text-accent" />
          <CardTitle className="font-display">Field Management</CardTitle>
        </div>
        <CardDescription>
          Add custom fields and reorder fields for each module
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeModule} onValueChange={(v) => setActiveModule(v as ModuleType)}>
          <TabsList className="grid grid-cols-5 mb-6">
            {MODULES.map((module) => (
              <TabsTrigger key={module.id} value={module.id} className="text-xs sm:text-sm">
                <span className="mr-1.5 hidden sm:inline">{module.icon}</span>
                {module.label}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {MODULES.map((module) => (
            <TabsContent key={module.id} value={module.id}>
              <ModuleFieldsManager module={module.id} />
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}
