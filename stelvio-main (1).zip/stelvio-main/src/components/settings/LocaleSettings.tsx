import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Clock, Calendar, Globe2, ChevronsUpDown, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import { invalidateLocaleCache } from "@/hooks/useLocaleFormat";

const DATE_FORMATS = [
  { value: "dd/MM/yyyy", label: "DD/MM/YYYY", example: "15/02/2026" },
  { value: "MM/dd/yyyy", label: "MM/DD/YYYY", example: "02/15/2026" },
  { value: "yyyy-MM-dd", label: "YYYY-MM-DD", example: "2026-02-15" },
  { value: "dd-MM-yyyy", label: "DD-MM-YYYY", example: "15-02-2026" },
  { value: "dd.MM.yyyy", label: "DD.MM.YYYY", example: "15.02.2026" },
  { value: "MMM dd, yyyy", label: "Mon DD, YYYY", example: "Feb 15, 2026" },
  { value: "dd MMM yyyy", label: "DD Mon YYYY", example: "15 Feb 2026" },
  { value: "MMMM dd, yyyy", label: "Month DD, YYYY", example: "February 15, 2026" },
];

const TIME_FORMATS = [
  { value: "HH:mm", label: "24-hour (14:30)" },
  { value: "hh:mm a", label: "12-hour (2:30 PM)" },
  { value: "HH:mm:ss", label: "24-hour with seconds (14:30:00)" },
  { value: "hh:mm:ss a", label: "12-hour with seconds (2:30:00 PM)" },
];

const TIMEZONES = [
  { value: "UTC", label: "UTC (Coordinated Universal Time)" },
  { value: "Europe/London", label: "London (GMT/BST)" },
  { value: "Europe/Paris", label: "Paris (CET/CEST)" },
  { value: "Europe/Berlin", label: "Berlin (CET/CEST)" },
  { value: "Europe/Amsterdam", label: "Amsterdam (CET/CEST)" },
  { value: "Europe/Madrid", label: "Madrid (CET/CEST)" },
  { value: "Europe/Rome", label: "Rome (CET/CEST)" },
  { value: "Europe/Zurich", label: "Zurich (CET/CEST)" },
  { value: "Europe/Stockholm", label: "Stockholm (CET/CEST)" },
  { value: "Europe/Dublin", label: "Dublin (GMT/IST)" },
  { value: "Europe/Moscow", label: "Moscow (MSK)" },
  { value: "America/New_York", label: "New York (EST/EDT)" },
  { value: "America/Chicago", label: "Chicago (CST/CDT)" },
  { value: "America/Denver", label: "Denver (MST/MDT)" },
  { value: "America/Los_Angeles", label: "Los Angeles (PST/PDT)" },
  { value: "America/Toronto", label: "Toronto (EST/EDT)" },
  { value: "America/Vancouver", label: "Vancouver (PST/PDT)" },
  { value: "America/Sao_Paulo", label: "São Paulo (BRT)" },
  { value: "Asia/Dubai", label: "Dubai (GST)" },
  { value: "Asia/Kolkata", label: "Mumbai/Kolkata (IST)" },
  { value: "Asia/Singapore", label: "Singapore (SGT)" },
  { value: "Asia/Hong_Kong", label: "Hong Kong (HKT)" },
  { value: "Asia/Tokyo", label: "Tokyo (JST)" },
  { value: "Asia/Shanghai", label: "Shanghai (CST)" },
  { value: "Asia/Seoul", label: "Seoul (KST)" },
  { value: "Australia/Sydney", label: "Sydney (AEST/AEDT)" },
  { value: "Australia/Melbourne", label: "Melbourne (AEST/AEDT)" },
  { value: "Australia/Perth", label: "Perth (AWST)" },
  { value: "Pacific/Auckland", label: "Auckland (NZST/NZDT)" },
  { value: "Africa/Johannesburg", label: "Johannesburg (SAST)" },
  { value: "Africa/Lagos", label: "Lagos (WAT)" },
  { value: "Africa/Cairo", label: "Cairo (EET)" },
];

export function LocaleSettings() {
  const [dateFormat, setDateFormat] = useState("dd/MM/yyyy");
  const [timeFormat, setTimeFormat] = useState("HH:mm");
  const [timezone, setTimezone] = useState("Europe/London");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data } = await supabase
        .from("app_settings")
        .select("setting_key, setting_value")
        .in("setting_key", ["locale_date_format", "locale_time_format", "locale_timezone"]);

      for (const s of data || []) {
        if (s.setting_key === "locale_date_format") setDateFormat(s.setting_value);
        if (s.setting_key === "locale_time_format") setTimeFormat(s.setting_value);
        if (s.setting_key === "locale_timezone") setTimezone(s.setting_value);
      }
    } catch (e) {
      console.error("Failed to load locale settings:", e);
    } finally {
      setLoading(false);
    }
  }

  async function saveSettings() {
    setSaving(true);
    try {
      const settings = [
        { setting_key: "locale_date_format", setting_value: dateFormat, setting_type: "string", description: "Date display format" },
        { setting_key: "locale_time_format", setting_value: timeFormat, setting_type: "string", description: "Time display format" },
        { setting_key: "locale_timezone", setting_value: timezone, setting_type: "string", description: "Local timezone" },
      ];

      for (const s of settings) {
        const { data: existing } = await supabase
          .from("app_settings")
          .select("id")
          .eq("setting_key", s.setting_key)
          .maybeSingle();

        if (existing) {
          await supabase.from("app_settings").update({ setting_value: s.setting_value }).eq("id", existing.id);
        } else {
          await supabase.from("app_settings").insert(s);
        }
      }

      invalidateLocaleCache();
      toast.success("Locale settings saved — refresh pages to see updated formats");
    } catch (e) {
      console.error("Failed to save locale settings:", e);
      toast.error("Failed to save settings");
    } finally {
      setSaving(false);
    }
  }

  const now = new Date();
  const previewDate = (() => {
    try {
      return format(now, dateFormat);
    } catch {
      return format(now, "dd/MM/yyyy");
    }
  })();
  const previewTime = (() => {
    try {
      return format(now, timeFormat);
    } catch {
      return format(now, "HH:mm");
    }
  })();

  const previewTimezone = (() => {
    try {
      return now.toLocaleTimeString("en-US", { timeZone: timezone, timeZoneName: "short" }).split(" ").pop() || timezone;
    } catch {
      return timezone;
    }
  })();

  if (loading) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">Loading locale settings...</CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
        <CardHeader className="border-b border-black/10">
          <div className="flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-black" />
            <CardTitle className="font-display text-black">Date, Time & Locale</CardTitle>
          </div>
          <CardDescription className="text-black/60">
            Configure how dates, times, and timezones are displayed throughout the portal
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 pt-6">
          {/* Date Format */}
          <div className="space-y-2">
            <Label className="text-black font-medium flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Date Format
            </Label>
            <Select value={dateFormat} onValueChange={setDateFormat}>
              <SelectTrigger className="w-full max-w-md bg-white border-black/20 text-black">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DATE_FORMATS.map((f) => (
                  <SelectItem key={f.value} value={f.value}>
                    <span className="flex items-center justify-between gap-4">
                      <span>{f.label}</span>
                      <span className="text-muted-foreground text-xs">({f.example})</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Time Format */}
          <div className="space-y-2">
            <Label className="text-black font-medium flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Time Format
            </Label>
            <Select value={timeFormat} onValueChange={setTimeFormat}>
              <SelectTrigger className="w-full max-w-md bg-white border-black/20 text-black">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TIME_FORMATS.map((f) => (
                  <SelectItem key={f.value} value={f.value}>
                    {f.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Timezone */}
          <div className="space-y-2">
            <Label className="text-black font-medium flex items-center gap-2">
              <Globe2 className="w-4 h-4" />
              Timezone
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full max-w-md justify-between bg-white border-black/20 text-black hover:bg-white/80"
                >
                  {TIMEZONES.find((tz) => tz.value === timezone)?.label || "Select timezone..."}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[var(--radix-popover-trigger-width)] max-w-md p-0 bg-white z-50" align="start">
                <Command>
                  <CommandInput placeholder="Search timezone..." />
                  <CommandList>
                    <CommandEmpty>No timezone found.</CommandEmpty>
                    <CommandGroup>
                      {TIMEZONES.map((tz) => (
                        <CommandItem
                          key={tz.value}
                          value={tz.label}
                          onSelect={() => setTimezone(tz.value)}
                        >
                          <Check className={cn("mr-2 h-4 w-4", timezone === tz.value ? "opacity-100" : "opacity-0")} />
                          {tz.label}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {/* Preview */}
          <div className="rounded-xl border-2 border-dashed border-black/15 bg-white/50 p-5 max-w-md">
            <p className="text-xs font-medium text-black/50 uppercase tracking-wider mb-3">Preview</p>
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <Calendar className="w-4 h-4 text-black/40" />
                <span className="text-sm font-medium text-black">{previewDate}</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-black/40" />
                <span className="text-sm font-medium text-black">{previewTime}</span>
              </div>
              <div className="flex items-center gap-3">
                <Globe2 className="w-4 h-4 text-black/40" />
                <span className="text-sm font-medium text-black">{previewTimezone}</span>
              </div>
            </div>
          </div>

          <Button
            onClick={saveSettings}
            disabled={saving}
            className="bg-purple-600 hover:bg-purple-700 text-white border-0 transition-all duration-200 shadow-md hover:shadow-lg"
          >
            {saving ? "Saving..." : "Save Locale Settings"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
