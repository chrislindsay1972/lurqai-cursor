import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { 
  Pen, 
  Upload, 
  Trash2, 
  Save, 
  Eye, 
  Palette,
  Type,
  Image as ImageIcon,
  Linkedin,
  Phone,
  Globe,
  Building2,
  Loader2,
  Mail
} from "lucide-react";

// Available signature fonts
const SIGNATURE_FONTS = [
  { value: "atos-body", label: "ATOS Body", family: "'ATOS Body', sans-serif" },
  // NOTE: "Inter" and many custom fonts are not reliably available in email clients.
  // To ensure the Settings preview matches what gets delivered, we use an email-safe fallback.
  { value: "inter", label: "Inter", family: "Arial, sans-serif" },
  { value: "georgia", label: "Georgia", family: "'Georgia', serif" },
  { value: "times", label: "Times New Roman", family: "'Times New Roman', serif" },
  { value: "arial", label: "Arial", family: "'Arial', sans-serif" },
  { value: "helvetica", label: "Helvetica", family: "'Helvetica Neue', 'Helvetica', sans-serif" },
  { value: "verdana", label: "Verdana", family: "'Verdana', sans-serif" },
  { value: "trebuchet", label: "Trebuchet MS", family: "'Trebuchet MS', sans-serif" },
  { value: "palatino", label: "Palatino", family: "'Palatino Linotype', 'Palatino', serif" },
  { value: "garamond", label: "Garamond", family: "'Garamond', serif" },
  { value: "courier", label: "Courier New", family: "'Courier New', monospace" },
];

interface SignatureSettings {
  signOff: string;
  fullName: string;
  jobTitle: string;
  company: string;
  email: string;
  phone: string;
  website: string;
  linkedin: string;
  fontFamily: string;
  fontSize: number;
  primaryColor: string;
  secondaryColor: string;
  showLogo: boolean;
  logoUrl: string | null;
  logoSize: number;
  showSocialIcons: boolean;
  dividerStyle: "line" | "dots" | "none";
}

const SIGN_OFF_OPTIONS = [
  "Best Regards",
  "Kind Regards",
  "Regards",
  "Best",
  "Thanks",
  "Thank you",
  "Warm Regards",
  "Sincerely",
  "Yours faithfully",
];

const DEFAULT_SETTINGS: SignatureSettings = {
  signOff: "Best Regards",
  fullName: "",
  jobTitle: "",
  company: "LurqAI",
  email: "",
  phone: "",
  website: "https://lurqai.com",
  linkedin: "",
  fontFamily: "inter",
  fontSize: 14,
  primaryColor: "#6B21A8",
  secondaryColor: "#1F2937",
  showLogo: true,
  logoUrl: null,
  logoSize: 80,
  showSocialIcons: true,
  dividerStyle: "line",
};

export function SignatureManager() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<SignatureSettings>(DEFAULT_SETTINGS);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      // Load signature settings from app_settings
      const { data, error } = await supabase
        .from("app_settings")
        .select("*")
        .eq("setting_key", "email_signature")
        .single();

      if (error && error.code !== "PGRST116") {
        console.error("Error loading signature settings:", error);
      }

      if (data) {
        const savedSettings = JSON.parse(data.setting_value);
        setSettings({ ...DEFAULT_SETTINGS, ...savedSettings });
      } else {
        // Pre-fill with user data
        setSettings(prev => ({
          ...prev,
          fullName: user?.user_metadata?.full_name || "",
          email: user?.email || "",
        }));
      }
    } catch (error) {
      console.error("Error loading settings:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from("app_settings")
        .upsert({
          setting_key: "email_signature",
          setting_value: JSON.stringify(settings),
          setting_type: "json",
          description: "Email signature configuration",
          updated_at: new Date().toISOString(),
        }, {
          onConflict: "setting_key",
        });

      if (error) throw error;
      toast.success("Signature settings saved successfully");
    } catch (error) {
      console.error("Error saving settings:", error);
      toast.error("Failed to save signature settings");
    } finally {
      setIsSaving(false);
    }
  };

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast.error("Please upload an image file");
      return;
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Image must be less than 2MB");
      return;
    }

    setIsUploading(true);
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `signature-logo-${Date.now()}.${fileExt}`;
      const filePath = `signatures/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from("assets")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from("assets")
        .getPublicUrl(filePath);

      setSettings(prev => ({ ...prev, logoUrl: urlData.publicUrl }));
      toast.success("Logo uploaded successfully");
    } catch (error) {
      console.error("Error uploading logo:", error);
      toast.error("Failed to upload logo. Please ensure the storage bucket exists.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveLogo = () => {
    setSettings(prev => ({ ...prev, logoUrl: null }));
  };

  const getFontFamily = (fontValue: string) => {
    return SIGNATURE_FONTS.find(f => f.value === fontValue)?.family || "'Inter', sans-serif";
  };

  const copyToClipboard = () => {
    const signatureHtml = generateSignatureHtml();
    navigator.clipboard.writeText(signatureHtml);
    toast.success("Signature HTML copied to clipboard");
  };

  const generateSignatureHtml = () => {
    const fontFamily = getFontFamily(settings.fontFamily);
    const cellStyle = `padding:4px 0;vertical-align:middle;font-size:${settings.fontSize}px;font-family:${fontFamily};`;

    // Build contact rows with plain text labels (matches campaign engine)
    const contactRows: string[] = [];
    
    if (settings.phone) {
      contactRows.push(`<tr><td style="${cellStyle}color:${settings.secondaryColor};white-space:nowrap;padding-right:12px;">Tel:</td><td style="${cellStyle}color:${settings.secondaryColor};white-space:nowrap;">${settings.phone}</td></tr>`);
    }
    
    if (settings.email) {
      contactRows.push(`<tr><td style="${cellStyle}color:${settings.secondaryColor};padding-right:12px;">Email:</td><td style="${cellStyle}"><a href="mailto:${settings.email}" style="color:${settings.primaryColor};text-decoration:none;font-family:${fontFamily};">${settings.email}</a></td></tr>`);
    }
    
    if (settings.website) {
      const displayUrl = settings.website.replace(/^https?:\/\//, "");
      contactRows.push(`<tr><td style="${cellStyle}color:${settings.secondaryColor};padding-right:12px;">Web:</td><td style="${cellStyle}"><a href="${settings.website}" style="color:${settings.primaryColor};text-decoration:none;font-family:${fontFamily};">${displayUrl}</a></td></tr>`);
    }
    
    if (settings.linkedin) {
      contactRows.push(`<tr><td style="${cellStyle}color:${settings.secondaryColor};padding-right:12px;">LinkedIn:</td><td style="${cellStyle}"><a href="${settings.linkedin}" style="color:${settings.primaryColor};text-decoration:none;font-family:${fontFamily};">LinkedIn Profile</a></td></tr>`);
    }

    const contactDivider = settings.dividerStyle !== "none"
      ? `<hr style="border:none;border-top:1px solid #d1d5db;margin:12px 0;width:250px;" />`
      : "";

    const contactTableHtml = contactRows.length > 0
      ? `<table cellpadding="0" cellspacing="0" style="font-family:${fontFamily};">${contactRows.join("")}</table>`
      : "";

    return `
<table cellpadding="0" cellspacing="0" style="font-family:${fontFamily};font-size:${settings.fontSize}px;color:${settings.secondaryColor};">
  <tr>
    ${settings.showLogo && settings.logoUrl ? `<td style="vertical-align:top;padding-right:24px;"><img src="${settings.logoUrl}" alt="Logo" style="width:${settings.logoSize}px;height:auto;" /></td>` : ""}
    <td style="vertical-align:top;">
      <p style="margin:0 0 8px 0;font-family:${fontFamily};font-size:${settings.fontSize}px;color:${settings.secondaryColor};">${settings.signOff || "Best Regards"},</p>
      <p style="margin:0;font-weight:700;font-size:${settings.fontSize + 4}px;color:${settings.secondaryColor};font-family:${fontFamily};">${settings.fullName || ""}</p>
      <p style="margin:4px 0 0 0;color:${settings.secondaryColor};font-family:${fontFamily};">${settings.jobTitle || ""}</p>
      ${settings.company ? `<p style="margin:2px 0 0 0;color:${settings.secondaryColor};font-family:${fontFamily};">${settings.company}</p>` : ""}
      ${contactDivider}
      ${contactTableHtml}
    </td>
  </tr>
</table>
    `.trim();
  };

  if (isLoading) {
    return (
      <Card className="overflow-hidden">
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="border-b border-border">
        <div className="flex items-center gap-2">
          <Pen className="w-5 h-5 text-foreground" />
          <CardTitle className="font-display text-foreground">Email Signature</CardTitle>
        </div>
        <CardDescription className="text-muted-foreground">
          Design your professional email signature with custom branding
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Settings Panel */}
          <div className="space-y-6">
            {/* Sign-Off */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Pen className="w-4 h-4" />
                Sign-Off
              </h3>
              <div className="space-y-2">
                <Label className="text-xs">Closing Greeting</Label>
                <Select
                  value={settings.signOff}
                  onValueChange={value => setSettings(prev => ({ ...prev, signOff: value }))}
                >
                  <SelectTrigger className="bg-white text-slate-900">
                    <SelectValue placeholder="Select sign-off" />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    {SIGN_OFF_OPTIONS.map(option => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Separator />

            {/* Contact Information */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Contact Information
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-xs">Full Name</Label>
                  <Input
                    value={settings.fullName}
                    onChange={e => setSettings(prev => ({ ...prev, fullName: e.target.value }))}
                    placeholder="John Doe"
                    className="bg-white text-slate-900"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Job Title</Label>
                  <Input
                    value={settings.jobTitle}
                    onChange={e => setSettings(prev => ({ ...prev, jobTitle: e.target.value }))}
                    placeholder="Senior Recruiter"
                    className="bg-white text-slate-900"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-xs">Company</Label>
                  <Input
                    value={settings.company}
                    onChange={e => setSettings(prev => ({ ...prev, company: e.target.value }))}
                    placeholder="LurqAI"
                    className="bg-white text-slate-900"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Email</Label>
                  <Input
                    value={settings.email}
                    onChange={e => setSettings(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="john@company.com"
                    className="bg-white text-slate-900"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-xs">Phone</Label>
                  <Input
                    value={settings.phone}
                    onChange={e => setSettings(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="+1 (555) 123-4567"
                    className="bg-white text-slate-900"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Website</Label>
                  <Input
                    value={settings.website}
                    onChange={e => setSettings(prev => ({ ...prev, website: e.target.value }))}
                    placeholder="https://company.com"
                    className="bg-white text-slate-900"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-xs">LinkedIn URL</Label>
                <Input
                  value={settings.linkedin}
                  onChange={e => setSettings(prev => ({ ...prev, linkedin: e.target.value }))}
                  placeholder="https://linkedin.com/in/johndoe"
                  className="bg-white text-slate-900"
                />
              </div>
            </div>

            <Separator />

            {/* Typography */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Type className="w-4 h-4" />
                Typography
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-xs">Font Family</Label>
                  <Select
                    value={settings.fontFamily}
                    onValueChange={value => setSettings(prev => ({ ...prev, fontFamily: value }))}
                  >
                    <SelectTrigger className="bg-white text-slate-900">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {SIGNATURE_FONTS.map(font => (
                        <SelectItem 
                          key={font.value} 
                          value={font.value}
                          style={{ fontFamily: font.family }}
                        >
                          {font.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Font Size: {settings.fontSize}px</Label>
                  <Slider
                    value={[settings.fontSize]}
                    onValueChange={([value]) => setSettings(prev => ({ ...prev, fontSize: value }))}
                    min={10}
                    max={18}
                    step={1}
                    className="mt-2"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Colors */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Palette className="w-4 h-4" />
                Colors
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-xs">Primary Color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={settings.primaryColor}
                      onChange={e => setSettings(prev => ({ ...prev, primaryColor: e.target.value }))}
                      className="w-12 h-10 p-1 cursor-pointer"
                    />
                    <Input
                      value={settings.primaryColor}
                      onChange={e => setSettings(prev => ({ ...prev, primaryColor: e.target.value }))}
                      className="flex-1 bg-white text-slate-900"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Text Color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={settings.secondaryColor}
                      onChange={e => setSettings(prev => ({ ...prev, secondaryColor: e.target.value }))}
                      className="w-12 h-10 p-1 cursor-pointer"
                    />
                    <Input
                      value={settings.secondaryColor}
                      onChange={e => setSettings(prev => ({ ...prev, secondaryColor: e.target.value }))}
                      className="flex-1 bg-white text-slate-900"
                    />
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Logo */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <ImageIcon className="w-4 h-4" />
                Logo
              </h3>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={settings.showLogo}
                    onCheckedChange={checked => setSettings(prev => ({ ...prev, showLogo: checked }))}
                  />
                  <Label className="text-xs">Show Logo</Label>
                </div>
                {settings.showLogo && (
                  <div className="flex items-center gap-2">
                    <Label className="text-xs">Size: {settings.logoSize}px</Label>
                    <Slider
                      value={[settings.logoSize]}
                      onValueChange={([value]) => setSettings(prev => ({ ...prev, logoSize: value }))}
                      min={40}
                      max={150}
                      step={5}
                      className="w-24"
                    />
                  </div>
                )}
              </div>
              {settings.showLogo && (
                <div className="flex items-center gap-3">
                  {settings.logoUrl ? (
                    <div className="relative group">
                      <img 
                        src={settings.logoUrl} 
                        alt="Signature Logo" 
                        className="h-16 w-auto object-contain rounded border border-border"
                      />
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute -top-2 -right-2 w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={handleRemoveLogo}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <div 
                      className="h-16 w-24 border-2 border-dashed border-border rounded flex items-center justify-center cursor-pointer hover:border-primary transition-colors"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      {isUploading ? (
                        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                      ) : (
                        <Upload className="w-5 h-5 text-muted-foreground" />
                      )}
                    </div>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                  <div className="text-xs text-muted-foreground">
                    <p>Upload your logo</p>
                    <p>PNG, JPG up to 2MB</p>
                  </div>
                </div>
              )}
            </div>

            <Separator />

            {/* Divider Style */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-foreground">Divider Style</h3>
              <div className="flex gap-2">
                {["line", "dots", "none"].map(style => (
                  <Button
                    key={style}
                    variant={settings.dividerStyle === style ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSettings(prev => ({ ...prev, dividerStyle: style as any }))}
                    className="capitalize"
                  >
                    {style}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Preview Panel */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Live Preview
              </h3>
              <Button variant="outline" size="sm" onClick={copyToClipboard}>
                Copy HTML
              </Button>
            </div>
            <div className="border border-border rounded-lg p-6 bg-white min-h-[200px]">
              {/* Live Signature Preview */}
              <div style={{ fontFamily: getFontFamily(settings.fontFamily), fontSize: settings.fontSize, lineHeight: 1.2 }}>
                <table cellPadding={0} cellSpacing={0}>
                  <tbody>
                    <tr>
                      {settings.showLogo && settings.logoUrl && (
                        <td style={{ verticalAlign: "top", paddingRight: 24 }}>
                          <img 
                            src={settings.logoUrl} 
                            alt="Logo" 
                            style={{ width: settings.logoSize, height: "auto" }}
                          />
                        </td>
                      )}
                      <td style={{ verticalAlign: "top" }}>
                        {/* Sign-off greeting - directly above name */}
                        {settings.signOff && (
                          <p style={{ 
                            margin: "0 0 8px 0", 
                            color: settings.secondaryColor,
                            fontSize: settings.fontSize,
                            lineHeight: 1.2,
                          }}>
                            {settings.signOff},
                          </p>
                        )}
                        <p style={{ 
                          margin: 0, 
                          fontWeight: 700, 
                          fontSize: settings.fontSize + 4, 
                          color: settings.secondaryColor,
                          lineHeight: 1.2,
                        }}>
                          {settings.fullName || "Your Name"}
                        </p>
                        <p style={{ margin: "4px 0 0 0", color: settings.secondaryColor, fontSize: settings.fontSize, lineHeight: 1.2 }}>
                          {settings.jobTitle || "Job Title"}
                        </p>
                        {settings.company && (
                          <p style={{ margin: "2px 0 0 0", color: settings.secondaryColor, fontSize: settings.fontSize, lineHeight: 1.2 }}>
                            {settings.company}
                          </p>
                        )}
                        
                        {settings.dividerStyle !== "none" && (
                          <hr style={{ 
                            border: "none", 
                            borderTop: "1px solid #d1d5db", 
                            margin: "16px 0", 
                            width: 250 
                          }} />
                        )}
                        
                        {/* Contact info with text labels (matches campaign email output) */}
                        <table cellPadding={0} cellSpacing={0} style={{ fontFamily: getFontFamily(settings.fontFamily) }}>
                          <tbody>
                            {settings.phone && (
                              <tr>
                                <td style={{ padding: "4px 0", verticalAlign: "middle", color: settings.secondaryColor, whiteSpace: "nowrap", paddingRight: 12, fontSize: settings.fontSize }}>
                                  Tel:
                                </td>
                                <td style={{ padding: "4px 0", verticalAlign: "middle", color: settings.secondaryColor, whiteSpace: "nowrap", fontSize: settings.fontSize }}>
                                  {settings.phone}
                                </td>
                              </tr>
                            )}
                            {settings.email && (
                              <tr>
                                <td style={{ padding: "4px 0", verticalAlign: "middle", color: settings.secondaryColor, paddingRight: 12, fontSize: settings.fontSize }}>
                                  Email:
                                </td>
                                <td style={{ padding: "4px 0", verticalAlign: "middle", fontSize: settings.fontSize }}>
                                  <a href={`mailto:${settings.email}`} style={{ color: settings.primaryColor, textDecoration: "none", fontFamily: getFontFamily(settings.fontFamily) }}>
                                    {settings.email}
                                  </a>
                                </td>
                              </tr>
                            )}
                            {settings.website && (
                              <tr>
                                <td style={{ padding: "4px 0", verticalAlign: "middle", color: settings.secondaryColor, paddingRight: 12, fontSize: settings.fontSize }}>
                                  Web:
                                </td>
                                <td style={{ padding: "4px 0", verticalAlign: "middle", fontSize: settings.fontSize }}>
                                  <a href={settings.website} style={{ color: settings.primaryColor, textDecoration: "none", fontFamily: getFontFamily(settings.fontFamily) }}>
                                    {settings.website.replace(/^https?:\/\//, "")}
                                  </a>
                                </td>
                              </tr>
                            )}
                            {settings.linkedin && (
                              <tr>
                                <td style={{ padding: "4px 0", verticalAlign: "middle", color: settings.secondaryColor, paddingRight: 12, fontSize: settings.fontSize }}>
                                  LinkedIn:
                                </td>
                                <td style={{ padding: "4px 0", verticalAlign: "middle", fontSize: settings.fontSize }}>
                                  <a href={settings.linkedin} style={{ color: settings.primaryColor, textDecoration: "none", fontFamily: getFontFamily(settings.fontFamily) }}>
                                    LinkedIn Profile
                                  </a>
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button 
                onClick={handleSave} 
                disabled={isSaving}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                {isSaving ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                Save Signature
              </Button>
            </div>

            {/* Usage Instructions */}
            <div className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-4 space-y-2">
              <p className="font-medium">How to use your signature:</p>
              <ol className="list-decimal list-inside space-y-1">
                <li>Click "Copy HTML" to copy the signature code</li>
                <li>In your email client, go to Settings → Signature</li>
                <li>Paste the HTML code or use the rich text editor</li>
              </ol>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
