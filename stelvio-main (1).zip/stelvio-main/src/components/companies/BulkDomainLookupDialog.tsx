import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, CheckCircle, XCircle, AlertCircle, Globe, Users, Building2, SkipForward } from "lucide-react";
import { useBulkDomainLookup } from "@/hooks/useBulkDomainLookup";

interface Company {
  id: string;
  name: string;
  domain: string | null;
  enrichment_status?: string;
}

interface BulkDomainLookupDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companies: Company[];
  onComplete: () => void;
}

const stepLabels = {
  domain: "Finding domain",
  enrich: "Enriching company",
  stakeholders: "Finding decision makers",
};

function StatusIcon({ status }: { status: "pending" | "running" | "success" | "failed" | "skipped" }) {
  switch (status) {
    case "running":
      return <Loader2 className="w-3 h-3 animate-spin text-primary" />;
    case "success":
      return <CheckCircle className="w-3 h-3 text-primary" />;
    case "failed":
      return <XCircle className="w-3 h-3 text-destructive" />;
    case "skipped":
      return <SkipForward className="w-3 h-3 text-muted-foreground" />;
    default:
      return <div className="w-3 h-3 rounded-full border border-muted-foreground/30" />;
  }
}

export function BulkDomainLookupDialog({
  open,
  onOpenChange,
  companies,
  onComplete,
}: BulkDomainLookupDialogProps) {
  const { progress, startBulkLookup, stopBulkLookup, resetProgress, checkActiveRun } = useBulkDomainLookup();
  const [hasStarted, setHasStarted] = useState(false);
  const [checkingActive, setCheckingActive] = useState(false);

  const companiesNeedingDomain = companies.filter(c => !c.domain || c.domain.trim() === "");
  const companiesNeedingEnrich = companies.filter(c => c.domain && c.domain.trim() !== "" && c.enrichment_status === "pending");
  const totalToProcess = companiesNeedingDomain.length + companiesNeedingEnrich.length;
  const progressPercent = progress.total > 0 ? (progress.completed / progress.total) * 100 : 0;

  // When dialog opens, check for an active run
  useEffect(() => {
    if (open) {
      setCheckingActive(true);
      checkActiveRun().then((hasActive) => {
        if (hasActive) {
          setHasStarted(true);
        }
        setCheckingActive(false);
      });
    } else {
      setHasStarted(false);
      resetProgress();
    }
  }, [open, checkActiveRun, resetProgress]);

  // When run completes, trigger refresh
  useEffect(() => {
    if (hasStarted && !progress.isRunning && progress.completed > 0) {
      onComplete();
    }
  }, [hasStarted, progress.isRunning, progress.completed, onComplete]);

  const handleStart = async () => {
    setHasStarted(true);
    await startBulkLookup(companies);
  };

  const handleStop = async () => {
    await stopBulkLookup();
  };

  const handleClose = () => {
    if (progress.isRunning) {
      stopBulkLookup();
    }
    onOpenChange(false);
  };

  const totalStakeholdersFound = progress.results.reduce(
    (sum, r) => sum + (r.stakeholdersFound || 0),
    0
  );

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display">
            <Globe className="w-5 h-5" />
            Bulk AI Lookup & Enrichment
          </DialogTitle>
          <DialogDescription>
            {checkingActive
              ? "Checking for active enrichment..."
              : !hasStarted
              ? `Found ${totalToProcess} companies to process${companiesNeedingDomain.length > 0 ? ` (${companiesNeedingDomain.length} need domains` : '('}${companiesNeedingEnrich.length > 0 ? `${companiesNeedingDomain.length > 0 ? ', ' : ''}${companiesNeedingEnrich.length} need enrichment)` : ')'}.`
              : progress.isRunning
              ? "Processing companies on the server... You can safely close this dialog."
              : "Bulk lookup complete!"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {checkingActive ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : !hasStarted ? (
            <>
              <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Companies to process:</span>
                  <span className="font-medium">{totalToProcess}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Estimated time:</span>
                  <span className="font-medium">
                    ~{Math.ceil(totalToProcess * 8 / 60)} min
                  </span>
                </div>
                <div className="border-t border-border/50 pt-2 mt-2">
                  <p className="text-xs text-muted-foreground">
                    For each company, AI will:
                  </p>
                  <ul className="text-xs text-muted-foreground mt-1 space-y-0.5">
                    <li className="flex items-center gap-1.5">
                      <Globe className="w-3 h-3" /> Find company domain
                    </li>
                    <li className="flex items-center gap-1.5">
                      <Building2 className="w-3 h-3" /> Enrich company data
                    </li>
                    <li className="flex items-center gap-1.5">
                      <Users className="w-3 h-3" /> Discover decision makers
                    </li>
                  </ul>
                </div>
                <div className="border-t border-border/50 pt-2 mt-2">
                  <p className="text-xs text-primary/80">
                    ✓ Server-side processing — safe to navigate away or close this dialog
                  </p>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <Button
                  onClick={handleStart}
                  disabled={totalToProcess === 0}
                  className="accent-gradient border-0"
                >
                  Start Lookup
                </Button>
              </div>
            </>
          ) : (
            <>
              {/* Progress Section */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>
                    {progress.completed} / {progress.total} companies
                  </span>
                  <span className="text-muted-foreground">
                    {Math.round(progressPercent)}%
                  </span>
                </div>
                <Progress value={progressPercent} className="h-2" />

                {progress.current && progress.currentStep && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{stepLabels[progress.currentStep]}: {progress.current}</span>
                  </div>
                )}

                {progress.isRunning && (
                  <p className="text-xs text-primary/70">
                    ✓ Running on server — safe to close this dialog
                  </p>
                )}

                <div className="flex gap-4 text-sm">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-primary" />
                    <span>{progress.succeeded} processed</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <XCircle className="w-4 h-4 text-destructive" />
                    <span>{progress.failed} failed</span>
                  </div>
                  {totalStakeholdersFound > 0 && (
                    <div className="flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-primary" />
                      <span>{totalStakeholdersFound} contacts</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Results List */}
              {progress.results.length > 0 && (
                <ScrollArea className="h-56 border rounded-lg">
                  <div className="p-2 space-y-1">
                    {progress.results.map((result, idx) => (
                      <div
                        key={idx}
                        className="py-2 px-2 text-sm rounded hover:bg-muted/50 border-b border-border/30 last:border-0"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium truncate flex-1 mr-2">
                            {result.companyName}
                          </span>
                          {result.domainStatus === "success" && result.domain && (
                            <Badge variant="secondary" className="shrink-0 text-xs">
                              {result.domain}
                            </Badge>
                          )}
                          {result.domainStatus === "failed" && (
                            <Badge variant="destructive" className="shrink-0 text-xs">
                              Failed
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <StatusIcon status={result.domainStatus} />
                            <span>Domain</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <StatusIcon status={result.enrichStatus} />
                            <span>Enrich</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <StatusIcon status={result.stakeholderStatus} />
                            <span>
                              Contacts
                              {result.stakeholdersFound !== undefined && result.stakeholdersFound > 0 && (
                                <span className="ml-0.5">({result.stakeholdersFound})</span>
                              )}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}

              {/* Actions */}
              <div className="flex justify-end gap-2 pt-2">
                {progress.isRunning ? (
                  <>
                    <Button variant="outline" onClick={handleClose}>
                      Close (keeps running)
                    </Button>
                    <Button variant="destructive" onClick={handleStop}>
                      <AlertCircle className="w-4 h-4 mr-2" />
                      Stop
                    </Button>
                  </>
                ) : (
                  <Button onClick={handleClose}>
                    Close
                  </Button>
                )}
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
