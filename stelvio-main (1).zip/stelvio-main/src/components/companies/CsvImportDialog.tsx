import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Upload, FileText, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

interface CsvImportDialogProps {
  onImportComplete: () => void;
}

interface ParsedCompany {
  name: string;
  website_url: string | null;
  domain: string | null;
  industry: string | null;
  employee_count: number | null;
  annual_revenue: number | null;
  street_address: string | null;
  city: string | null;
  state: string | null;
  country: string | null;
  postal_code: string | null;
  linkedin_url: string | null;
  description: string | null;
  phone: string | null;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

function extractDomain(website: string | null): string | null {
  if (!website) return null;
  try {
    const url = website.startsWith('http') ? website : `https://${website}`;
    const parsed = new URL(url);
    return parsed.hostname.replace(/^www\./, '');
  } catch {
    return null;
  }
}

function parseCompanyRow(headers: string[], row: string[]): ParsedCompany | null {
  const get = (key: string) => {
    const idx = headers.indexOf(key);
    return idx >= 0 ? (row[idx] || '').trim() : '';
  };

  const name = get('Company Name');
  if (!name) return null;

  const website = get('Website') || null;
  const domain = extractDomain(website);

  const employeeStr = get('Employees');
  const employee_count = employeeStr ? parseInt(employeeStr.replace(/[^0-9]/g, ''), 10) || null : null;

  const revenueStr = get('Annual Revenue');
  const annual_revenue = revenueStr ? parseInt(revenueStr.replace(/[^0-9]/g, ''), 10) || null : null;

  const linkedin = get('LinkedIn Page') || null;
  const description = get('About the company') || null;
  const phone = get('Corporate Phone number') || null;
  const industry = get('Industry') || null;

  return {
    name,
    website_url: website ? (website.startsWith('http') ? website : `https://${website}`) : null,
    domain,
    industry,
    employee_count,
    annual_revenue,
    street_address: get('Billing Street') || null,
    city: get('Billing City') || null,
    state: get('Billing Province') || null,
    country: get('Billing Country') || null,
    postal_code: get('Billing zip code') || null,
    linkedin_url: linkedin,
    description,
    phone,
  };
}

const BATCH_SIZE = 100;

export function CsvImportDialog({ onImportComplete }: CsvImportDialogProps) {
  const [open, setOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [parsedCount, setParsedCount] = useState(0);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [imported, setImported] = useState(0);
  const [skipped, setSkipped] = useState(0);
  const [errors, setErrors] = useState(0);
  const [done, setDone] = useState(false);
  const [fileName, setFileName] = useState('');
  const [companies, setCompanies] = useState<ParsedCompany[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  const reset = () => {
    setParsedCount(0);
    setImporting(false);
    setProgress(0);
    setImported(0);
    setSkipped(0);
    setErrors(0);
    setDone(false);
    setFileName('');
    setCompanies([]);
  };

  const handleFile = (file: File) => {
    if (!file.name.endsWith('.csv')) {
      toast({ title: "Invalid file", description: "Please upload a CSV file", variant: "destructive" });
      return;
    }
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n').filter(l => l.trim());
      if (lines.length < 2) {
        toast({ title: "Empty file", description: "CSV has no data rows", variant: "destructive" });
        return;
      }
      const headers = parseCSVLine(lines[0]);
      const parsed: ParsedCompany[] = [];
      for (let i = 1; i < lines.length; i++) {
        const row = parseCSVLine(lines[i]);
        const company = parseCompanyRow(headers, row);
        if (company) parsed.push(company);
      }
      setCompanies(parsed);
      setParsedCount(parsed.length);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const startImport = async () => {
    if (!companies.length) return;
    setImporting(true);
    setProgress(0);
    setImported(0);
    setSkipped(0);
    setErrors(0);

    let totalImported = 0;
    let totalSkipped = 0;
    let totalErrors = 0;

    for (let i = 0; i < companies.length; i += BATCH_SIZE) {
      const batch = companies.slice(i, i + BATCH_SIZE).map(c => ({
        ...c,
        enrichment_status: 'skipped',
        created_by: user?.id ?? null,
      }));

      const { error, data } = await supabase
        .from('companies')
        .upsert(batch, { onConflict: 'name', ignoreDuplicates: true })
        .select('id');

      if (error) {
        console.error('Batch insert error:', error);
        totalErrors += batch.length;
      } else {
        const insertedCount = data?.length ?? 0;
        totalImported += insertedCount;
        totalSkipped += batch.length - insertedCount;
      }

      const processed = Math.min(i + BATCH_SIZE, companies.length);
      setProgress(Math.round((processed / companies.length) * 100));
      setImported(totalImported);
      setSkipped(totalSkipped);
      setErrors(totalErrors);
    }

    setImporting(false);
    setDone(true);
    onImportComplete();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Upload className="w-4 h-4 mr-2" />
          Import CSV
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Import Companies from CSV</DialogTitle>
          <DialogDescription>
            Upload a CSV exported from ZOHO CRM. Fields will be mapped automatically. Enrichment will <strong>not</strong> be triggered.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Field mapping reference */}
          {!parsedCount && !importing && (
            <div className="text-xs text-muted-foreground bg-muted rounded-md p-3 space-y-1">
              <p className="font-medium text-foreground mb-1">CSV → Database mapping:</p>
              <div className="grid grid-cols-2 gap-x-4">
                <span>Company Name → name</span>
                <span>Website → website_url / domain</span>
                <span>Industry → industry</span>
                <span>Employees → employee_count</span>
                <span>Annual Revenue → annual_revenue</span>
                <span>Billing Street/City → address</span>
                <span>LinkedIn Page → linkedin_url</span>
                <span>About the company → description</span>
                <span>Corporate Phone → phone</span>
                <span>Billing Country → country</span>
              </div>
            </div>
          )}

          {/* Drop zone */}
          {!parsedCount && !importing && (
            <div
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileRef.current?.click()}
              className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                isDragging ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
              }`}
            >
              <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm font-medium">Drop CSV file here or click to browse</p>
              <p className="text-xs text-muted-foreground mt-1">Supports ZOHO CRM export format</p>
              <input
                ref={fileRef}
                type="file"
                accept=".csv"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
              />
            </div>
          )}

          {/* File parsed — ready to import */}
          {parsedCount > 0 && !importing && !done && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm bg-muted rounded-md p-3">
                <FileText className="w-4 h-4 text-primary flex-shrink-0" />
                <div>
                  <p className="font-medium">{fileName}</p>
                  <p className="text-muted-foreground">{parsedCount.toLocaleString()} companies ready to import</p>
                </div>
              </div>
              <Button onClick={startImport} className="w-full">
                <Upload className="w-4 h-4 mr-2" />
                Import {parsedCount.toLocaleString()} Companies
              </Button>
              <Button variant="outline" onClick={reset} className="w-full">
                Choose different file
              </Button>
            </div>
          )}

          {/* Importing progress */}
          {importing && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
                Importing {parsedCount.toLocaleString()} companies in batches of {BATCH_SIZE}…
              </div>
              <Progress value={progress} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{progress}% complete</span>
                <span>{imported.toLocaleString()} inserted · {skipped.toLocaleString()} duplicates skipped</span>
              </div>
            </div>
          )}

          {/* Done */}
          {done && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm bg-accent border border-border rounded-md p-3">
                <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                <div>
                  <p className="font-medium text-foreground">Import complete!</p>
                  <p className="text-muted-foreground text-xs mt-0.5">
                    {imported.toLocaleString()} inserted · {skipped.toLocaleString()} duplicates skipped
                    {errors > 0 && ` · ${errors.toLocaleString()} errors`}
                  </p>
                </div>
              </div>
              {errors > 0 && (
                <div className="flex items-center gap-2 text-xs text-destructive">
                  <AlertCircle className="w-3 h-3" />
                  {errors} rows failed — check console for details
                </div>
              )}
              <Button onClick={() => { setOpen(false); reset(); }} className="w-full">
                Done
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
