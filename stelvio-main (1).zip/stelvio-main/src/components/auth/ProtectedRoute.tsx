import { Navigate, useLocation } from 'react-router-dom';
import { useAuth, AppRole } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';
import { useEffect } from 'react';

// Session storage key must match MatchedJobsGrid.tsx
const ACTIVE_SEARCH_KEY = 'lurq_active_search';
const ACTIVE_SEARCH_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours
const PIPELINE_RESUME_KEY = 'lurq_pipeline_resume_v1';

/**
 * ProtectedRoute Component - Provides UX-level route protection
 * 
 * ⚠️ SECURITY NOTE: This component provides UX-level protection ONLY.
 * Server-side authorization is enforced via:
 * - Row Level Security (RLS) policies on all database tables
 * - Edge function JWT verification and role checks
 * - config.toml verify_jwt = true for all functions
 * 
 * The client-side role check prevents users from seeing pages they
 * can't use, but ALL data access is protected server-side by RLS.
 * Even if a user bypasses this component, they cannot access
 * protected data without proper database permissions.
 */
interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: AppRole;
}

/**
 * Check if there's an active search running and save resume info to localStorage
 * before redirecting to /login. This ensures the search can continue after re-auth.
 */
function saveResumeInfoIfNeeded() {
  try {
    const stored = sessionStorage.getItem(ACTIVE_SEARCH_KEY);
    if (!stored) return;
    
    const parsed = JSON.parse(stored) as { candidateId?: string; startedAt?: number };
    if (!parsed?.candidateId || typeof parsed.startedAt !== 'number') return;
    
    // Check TTL
    if (Date.now() - parsed.startedAt > ACTIVE_SEARCH_TTL_MS) {
      sessionStorage.removeItem(ACTIVE_SEARCH_KEY);
      return;
    }
    
    // Save to localStorage so Login page can redirect back after auth
    // Note: We don't know the exact board index here, but the MatchedJobsGrid
    // will detect the incomplete search and continue from where it left off
    localStorage.setItem(PIPELINE_RESUME_KEY, JSON.stringify({
      candidateId: parsed.candidateId,
      continueFromBoard: 0, // Will be detected from pipeline_events
    }));
    
    console.log('ProtectedRoute: Saved pipeline resume info for candidate:', parsed.candidateId);
  } catch {
    // Ignore errors
  }
}

export function ProtectedRoute({ children, requiredRole }: ProtectedRouteProps) {
  const { user, isLoading, hasRole } = useAuth();
  const location = useLocation();

  // Save resume info before redirect when session expires
  useEffect(() => {
    if (!isLoading && !user) {
      saveResumeInfoIfNeeded();
    }
  }, [isLoading, user]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-accent" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    // saveResumeInfoIfNeeded already called in useEffect
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (requiredRole && !hasRole(requiredRole)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold text-foreground">Access Denied</h1>
          <p className="text-muted-foreground">
            You don't have permission to access this page.
          </p>
          <p className="text-sm text-muted-foreground">
            Required role: <span className="font-medium capitalize">{requiredRole}</span>
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
