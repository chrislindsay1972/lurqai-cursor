import { useEffect, useState } from "react";

interface SplashScreenProps {
  onComplete: () => void;
  minDuration?: number;
}

export function SplashScreen({ onComplete, minDuration = 2000 }: SplashScreenProps) {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    // Check if splash was already shown this session
    const splashShown = sessionStorage.getItem('splashShown');
    if (splashShown) {
      onComplete();
      return;
    }

    const timer = setTimeout(() => {
      setFadeOut(true);
      sessionStorage.setItem('splashShown', 'true');
      setTimeout(onComplete, 500); // Wait for fade animation
    }, minDuration);

    return () => clearTimeout(timer);
  }, [onComplete, minDuration]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-black transition-opacity duration-500 ${
        fadeOut ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      {/* Animated background gradient */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-[#E0FA29]/10 via-transparent to-transparent rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-[#E0FA29]/10 via-transparent to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Logo container with animations */}
      <div className="relative flex flex-col items-center gap-8">
        {/* AI Network Icon - Animated */}
        <div className="relative">
          {/* Outer glow ring */}
          <div className="absolute -inset-8 rounded-full bg-[#E0FA29]/20 blur-xl animate-pulse" />
          
          {/* Spinning ring */}
          <div 
            className="absolute -inset-4 rounded-full border-2 border-[#E0FA29]/30"
            style={{
              animation: 'spin 8s linear infinite'
            }}
          />
          
          {/* Second spinning ring (opposite direction) */}
          <div 
            className="absolute -inset-6 rounded-full border border-[#E0FA29]/20"
            style={{
              animation: 'spin 12s linear infinite reverse'
            }}
          />

          {/* Main icon */}
          <svg
            viewBox="0 0 48 48"
            className="w-24 h-24 relative z-10"
            style={{
              animation: 'float 3s ease-in-out infinite'
            }}
          >
            {/* Neural network nodes with staggered animations */}
            <g className="stroke-[#E0FA29]" fill="none" strokeWidth="1.5">
              {/* Connections - animated dash */}
              <path 
                d="M24 8 L24 16 M24 32 L24 40 M8 24 L16 24 M32 24 L40 24" 
                className="animate-pulse"
                style={{ animationDelay: '0.1s' }}
              />
              <path 
                d="M12 12 L18 18 M30 18 L36 12 M12 36 L18 30 M30 30 L36 36" 
                className="animate-pulse"
                style={{ animationDelay: '0.3s' }}
              />
              <path 
                d="M24 20 L20 24 L24 28 L28 24 Z" 
                className="animate-pulse"
                style={{ animationDelay: '0.5s' }}
              />
            </g>
            
            {/* Nodes with glow effect */}
            <g className="fill-[#E0FA29]">
              {/* Center node */}
              <circle cx="24" cy="24" r="4" className="animate-pulse">
                <animate attributeName="r" values="3;4;3" dur="2s" repeatCount="indefinite" />
              </circle>
              
              {/* Outer nodes */}
              <circle cx="24" cy="8" r="2.5" style={{ animationDelay: '0.1s' }}>
                <animate attributeName="opacity" values="0.5;1;0.5" dur="2s" repeatCount="indefinite" />
              </circle>
              <circle cx="24" cy="40" r="2.5" style={{ animationDelay: '0.2s' }}>
                <animate attributeName="opacity" values="0.5;1;0.5" dur="2s" repeatCount="indefinite" begin="0.2s" />
              </circle>
              <circle cx="8" cy="24" r="2.5">
                <animate attributeName="opacity" values="0.5;1;0.5" dur="2s" repeatCount="indefinite" begin="0.4s" />
              </circle>
              <circle cx="40" cy="24" r="2.5">
                <animate attributeName="opacity" values="0.5;1;0.5" dur="2s" repeatCount="indefinite" begin="0.6s" />
              </circle>
              
              {/* Corner nodes */}
              <circle cx="12" cy="12" r="2">
                <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" begin="0.1s" />
              </circle>
              <circle cx="36" cy="12" r="2">
                <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" begin="0.3s" />
              </circle>
              <circle cx="12" cy="36" r="2">
                <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" begin="0.5s" />
              </circle>
              <circle cx="36" cy="36" r="2">
                <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" begin="0.7s" />
              </circle>
            </g>
          </svg>
        </div>

        {/* Brand name with typewriter effect */}
        <div className="flex items-center gap-1">
          <span 
            className="text-4xl font-display font-bold text-[#E0FA29] tracking-tight"
            style={{
              animation: 'slideUp 0.6s ease-out forwards',
              opacity: 0,
              transform: 'translateY(20px)'
            }}
          >
            Lurq
          </span>
          <span 
            className="text-4xl font-display font-bold text-white tracking-tight"
            style={{
              animation: 'slideUp 0.6s ease-out 0.2s forwards',
              opacity: 0,
              transform: 'translateY(20px)'
            }}
          >
            AI
          </span>
        </div>

        {/* Loading indicator */}
        <div className="flex items-center gap-2">
          <span 
            className="text-sm text-[#E0FA29]/70 font-medium"
            style={{
              animation: 'slideUp 0.6s ease-out 0.4s forwards',
              opacity: 0,
              transform: 'translateY(10px)'
            }}
          >
            Lurqing Resumes...
          </span>
        </div>
      </div>

      {/* Inline keyframe styles */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes slideUp {
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); opacity: 0.5; }
          50% { transform: translateY(-8px); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
