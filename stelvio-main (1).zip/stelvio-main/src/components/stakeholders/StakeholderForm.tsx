import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Company {
  id: string;
  name: string;
}

interface JobBoard {
  id: string;
  name: string;
}

export interface StakeholderFormData {
  name: string;
  title: string;
  email: string;
  phone: string;
  linkedin_url: string;
  location: string;
  company_id: string;
  job_board_id: string;
  source: string;
  contacted: boolean;
  notes: string;
}

interface StakeholderFormProps {
  formData: StakeholderFormData;
  setFormData: React.Dispatch<React.SetStateAction<StakeholderFormData>>;
  onSubmit: (e: React.FormEvent) => void;
  onCancel: () => void;
  isEdit?: boolean;
  isPending: boolean;
  companies: Company[];
  jobBoards: JobBoard[];
  containerRef?: React.RefObject<HTMLDivElement>;
}

export function StakeholderForm({
  formData,
  setFormData,
  onSubmit,
  onCancel,
  isEdit = false,
  isPending,
  companies,
  jobBoards,
  containerRef,
}: StakeholderFormProps) {
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor={isEdit ? "edit-name" : "name"}>Name *</Label>
          <Input
            id={isEdit ? "edit-name" : "name"}
            value={formData.name}
            onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
            placeholder="John Doe"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor={isEdit ? "edit-title" : "title"}>Title</Label>
          <Input
            id={isEdit ? "edit-title" : "title"}
            value={formData.title}
            onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
            placeholder="Head of Engineering"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor={isEdit ? "edit-email" : "email"}>Email</Label>
          <Input
            id={isEdit ? "edit-email" : "email"}
            type="email"
            value={formData.email}
            onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
            placeholder="john@company.com"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor={isEdit ? "edit-phone" : "phone"}>Phone</Label>
          <Input
            id={isEdit ? "edit-phone" : "phone"}
            value={formData.phone}
            onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
            placeholder="+1 555-0123"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor={isEdit ? "edit-linkedin" : "linkedin"}>LinkedIn URL</Label>
          <Input
            id={isEdit ? "edit-linkedin" : "linkedin"}
            value={formData.linkedin_url}
            onChange={(e) => setFormData((prev) => ({ ...prev, linkedin_url: e.target.value }))}
            placeholder="https://linkedin.com/in/..."
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor={isEdit ? "edit-location" : "location"}>Location</Label>
          <Input
            id={isEdit ? "edit-location" : "location"}
            value={formData.location}
            onChange={(e) => setFormData((prev) => ({ ...prev, location: e.target.value }))}
            placeholder="Austin, TX"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Company</Label>
          <Select
            value={formData.company_id || "none"}
            onValueChange={(value) => setFormData((prev) => ({ ...prev, company_id: value === "none" ? "" : value }))}
          >
            <SelectTrigger className="bg-white text-slate-900 border-slate-300">
              <SelectValue placeholder="Select company" />
            </SelectTrigger>
            <SelectContent container={containerRef?.current}>
              <SelectItem value="none">None</SelectItem>
              {companies.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Job Board Source</Label>
          <Select
            value={formData.job_board_id || "none"}
            onValueChange={(value) => setFormData((prev) => ({ ...prev, job_board_id: value === "none" ? "" : value }))}
          >
            <SelectTrigger className="bg-white text-slate-900 border-slate-300">
              <SelectValue placeholder="Select job board" />
            </SelectTrigger>
            <SelectContent container={containerRef?.current}>
              <SelectItem value="none">None</SelectItem>
              {jobBoards.map((jb) => (
                <SelectItem key={jb.id} value={jb.id}>
                  {jb.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor={isEdit ? "edit-notes" : "notes"}>Notes</Label>
        <Textarea
          id={isEdit ? "edit-notes" : "notes"}
          value={formData.notes}
          onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
          placeholder="Any additional notes..."
          rows={3}
          className="bg-white text-slate-900 border-slate-300 placeholder:text-slate-500"
        />
      </div>
      <div className="flex items-center space-x-2">
        <Checkbox
          id={isEdit ? "edit-contacted" : "contacted"}
          checked={formData.contacted}
          onCheckedChange={(checked) =>
            setFormData((prev) => ({ ...prev, contacted: checked as boolean }))
          }
        />
        <Label htmlFor={isEdit ? "edit-contacted" : "contacted"}>Already contacted</Label>
      </div>
      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isPending}>
          {isEdit
            ? isPending
              ? "Saving..."
              : "Save Changes"
            : isPending
            ? "Adding..."
            : "Add Stakeholder"}
        </Button>
      </div>
    </form>
  );
}
