import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";
import { useTopMatches } from "@/hooks/useTopMatches";
import { useNavigate } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";

function getScoreColor(score: number) {
  if (score >= 90) return "text-success";
  if (score >= 80) return "text-accent";
  return "text-warning";
}

export function TopMatches() {
  const { data: topMatches, isLoading } = useTopMatches(4);
  const navigate = useNavigate();

  return (
    <div className="bg-card rounded-xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold text-lg text-card-foreground">Top Lurqs</h3>
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-card-foreground hover:text-card-foreground hover:bg-card-foreground/10"
          onClick={() => navigate("/jobs")}
        >
          View All
          <ExternalLink className="w-4 h-4 ml-1" />
        </Button>
      </div>
      <div className="space-y-4">
        {isLoading ? (
          // Loading skeleton
          Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="flex items-center gap-4 p-3">
              <Skeleton className="w-12 h-12 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-48" />
                <div className="flex gap-1">
                  <Skeleton className="h-5 w-12" />
                  <Skeleton className="h-5 w-16" />
                  <Skeleton className="h-5 w-14" />
                </div>
              </div>
              <Skeleton className="h-8 w-12" />
            </div>
          ))
        ) : topMatches && topMatches.length > 0 ? (
          topMatches.map((match, index) => (
            <div
              key={match.id}
              className="flex items-center gap-4 p-3 rounded-lg hover:bg-card-foreground/5 transition-colors animate-slide-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <Avatar className="w-12 h-12">
                <AvatarFallback className="bg-card-foreground/10 text-card-foreground font-semibold">
                  {match.initials}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-card-foreground">
                  {match.candidateName}
                </p>
                <p className="text-sm text-card-foreground/70">
                  {match.jobTitle} at {match.companyName}
                </p>
                <div className="flex gap-1 mt-1">
                  {match.skills.slice(0, 3).map((skill) => (
                    <Badge
                      key={skill}
                      variant="secondary"
                      className="text-xs px-1.5 py-0"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="text-right">
                <p
                  className={`text-2xl font-bold ${getScoreColor(match.matchScore)}`}
                >
                  {match.matchScore}%
                </p>
                <p className="text-xs text-card-foreground/60">Match</p>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-card-foreground/60">
            <p>No Lurqs yet</p>
            <p className="text-sm mt-1">Start Lurqing candidates to find top matches</p>
          </div>
        )}
      </div>
    </div>
  );
}
