import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";

function usePipelineStats() {
  return useQuery({
    queryKey: ["pipeline-stats"],
    queryFn: async () => {
      const [candidatesResult, parsedResult, matchesResult, enrichedResult] =
        await Promise.all([
          // CVs Uploaded - candidates with cv_file_url
          supabase
            .from("candidates")
            .select("id", { count: "exact", head: true })
            .not("cv_file_url", "is", null),
          // Parsed - candidates with cv_raw_text (parsed CVs)
          supabase
            .from("candidates")
            .select("id", { count: "exact", head: true })
            .not("cv_raw_text", "is", null),
          // Jobs Matched - count of matches
          supabase.from("matches").select("id", { count: "exact", head: true }),
          // Companies Enriched
          supabase
            .from("companies")
            .select("id", { count: "exact", head: true })
            .eq("enrichment_status", "enriched"),
        ]);

      const firstError =
        candidatesResult.error ||
        parsedResult.error ||
        matchesResult.error ||
        enrichedResult.error;

      if (firstError) {
        throw new Error(firstError.message);
      }

      return [
        {
          label: "CVs Uploaded",
          count: candidatesResult.count ?? 0,
          color: "bg-primary",
        },
        { label: "✨ Ready to Lurq", count: parsedResult.count ?? 0, color: "bg-purple-500" },
        {
          label: "Jobs Matched",
          count: matchesResult.count ?? 0,
          color: "bg-success",
        },
        {
          label: "Companies Enriched",
          count: enrichedResult.count ?? 0,
          color: "bg-warning",
        },
      ];
    },
  });
}

export function MatchingPipeline() {
  const { data: pipelineStages, isLoading, error } = usePipelineStats();

  if (error) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-sm">
        <h3 className="font-display font-semibold text-lg mb-2 text-card-foreground">
          Recruitment Pipeline
        </h3>
        <p className="text-sm text-card-foreground/60">
          Unable to load pipeline stats.
        </p>
      </div>
    );
  }

  // Use a minimum display width so bars aren't invisible when counts are equal or very small
  const maxCount = pipelineStages
    ? Math.max(...pipelineStages.map((s) => s.count), 1)
    : 1;
  
  // Calculate percentage with a minimum of 5% if there's any count, to ensure visibility
  const getBarWidth = (count: number) => {
    if (count === 0) return 0;
    return Math.max((count / maxCount) * 100, 5);
  };

  return (
    <div className="bg-card rounded-xl p-6 shadow-sm">
      <h3 className="font-display font-semibold text-lg mb-6 text-card-foreground">
        Recruitment Pipeline
      </h3>
      <div className="space-y-4">
        {isLoading ? (
          Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-8" />
              </div>
              <Skeleton className="h-2 w-full" />
            </div>
          ))
        ) : (
          pipelineStages?.map((stage, index) => (
            <div
              key={stage.label}
              className="animate-slide-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-card-foreground">
                  {stage.label}
                </span>
                <span className="text-sm font-semibold text-card-foreground">
                  {stage.count}
                </span>
              </div>
              <div className="h-2 bg-card-foreground/10 rounded-full overflow-hidden">
                <div
                  className={cn(
                    "h-full rounded-full transition-all duration-700 ease-out",
                    stage.color
                  )}
                  style={{
                    width: `${getBarWidth(stage.count)}%`,
                  }}
                />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
