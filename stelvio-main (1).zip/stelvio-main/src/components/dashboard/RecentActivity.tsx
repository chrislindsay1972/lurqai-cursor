import * as React from "react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FileText, UserPlus, Briefcase, Building2, Target, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";

interface Activity {
  id: string;
  type: "candidate" | "job" | "company" | "match";
  title: string;
  description: string;
  time: string;
  link?: string;
}

const typeConfig = {
  candidate: { icon: UserPlus, className: "bg-accent/10 text-accent" },
  job: { icon: Briefcase, className: "bg-success/10 text-success" },
  company: { icon: Building2, className: "bg-primary/10 text-primary" },
  match: { icon: Target, className: "bg-warning/10 text-warning" },
};

export const RecentActivity = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  function RecentActivity(props, ref) {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchRecentActivity();
  }, []);

  const fetchRecentActivity = async () => {
    try {
      // Fetch recent data from all relevant tables in parallel
      const [candidatesRes, jobsRes, companiesRes, matchesRes] = await Promise.all([
        supabase
          .from("candidates")
          .select("id, name, current_title, created_at")
          .order("created_at", { ascending: false })
          .limit(5),
        supabase
          .from("jobs")
          .select("id, title, created_at, companies(name)")
          .order("created_at", { ascending: false })
          .limit(5),
        supabase
          .from("companies")
          .select("id, name, enriched_at, enrichment_status")
          .eq("enrichment_status", "enriched")
          .order("enriched_at", { ascending: false })
          .limit(5),
        supabase
          .from("matches")
          .select("id, match_score, created_at, candidates(name), jobs(title)")
          .order("created_at", { ascending: false })
          .limit(5),
      ]);

      const allActivities: Activity[] = [];

      // Process candidates
      if (candidatesRes.data) {
        candidatesRes.data.forEach((c) => {
          allActivities.push({
            id: `candidate-${c.id}`,
            type: "candidate",
            title: "New candidate added",
            description: `${c.name}${c.current_title ? ` - ${c.current_title}` : ""}`,
            time: c.created_at,
            link: `/candidates/${c.id}`,
          });
        });
      }

      // Process jobs
      if (jobsRes.data) {
        jobsRes.data.forEach((j) => {
          const company = j.companies as { name: string } | null;
          allActivities.push({
            id: `job-${j.id}`,
            type: "job",
            title: "New job added",
            description: `${j.title}${company?.name ? ` at ${company.name}` : ""}`,
            time: j.created_at,
            link: `/jobs/${j.id}`,
          });
        });
      }

      // Process enriched companies
      if (companiesRes.data) {
        companiesRes.data.forEach((c) => {
          if (c.enriched_at) {
            allActivities.push({
              id: `company-${c.id}`,
              type: "company",
              title: "Company enriched",
              description: `${c.name} data updated`,
              time: c.enriched_at,
              link: `/companies/${c.id}`,
            });
          }
        });
      }

      // Process matches
      if (matchesRes.data) {
        matchesRes.data.forEach((m) => {
          const candidate = m.candidates as { name: string } | null;
          const job = m.jobs as { title: string } | null;
          if (candidate && job) {
            allActivities.push({
              id: `match-${m.id}`,
              type: "match",
              title: "Candidate matched",
              description: `${candidate.name} matched ${m.match_score}% to ${job.title}`,
              time: m.created_at,
            });
          }
        });
      }

      // Sort by time descending and take top 8
      allActivities.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());
      
      // Format times
      const formattedActivities = allActivities.slice(0, 8).map((a) => ({
        ...a,
        time: formatDistanceToNow(new Date(a.time), { addSuffix: true }),
      }));

      setActivities(formattedActivities);
    } catch (error) {
      console.error("Error fetching recent activity:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div ref={ref} {...props} className={cn("bg-card rounded-xl p-6 shadow-sm", props.className)}>
        <h3 className="font-display font-semibold text-lg mb-4 text-card-foreground">Recent Activity</h3>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-card-foreground/60" />
        </div>
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div ref={ref} {...props} className={cn("bg-card rounded-xl p-6 shadow-sm", props.className)}>
        <h3 className="font-display font-semibold text-lg mb-4 text-card-foreground">Recent Activity</h3>
        <div className="text-center py-8">
          <FileText className="w-10 h-10 text-card-foreground/50 mx-auto mb-2" />
          <p className="text-card-foreground/60 text-sm">No recent activity</p>
        </div>
      </div>
    );
  }

  return (
    <div ref={ref} {...props} className={cn("bg-card rounded-xl p-6 shadow-sm", props.className)}>
      <h3 className="font-display font-semibold text-lg mb-4 text-card-foreground">Recent Activity</h3>
      <div className="space-y-4">
        {activities.map((activity, index) => {
          const config = typeConfig[activity.type];
          const Icon = config.icon;
          
          const content = (
            <div
              className={cn(
                "flex items-start gap-4 animate-slide-up",
                activity.link && "cursor-pointer hover:bg-card-foreground/5 -mx-2 px-2 py-1 rounded-lg transition-colors"
              )}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div
                className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
                  config.className
                )}
              >
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-card-foreground">
                  {activity.title}
                </p>
                <p className="text-sm text-card-foreground/70 truncate">
                  {activity.description}
                </p>
              </div>
              <span className="text-xs text-card-foreground/60 whitespace-nowrap">
                {activity.time}
              </span>
            </div>
          );

          return activity.link ? (
            <Link key={activity.id} to={activity.link}>
              {content}
            </Link>
          ) : (
            <div key={activity.id}>{content}</div>
          );
        })}
      </div>
    </div>
  );
});
RecentActivity.displayName = "RecentActivity";
