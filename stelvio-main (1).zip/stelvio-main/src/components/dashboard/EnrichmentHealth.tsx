import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Mail,
  Globe,
  Clock,
  Shield,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Bell,
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface HealthStats {
  totalStakeholders: number;
  withEmail: number;
  emailCoverage: number;
  bySource: Record<string, number>;
  bcPendingCount: number;
  bcPendingOver30m: number;
  bcPendingOver24h: number;
  bcMedianAgeMin: number | null;
  totalCompanies: number;
  domainResolved: number;
  domainLowConf: number;
  domainUnresolved: number;
  domainUnresolvedRate: number;
  deepDiscoveryCalls: number;
  companiesWithIntel: number;
  // New send-eligibility metrics
  sendEligible: number;
  sendEligibleRate: number;
  verifiedEmails: number;
  catchAllEmails: number;
  undeliverableEmails: number;
  aliasLockCount: number;
}

export function EnrichmentHealth() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["enrichment-health"],
    queryFn: async (): Promise<HealthStats> => {
      const now = Date.now();
      const thirtyMin = new Date(now - 30 * 60_000).toISOString();
      const twentyFourH = new Date(now - 24 * 3600_000).toISOString();

      const [
        stakeholdersRes,
        withEmailRes,
        sourceRes,
        bcPendingRes,
        bcOver30mRes,
        bcOver24hRes,
        companiesRes,
        resolvedRes,
        lowConfRes,
        unresolvedRes,
        intelRes,
        attemptsRes,
        verifiedRes,
        catchAllRes,
        undeliverableRes,
        aliasLockedRes,
        sendEligibleRes,
      ] = await Promise.all([
        supabase.from("stakeholders").select("id", { count: "exact", head: true }),
        supabase.from("stakeholders").select("id", { count: "exact", head: true }).not("email", "is", null),
        supabase.from("stakeholders").select("enrichment_source").not("email", "is", null),
        supabase.from("stakeholders").select("id, bettercontact_submitted_at", { count: "exact" }).eq("bettercontact_status", "pending"),
        supabase.from("stakeholders").select("id", { count: "exact", head: true }).eq("bettercontact_status", "pending").lt("bettercontact_submitted_at", thirtyMin),
        supabase.from("stakeholders").select("id", { count: "exact", head: true }).eq("bettercontact_status", "pending").lt("bettercontact_submitted_at", twentyFourH),
        supabase.from("companies").select("id", { count: "exact", head: true }),
        supabase.from("companies").select("id", { count: "exact", head: true }).eq("domain_status", "resolved"),
        supabase.from("companies").select("id", { count: "exact", head: true }).eq("domain_status", "low_confidence"),
        supabase.from("companies").select("id", { count: "exact", head: true }).eq("domain_status", "unresolved"),
        supabase.from("company_email_intel").select("company_id", { count: "exact", head: true }).not("pattern", "is", null),
        supabase.from("stakeholder_enrichment_attempts").select("id", { count: "exact", head: true }),
        supabase.from("stakeholders").select("id", { count: "exact", head: true }).eq("email_status", "verified"),
        supabase.from("stakeholders").select("id", { count: "exact", head: true }).eq("email_status", "catch_all"),
        supabase.from("stakeholders").select("id", { count: "exact", head: true }).eq("email_status", "undeliverable"),
        supabase.from("company_domain_aliases").select("id", { count: "exact", head: true }).eq("locked", true),
        // Send-eligible: has verified/catch_all email + company domain resolved
        supabase.from("stakeholders").select("id, email_status, company_id").in("email_status", ["verified", "catch_all"]).not("email", "is", null),
      ]);

      const totalSH = stakeholdersRes.count ?? 0;
      const withEmail = withEmailRes.count ?? 0;

      const bySource: Record<string, number> = {};
      (sourceRes.data ?? []).forEach((s) => {
        const src = s.enrichment_source || "unknown";
        bySource[src] = (bySource[src] || 0) + 1;
      });

      const bcPendingData = bcPendingRes.data ?? [];
      let bcMedianAgeMin: number | null = null;
      if (bcPendingData.length > 0) {
        const ages = bcPendingData
          .filter((r) => r.bettercontact_submitted_at)
          .map((r) => (now - new Date(r.bettercontact_submitted_at!).getTime()) / 60_000)
          .sort((a, b) => a - b);
        if (ages.length > 0) {
          bcMedianAgeMin = ages[Math.floor(ages.length / 2)];
        }
      }

      const totalCo = companiesRes.count ?? 0;
      const domainResolved = resolvedRes.count ?? 0;
      const domainLowConf = lowConfRes.count ?? 0;
      const domainUnresolved = unresolvedRes.count ?? 0;
      const verifiedEmails = verifiedRes.count ?? 0;
      const catchAllEmails = catchAllRes.count ?? 0;
      const undeliverableEmails = undeliverableRes.count ?? 0;
      const aliasLockCount = aliasLockedRes.count ?? 0;

      // Calculate send-eligible: stakeholders with verified/catch_all email whose company domain is resolved
      const eligibleData = sendEligibleRes.data ?? [];
      // We need to cross-check company domain status - fetch resolved company IDs
      const eligibleCompanyIds = [...new Set(eligibleData.map(s => s.company_id).filter(Boolean))] as string[];
      let resolvedCompanySet = new Set<string>();
      if (eligibleCompanyIds.length > 0) {
        const { data: resolvedCos } = await supabase
          .from("companies")
          .select("id")
          .in("id", eligibleCompanyIds)
          .eq("domain_status", "resolved");
        resolvedCompanySet = new Set((resolvedCos ?? []).map(c => c.id));
      }
      const sendEligible = eligibleData.filter(s => s.company_id && resolvedCompanySet.has(s.company_id)).length;

      return {
        totalStakeholders: totalSH,
        withEmail,
        emailCoverage: totalSH > 0 ? Math.round((withEmail / totalSH) * 100) : 0,
        bySource,
        bcPendingCount: bcPendingRes.count ?? 0,
        bcPendingOver30m: bcOver30mRes.count ?? 0,
        bcPendingOver24h: bcOver24hRes.count ?? 0,
        bcMedianAgeMin,
        totalCompanies: totalCo,
        domainResolved,
        domainLowConf,
        domainUnresolved,
        domainUnresolvedRate: totalCo > 0 ? Math.round((domainUnresolved / totalCo) * 100) : 0,
        deepDiscoveryCalls: attemptsRes.count ?? 0,
        companiesWithIntel: intelRes.count ?? 0,
        sendEligible,
        sendEligibleRate: withEmail > 0 ? Math.round((sendEligible / withEmail) * 100) : 0,
        verifiedEmails,
        catchAllEmails,
        undeliverableEmails,
        aliasLockCount,
      };
    },
    refetchInterval: 60_000,
  });

  // Fetch active drift alerts
  const { data: driftAlerts } = useQuery({
    queryKey: ["drift-alerts"],
    queryFn: async () => {
      const { data } = await supabase
        .from("system_alerts")
        .select("*")
        .eq("resolved", false)
        .order("created_at", { ascending: false })
        .limit(10);
      return data ?? [];
    },
    refetchInterval: 60_000,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Enrichment Health
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <Skeleton key={i} className="h-16" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!stats) return null;

  const topSources = Object.entries(stats.bySource)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Enrichment Health
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Row 0: Send Eligible (hero metric) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-1.5 md:col-span-2">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Safe to Send
            </div>
            <p className="text-3xl font-bold text-foreground">
              {stats.sendEligible}
              <span className="text-sm font-normal text-muted-foreground ml-2">
                {stats.sendEligibleRate}% of contacts with email
              </span>
            </p>
            <div className="flex gap-1.5 flex-wrap">
              <Badge variant="default" className="text-[10px]">{stats.verifiedEmails} verified</Badge>
              {stats.catchAllEmails > 0 && (
                <Badge variant="outline" className="text-[10px]">{stats.catchAllEmails} catch-all</Badge>
              )}
              {stats.undeliverableEmails > 0 && (
                <Badge variant="destructive" className="text-[10px]">{stats.undeliverableEmails} undeliverable</Badge>
              )}
              {stats.aliasLockCount > 0 && (
                <Badge variant="secondary" className="text-[10px]">{stats.aliasLockCount} locked aliases</Badge>
              )}
            </div>
          </div>

          {/* Email coverage */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Mail className="w-3.5 h-3.5" />
              Email Coverage
            </div>
            <p className="text-2xl font-bold text-foreground">{stats.emailCoverage}%</p>
            <p className="text-[10px] text-muted-foreground">
              {stats.withEmail} / {stats.totalStakeholders} stakeholders
            </p>
            <Progress value={stats.emailCoverage} className="h-1.5" />
          </div>

          {/* BC Pending */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="w-3.5 h-3.5" />
              BC Pending
            </div>
            <p className="text-2xl font-bold text-foreground">{stats.bcPendingCount}</p>
            <div className="flex gap-1.5">
              {stats.bcPendingOver30m > 0 && (
                <Badge variant="outline" className="text-[10px] text-destructive border-destructive/30">
                  {stats.bcPendingOver30m} &gt;30m
                </Badge>
              )}
              {stats.bcPendingOver24h > 0 && (
                <Badge variant="destructive" className="text-[10px]">
                  {stats.bcPendingOver24h} &gt;24h
                </Badge>
              )}
            </div>
            {stats.bcMedianAgeMin !== null && (
              <p className="text-[10px] text-muted-foreground">
                Median age: {stats.bcMedianAgeMin < 60
                  ? `${Math.round(stats.bcMedianAgeMin)}m`
                  : `${(stats.bcMedianAgeMin / 60).toFixed(1)}h`}
              </p>
            )}
          </div>
        </div>

        {/* Row 1: Domain Health + Intel */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">

          {/* BC Pending */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="w-3.5 h-3.5" />
              BC Pending
            </div>
            <p className="text-2xl font-bold text-foreground">{stats.bcPendingCount}</p>
            <div className="flex gap-1.5">
              {stats.bcPendingOver30m > 0 && (
                <Badge variant="outline" className="text-[10px] text-destructive border-destructive/30">
                  {stats.bcPendingOver30m} &gt;30m
                </Badge>
              )}
              {stats.bcPendingOver24h > 0 && (
                <Badge variant="destructive" className="text-[10px]">
                  {stats.bcPendingOver24h} &gt;24h
                </Badge>
              )}
            </div>
            {stats.bcMedianAgeMin !== null && (
              <p className="text-[10px] text-muted-foreground">
                Median age: {stats.bcMedianAgeMin < 60
                  ? `${Math.round(stats.bcMedianAgeMin)}m`
                  : `${(stats.bcMedianAgeMin / 60).toFixed(1)}h`}
              </p>
            )}
          </div>

          {/* Domain Health */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Globe className="w-3.5 h-3.5" />
              Domain Health
            </div>
            <p className="text-2xl font-bold text-foreground">
              {stats.totalCompanies > 0 ? Math.round(((stats.domainResolved) / stats.totalCompanies) * 100) : 0}%
              <span className="text-sm font-normal text-muted-foreground ml-1">resolved</span>
            </p>
            <div className="flex gap-1.5 flex-wrap">
              <Badge variant="default" className="text-[10px]">{stats.domainResolved} ok</Badge>
              {stats.domainLowConf > 0 && (
                <Badge variant="outline" className="text-[10px]">{stats.domainLowConf} low</Badge>
              )}
              {stats.domainUnresolved > 0 && (
                <Badge variant="destructive" className="text-[10px]">{stats.domainUnresolved} missing</Badge>
              )}
            </div>
          </div>

          {/* Intel Cache */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Shield className="w-3.5 h-3.5" />
              Email Intel Cache
            </div>
            <p className="text-2xl font-bold text-foreground">{stats.companiesWithIntel}</p>
            <p className="text-[10px] text-muted-foreground">
              companies with cached pattern
            </p>
            <p className="text-[10px] text-muted-foreground">
              {stats.deepDiscoveryCalls} total enrichment attempts
            </p>
          </div>
        </div>

        {/* Row 2: Email sources breakdown */}
        {topSources.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-2">Email Sources</p>
            <div className="flex flex-wrap gap-1.5">
              {topSources.map(([source, count]) => (
                <Badge key={source} variant="outline" className="text-xs gap-1">
                  {source}
                  <span className="text-muted-foreground">{count}</span>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Drift Alerts from system_alerts */}
        {driftAlerts && driftAlerts.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-border">
            <div className="flex items-center gap-1.5 text-xs font-medium text-foreground">
              <Bell className="w-3.5 h-3.5" />
              Drift Alerts
            </div>
            {driftAlerts.map((alert: any) => (
              <div
                key={alert.id}
                className={`flex items-center gap-1.5 text-xs ${
                  alert.severity === "critical" ? "text-destructive" : "text-muted-foreground"
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>{alert.message}</span>
                <span className="text-[10px] text-muted-foreground ml-auto shrink-0">
                  {formatDistanceToNow(new Date(alert.created_at), { addSuffix: true })}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Inline alerts row */}
        {(stats.bcPendingOver24h > 0 || stats.domainUnresolvedRate > 20) && (
          <div className="flex flex-wrap gap-2 pt-2 border-t border-border">
            {stats.bcPendingOver24h > 0 && (
              <div className="flex items-center gap-1.5 text-xs text-destructive">
                <AlertTriangle className="w-3.5 h-3.5" />
                {stats.bcPendingOver24h} BC tasks stale &gt;24h — consider manual intervention
              </div>
            )}
            {stats.domainUnresolvedRate > 20 && (
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <AlertTriangle className="w-3.5 h-3.5" />
                {stats.domainUnresolvedRate}% domains unresolved — review in Company Inspector
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
