import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  change?: {
    value: number;
    label: string;
  };
  icon: ReactNode;
  className?: string;
}

export function StatCard({ title, value, change, icon, className }: StatCardProps) {
  const isPositive = change && change.value >= 0;

  return (
    <div className={cn("stat-card", className)}>
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-card-foreground/10 flex items-center justify-center text-card-foreground">
          {icon}
        </div>
        {change && (
          <div
            className={cn(
              "flex items-center gap-1 text-sm font-medium px-2 py-1 rounded-full",
              isPositive
                ? "!text-green-700 bg-green-800/20"
                : "!text-red-700 bg-red-800/20"
            )}
          >
            {isPositive ? (
              <TrendingUp className="w-3 h-3" />
            ) : (
              <TrendingDown className="w-3 h-3" />
            )}
            <span>{Math.abs(change.value)}%</span>
          </div>
        )}
      </div>
      <p className="text-card-foreground/70 text-sm mb-1">{title}</p>
      <p className="text-3xl font-display font-bold text-card-foreground">{value}</p>
      {change && (
        <p className="text-xs text-card-foreground/60 mt-1">{change.label}</p>
      )}
    </div>
  );
}