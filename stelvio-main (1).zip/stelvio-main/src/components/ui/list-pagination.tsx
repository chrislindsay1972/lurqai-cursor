 import { ChevronLeft, ChevronRight } from "lucide-react";
 import { Button } from "@/components/ui/button";
 import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
 } from "@/components/ui/select";
 import { cn } from "@/lib/utils";
 import type { PageSize } from "@/hooks/useListPagination";
 
 interface ListPaginationProps {
   currentPage: number;
   totalPages: number;
   pageSize: PageSize;
   totalItems: number;
   startIndex: number;
   endIndex: number;
   hasNextPage: boolean;
   hasPreviousPage: boolean;
   onPageChange: (page: number) => void;
   onPageSizeChange: (size: PageSize) => void;
   className?: string;
 }
 
 export function ListPagination({
   currentPage,
   totalPages,
   pageSize,
   totalItems,
   startIndex,
   endIndex,
   hasNextPage,
   hasPreviousPage,
   onPageChange,
   onPageSizeChange,
   className,
 }: ListPaginationProps) {
   if (totalItems === 0) return null;
 
   // Generate page numbers to display
   const getPageNumbers = () => {
     const pages: (number | 'ellipsis')[] = [];
     const maxVisible = 5;
     
     if (totalPages <= maxVisible) {
       for (let i = 1; i <= totalPages; i++) {
         pages.push(i);
       }
     } else {
       // Always show first page
       pages.push(1);
       
       if (currentPage > 3) {
         pages.push('ellipsis');
       }
       
       // Show pages around current
       const start = Math.max(2, currentPage - 1);
       const end = Math.min(totalPages - 1, currentPage + 1);
       
       for (let i = start; i <= end; i++) {
         pages.push(i);
       }
       
       if (currentPage < totalPages - 2) {
         pages.push('ellipsis');
       }
       
       // Always show last page
       pages.push(totalPages);
     }
     
     return pages;
   };
 
   return (
     <div className={cn("flex flex-col sm:flex-row items-center justify-between gap-4 px-2 py-4", className)}>
       {/* Left side: Showing X-Y of Z */}
       <div className="text-sm text-muted-foreground">
         Showing <span className="font-medium text-foreground">{startIndex}</span> to{" "}
         <span className="font-medium text-foreground">{endIndex}</span> of{" "}
         <span className="font-medium text-foreground">{totalItems}</span> records
       </div>
 
       {/* Right side: Page size + navigation */}
       <div className="flex items-center gap-4">
         {/* Page size selector */}
         <div className="flex items-center gap-2">
           <span className="text-sm text-muted-foreground">Show</span>
           <Select
             value={String(pageSize)}
             onValueChange={(value) => onPageSizeChange(parseInt(value, 10) as PageSize)}
           >
             <SelectTrigger className="w-[70px] h-8">
               <SelectValue />
             </SelectTrigger>
             <SelectContent>
               <SelectItem value="25">25</SelectItem>
               <SelectItem value="50">50</SelectItem>
               <SelectItem value="100">100</SelectItem>
             </SelectContent>
           </Select>
         </div>
 
         {/* Page navigation */}
         <div className="flex items-center gap-1">
           <Button
             variant="outline"
             size="icon"
             className="h-8 w-8"
             onClick={() => onPageChange(currentPage - 1)}
             disabled={!hasPreviousPage}
           >
             <ChevronLeft className="h-4 w-4" />
             <span className="sr-only">Previous page</span>
           </Button>
           
           {getPageNumbers().map((page, index) => 
             page === 'ellipsis' ? (
               <span key={`ellipsis-${index}`} className="px-2 text-muted-foreground">
                 ...
               </span>
             ) : (
               <Button
                 key={page}
                 variant={currentPage === page ? "default" : "outline"}
                 size="icon"
                 className="h-8 w-8"
                 onClick={() => onPageChange(page)}
               >
                 {page}
               </Button>
             )
           )}
           
           <Button
             variant="outline"
             size="icon"
             className="h-8 w-8"
             onClick={() => onPageChange(currentPage + 1)}
             disabled={!hasNextPage}
           >
             <ChevronRight className="h-4 w-4" />
             <span className="sr-only">Next page</span>
           </Button>
         </div>
       </div>
     </div>
   );
 }