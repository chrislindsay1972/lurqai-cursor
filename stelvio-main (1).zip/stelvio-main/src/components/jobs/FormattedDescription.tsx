import { cn } from "@/lib/utils";

interface FormattedDescriptionProps {
  content: string;
  className?: string;
}

/**
 * Intelligently formats job descriptions by detecting and styling:
 * - Section headings (short lines ending with colon or all-caps)
 * - Bulleted and numbered lists
 * - Regular paragraphs
 * - Inline formatting preservation
 */
export function FormattedDescription({ content, className }: FormattedDescriptionProps) {
  if (!content) {
    return <p className="text-muted-foreground italic">No description provided</p>;
  }

  // Normalize line endings and clean up excessive whitespace
  const normalized = content
    .replace(/\r\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  // Split into blocks (separated by double newlines or section breaks)
  const blocks = normalized.split(/\n\n+/);

  const renderBlock = (block: string, index: number) => {
    const trimmed = block.trim();
    if (!trimmed) return null;

    // Check if this is a heading-style line
    if (isHeading(trimmed)) {
      return (
        <h4 key={index} className="font-semibold text-card-foreground mt-5 mb-2 first:mt-0">
          {trimmed.replace(/:$/, '')}
        </h4>
      );
    }

    // Check if this block contains list items
    const lines = trimmed.split('\n');
    const listItems = lines.filter(line => isListItem(line.trim()));
    
    if (listItems.length > 0 && listItems.length >= lines.length * 0.5) {
      // It's primarily a list
      return (
        <ul key={index} className="space-y-1.5 my-3 ml-1">
          {lines.filter(l => l.trim()).map((line, lineIdx) => {
            const cleanLine = cleanListItem(line.trim());
            return (
              <li key={lineIdx} className="flex items-start gap-2 text-card-foreground leading-relaxed">
                <span className="text-muted-foreground mt-1.5 flex-shrink-0">•</span>
                <span>{cleanLine}</span>
              </li>
            );
          })}
        </ul>
      );
    }

    // Regular paragraph - handle single newlines as line breaks
    return (
      <p key={index} className="text-card-foreground mb-3 leading-relaxed last:mb-0">
        {lines.map((line, lineIdx) => (
          <span key={lineIdx}>
            {line}
            {lineIdx < lines.length - 1 && <br />}
          </span>
        ))}
      </p>
    );
  };

  return (
    <div className={cn("text-sm", className)}>
      {blocks.map(renderBlock)}
    </div>
  );
}

/**
 * Determines if a line looks like a section heading
 */
function isHeading(line: string): boolean {
  const trimmed = line.trim();
  
  // Too long to be a heading
  if (trimmed.length > 80) return false;
  
  // Empty or very short
  if (trimmed.length < 3) return false;
  
  // Ends with colon (common heading pattern)
  if (trimmed.endsWith(':')) return true;
  
  // All uppercase (at least 3 words)
  if (trimmed === trimmed.toUpperCase() && trimmed.split(/\s+/).length >= 2) {
    return true;
  }
  
  // Title case short phrases (e.g., "About The Role", "What We Offer")
  const words = trimmed.split(/\s+/);
  if (words.length >= 2 && words.length <= 6) {
    const titleCaseWords = words.filter(w => 
      /^[A-Z]/.test(w) || ['the', 'a', 'an', 'of', 'for', 'and', 'or', 'in', 'to'].includes(w.toLowerCase())
    );
    if (titleCaseWords.length === words.length && !trimmed.includes('.')) {
      return true;
    }
  }
  
  return false;
}

/**
 * Determines if a line is a list item
 */
function isListItem(line: string): boolean {
  if (!line) return false;
  
  // Bullet patterns: -, *, •, ●, ○, ▪, ▸
  if (/^[-•*●○▪▸]\s/.test(line)) return true;
  
  // Numbered patterns: 1., 1), (1), a., a)
  if (/^(\d+[.)]\s|\(\d+\)\s|[a-zA-Z][.)]\s)/.test(line)) return true;
  
  // Check mark patterns: ✓, ✔, ☑
  if (/^[✓✔☑]\s/.test(line)) return true;
  
  return false;
}

/**
 * Removes list item markers from a line
 */
function cleanListItem(line: string): string {
  return line
    .replace(/^[-•*●○▪▸]\s*/, '')
    .replace(/^(\d+[.)]\s|\(\d+\)\s|[a-zA-Z][.)]\s)/, '')
    .replace(/^[✓✔☑]\s*/, '')
    .trim();
}
