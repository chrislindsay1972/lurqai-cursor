interface LurqLogoProps {
  className?: string;
  showText?: boolean;
  textClassName?: string;
  size?: "sm" | "md" | "lg";
}

export function LurqLogo({ 
  className = "", 
  showText = true, 
  textClassName = "",
  size = "md" 
}: LurqLogoProps) {
  const sizes = {
    sm: { icon: "w-8 h-8", text: "text-lg" },
    md: { icon: "w-10 h-10", text: "text-xl" },
    lg: { icon: "w-12 h-12", text: "text-2xl" },
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* AI Brain/Network Icon */}
      <svg 
        viewBox="0 0 48 48" 
        className={sizes[size].icon}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Outer ring */}
        <circle
          cx="24"
          cy="24"
          r="18"
          stroke="currentColor"
          strokeWidth="2"
          fill="none"
        />
        {/* Inner accent circle - using brand neon lime */}
        <circle
          cx="24"
          cy="24"
          r="10"
          fill="#E0FA29"
        />
        {/* Center highlight */}
        <circle
          cx="24"
          cy="24"
          r="4"
          fill="white"
          opacity="0.9"
        />
        {/* Connection nodes */}
        <circle cx="24" cy="8" r="3" fill="currentColor" />
        <circle cx="24" cy="40" r="3" fill="currentColor" />
        <circle cx="8" cy="24" r="3" fill="currentColor" />
        <circle cx="40" cy="24" r="3" fill="currentColor" />
      </svg>
      
      {showText && (
        <span className={`font-display font-bold tracking-tight ${sizes[size].text} ${textClassName}`}>
          LurqAI
        </span>
      )}
    </div>
  );
}

export function LurqLogoFull({ 
  className = "", 
  size = "md" 
}: Omit<LurqLogoProps, 'showText'>) {
  const sizes = {
    sm: { icon: "w-8 h-8", title: "text-lg", subtitle: "text-xs" },
    md: { icon: "w-10 h-10", title: "text-xl", subtitle: "text-xs" },
    lg: { icon: "w-12 h-12", title: "text-2xl", subtitle: "text-sm" },
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* AI Brain/Network Icon */}
      <svg 
        viewBox="0 0 48 48" 
        className={sizes[size].icon}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle
          cx="24"
          cy="24"
          r="18"
          stroke="currentColor"
          strokeWidth="2"
          fill="none"
        />
        {/* Inner accent circle - using brand neon lime */}
        <circle
          cx="24"
          cy="24"
          r="10"
          fill="#E0FA29"
        />
        <circle
          cx="24"
          cy="24"
          r="4"
          fill="white"
          opacity="0.9"
        />
        <circle cx="24" cy="8" r="3" fill="currentColor" />
        <circle cx="24" cy="40" r="3" fill="currentColor" />
        <circle cx="8" cy="24" r="3" fill="currentColor" />
        <circle cx="40" cy="24" r="3" fill="currentColor" />
      </svg>
      
      <div>
        <h1 className={`font-display font-bold ${sizes[size].title}`}>
          LurqAI
        </h1>
        <p className={`${sizes[size].subtitle} opacity-70`}>
          Recruitment Portal
        </p>
      </div>
    </div>
  );
}
