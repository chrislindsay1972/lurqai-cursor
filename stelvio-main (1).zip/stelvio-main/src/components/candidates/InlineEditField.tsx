import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Pencil, Check, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface InlineEditFieldProps {
  label: string;
  value: string | null;
  placeholder?: string;
  onSave: (value: string) => Promise<void>;
  className?: string;
}

export function InlineEditField({
  label,
  value,
  placeholder,
  onSave,
  className,
}: InlineEditFieldProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(value || "");
  const [isSaving, setIsSaving] = useState(false);

  const handleStartEdit = () => {
    setEditValue(value || "");
    setIsEditing(true);
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await onSave(editValue);
      setIsEditing(false);
      toast({ title: "Updated", description: `${label} saved successfully` });
    } catch (error) {
      console.error("Error saving:", error);
      toast({ 
        title: "Error", 
        description: "Failed to save changes", 
        variant: "destructive" 
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setEditValue(value || "");
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSave();
    } else if (e.key === "Escape") {
      handleCancel();
    }
  };

  return (
    <div className={cn("space-y-2", className)}>
      <Label className="text-sm font-medium text-muted-foreground">{label}</Label>
      {isEditing ? (
        <div className="flex items-center gap-2">
          <Input
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            className="flex-1 h-9 bg-background"
            autoFocus
            disabled={isSaving}
          />
          <Button
            size="icon"
            variant="ghost"
            onClick={handleSave}
            disabled={isSaving}
            className="h-9 w-9 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Check className="w-4 h-4" />
            )}
          </Button>
          <Button
            size="icon"
            variant="ghost"
            onClick={handleCancel}
            disabled={isSaving}
            className="h-9 w-9 text-muted-foreground hover:text-foreground"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      ) : (
        <div 
          className="group flex items-center gap-2 py-1.5 px-3 -mx-3 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
          onClick={handleStartEdit}
        >
          <p className={cn(
            "flex-1 text-foreground",
            !value && "text-muted-foreground italic"
          )}>
            {value || "Not set"}
          </p>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={(e) => {
              e.stopPropagation();
              handleStartEdit();
            }}
          >
            <Pencil className="w-3.5 h-3.5" />
          </Button>
        </div>
      )}
    </div>
  );
}
