import { useCallback, useEffect, useState, useRef } from "react";
import { AlertCircle } from "lucide-react";

import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";

type RejectionItem = { reason: string; count: number };

const REASON_LABELS: Record<string, string> = {
  company_too_large: "Company too large",
  job_too_old: "Job posting too old",
  low_score: "Match score below threshold",
  blocked_url: "Non-job content filtered",
  duplicate: "Duplicate job",
  company_unknown: "Company not found",
  scrape_failed: "Failed to load job",
  content_too_short: "Insufficient job details",
  location_mismatch: "Location mismatch",
  location_missing: "No location specified",
  incomplete_record: "Incomplete job record",
  not_job_posting: "Not a job posting",
  ai_parse_failed: "AI parsing failed",
};

function getChipClass(index: number) {
  // Use semantic tokens only.
  const styles = [
    "bg-warning/15 text-warning border-warning/30",
    "bg-success/15 text-success border-success/30",
    "bg-primary/15 text-primary border-primary/30",
    "bg-destructive/15 text-destructive border-destructive/30",
    "bg-accent text-accent-foreground border-accent/40",
  ];
  return styles[index % styles.length];
}

export function RejectionSummaryPanel({
  candidateId,
  searchComplete,
  isSearching = false,
}: {
  candidateId: string | null;
  searchComplete: boolean;
  isSearching?: boolean;
}) {
  const [items, setItems] = useState<RejectionItem[]>([]);
  // Track when current search started to filter out stale events
  const searchStartTimeRef = useRef<string | null>(null);

  // Reset when a new search starts
  useEffect(() => {
    if (isSearching && candidateId) {
      // Mark the start of this search session
      searchStartTimeRef.current = new Date().toISOString();
      // Clear stale data from previous searches
      setItems([]);
    }
  }, [isSearching, candidateId]);

  const fetchLatest = useCallback(async () => {
    if (!candidateId) return;

    // Build the query - only fetch events from current search session if we have a start time
    let query = supabase
      .from("pipeline_events")
      .select("message, created_at")
      .eq("candidate_id", candidateId)
      .eq("event_type", "rejection_summary")
      .order("created_at", { ascending: false })
      .limit(1);

    // If search is in progress, only show events from after the search started
    if (searchStartTimeRef.current) {
      query = query.gte("created_at", searchStartTimeRef.current);
    }

    const { data: events } = await query;

    if (!events?.length) {
      // Only clear if we're actively searching and no new events yet
      // Otherwise keep showing the last valid data
      if (isSearching) {
        setItems([]);
      }
      return;
    }

    try {
      const parsed = typeof events[0].message === "string" ? JSON.parse(events[0].message) : events[0].message;
      const byReason = parsed?.byReason as Record<string, number> | undefined;
      if (!byReason) {
        setItems([]);
        return;
      }

      const next = Object.entries(byReason)
        .filter(([, count]) => (count ?? 0) > 0)
        .map(([reason, count]) => ({ reason: REASON_LABELS[reason] || reason, count }))
        .sort((a, b) => b.count - a.count);

      setItems(next);
    } catch {
      setItems([]);
    }
  }, [candidateId, isSearching]);

  // Load on candidate change and when search completes (so users see the final report).
  useEffect(() => {
    // Don't fetch old data when search just started
    if (isSearching && searchStartTimeRef.current) {
      // Only fetch if we have a start time (meaning search is in progress)
      fetchLatest();
    } else if (searchComplete) {
      // Search completed - fetch the final summary
      fetchLatest();
    }
  }, [fetchLatest, searchComplete, isSearching]);

  // Live updates while searching (rejection_summary is emitted multiple times).
  useEffect(() => {
    if (!candidateId) return;

    const channel = supabase
      .channel(`rejection-summary-${candidateId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "pipeline_events",
          filter: `candidate_id=eq.${candidateId}`,
        },
        (payload) => {
          const ev = payload.new as { event_type?: string; created_at?: string };
          if (ev?.event_type === "rejection_summary") {
            // Only process events from the current search session
            if (searchStartTimeRef.current && ev.created_at && ev.created_at >= searchStartTimeRef.current) {
              fetchLatest();
            } else if (!searchStartTimeRef.current) {
              // No active search, accept any new event
              fetchLatest();
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [candidateId, fetchLatest]);

  if (!candidateId || items.length === 0) return null;

  return (
    <div className="mt-4 rounded-lg border border-muted bg-muted/30 p-4">
      <div className="flex items-center gap-2 mb-3">
        <AlertCircle className="w-4 h-4 text-muted-foreground" />
        <p className="text-sm font-medium text-foreground">Filtered out during search:</p>
      </div>
      <div className="flex flex-wrap gap-2">
        {items.map((item, idx) => (
          <Badge key={`${item.reason}-${idx}`} variant="outline" className={`text-xs ${getChipClass(idx)}`}>
            {item.reason}: {item.count}
          </Badge>
        ))}
      </div>
      {!searchComplete && (
        <p className="mt-2 text-xs text-muted-foreground">This report updates as the search progresses.</p>
      )}
    </div>
  );
}
