import { useState, useEffect, useCallback, useRef } from 'react';
import { ChevronDown, ChevronUp, Trash2, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export interface UXLogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'warn' | 'error' | 'success';
  source: string;
  message: string;
  details?: Record<string, unknown>;
}

// Global log store so logs persist across component remounts
let globalLogs: UXLogEntry[] = [];
let logListeners: Array<(logs: UXLogEntry[]) => void> = [];

function notifyListeners() {
  logListeners.forEach(fn => fn([...globalLogs]));
}

export function addUXLog(
  level: UXLogEntry['level'],
  source: string,
  message: string,
  details?: Record<string, unknown>
) {
  const entry: UXLogEntry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date(),
    level,
    source,
    message,
    details,
  };
  
  // Also log to console for debugging
  const consoleMethod = level === 'error' ? 'error' : level === 'warn' ? 'warn' : 'log';
  console[consoleMethod](`[UX:${source}] ${message}`, details || '');
  
  globalLogs = [entry, ...globalLogs].slice(0, 200); // Keep last 200 entries
  notifyListeners();
}

export function clearUXLogs() {
  globalLogs = [];
  notifyListeners();
}

export function useUXLogs() {
  const [logs, setLogs] = useState<UXLogEntry[]>([...globalLogs]);
  
  useEffect(() => {
    logListeners.push(setLogs);
    return () => {
      logListeners = logListeners.filter(fn => fn !== setLogs);
    };
  }, []);
  
  return logs;
}

function formatTime(date: Date) {
  const h = date.getHours().toString().padStart(2, '0');
  const m = date.getMinutes().toString().padStart(2, '0');
  const s = date.getSeconds().toString().padStart(2, '0');
  const ms = date.getMilliseconds().toString().padStart(3, '0');
  return `${h}:${m}:${s}.${ms}`;
}

export function UXDebugLogger({ defaultExpanded = false }: { defaultExpanded?: boolean }) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const [copied, setCopied] = useState(false);
  const logs = useUXLogs();
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (isExpanded && scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [logs.length, isExpanded]);
  
  const copyLogs = useCallback(() => {
    const text = logs.map(log => {
      const details = log.details ? ` | ${JSON.stringify(log.details)}` : '';
      return `[${formatTime(log.timestamp)}] [${log.level.toUpperCase()}] [${log.source}] ${log.message}${details}`;
    }).join('\n');
    
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [logs]);
  
  const levelColors: Record<UXLogEntry['level'], string> = {
    info: 'bg-blue-500/15 text-blue-600 border-blue-500/30',
    warn: 'bg-amber-500/15 text-amber-600 border-amber-500/30',
    error: 'bg-red-500/15 text-red-600 border-red-500/30',
    success: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30',
  };
  
  const errorCount = logs.filter(l => l.level === 'error').length;
  const warnCount = logs.filter(l => l.level === 'warn').length;
  
  return (
    <div className="rounded-lg border-2 border-purple-500/50 bg-purple-900/10 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 bg-purple-500/10">
        <button
          onClick={() => setIsExpanded(v => !v)}
          className="flex items-center gap-2 text-sm font-medium text-purple-700 dark:text-purple-300 hover:text-purple-900 dark:hover:text-purple-100 transition-colors"
          type="button"
        >
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          🔍 UX Debug Log
          <Badge variant="outline" className="ml-2 bg-purple-100 dark:bg-purple-900">
            {logs.length} events
          </Badge>
          {errorCount > 0 && (
            <Badge variant="destructive" className="ml-1">
              {errorCount} errors
            </Badge>
          )}
          {warnCount > 0 && (
            <Badge variant="outline" className="ml-1 bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300">
              {warnCount} warns
            </Badge>
          )}
        </button>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={copyLogs}
            className="h-7 text-xs"
            disabled={logs.length === 0}
          >
            {copied ? <Check className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
            {copied ? 'Copied!' : 'Copy'}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={clearUXLogs}
            className="h-7 text-xs"
            disabled={logs.length === 0}
          >
            <Trash2 className="w-3 h-3 mr-1" />
            Clear
          </Button>
        </div>
      </div>

      {isExpanded && (
        <div 
          ref={scrollRef}
          className="border-t border-purple-500/30 px-4 py-3 max-h-[400px] overflow-auto"
        >
          {logs.length === 0 ? (
            <p className="text-sm text-muted-foreground">No UX events logged yet. Start a search to see events.</p>
          ) : (
            <div className="space-y-1.5 font-mono text-xs">
              {logs.map(log => (
                <div 
                  key={log.id} 
                  className={`rounded px-2 py-1.5 ${
                    log.level === 'error' ? 'bg-red-50 dark:bg-red-950/30' :
                    log.level === 'warn' ? 'bg-amber-50 dark:bg-amber-950/30' :
                    log.level === 'success' ? 'bg-emerald-50 dark:bg-emerald-950/30' :
                    'bg-background/50'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <span className="text-muted-foreground shrink-0">{formatTime(log.timestamp)}</span>
                    <Badge variant="outline" className={`shrink-0 text-[10px] px-1.5 py-0 ${levelColors[log.level]}`}>
                      {log.level}
                    </Badge>
                    <span className="text-purple-600 dark:text-purple-400 shrink-0">[{log.source}]</span>
                    <span className="text-foreground break-words">{log.message}</span>
                  </div>
                  {log.details && Object.keys(log.details).length > 0 && (
                    <pre className="mt-1 ml-16 text-[10px] text-muted-foreground whitespace-pre-wrap break-all">
                      {JSON.stringify(log.details, null, 2)}
                    </pre>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
