import { DollarSign, Clock, Search, Target } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface SearchCostEstimateProps {
  boardCount: number;
  targetMatches?: number;
}

export function SearchCostEstimate({ boardCount, targetMatches = 10 }: SearchCostEstimateProps) {
  // Cost estimation based on:
  // - Firecrawl: ~$0.001 per scrape, ~8-10 URLs per board = ~$0.01 per board
  // - AI scoring: ~$0.0003 per job scored (Gemini Flash)
  // - Company enrichment: ~$0.001 per company
  // Conservative estimate: ~$0.02 per board searched
  
  const costPerBoard = 0.02;
  const estimatedBoardsToSearch = Math.min(boardCount, 50); // Max 50 boards
  const estimatedMinCost = (Math.min(5, estimatedBoardsToSearch) * costPerBoard).toFixed(2);
  const estimatedMaxCost = (estimatedBoardsToSearch * costPerBoard).toFixed(2);
  
  // Time estimation: ~5-10 seconds per board in batches of 5
  const estimatedMinTimeMin = Math.ceil((Math.min(5, estimatedBoardsToSearch) / 5) * 10 / 60);
  const estimatedMaxTimeMin = Math.ceil((estimatedBoardsToSearch / 5) * 10 / 60);
  
  return (
    <div className="bg-muted/50 rounded-lg p-3 space-y-2">
      <div className="flex items-center gap-2 text-sm font-medium text-foreground">
        <DollarSign className="w-4 h-4" />
        Estimated Search Cost
      </div>
      
      <div className="grid grid-cols-2 gap-3 text-sm">
        <div className="flex items-center gap-2">
          <Search className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-muted-foreground">Boards available:</span>
          <span className="font-medium">{boardCount}</span>
        </div>
        
        <div className="flex items-center gap-2">
          <Target className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-muted-foreground">Target matches:</span>
          <span className="font-medium">{targetMatches}</span>
        </div>
        
        <div className="flex items-center gap-2">
          <DollarSign className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-muted-foreground">Est. cost:</span>
          <Badge variant="outline" className="font-mono text-xs">
            ${estimatedMinCost} - ${estimatedMaxCost}
          </Badge>
        </div>
        
        <div className="flex items-center gap-2">
          <Clock className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-muted-foreground">Est. time:</span>
          <Badge variant="outline" className="text-xs">
            {estimatedMinTimeMin}-{estimatedMaxTimeMin} min
          </Badge>
        </div>
      </div>
      
      <p className="text-xs text-muted-foreground mt-1">
        Search continues until {targetMatches} matches found or all boards exhausted.
        Cost depends on job board availability and match rate.
      </p>
    </div>
  );
}
