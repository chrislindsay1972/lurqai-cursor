import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

import { 
  Loader2, 
  Search, 
  Target, 
  Clock, 
  Layers, 
  CheckCircle2, 
  XCircle, 
  Minimize2,
  StopCircle,
} from "lucide-react";

interface BoardStatus {
  name: string;
  status: 'success' | 'failed' | 'timeout' | 'searching';
  jobsFound: number;
}

interface JobMatchingProgressModalProps {
  open: boolean;
  onMinimize: () => void;
  onStop?: () => void;
  isStopping?: boolean;
  searchStatus: string;
  boardsSearched: BoardStatus[];
  totalBoardsAvailable: number;
  matchesFound: number;
  targetMatches: number;
  pendingJobsCount: number;
  newJobsCount: number;
  startedAt: number | null;
  searchCriteria?: string;
  matchThreshold?: number;
  firecrawlQuotaExceeded?: boolean;
}

function formatElapsed(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

/** Spinning LurqAI logo used as a clock/activity indicator */
function SpinningLurqClock({ className = "" }: { className?: string }) {
  return (
    <div className={`animate-spin ${className}`} style={{ animationDuration: "3s" }}>
      <svg 
        viewBox="0 0 48 48" 
        className="w-full h-full"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="24" cy="24" r="18" stroke="currentColor" strokeWidth="2" fill="none" />
        <circle cx="24" cy="24" r="10" fill="#E0FA29" />
        <circle cx="24" cy="24" r="4" fill="white" opacity="0.9" />
        <circle cx="24" cy="8" r="3" fill="currentColor" />
        <circle cx="24" cy="40" r="3" fill="currentColor" />
        <circle cx="8" cy="24" r="3" fill="currentColor" />
        <circle cx="40" cy="24" r="3" fill="currentColor" />
      </svg>
    </div>
  );
}

export function JobMatchingProgressModal({
  open,
  onMinimize,
  onStop,
  isStopping,
  searchStatus,
  boardsSearched,
  totalBoardsAvailable,
  matchesFound,
  targetMatches,
  pendingJobsCount,
  newJobsCount,
  startedAt,
  searchCriteria,
  matchThreshold,
  firecrawlQuotaExceeded,
}: JobMatchingProgressModalProps) {
  const [elapsed, setElapsed] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!open || !startedAt) {
      setElapsed(0);
      if (intervalRef.current) clearInterval(intervalRef.current);
      return;
    }

    setElapsed(Date.now() - startedAt);
    intervalRef.current = setInterval(() => {
      setElapsed(Date.now() - startedAt);
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [open, startedAt]);

  const successBoards = boardsSearched.filter(b => b.status === "success");
  const failedBoards = boardsSearched.filter(b => b.status === "failed" || b.status === "timeout");
  const searchingBoards = boardsSearched.filter(b => b.status === "searching");
  const totalJobsDiscovered = boardsSearched.reduce((sum, b) => sum + b.jobsFound, 0);

  const boardProgress = totalBoardsAvailable > 0
    ? Math.round((boardsSearched.length / totalBoardsAvailable) * 100)
    : 0;

  const matchProgress = targetMatches > 0
    ? Math.min(100, Math.round((matchesFound / targetMatches) * 100))
    : 0;

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent
        className="sm:max-w-[960px] border-2 border-accent bg-background text-foreground p-0 overflow-hidden"
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        {/* Header */}
        <div className="bg-accent px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <SpinningLurqClock className="w-20 h-20 text-accent-foreground" />
            <div>
              <h2 className="font-display font-bold text-2xl text-accent-foreground">
                LurqAI Job Matching
              </h2>
              <p className="text-sm text-accent-foreground/70">Processing pipeline active</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-accent-foreground/10 rounded-full px-4 py-2">
              <Clock className="w-5 h-5 text-accent-foreground" />
              <span className="font-mono text-lg font-semibold text-accent-foreground tabular-nums">
                {formatElapsed(elapsed)}
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onMinimize}
              className="h-10 w-10 text-accent-foreground hover:bg-accent-foreground/10"
              title="Minimize"
            >
              <Minimize2 className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Body */}
        <div className="px-8 py-8 space-y-8">
          {/* Status */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <Loader2 className="w-6 h-6 animate-spin text-accent" />
              <div className="absolute inset-0 w-6 h-6 animate-ping opacity-20 rounded-full bg-accent" />
            </div>
            <p className="text-base font-medium">{searchStatus}</p>
          </div>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Matches Found */}
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-5 h-5 text-accent" />
                <span className="text-sm text-muted-foreground">Matches</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-bold font-display">{matchesFound}</span>
                <span className="text-base text-muted-foreground">/ {targetMatches}</span>
              </div>
              <Progress value={matchProgress} className="h-2 mt-3" />
            </div>

            {/* Boards Searched */}
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-2 mb-2">
                <Search className="w-5 h-5 text-accent" />
                <span className="text-sm text-muted-foreground">Boards</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-bold font-display">{boardsSearched.length}</span>
                <span className="text-base text-muted-foreground">/ {totalBoardsAvailable || "—"}</span>
              </div>
              <Progress value={boardProgress} className="h-2 mt-3" />
            </div>

            {/* Jobs Discovered */}
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-2 mb-2">
                <Layers className="w-5 h-5 text-accent" />
                <span className="text-sm text-muted-foreground">Jobs Discovered</span>
              </div>
              <span className="text-4xl font-bold font-display">{totalJobsDiscovered}</span>
            </div>

            {/* Queue */}
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-5 h-5 text-accent" />
                <span className="text-sm text-muted-foreground">Scoring Queue</span>
              </div>
              <span className="text-4xl font-bold font-display">{pendingJobsCount}</span>
            </div>
          </div>

          {/* Search Criteria */}
          {searchCriteria && (
            <div className="rounded-xl bg-muted/50 p-5">
              <p className="text-sm text-muted-foreground mb-1">Search Criteria</p>
              <p className="text-base">{searchCriteria}</p>
              {matchThreshold && (
                <p className="text-sm text-muted-foreground mt-1">Threshold: {matchThreshold}%</p>
              )}
            </div>
          )}

          {/* Board Status Ticker */}
          {boardsSearched.length > 0 && (
            <div>
              <p className="text-sm text-muted-foreground mb-3">
                Board Activity
                <span className="ml-3">
                  <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/30">{successBoards.length} ✓</Badge>
                  {failedBoards.length > 0 && (
                    <Badge variant="outline" className="text-xs ml-1.5 bg-destructive/10 text-destructive border-destructive/30">{failedBoards.length} ✗</Badge>
                  )}
                  {searchingBoards.length > 0 && (
                    <Badge variant="outline" className="text-xs ml-1.5 bg-secondary text-secondary-foreground">{searchingBoards.length} …</Badge>
                  )}
                </span>
              </p>
              <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto">
                {boardsSearched.slice(-30).map((board, idx) => (
                  <Badge
                    key={idx}
                    variant="outline"
                    className={`text-xs ${
                      board.status === "success"
                        ? "bg-success/10 text-success border-success/30"
                        : board.status === "searching"
                        ? "bg-secondary text-secondary-foreground border-secondary/40 animate-pulse"
                        : "bg-muted text-muted-foreground border-muted/60"
                    }`}
                  >
                    {board.name}
                    {board.status === "success" && ` (${board.jobsFound})`}
                    {board.status === "searching" && " …"}
                    {board.status === "timeout" && " ⏱"}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Quota Warning */}
          {firecrawlQuotaExceeded && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-warning/10 border border-warning/30">
              <XCircle className="w-5 h-5 text-warning shrink-0" />
              <p className="text-sm text-warning">Search API credits low or exhausted</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-8 py-4 border-t border-border flex items-center justify-between bg-muted/30">
          <p className="text-sm text-muted-foreground">
            Pipeline runs in the background. You can minimize this dialog.
          </p>
          {onStop && (
            <Button
              variant="outline"
              size="sm"
              onClick={onStop}
              disabled={isStopping}
              className="text-destructive border-destructive/50 hover:bg-destructive hover:text-destructive-foreground"
            >
              {isStopping ? (
                <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
              ) : (
                <StopCircle className="w-4 h-4 mr-1.5" />
              )}
              {isStopping ? "Stopping…" : "Stop"}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
