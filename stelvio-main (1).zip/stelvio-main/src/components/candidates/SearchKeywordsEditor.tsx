import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, Plus, Loader2, Sparkles, Pencil } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SearchKeywordsEditorProps {
  candidateId: string;
  keywords: string[] | null;
  searchNotes: string | null;
  onUpdate: (keywords: string[]) => void;
}

export function SearchKeywordsEditor({
  candidateId,
  keywords,
  searchNotes,
  onUpdate,
}: SearchKeywordsEditorProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [newKeyword, setNewKeyword] = useState("");
  const [editedKeywords, setEditedKeywords] = useState<string[]>(keywords || []);

  const handleAddKeyword = () => {
    if (!newKeyword.trim()) return;
    const keyword = newKeyword.trim().toLowerCase();
    if (!editedKeywords.includes(keyword)) {
      setEditedKeywords([...editedKeywords, keyword]);
    }
    setNewKeyword("");
  };

  const handleRemoveKeyword = (index: number) => {
    setEditedKeywords(editedKeywords.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from("candidates")
        .update({ search_keywords: editedKeywords.length > 0 ? editedKeywords : null })
        .eq("id", candidateId);

      if (error) throw error;

      onUpdate(editedKeywords);
      setIsEditing(false);
      toast({
        title: "Keywords Saved",
        description: "Search keywords updated successfully",
      });
    } catch (error) {
      console.error("Error saving keywords:", error);
      toast({
        title: "Error",
        description: "Failed to save keywords",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setEditedKeywords(keywords || []);
    setNewKeyword("");
    setIsEditing(false);
  };

  const handleRegenerate = async () => {
    if (!searchNotes || searchNotes.trim().length < 10) {
      toast({
        title: "No Notes",
        description: "Add notes to the pre-search questions first to extract keywords",
        variant: "destructive",
      });
      return;
    }

    setIsRegenerating(true);
    try {
      // Call the pipeline to re-extract keywords
      const { data, error } = await supabase.functions.invoke("run-candidate-pipeline", {
        body: { candidateId, extractKeywordsOnly: true },
      });

      if (error) throw error;
      
      if (data?.notesKeywords && data.notesKeywords.length > 0) {
        const newKeywords = data.notesKeywords;
        
        // Save to database
        await supabase
          .from("candidates")
          .update({ search_keywords: newKeywords })
          .eq("id", candidateId);

        setEditedKeywords(newKeywords);
        onUpdate(newKeywords);
        
        toast({
          title: "Keywords Regenerated",
          description: `AI extracted ${newKeywords.length} keywords from notes`,
        });
      } else {
        toast({
          title: "No Keywords Found",
          description: "AI couldn't extract keywords from the notes",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error regenerating keywords:", error);
      toast({
        title: "Error",
        description: "Failed to regenerate keywords",
        variant: "destructive",
      });
    } finally {
      setIsRegenerating(false);
    }
  };

  const displayKeywords = isEditing ? editedKeywords : (keywords || []);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">AI Search Keywords</span>
          {displayKeywords.length > 0 && (
            <Badge variant="secondary" className="text-xs">
              {displayKeywords.length} keywords
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          {!isEditing && (
            <>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRegenerate}
                disabled={isRegenerating}
                className="h-7 text-xs"
              >
                {isRegenerating ? (
                  <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                ) : (
                  <Sparkles className="w-3 h-3 mr-1" />
                )}
                Regenerate
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsEditing(true)}
                className="h-7 text-xs"
              >
                <Pencil className="w-3 h-3 mr-1" />
                Edit
              </Button>
            </>
          )}
        </div>
      </div>

      {isEditing ? (
        <div className="space-y-3 p-3 rounded-lg bg-accent/50 border border-border">
          {/* Current keywords */}
          <div className="flex flex-wrap gap-2">
            {editedKeywords.map((keyword, index) => (
              <Badge
                key={index}
                variant="outline"
                className="bg-primary/10 text-primary border-primary/30 pr-1"
              >
                {keyword}
                <button
                  onClick={() => handleRemoveKeyword(index)}
                  className="ml-1 p-0.5 hover:bg-primary/20 rounded"
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            {editedKeywords.length === 0 && (
              <span className="text-sm text-muted-foreground">No keywords yet</span>
            )}
          </div>

          {/* Add new keyword */}
          <div className="flex gap-2">
            <Input
              value={newKeyword}
              onChange={(e) => setNewKeyword(e.target.value)}
              placeholder="Add keyword (e.g., healthcare, startup)"
              className="flex-1 h-8 text-sm"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  handleAddKeyword();
                }
              }}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={handleAddKeyword}
              disabled={!newKeyword.trim()}
              className="h-8"
            >
              <Plus className="w-3 h-3" />
            </Button>
          </div>

          {/* Save/Cancel buttons */}
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCancel}
              disabled={isSaving}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSave}
              disabled={isSaving}
              className="bg-primary"
            >
              {isSaving ? (
                <Loader2 className="w-3 h-3 mr-1 animate-spin" />
              ) : null}
              Save Keywords
            </Button>
          </div>
        </div>
      ) : displayKeywords.length > 0 ? (
        <div className="flex flex-wrap gap-2">
          {displayKeywords.map((keyword, index) => (
            <Badge
              key={index}
              variant="outline"
              className="bg-primary/10 text-primary border-primary/30"
            >
              {keyword}
            </Badge>
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">
          No keywords extracted yet. Add notes to pre-search questions and click "Regenerate" to extract keywords.
        </p>
      )}

      <p className="text-xs text-muted-foreground">
        These keywords are used by AI to filter and prioritize job matches based on candidate preferences.
      </p>
    </div>
  );
}
