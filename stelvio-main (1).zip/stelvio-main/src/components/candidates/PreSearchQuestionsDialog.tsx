import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, Home, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { CityAutocomplete } from "./CityAutocomplete";

const KM_TO_MILES = 0.621371;
const MILES_TO_KM = 1.60934;

interface PreSearchQuestionsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  candidateId: string;
  candidateName: string;
  onComplete: () => void;
  onSearchStarted?: (candidateId: string, candidateName: string) => void;
}

interface DynamicQuestion {
  id: string;
  question_label: string;
  question_type: string;
  options: string[];
}

interface PreSearchFormData {
  city: string;
  country: string;
  distance: number;
  isRemoteWorker: boolean;
  searchNotes: string;
  dynamicAnswers: Record<string, string>;
}

export function PreSearchQuestionsDialog({
  open,
  onOpenChange,
  candidateId,
  candidateName,
  onComplete,
  onSearchStarted,
}: PreSearchQuestionsDialogProps) {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  const [useImperial, setUseImperial] = useState(true); // Default to miles
  const [formData, setFormData] = useState<PreSearchFormData>({
    city: "",
    country: "",
    distance: 50, // Always stored in km internally
    isRemoteWorker: false,
    searchNotes: "",
    dynamicAnswers: {},
  });

  // Convert km to display value based on unit preference
  const displayDistance = useImperial 
    ? Math.round(formData.distance * KM_TO_MILES) 
    : formData.distance;
  
  const maxDistance = useImperial ? 125 : 200; // ~200km = ~125 miles
  const unitLabel = useImperial ? "miles" : "km";

  // Fetch dynamic questions
  const { data: dynamicQuestions = [] } = useQuery({
    queryKey: ["pre-search-questions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pre_search_questions")
        .select("*")
        .eq("is_active", true)
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data.map((q) => ({
        ...q,
        options: Array.isArray(q.options) ? q.options : [],
      })) as DynamicQuestion[];
    },
  });

  const handleCityChange = (city: string, country: string) => {
    setFormData((prev) => ({ ...prev, city, country }));
  };

  const handleDistanceChange = (value: number[]) => {
    // Convert display value to km for storage
    const displayValue = value[0];
    const kmValue = useImperial ? Math.round(displayValue * MILES_TO_KM) : displayValue;
    setFormData((prev) => ({ ...prev, distance: kmValue }));
  };

  const handleRemoteChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, isRemoteWorker: checked }));
  };

  const handleNotesChange = (notes: string) => {
    setFormData((prev) => ({ ...prev, searchNotes: notes }));
  };

  const handleDynamicAnswerChange = (questionId: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      dynamicAnswers: { ...prev.dynamicAnswers, [questionId]: value },
    }));
  };

  const handleSubmit = async () => {
    // Always require a city - even for remote workers, this provides
    // fallback location context for job matching on boards like LinkedIn
    if (!formData.city) {
      toast({
        title: "Location Required",
        description: "Please enter a city (even for remote workers - this helps match jobs on LinkedIn and other boards)",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);
    try {
      // Update candidate with new pre-search fields
      const { error: candidateError } = await supabase
        .from("candidates")
        .update({
          search_city: formData.city || null,
          search_country: formData.country || null,
          search_distance_km: formData.distance,
          is_remote_worker: formData.isRemoteWorker,
          search_notes: formData.searchNotes || null,
          // Also update legacy fields for compatibility
          desired_location: formData.isRemoteWorker 
            ? `Remote - ${formData.country || 'Worldwide'}` 
            : formData.city 
              ? `${formData.city}, ${formData.country}` 
              : null,
          pre_search_completed: true,
        })
        .eq("id", candidateId);

      if (candidateError) throw candidateError;

      // Save dynamic question answers
      for (const [questionId, answer] of Object.entries(formData.dynamicAnswers)) {
        if (answer) {
          await supabase
            .from("candidate_pre_search_answers")
            .upsert({
              candidate_id: candidateId,
              question_id: questionId,
              answer_value: answer,
            }, {
              onConflict: "candidate_id,question_id",
            });
        }
      }

      toast({
        title: "Pre-Search Questions Saved",
        description: `Answers saved for ${candidateName}. Starting job search...`,
      });

      // IMPORTANT: Notify parent that search is starting BEFORE closing the dialog.
      // This lets the parent set up the live results grid.
      onSearchStarted?.(candidateId, candidateName);

      // Close dialog AFTER the search-started callback has run
      onOpenChange(false);

      // Trigger completion callback (e.g., refetch candidates) after closing
      onComplete();

      // Trigger the matching pipeline
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData?.session?.access_token;

      if (!token) {
        console.error('Pipeline start blocked: missing auth session');
        toast({
          title: 'Login required',
          description: 'Please log in to start the job search.',
          variant: 'destructive',
        });
        return;
      }

      supabase.functions.invoke("run-candidate-pipeline", {
        body: { candidateId },
        headers: { Authorization: `Bearer ${token}` },
      }).then(({ data, error: pipelineError }) => {
        if (pipelineError || data?.error) {
          console.error("Pipeline error:", pipelineError || data?.error);
        } else {
          const internalCount = data?.internalMatches?.length || 0;
          const externalCount = data?.externalJobs?.length || 0;
          if (internalCount > 0 || externalCount > 0) {
            toast({
              title: "Job Matches Found",
              description: `${candidateName}: ${internalCount} internal + ${externalCount} external matches`,
            });
          }
        }
      });
    } catch (error) {
      console.error("Error saving pre-search answers:", error);
      toast({
        title: "Error",
        description: "Failed to save pre-search answers",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl bg-background border-border">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-center">
            Pre-Search Questions for {candidateName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* 1. City Location */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground text-center font-medium uppercase tracking-wide">
              Location
            </p>
            <CityAutocomplete
              value={formData.city ? `${formData.city}, ${formData.country}` : ""}
              onChange={handleCityChange}
              placeholder="Start typing a city..."
            />
          </div>

          {/* 2. Distance from city */}
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-3">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Distance willing to travel
              </p>
              <div className="flex items-center gap-2 bg-muted rounded-full px-3 py-1">
                <span className={`text-xs font-medium ${!useImperial ? 'text-primary' : 'text-muted-foreground'}`}>km</span>
                <Switch
                  checked={useImperial}
                  onCheckedChange={setUseImperial}
                  className="data-[state=checked]:bg-primary"
                />
                <span className={`text-xs font-medium ${useImperial ? 'text-primary' : 'text-muted-foreground'}`}>miles</span>
              </div>
            </div>
            <div className="px-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">0 {unitLabel}</span>
                <span className="text-lg font-bold text-primary">{displayDistance} {unitLabel}</span>
                <span className="text-sm text-muted-foreground">{maxDistance} {unitLabel}</span>
              </div>
              <Slider
                value={[displayDistance]}
                onValueChange={handleDistanceChange}
                max={maxDistance}
                min={0}
                step={5}
                className="w-full"
              />
            </div>
          </div>

          {/* 3. Remote Worker Checkbox */}
          <div className={`flex items-center justify-center gap-3 p-4 rounded-full transition-all duration-200 ${
            formData.isRemoteWorker 
              ? 'bg-primary/20 ring-2 ring-primary' 
              : 'bg-muted'
          }`}>
            <Checkbox
              id="remote-worker"
              checked={formData.isRemoteWorker}
              onCheckedChange={handleRemoteChange}
              className="h-5 w-5 border-border data-[state=checked]:bg-primary data-[state=checked]:border-primary data-[state=checked]:text-primary-foreground"
            />
            <Label
              htmlFor="remote-worker"
              className={`font-semibold cursor-pointer flex items-center gap-2 transition-colors ${
                formData.isRemoteWorker ? 'text-primary' : 'text-foreground'
              }`}
            >
              <Home className="h-4 w-4" />
              Remote Worker
            </Label>
          </div>

          {/* Dynamic Questions */}
          {dynamicQuestions.map((question) => (
            <div key={question.id} className="space-y-2">
              <p className="text-xs text-muted-foreground text-center font-medium uppercase tracking-wide">
                {question.question_label}
              </p>
              {question.question_type === "select" && question.options.length > 0 ? (
                <select
                  value={formData.dynamicAnswers[question.id] || ""}
                  onChange={(e) => handleDynamicAnswerChange(question.id, e.target.value)}
                  className="w-full h-14 rounded-full bg-muted text-foreground border-0 px-6 text-center font-medium appearance-none cursor-pointer"
                >
                  <option value="">Select an option...</option>
                  {question.options.map((opt, idx) => (
                    <option key={idx} value={String(opt)}>
                      {String(opt)}
                    </option>
                  ))}
                </select>
              ) : (
                <Input
                  value={formData.dynamicAnswers[question.id] || ""}
                  onChange={(e) => handleDynamicAnswerChange(question.id, e.target.value)}
                  placeholder={`Enter ${question.question_label.toLowerCase()}...`}
                  className="h-14 rounded-full bg-muted text-foreground border-0 text-center font-medium placeholder:text-muted-foreground"
                />
              )}
            </div>
          ))}

          {/* Search Notes */}
          <div className="space-y-2">
            <div className="flex items-center justify-center gap-2">
              <FileText className="w-4 h-4 text-muted-foreground" />
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Additional Notes
              </p>
            </div>
            <Textarea
              value={formData.searchNotes}
              onChange={(e) => handleNotesChange(e.target.value)}
              placeholder="Add any specific requirements, preferences, or context that should be considered during the job search... (e.g., 'Looking for startups', 'Prefers healthcare industry', 'Needs visa sponsorship')"
              className="min-h-[100px] rounded-xl bg-muted text-foreground border-0 placeholder:text-muted-foreground resize-none"
            />
            <p className="text-xs text-muted-foreground text-center">
              AI will use these notes to filter and prioritize job matches
            </p>
          </div>

          {/* Add Question Hint */}
          <div className="flex justify-center">
            <p className="text-xs text-muted-foreground">
              Add more questions in Settings → Data & Fields
            </p>
          </div>
        </div>

        <div className="flex justify-center pt-4">
          <Button
            onClick={handleSubmit}
            disabled={isSaving}
            className="px-12 py-6 rounded-full text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                SAVING...
              </>
            ) : (
              "FIND SUITABLE JOBS"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
