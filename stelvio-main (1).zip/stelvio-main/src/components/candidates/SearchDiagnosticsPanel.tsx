import { useState } from 'react';
import { ChevronDown, ChevronUp, Database, Radio, Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface DiagnosticsData {
  lastDbPollTime: Date | null;
  lastRealtimeEventTime: Date | null;
  matchCountInDb: number;
  lastAuthError: boolean;
  lastAuthErrorMessage?: string;
}

interface SearchDiagnosticsPanelProps {
  diagnostics: DiagnosticsData;
  isVisible: boolean;
}

function formatTime(date: Date | null): string {
  if (!date) return 'Never';
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  
  if (diffSec < 5) return 'Just now';
  if (diffSec < 60) return `${diffSec}s ago`;
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  return date.toLocaleTimeString();
}

export function SearchDiagnosticsPanel({ diagnostics, isVisible }: SearchDiagnosticsPanelProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  if (!isVisible) return null;

  const { lastDbPollTime, lastRealtimeEventTime, matchCountInDb, lastAuthError, lastAuthErrorMessage } = diagnostics;

  return (
    <div className="mt-4 border border-border/50 rounded-lg bg-muted/30 overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
      >
        <span className="flex items-center gap-2">
          <Database className="w-4 h-4" />
          Diagnostics
        </span>
        {isExpanded ? (
          <ChevronUp className="w-4 h-4" />
        ) : (
          <ChevronDown className="w-4 h-4" />
        )}
      </button>
      
      {isExpanded && (
        <div className="px-4 py-3 border-t border-border/50 space-y-3 text-sm">
          {/* Last DB Poll */}
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-muted-foreground">
              <Database className="w-4 h-4" />
              Last DB Poll
            </span>
            <span className="font-mono text-foreground">
              {formatTime(lastDbPollTime)}
            </span>
          </div>

          {/* Last Realtime Event */}
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-muted-foreground">
              <Radio className="w-4 h-4" />
              Last Realtime Event
            </span>
            <span className="font-mono text-foreground">
              {formatTime(lastRealtimeEventTime)}
            </span>
          </div>

          {/* Match Count in DB */}
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-muted-foreground">
              <Clock className="w-4 h-4" />
              Matches in DB
            </span>
            <span className="font-mono text-foreground font-semibold">
              {matchCountInDb}
            </span>
          </div>

          {/* Auth Status */}
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-muted-foreground">
              {lastAuthError ? (
                <AlertTriangle className="w-4 h-4 text-destructive" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-primary" />
              )}
              Last Query Auth
            </span>
            <span className={cn(
              "font-mono",
              lastAuthError ? "text-destructive" : "text-primary"
            )}>
              {lastAuthError ? 'Error' : 'OK'}
            </span>
          </div>

          {/* Auth Error Message */}
          {lastAuthError && lastAuthErrorMessage && (
            <div className="p-2 bg-destructive/10 rounded text-destructive text-xs">
              {lastAuthErrorMessage}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
