import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import {
  Users,
  Loader2,
  CheckCircle2,
  ExternalLink,
  Mail,
  Phone,
  Linkedin,
  Sparkles,
  UserSearch,
  RefreshCw,
  Zap,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ShortlistedCompany {
  id: string;
  name: string;
  domain: string | null;
  industry: string | null;
  jobTitle: string;
  matchScore: number;
}

interface Stakeholder {
  id: string;
  name: string;
  title: string | null;
  email: string | null;
  phone: string | null;
  linkedin_url: string | null;
  company_name: string | null;
}

interface EnrichmentProgress {
  total: number;
  completed: number;
  current: string | null;
  errors: string[];
}

interface StakeholderSearchWizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  candidateId: string;
  candidateName: string;
}

export function StakeholderSearchWizard({
  open,
  onOpenChange,
  candidateId,
  candidateName,
}: StakeholderSearchWizardProps) {
  const { toast } = useToast();
  const [companies, setCompanies] = useState<ShortlistedCompany[]>([]);
  const [selectedCompanyIds, setSelectedCompanyIds] = useState<Set<string>>(new Set());
  const [isLoadingCompanies, setIsLoadingCompanies] = useState(true);
  const [isSearchingStakeholders, setIsSearchingStakeholders] = useState(false);
  const [stakeholders, setStakeholders] = useState<Stakeholder[]>([]);
  const [displayedStakeholders, setDisplayedStakeholders] = useState<Stakeholder[]>([]);
  const [searchComplete, setSearchComplete] = useState(false);
  const [showTransition, setShowTransition] = useState(false);
  const [currentCompanyIndex, setCurrentCompanyIndex] = useState(0);
  const [isEnriching, setIsEnriching] = useState(false);
  const [enrichmentProgress, setEnrichmentProgress] = useState<EnrichmentProgress>({
    total: 0,
    completed: 0,
    current: null,
    errors: [],
  });

  useEffect(() => {
    if (open) {
      // Reset state and auto-start search
      setStakeholders([]);
      setDisplayedStakeholders([]);
      setSearchComplete(false);
      setShowTransition(false);
      setCurrentCompanyIndex(0);
      setIsEnriching(false);
      setEnrichmentProgress({ total: 0, completed: 0, current: null, errors: [] });
      
      // Fetch companies and immediately search
      fetchAndSearchStakeholders();
    }
  }, [open, candidateId]);

  const fetchAndSearchStakeholders = async () => {
    setIsLoadingCompanies(true);
    setShowTransition(true);
    
    try {
      // Fetch shortlisted companies
      const { data, error } = await supabase
        .from("matches")
        .select(`
          id,
          match_score,
          jobs(
            id,
            title,
            companies(id, name, domain, industry)
          )
        `)
        .eq("candidate_id", candidateId)
        .eq("status", "shortlisted");

      if (error) throw error;

      const companyMap = new Map<string, ShortlistedCompany>();
      (data || []).forEach((match: any) => {
        if (match.jobs?.companies) {
          const company = match.jobs.companies;
          if (!companyMap.has(company.id)) {
            companyMap.set(company.id, {
              id: company.id,
              name: company.name,
              domain: company.domain,
              industry: company.industry,
              jobTitle: match.jobs.title,
              matchScore: match.match_score,
            });
          }
        }
      });

      const companiesArray = Array.from(companyMap.values());
      setCompanies(companiesArray);
      
      // Select ALL companies automatically
      const allCompanyIds = new Set(companiesArray.map(c => c.id));
      setSelectedCompanyIds(allCompanyIds);
      
      if (companiesArray.length === 0) {
        setIsLoadingCompanies(false);
        setShowTransition(false);
        toast({
          title: "No Shortlisted Companies",
          description: "This candidate has no shortlisted matches yet.",
        });
        return;
      }

      // Animate through companies
      for (let i = 0; i < companiesArray.length; i++) {
        setCurrentCompanyIndex(i);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      await new Promise(resolve => setTimeout(resolve, 400));
      setShowTransition(false);
      setIsLoadingCompanies(false);
      setIsSearchingStakeholders(true);

      // Search for stakeholders
      const { data: stakeholderData, error: stakeholderError } = await supabase
        .from("stakeholders")
        .select(`
          id,
          name,
          title,
          email,
          phone,
          linkedin_url,
          companies(name)
        `)
        .in("company_id", Array.from(allCompanyIds));

      if (stakeholderError) throw stakeholderError;

      const formattedStakeholders: Stakeholder[] = (stakeholderData || []).map((s: any) => ({
        id: s.id,
        name: s.name,
        title: s.title,
        email: s.email,
        phone: s.phone,
        linkedin_url: s.linkedin_url,
        company_name: s.companies?.name || null,
      }));

      setStakeholders(formattedStakeholders);
      setSearchComplete(true);

      if (formattedStakeholders.length === 0) {
        toast({
          title: "No Stakeholders Found",
          description: "No stakeholders found for the shortlisted companies. You can enrich to find decision makers.",
        });
      }
    } catch (error) {
      console.error("Error fetching stakeholders:", error);
      toast({
        title: "Error",
        description: "Failed to search for stakeholders",
        variant: "destructive",
      });
    } finally {
      setIsLoadingCompanies(false);
      setShowTransition(false);
      setIsSearchingStakeholders(false);
    }
  };

  // Animate stakeholders appearing one by one
  useEffect(() => {
    if (stakeholders.length > 0 && displayedStakeholders.length < stakeholders.length) {
      const timer = setTimeout(() => {
        setDisplayedStakeholders(prev => [...prev, stakeholders[prev.length]]);
      }, 150); // Stagger each row by 150ms
      return () => clearTimeout(timer);
    }
  }, [stakeholders, displayedStakeholders]);

  const handleClose = () => {
    onOpenChange(false);
  };

  const handleRefreshSearch = () => {
    // Re-run the search
    fetchAndSearchStakeholders();
  };

  // Enrich companies that have no stakeholders using BetterContact
  const handleEnrichCompanies = async () => {
    const companiesWithDomains = selectedCompaniesArray.filter(c => c.domain);
    
    if (companiesWithDomains.length === 0) {
      toast({
        title: "No Domains Available",
        description: "Selected companies don't have domain information for enrichment.",
        variant: "destructive",
      });
      return;
    }

    setIsEnriching(true);
    setEnrichmentProgress({
      total: companiesWithDomains.length,
      completed: 0,
      current: companiesWithDomains[0].name,
      errors: [],
    });

    const errors: string[] = [];
    let totalStakeholdersCreated = 0;

    for (let i = 0; i < companiesWithDomains.length; i++) {
      const company = companiesWithDomains[i];
      setEnrichmentProgress(prev => ({
        ...prev,
        current: company.name,
        completed: i,
      }));

      try {
        // Use the enrich-stakeholders function for AI + Apollo enrichment
        const { data, error } = await supabase.functions.invoke('enrich-stakeholders', {
          body: { 
            companyId: company.id, 
            companyName: company.name,
            domain: company.domain,
            jobTitle: company.jobTitle, // Pass job context for AI analysis
          },
        });

        if (error) {
          console.error(`Enrichment error for ${company.name}:`, error);
          errors.push(company.name);
        } else if (data?.creditsExhausted) {
          toast({
            title: "Apollo Credits Exhausted",
            description: "Please top up your Apollo credits to continue enrichment.",
            variant: "destructive",
          });
          errors.push(company.name);
          break; // Stop further attempts
        } else if (!data?.success) {
          console.error(`Enrichment failed for ${company.name}:`, data?.error);
          errors.push(company.name);
        } else {
          totalStakeholdersCreated += data.stakeholdersCreated || 0;
        }
      } catch (err) {
        console.error(`Error enriching ${company.name}:`, err);
        errors.push(company.name);
      }

      // Small delay between requests
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    setEnrichmentProgress(prev => ({
      ...prev,
      completed: companiesWithDomains.length,
      current: null,
      errors,
    }));

    setIsEnriching(false);

    if (errors.length === 0) {
      toast({
        title: "Enrichment Complete",
        description: `Found ${totalStakeholdersCreated} stakeholder(s) from ${companiesWithDomains.length} ${companiesWithDomains.length === 1 ? 'company' : 'companies'}. Refreshing...`,
      });
    } else {
      toast({
        title: "Enrichment Partially Complete",
        description: `Enriched ${companiesWithDomains.length - errors.length} of ${companiesWithDomains.length} companies.`,
        variant: errors.length === companiesWithDomains.length ? "destructive" : "default",
      });
    }

    // Re-search for stakeholders after enrichment
    setDisplayedStakeholders([]);
    setIsSearchingStakeholders(true);
    setSearchComplete(false);

    try {
      const { data, error } = await supabase
        .from("stakeholders")
        .select(`
          id,
          name,
          title,
          email,
          phone,
          linkedin_url,
          companies(name)
        `)
        .in("company_id", Array.from(selectedCompanyIds));

      if (error) throw error;

      const formattedStakeholders: Stakeholder[] = (data || []).map((s: any) => ({
        id: s.id,
        name: s.name,
        title: s.title,
        email: s.email,
        phone: s.phone,
        linkedin_url: s.linkedin_url,
        company_name: s.companies?.name || null,
      }));

      setStakeholders(formattedStakeholders);
      setSearchComplete(true);

      if (formattedStakeholders.length > 0) {
        toast({
          title: "Stakeholders Found",
          description: `Found ${formattedStakeholders.length} stakeholder(s) after enrichment!`,
        });
      }
    } catch (error) {
      console.error("Error searching stakeholders after enrichment:", error);
    } finally {
      setIsSearchingStakeholders(false);
    }
  };

  const selectedCompaniesArray = companies.filter(c => selectedCompanyIds.has(c.id));
  const companiesWithDomains = selectedCompaniesArray.filter(c => c.domain);
  const enrichmentPercent = enrichmentProgress.total > 0 
    ? Math.round((enrichmentProgress.completed / enrichmentProgress.total) * 100) 
    : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-hidden flex flex-col bg-background">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Decision Makers
          </DialogTitle>
          <DialogDescription>
            {isLoadingCompanies || showTransition
              ? `Searching shortlisted companies for ${candidateName}...`
              : `Contacts at ${selectedCompanyIds.size} shortlisted ${selectedCompanyIds.size === 1 ? 'company' : 'companies'}`}
          </DialogDescription>
        </DialogHeader>

        {/* Transition Animation */}
        {showTransition && (
          <div className="flex-1 flex flex-col items-center justify-center py-12 animate-fade-in">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-accent/20 flex items-center justify-center mb-6 animate-pulse">
                <UserSearch className="w-10 h-10 text-accent" />
              </div>
              <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-accent animate-bounce" />
            </div>
            <p className="text-lg font-semibold text-foreground mb-2">
              Finding Decision Makers...
            </p>
            <p className="text-sm text-muted-foreground mb-6">
              Scanning {companies.length} shortlisted {companies.length === 1 ? 'company' : 'companies'}
            </p>
            <div className="flex flex-wrap justify-center gap-2 max-w-md">
              {companies.map((company, index) => (
                <Badge
                  key={company.id}
                  className={`transition-all duration-300 ${
                    index <= currentCompanyIndex
                      ? "bg-accent text-accent-foreground scale-110"
                      : "bg-muted text-muted-foreground scale-100"
                  }`}
                >
                  {company.name}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Stakeholder Results */}
        {!showTransition && (
          <div className="flex-1 overflow-hidden flex flex-col">
            {/* Search Progress / Results Header */}
            <div className="py-3 px-1">
              {isSearchingStakeholders ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-accent/10 border border-accent/30 animate-pulse">
                  <Loader2 className="w-5 h-5 animate-spin text-accent" />
                  <div>
                    <p className="font-medium text-foreground">Searching for decision makers...</p>
                    <p className="text-sm text-muted-foreground">
                      Scanning {selectedCompanyIds.size} {selectedCompanyIds.size === 1 ? 'company' : 'companies'} for stakeholders
                    </p>
                  </div>
                </div>
              ) : searchComplete && (
                <div className={`flex items-center gap-3 p-4 rounded-lg transition-all duration-500 ${
                  stakeholders.length > 0 
                    ? "bg-green-500/10 border border-green-500/30"
                    : "bg-amber-500/10 border border-amber-500/30"
                }`}>
                  {stakeholders.length > 0 ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                      <div>
                        <p className="font-medium text-foreground">Search Complete</p>
                        <p className="text-sm text-muted-foreground">
                          Found {stakeholders.length} stakeholder{stakeholders.length !== 1 ? 's' : ''} at {selectedCompanyIds.size} {selectedCompanyIds.size === 1 ? 'company' : 'companies'}
                        </p>
                      </div>
                    </>
                  ) : (
                    <>
                      <Users className="w-5 h-5 text-amber-600" />
                      <div>
                        <p className="font-medium text-foreground">No Stakeholders Found</p>
                        <p className="text-sm text-muted-foreground">
                          The selected companies may need enrichment to populate stakeholder data
                        </p>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Stakeholders Table */}
            <ScrollArea className="flex-1">
              <div className="rounded-lg border overflow-hidden bg-accent">
                <Table className="accent-grid-table">
                  <TableHeader>
                    <TableRow className="bg-accent border-b border-black/20">
                      <TableHead className="text-black font-semibold">Name</TableHead>
                      <TableHead className="text-black font-semibold">Title</TableHead>
                      <TableHead className="text-black font-semibold">Company</TableHead>
                      <TableHead className="text-black font-semibold text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* Empty rows skeleton while searching */}
                    {isSearchingStakeholders && (
                      <>
                        {[1, 2, 3, 4, 5].map((i) => (
                          <TableRow key={`skeleton-${i}`} className="border-b border-black/10 animate-pulse">
                            <TableCell>
                              <div className="h-4 bg-black/10 rounded w-32" />
                            </TableCell>
                            <TableCell>
                              <div className="h-4 bg-black/10 rounded w-24" />
                            </TableCell>
                            <TableCell>
                              <div className="h-4 bg-black/10 rounded w-28" />
                            </TableCell>
                            <TableCell>
                              <div className="h-4 bg-black/10 rounded w-20 ml-auto" />
                            </TableCell>
                          </TableRow>
                        ))}
                      </>
                    )}

                    {/* Animated stakeholder rows */}
                    {!isSearchingStakeholders && displayedStakeholders.map((stakeholder, index) => (
                      <TableRow 
                        key={stakeholder.id} 
                        className="border-b border-black/10 animate-fade-in"
                        style={{ animationDelay: `${index * 50}ms` }}
                      >
                        <TableCell className="font-medium">
                          <Link
                            to={`/stakeholders/${stakeholder.id}`}
                            className="text-black hover:underline"
                            onClick={() => onOpenChange(false)}
                          >
                            {stakeholder.name}
                          </Link>
                        </TableCell>
                        <TableCell className="text-black/80">
                          {stakeholder.title || "—"}
                        </TableCell>
                        <TableCell className="text-black/80">
                          {stakeholder.company_name || "—"}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            {stakeholder.email && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-8 h-8 text-black hover:bg-black/10"
                                onClick={() => window.open(`mailto:${stakeholder.email}`, "_blank")}
                              >
                                <Mail className="w-4 h-4" />
                              </Button>
                            )}
                            {stakeholder.phone && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-8 h-8 text-black hover:bg-black/10"
                                onClick={() => window.open(`tel:${stakeholder.phone}`, "_blank")}
                              >
                                <Phone className="w-4 h-4" />
                              </Button>
                            )}
                            {stakeholder.linkedin_url && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-8 h-8 text-black hover:bg-black/10"
                                onClick={() => window.open(stakeholder.linkedin_url!, "_blank")}
                              >
                                <Linkedin className="w-4 h-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="icon"
                              className="w-8 h-8 text-black hover:bg-black/10"
                              onClick={() => {
                                onOpenChange(false);
                                window.location.href = `/stakeholders/${stakeholder.id}`;
                              }}
                            >
                              <ExternalLink className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}

                    {/* Empty state when no results after search */}
                    {!isSearchingStakeholders && !isEnriching && searchComplete && stakeholders.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="py-8">
                          <div className="flex flex-col items-center justify-center text-black/80">
                            {companiesWithDomains.length > 0 ? (
                              <>
                                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                                  <Sparkles className="w-8 h-8 text-primary" />
                                </div>
                                <p className="font-semibold text-lg mb-1">No Decision Makers Yet</p>
                                <p className="text-sm text-black/60 mb-4 max-w-xs text-center">
                                  AI research can identify key contacts at these companies.
                                </p>
                                <Button
                                  onClick={handleEnrichCompanies}
                                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                                >
                                  <Sparkles className="w-4 h-4 mr-2" />
                                  Find Decision Makers
                                </Button>
                              </>
                            ) : (
                              <>
                                <div className="w-16 h-16 rounded-full bg-black/10 flex items-center justify-center mb-4">
                                  <Zap className="w-8 h-8 text-black/60" />
                                </div>
                                <p className="font-semibold text-lg mb-1">No Contacts Found</p>
                                <p className="text-sm text-black/60 mb-4 max-w-xs text-center">
                                  Companies need domain information to discover decision makers.
                                </p>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )}

                    {/* Enrichment in progress */}
                    {isEnriching && (
                      <TableRow>
                        <TableCell colSpan={4} className="py-8">
                          <div className="flex flex-col items-center justify-center text-black/80">
                            <div className="w-16 h-16 rounded-full bg-purple-500/20 flex items-center justify-center mb-4">
                              <RefreshCw className="w-8 h-8 text-purple-600 animate-spin" />
                            </div>
                            <p className="font-semibold text-lg mb-1">Enriching Companies...</p>
                            <p className="text-sm text-black/60 mb-4">
                              {enrichmentProgress.current ? `Processing: ${enrichmentProgress.current}` : 'Preparing...'}
                            </p>
                            <div className="w-64 mb-2">
                              <Progress value={enrichmentPercent} className="h-2 bg-black/10" />
                            </div>
                            <p className="text-xs text-black/50">
                              {enrichmentProgress.completed} of {enrichmentProgress.total} complete
                            </p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </ScrollArea>

            {/* Actions */}
            <div className="flex justify-between items-center gap-2 pt-4 border-t mt-4">
              <div className="flex gap-2">
                {!isEnriching && !isSearchingStakeholders && searchComplete && companiesWithDomains.length > 0 && (
                  <Button
                    onClick={handleEnrichCompanies}
                    variant="default"
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Find Decision Makers ({companiesWithDomains.length})
                  </Button>
                )}
                {!isEnriching && !isSearchingStakeholders && searchComplete && companiesWithDomains.length === 0 && selectedCompaniesArray.length > 0 && (
                  <p className="text-sm text-muted-foreground">
                    No companies have domain information for enrichment
                  </p>
                )}
              </div>
              <Button
                onClick={handleClose}
                disabled={isEnriching}
                variant="outline"
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Done
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
