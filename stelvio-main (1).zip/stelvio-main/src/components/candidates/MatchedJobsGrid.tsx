import { useState, useEffect, useRef, useCallback, startTransition } from "react";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Info, Loader2, Search, CheckCircle2, Users, ChevronDown, ChevronUp, AlertCircle, StopCircle, Database, Timer } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { StakeholderSearchWizard } from "./StakeholderSearchWizard";
import { JobMatchingProgressModal } from "./JobMatchingProgressModal";
import { useAuth } from "@/contexts/AuthContext";
import { SearchCostEstimate } from "./SearchCostEstimate";
import { SearchDebugFeed } from "./SearchDebugFeed";
import { UXDebugLogger, addUXLog } from "./UXDebugLogger";

import { isValidSalaryDisplay } from "@/lib/salaryValidation";

// Sanitize pipeline event messages - strip JSON payloads that shouldn't be shown to users
function sanitizeStatusMessage(msg: string): string {
  const trimmed = msg.trim();
  // If the message starts with { or [ it's a raw JSON payload - don't display it
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    return '';
  }
  return trimmed;
}

// Expandable reasoning cell component — always 2 rows: text row + show more/less row
function ExpandableReasoning({ reason }: { reason: string | null }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const text = reason || "-";
  const isLongText = text.length > 80;

  return (
    <div className="flex flex-col">
      <p className={`text-xs text-foreground leading-tight ${isExpanded ? "" : "line-clamp-1"}`}>
        {text}
      </p>
      {isLongText && text !== "-" ? (
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center gap-0.5 text-[10px] font-medium text-foreground/50 hover:text-foreground transition-colors leading-tight mt-px"
        >
          {isExpanded ? (
            <><ChevronUp className="w-2.5 h-2.5" />Show less</>
          ) : (
            <><ChevronDown className="w-2.5 h-2.5" />Show more</>
          )}
        </button>
      ) : (
        <span className="text-[10px] leading-tight mt-px opacity-0 select-none">·</span>
      )}
    </div>
  );
}

interface Match {
  id: string;
  job_id: string;
  match_score: number;
  match_reason: string | null;
  skills_matched: string[] | null;
  skills_missing: string[] | null;
  status: string;
  created_at?: string;
  // Salary benchmark data
  salary_benchmark: {
    min?: number;
    max?: number;
    median?: number;
    job_salary?: number;
    currency?: string;
  } | null;
  salary_percentile: number | null;
  jobs: {
    id: string;
    title: string;
    source_url: string | null;
    location: string | null;
    job_type: string | null;
    salary_range: string | null;
    posted_at: string | null;
    companies: { 
      id: string; 
      name: string;
      created_by: string | null;
    } | null;
  };
}

interface MatchedJobsGridProps {
  matches: Match[];
  onMatchUpdated: () => void;
  candidateId: string;
  candidateName: string;
}

// Session storage key for persisting active search state
const ACTIVE_SEARCH_KEY = 'lurq_active_search';
// Searches can run in multiple waves and exceed 10 minutes; keep state long enough
// to survive navigation and re-login during an active run.
const ACTIVE_SEARCH_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours

// Local storage key for resuming the pipeline after being redirected to /login.
// (Must be localStorage so it survives a full auth redirect + page reload.)
const PIPELINE_RESUME_KEY = 'lurq_pipeline_resume_v1';

interface ActiveSearchState {
  candidateId: string;
  startedAt: number;
  status: string;
}

function getActiveSearch(): ActiveSearchState | null {
  try {
    const stored = sessionStorage.getItem(ACTIVE_SEARCH_KEY);
    if (!stored) return null;
    const parsed = JSON.parse(stored) as ActiveSearchState;
    // Expire after TTL
    if (typeof parsed?.startedAt !== 'number' || Date.now() - parsed.startedAt > ACTIVE_SEARCH_TTL_MS) {
      sessionStorage.removeItem(ACTIVE_SEARCH_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function setActiveSearch(candidateId: string, status: string) {
  sessionStorage.setItem(ACTIVE_SEARCH_KEY, JSON.stringify({
    candidateId,
    startedAt: Date.now(),
    status,
  }));
}

function clearActiveSearch() {
  sessionStorage.removeItem(ACTIVE_SEARCH_KEY);
}

export function MatchedJobsGrid({ matches, onMatchUpdated, candidateId, candidateName }: MatchedJobsGridProps) {
  const { formatDate } = useLocaleFormat();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const { session: authSession, user } = useAuth();
  const [addingMatchId, setAddingMatchId] = useState<string | null>(null);
  const [showStakeholderWizard, setShowStakeholderWizard] = useState(false);
  
  // Local matches state for real-time updates during search
  // This allows the grid to display matches even if the parent doesn't refresh
  const [localMatches, setLocalMatches] = useState<Match[]>([]);
  
  // Merge parent matches with locally-fetched matches (prefer parent when not searching)
  const effectiveMatches = localMatches.length > 0 ? localMatches : matches;

  const writeClientDebugEvent = useCallback(
    async (payload: Record<string, unknown>) => {
      // Best-effort debug logging. If RLS blocks this, we silently ignore.
      try {
        if (!candidateId || !user?.id) return;
        await supabase.from('pipeline_events').insert({
          candidate_id: candidateId,
          created_by: user.id,
          event_type: 'debug',
          message: JSON.stringify({
            source: 'client',
            at: new Date().toISOString(),
            route: location.pathname,
            ...payload,
          }),
        });
      } catch {
        // ignore
      }
    },
    [candidateId, location.pathname, user?.id]
  );
  
  // Search state
  const [isSearching, setIsSearching] = useState(false);
  const [isStopping, setIsStopping] = useState(false);
  const stopRequestedRef = useRef(false);
  const [searchStatus, setSearchStatus] = useState<string>("");
  const [searchComplete, setSearchComplete] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [firecrawlQuotaExceeded, setFirecrawlQuotaExceeded] = useState(false);
  const [newJobsCount, setNewJobsCount] = useState(0);
  const [rejectionSummary, setRejectionSummary] = useState<{ reason: string; count: number }[]>([]);
  const [pendingJobsCount, setPendingJobsCount] = useState(0);
  const [isMatchingExisting, setIsMatchingExisting] = useState(false);
  const scoreRetryCountRef = useRef(0);
  const lastPendingCountRef = useRef(0);
  const chainContinuationCountRef = useRef(0);
  const MAX_CHAIN_CONTINUATIONS = 10;
  const [searchProgress, setSearchProgress] = useState<{
    searchCriteria: string;
    boardsSearched: Array<{ name: string; status: 'success' | 'failed' | 'timeout' | 'searching'; jobsFound: number }>;
    totalBoardsAttempted: number;
    matchThreshold: number;
    // Continuation tracking
    stoppedDueToTimeout?: boolean;
    nextBoardIndex?: number;
    totalBoardsAvailable?: number;
    isContinuation?: boolean;
  } | null>(null);
  
  // Active job board count for cost estimation
  const [activeBoardCount, setActiveBoardCount] = useState(0);
  
  // Target matches setting from app_settings
  const [targetMatches, setTargetMatches] = useState(20);

  // Progress modal state
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [searchStartedAt, setSearchStartedAt] = useState<number | null>(null);

  // Realtime-derived board progress (so boards show up while mining, even before the function returns)
  const [realtimeBoards, setRealtimeBoards] = useState<Record<string, { name: string; status: 'success' | 'failed' | 'timeout' | 'searching'; jobsFound: number }>>({});
  
  // Ref for scrolling to results
  const resultsRef = useRef<HTMLDivElement>(null);

  const scrollToResults = useCallback(() => {
    // Use a short delay to ensure the banner DOM is rendered before scrolling.
    // requestAnimationFrame + setTimeout ensures React has flushed the update.
    requestAnimationFrame(() => {
      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 50);
    });
  }, []);
  
  // Ref for polling interval cleanup
  const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  
  // Ref for restored search polling
  const restoredSearchPollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  
  // Ref for onMatchUpdated to avoid dependency array issues
  const onMatchUpdatedRef = useRef(onMatchUpdated);
  useEffect(() => {
    onMatchUpdatedRef.current = onMatchUpdated;
  }, [onMatchUpdated]);
  
  // Ref to access handleFindJobs from the restore effect (defined later)
  const handleFindJobsRef = useRef<(continueFromBoard?: number, mode?: 'scrape' | 'score') => Promise<void>>();
  
  // Flag to trigger rejection summary fetch after search completes (avoids using callback before declaration)
  const [needsRejectionSummary, setNeedsRejectionSummary] = useState(false);

  // Auto-close progress modal when search ends and reset timer
  useEffect(() => {
    if (!isSearching && showProgressModal) {
      // Delay slightly so user sees the final state
      const t = setTimeout(() => {
        setShowProgressModal(false);
        setSearchStartedAt(null);
      }, 1500);
      return () => clearTimeout(t);
    }
  }, [isSearching, showProgressModal]);

  // Keep the session alive during long-running searches to avoid redirecting to /login mid-pipeline.
  // This is intentionally lightweight (periodic refresh) and only runs while the pipeline is active.
  useEffect(() => {
    if (!isSearching) return;

    let cancelled = false;
    const interval = window.setInterval(async () => {
      if (cancelled) return;
      try {
        const { data } = await supabase.auth.getSession();
        // If there's no session (or it's close to expiring), attempt a refresh.
        if (!data.session) {
          await supabase.auth.refreshSession();
        }
      } catch {
        // Ignore refresh errors; the UI will handle auth redirects and resume via PIPELINE_RESUME_KEY.
      }
    }, 4 * 60 * 1000); // every 4 minutes

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, [isSearching]);

  const parseBoardsFromTimeoutMessage = useCallback((message: string | null | undefined) => {
    if (!message) return null;
    const boardMatch = message.match(/Searched (\d+) of (\d+) boards/i);
    if (!boardMatch) return null;
    return {
      boardsSearched: parseInt(boardMatch[1], 10),
      totalBoards: parseInt(boardMatch[2], 10),
    };
  }, []);

  // On mount (or after login), check if there's an incomplete search that needs auto-continuation.
  // This runs ALWAYS - not just when PIPELINE_RESUME_KEY exists - to catch paused searches.
  // 
  // CRITICAL: We use a ref-based approach to ensure the effect re-runs when auth becomes available,
  // even if React batches state updates. The effect schedules a check that runs after a short delay
  // to allow the handleFindJobsRef to be populated.
  const hasTriedAutoResumeRef = useRef(false);
  const autoResumeAttemptRef = useRef(0);
  
  useEffect(() => {
    // Reset the flag when candidateId changes
    hasTriedAutoResumeRef.current = false;
    autoResumeAttemptRef.current = 0;
  }, [candidateId]);
  
  useEffect(() => {
    const accessToken = authSession?.access_token;
    
    // Don't run if no auth, already tried, or already searching
    if (!accessToken || isSearching) return;
    
    // Limit retry attempts
    if (autoResumeAttemptRef.current >= 3) return;
    autoResumeAttemptRef.current += 1;

    const checkForIncompleteSearch = async () => {
      // Ensure the handleFindJobs ref is ready
      if (!handleFindJobsRef.current) {
        console.log('Resume: handleFindJobsRef not ready, will retry on next render');
        return;
      }
      
      // Don't run again if we've already successfully started
      if (hasTriedAutoResumeRef.current) return;
      
      try {
        // Clear any stale resume key for THIS candidate
        const raw = window.localStorage.getItem(PIPELINE_RESUME_KEY);
        if (raw) {
          const parsed = JSON.parse(raw) as { candidateId?: string };
          if (parsed?.candidateId === candidateId) {
            window.localStorage.removeItem(PIPELINE_RESUME_KEY);
            console.log('Resume: Cleared PIPELINE_RESUME_KEY for this candidate');
          }
        }

        // FIRST: Check for pending jobs that need scoring (most common case after session expiry)
        const { count: pendingJobsCount, error: pendingErr } = await supabase
          .from('pipeline_pending_jobs')
          .select('id', { count: 'exact' })
          .eq('candidate_id', candidateId)
          .eq('status', 'pending')
          .limit(1);

        if (pendingErr) {
          // If we can't read pending jobs (likely auth/session), do not conclude anything.
          addUXLog('error', 'Resume', 'Failed to check pending jobs', { error: pendingErr.message });
          await writeClientDebugEvent({
            kind: 'resume_check_failed',
            where: 'pending_jobs_count',
            error: pendingErr.message,
          });
          return;
        }
        
        const hasPendingJobs = (pendingJobsCount || 0) > 0;
        
        // Check current match count against target
        const [matchResult, targetResult] = await Promise.all([
          supabase.from('matches').select('id', { count: 'exact' }).eq('candidate_id', candidateId).limit(1),
          supabase.from('app_settings').select('setting_value').eq('setting_key', 'target_matches').maybeSingle()
        ]);

        const currentMatches = matchResult.count || 0;
        const target = targetResult.data?.setting_value ? parseInt(targetResult.data.setting_value, 10) || 25 : 25;
        const needsMoreMatches = currentMatches < target;

        console.log(`Resume: matches=${currentMatches}/${target}, pendingJobs=${pendingJobsCount}, needsMore=${needsMoreMatches}`);
        addUXLog('info', 'Resume', `Check: ${currentMatches}/${target} matches, ${pendingJobsCount} pending`, { needsMoreMatches, hasPendingJobs });

        // Priority 1: If there are pending jobs and we need matches, trigger scoring immediately
        if (hasPendingJobs && needsMoreMatches) {
          hasTriedAutoResumeRef.current = true;
          console.log(`Resume: AUTO-SCORING ${pendingJobsCount} pending jobs`);
          addUXLog('success', 'Resume', `Auto-triggering score phase for ${pendingJobsCount} pending jobs`);
          setSearchStatus(`Scoring ${pendingJobsCount} pending jobs...`);
          setIsSearching(true);
          
          // Use a short delay to ensure UI updates before the async call
          setTimeout(() => {
            handleFindJobsRef.current?.(undefined, 'score');
          }, 100);
          return;
        }

        // Priority 2: Check for scrape timeout events that need continuation
        const windowStart = new Date(Date.now() - 30 * 60 * 1000).toISOString(); // 30 min window
        const { data: events } = await supabase
          .from('pipeline_events')
          .select('message, created_at')
          .eq('candidate_id', candidateId)
          .eq('event_type', 'warning')
          .gte('created_at', windowStart)
          .order('created_at', { ascending: false })
          .limit(10);

        const timeoutEvent = events?.find(e =>
          e.message?.includes('time limit reached') || e.message?.includes('Search paused')
        );

        if (!timeoutEvent?.message) {
          console.log('Resume: No pending jobs or timeout events - nothing to resume');
          hasTriedAutoResumeRef.current = true;
          return;
        }

        // Parse board progress
        const boardMatch = timeoutEvent.message.match(/Searched (\d+) of (\d+) boards/);
        if (!boardMatch) {
          console.log('Resume: Could not parse board progress from:', timeoutEvent.message);
          hasTriedAutoResumeRef.current = true;
          return;
        }

        const boardsSearched = parseInt(boardMatch[1], 10);
        const totalBoards = parseInt(boardMatch[2], 10);

        if (boardsSearched >= totalBoards) {
          console.log('Resume: All boards already searched');
          hasTriedAutoResumeRef.current = true;
          return;
        }

        if (currentMatches >= target) {
          console.log('Resume: Target already met, no continuation needed');
          hasTriedAutoResumeRef.current = true;
          return;
        }

        // Need to continue scraping - trigger search from where we left off
        hasTriedAutoResumeRef.current = true;
        console.log(`Resume: AUTO-CONTINUING scrape from board ${boardsSearched}`);
        addUXLog('success', 'Resume', `Auto-continuing scrape from board ${boardsSearched}/${totalBoards}`);
        setSearchStatus(`Resuming search from board ${boardsSearched}/${totalBoards}...`);
        setIsSearching(true);
        
        setTimeout(() => {
          handleFindJobsRef.current?.(boardsSearched, 'scrape');
        }, 100);
      } catch (err) {
        console.error('Resume: Error checking for incomplete search:', err);
        addUXLog('error', 'Resume', 'Error during auto-resume check', { error: (err as Error)?.message });
      }
    };

    // Run check after a short delay to ensure refs are populated and component is stable
    const timer = setTimeout(checkForIncompleteSearch, 500);
    return () => clearTimeout(timer);
  }, [authSession?.access_token, candidateId, isSearching, writeClientDebugEvent]);
  
  // Track if we've already restored active search to prevent repeated restores
  const hasRestoredSearchRef = useRef(false);
  
  // Reset the restore flag when candidateId changes
  useEffect(() => {
    hasRestoredSearchRef.current = false;
  }, [candidateId]);

  // On mount: Check if there's an active search for this candidate and restore state
  useEffect(() => {
    // Skip if we've already restored or if search is already active
    if (hasRestoredSearchRef.current || isSearching) return;
    
    const activeSearch = getActiveSearch();
    if (activeSearch && activeSearch.candidateId === candidateId) {
      hasRestoredSearchRef.current = true;
      console.log('Restoring active search state for candidate:', candidateId);
      setIsSearching(true);
      setShowProgressModal(true);
      setSearchStartedAt(activeSearch.startedAt || Date.now());
      setSearchStatus(activeSearch.status || "Search in progress...");
      // Keep the live grid in view even if there are currently 0 matches.
      scrollToResults();
      // Refresh matches immediately
      onMatchUpdatedRef.current();
      
      // Start polling to detect when the search completes
      // The search is running server-side; we just need to monitor pipeline_events
      let pollCount = 0;
       // Runs can pause/continue in waves; 5 minutes was too short and could falsely mark
       // a paused run as "complete" while boards remain.
       const maxPolls = 360; // 30 minutes max (5s interval)
      
      restoredSearchPollRef.current = setInterval(async () => {
        pollCount++;
        
        // Refresh matches
        onMatchUpdatedRef.current();
        
        // Check for completion events and pending jobs
        const [eventsResult, pendingResult, matchResult, targetResult] = await Promise.all([
          supabase.from('pipeline_events').select('event_type, message, created_at').eq('candidate_id', candidateId).neq('event_type', 'debug').order('created_at', { ascending: false }).limit(5),
          supabase.from('pipeline_pending_jobs').select('id', { count: 'exact' }).eq('candidate_id', candidateId).eq('status', 'pending').limit(1),
          supabase.from('matches').select('id', { count: 'exact' }).eq('candidate_id', candidateId).limit(1),
          supabase.from('app_settings').select('setting_value').eq('setting_key', 'target_matches').maybeSingle()
        ]);
        
        const events = eventsResult.data;
        const pendingJobsCount = pendingResult.count || 0;
        const hasPendingJobs = pendingJobsCount > 0;
        const totalMatchesInDB = matchResult.count || 0;
        const freshTargetMatches = targetResult.data?.setting_value 
          ? parseInt(targetResult.data.setting_value, 10) || 20 
          : 20;
        const needsMoreMatches = totalMatchesInDB < freshTargetMatches;
        
        // Look for completion indicators
        const completionEvent = events?.find(e => 
          e.event_type === 'success' || 
          (e.event_type === 'info' && e.message?.includes('Search complete'))
        );
        
        const timeoutEvent = events?.find(e => 
          e.event_type === 'warning' && e.message?.includes('time limit reached')
        );
        
        // Priority 1: If there are pending jobs and we need matches, trigger scoring
        if (hasPendingJobs && needsMoreMatches) {
          console.log(`Restored poll: Triggering score phase (${pendingJobsCount} pending, ${totalMatchesInDB}/${freshTargetMatches} matches)`);
          if (restoredSearchPollRef.current) {
            clearInterval(restoredSearchPollRef.current);
            restoredSearchPollRef.current = null;
          }
          setSearchStatus(`Scoring ${pendingJobsCount} pending jobs...`);
          setTimeout(() => handleFindJobsRef.current?.(undefined, 'score'), 1000);
          return;
        }
        
        if (completionEvent && !hasPendingJobs) {
          // Search completed and no pending jobs!
          console.log('Restored search detected completion:', completionEvent);
          if (restoredSearchPollRef.current) {
            clearInterval(restoredSearchPollRef.current);
            restoredSearchPollRef.current = null;
          }
          setIsSearching(false);
          setSearchComplete(true);
          clearActiveSearch();
          setSearchStatus(`Search complete! Found ${totalMatchesInDB} matches.`);
          setNeedsRejectionSummary(true);
          return;
        }
        
        if (timeoutEvent && !hasPendingJobs) {
          // Timeout detected and no pending - check if we should continue scraping
          console.log('Restored search detected timeout event:', timeoutEvent);
          
          const parsedBoards = parseBoardsFromTimeoutMessage(timeoutEvent.message);
          const boardsSearched = parsedBoards?.boardsSearched ?? 0;
          const totalBoards = parsedBoards?.totalBoards ?? 0;
          const hasMoreBoards = boardsSearched > 0 && boardsSearched < totalBoards;
          
          if (hasMoreBoards && needsMoreMatches) {
            if (restoredSearchPollRef.current) {
              clearInterval(restoredSearchPollRef.current);
              restoredSearchPollRef.current = null;
            }
            
            const remaining = totalBoards - boardsSearched;
            console.log(`AUTO-CONTINUING scrape from restored state: ${totalMatchesInDB} matches, ${remaining} boards remaining`);
            setSearchStatus(`Found ${totalMatchesInDB}/${freshTargetMatches} matches - searching ${remaining} more boards...`);
            
            setTimeout(() => handleFindJobsRef.current?.(boardsSearched, 'scrape'), 1000);
            return;
          }
          
          // No more boards or target met
          if (restoredSearchPollRef.current) {
            clearInterval(restoredSearchPollRef.current);
            restoredSearchPollRef.current = null;
          }
          setIsSearching(false);
          setSearchComplete(true);
          clearActiveSearch();
          
          const matchCount = (await supabase.from('matches').select('id', { count: 'exact' }).eq('candidate_id', candidateId).limit(1)).count || 0;
          setSearchStatus(`Search complete. Found ${matchCount} matches.`);
          setNeedsRejectionSummary(true);
          return;
        }
        
        // Update status from latest event
        const latestStatus = events?.find(e => e.event_type === 'info' || e.event_type === 'warning');
        if (latestStatus?.message) {
          setSearchStatus(latestStatus.message);
        }
        
        if (pollCount >= maxPolls) {
          // Timeout - assume search is done
          if (restoredSearchPollRef.current) {
            clearInterval(restoredSearchPollRef.current);
            restoredSearchPollRef.current = null;
          }
          setIsSearching(false);
          setSearchComplete(true);
          clearActiveSearch();
          setSearchStatus("Search monitoring timed out. Showing available results.");
        }
      }, 5000);
    }
    
    return () => {
      if (restoredSearchPollRef.current) {
        clearInterval(restoredSearchPollRef.current);
      }
    };
  }, [candidateId, isSearching, scrollToResults]);

  // If a search becomes active (including auto-resume), keep the live results section visible.
  useEffect(() => {
    if (!isSearching) return;
    scrollToResults();
  }, [isSearching, scrollToResults]);
  
  // Cleanup polling interval on unmount
  useEffect(() => {
    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
      }
    };
  }, []);
  
  // Fetch active job board count and target matches setting
  useEffect(() => {
    async function fetchSettings() {
      // Fetch board count
      const { count } = await supabase
        .from('job_boards')
        .select('id', { count: 'exact' })
        .eq('status', 'active')
        .not('search_url_template', 'is', null)
        .limit(1);
      setActiveBoardCount(count || 0);
      
      // Fetch target matches setting
      const { data: targetSetting } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'target_matches')
        .maybeSingle();
      
      if (targetSetting?.setting_value) {
        const parsed = parseInt(targetSetting.setting_value, 10);
        if (!isNaN(parsed) && parsed >= 1 && parsed <= 100) {
          setTargetMatches(parsed);
        }
      }
    }
    fetchSettings();
  }, []);

  // NOTE: Realtime subscription for matches is handled by the PARENT component (CandidateDetail).
  // Do NOT add a second subscription here - it causes an infinite remount loop:
  // subscription fires → onMatchUpdated → parent refetch → grid remount → new subscription → repeat.
  // The parent's subscription + polling is sufficient.

  // Fallback polling: some environments/domains can miss realtime events.
  // While searching, poll periodically to keep the grid + status fresh.
  // Uses refs to track last-seen values and only triggers updates when data changes,
  // preventing layout shifts ("shaking") from unnecessary re-renders.
  // 
  // PERFORMANCE: Uses startTransition for heavy state updates to prevent UI freezing,
  // and uses longer intervals during heavy scoring phases.
  const lastPollMatchCountRef = useRef<number | null>(null);
  const lastPollStatusRef = useRef<string | null>(null);
  const pollTickCountRef = useRef(0);

  useEffect(() => {
    if (!isSearching || !candidateId) return;

    addUXLog('info', 'Polling', 'Starting fallback polling for matches', { candidateId: candidateId.slice(0, 8) });

    let cancelled = false;
    let timeoutId: ReturnType<typeof setTimeout> | null = null;

    const tick = async () => {
      if (cancelled) return;
      pollTickCountRef.current += 1;

      try {
        // First, quickly fetch just counts to determine polling strategy
        const [matchCountResult, pendingCountResult] = await Promise.all([
          supabase.from('matches').select('id', { count: 'exact' }).eq('candidate_id', candidateId).limit(1),
          supabase.from('pipeline_pending_jobs').select('id', { count: 'exact' }).eq('candidate_id', candidateId).eq('status', 'pending').limit(1)
        ]);

        const matchCount = matchCountResult.count ?? 0;
        const pendingCount = pendingCountResult.count ?? 0;
        const isHeavyScoring = pendingCount > 50;
        
        // Update pending jobs count in state for UI display
        setPendingJobsCount(pendingCount);

        addUXLog('info', 'Polling', `Tick #${pollTickCountRef.current}: ${matchCount} matches, ${pendingCount} pending`, { 
          matchCount, 
          pendingCount, 
          isHeavyScoring,
          lastKnownMatchCount: lastPollMatchCountRef.current
        });

        // Fetch full match data when count changes or on regular intervals
        const countChanged = lastPollMatchCountRef.current !== matchCount;
        const isRegularRefresh = !isHeavyScoring && pollTickCountRef.current % 2 === 0;
        
        if (countChanged || isRegularRefresh) {
          if (countChanged) {
            addUXLog('success', 'Polling', `Match count changed: ${lastPollMatchCountRef.current} → ${matchCount}, fetching full data`);
          }
          lastPollMatchCountRef.current = matchCount;

          // Fetch full match data in background, use startTransition to keep UI responsive
          const { data: matchesData, error: matchesError } = await supabase
            .from('matches')
            .select(`
              id,
              job_id,
              match_score,
              match_reason,
              skills_matched,
              skills_missing,
              status,
              created_at,
              salary_benchmark,
              salary_percentile,
              jobs(id, title, source_url, location, job_type, salary_range, posted_at, companies(id, name, created_by))
            `)
            .eq('candidate_id', candidateId)
            .order('match_score', { ascending: false });

          if (matchesError) {
            addUXLog('error', 'Polling', 'Failed to fetch full match data', { error: matchesError.message });
          } else if (matchesData && !cancelled) {
            addUXLog('success', 'Polling', `Fetched ${matchesData.length} matches, updating grid`);
            // Use startTransition to prevent blocking the UI during large state updates
            startTransition(() => {
              setLocalMatches(matchesData as unknown as Match[]);
            });
          }
        }

        // Fetch latest pipeline event (with event_type to detect completion)
        // Exclude debug events (client-side JSON logs) from status display
        const { data } = await supabase
          .from('pipeline_events')
          .select('message, event_type')
          .eq('candidate_id', candidateId)
          .neq('event_type', 'debug')
          .order('created_at', { ascending: false })
          .limit(1);

        const latestEvent = data?.[0];
        const msg = latestEvent?.message ?? null;
        const eventType = latestEvent?.event_type ?? null;

        if (msg && msg !== lastPollStatusRef.current) {
          addUXLog('info', 'Polling', `New pipeline event: [${eventType}] ${msg.slice(0, 100)}...`);
          lastPollStatusRef.current = msg;
          const sanitized = sanitizeStatusMessage(msg);
          if (sanitized) setSearchStatus(sanitized);
        }

        // Detect if scrape finished and we need to auto-trigger scoring
        // Look for "queued for AI scoring" message with pending jobs ready
        const scrapeDoneNeedsScoring = pendingCount > 0 && 
          matchCount < targetMatches &&
          msg && (
            msg.includes('queued for AI scoring') ||
            msg.includes('Scrape paused') ||
            (msg.includes('jobs queued') && !msg.includes('Scoring'))
          );
        
        if (scrapeDoneNeedsScoring) {
          addUXLog('success', 'Polling', `Auto-triggering scoring phase: ${pendingCount} pending, ${matchCount}/${targetMatches} matches`);
          setSearchStatus(`Scoring ${pendingCount} pending jobs...`);
          // Trigger scoring after a short delay to allow UI to update
          setTimeout(() => {
            handleFindJobsRef.current?.(undefined, 'score');
          }, 1000);
          // Continue polling so the modal keeps updating during scoring
          if (!cancelled) {
            timeoutId = setTimeout(tick, 6000);
          }
          return;
        }

        // Detect completion: success event or "Target reached" message
        if (
          eventType === 'success' ||
          (msg && (msg.includes('Target reached') || msg.includes('Search complete')))
        ) {
          addUXLog('success', 'Polling', 'Search completion detected!', { eventType, msg: msg?.slice(0, 100) });
          
          // Fetch final matches before transitioning state to ensure grid stays populated
          const { data: finalMatches } = await supabase
            .from('matches')
            .select(`
              id,
              job_id,
              match_score,
              match_reason,
              skills_matched,
              skills_missing,
              status,
              created_at,
              salary_benchmark,
              salary_percentile,
              jobs(id, title, source_url, location, job_type, salary_range, posted_at, companies(id, name, created_by))
            `)
            .eq('candidate_id', candidateId)
            .order('match_score', { ascending: false });
          
          if (finalMatches) {
            setLocalMatches(finalMatches as unknown as Match[]);
          }
          
          setIsSearching(false);
          setSearchComplete(true);
          clearActiveSearch();
          setNeedsRejectionSummary(true);
          onMatchUpdated();
          return; // Don't schedule next tick
        }

        // Schedule next tick with adaptive interval
        // Use longer intervals during heavy scoring to reduce UI load
        const nextInterval = isHeavyScoring ? 8000 : 4000;
        if (!cancelled) {
          timeoutId = setTimeout(tick, nextInterval);
        }
      } catch (err: any) {
        addUXLog('error', 'Polling', 'Polling tick failed', { error: err?.message });
        // On error, still schedule next tick
        if (!cancelled) {
          timeoutId = setTimeout(tick, 4000);
        }
      }
    };

    // Run immediately
    void tick();

    return () => {
      cancelled = true;
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      addUXLog('info', 'Polling', 'Polling stopped');
    };
  }, [isSearching, candidateId, targetMatches]);

  // Subscribe to pipeline events for live progress updates
  useEffect(() => {
    if (!isSearching || !candidateId) return;

    addUXLog('info', 'Realtime', `Setting up pipeline_events subscription for candidate ${candidateId.slice(0, 8)}...`);

    const channel = supabase
      .channel(`pipeline-events-${candidateId}-${Date.now()}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'pipeline_events',
          filter: `candidate_id=eq.${candidateId}`,
        },
        (payload) => {
          const event = payload.new as { message: string; event_type: string };
          addUXLog('info', 'Realtime', `Pipeline event received: [${event?.event_type}]`, { 
            message: event?.message?.slice(0, 150) 
          });
          
          // Skip debug events - they contain JSON payloads not meant for user display
          if (event?.message && event?.event_type !== 'debug') {
            const sanitized = sanitizeStatusMessage(event.message);
            if (sanitized) setSearchStatus(sanitized);

            // Parse board progress from messages like:
            // - "Searching LinkedIn..."
            // - "LinkedIn: Found 5 jobs"
            // - "Dice: Found 1 jobs"
            const searchingMatch = event.message.match(/^Searching\s+(.+?)\.\.\.$/i);
            const foundMatch = event.message.match(/^(.+?):\s*Found\s+(\d+)\s+jobs?/i);

            if (searchingMatch?.[1]) {
              const name = searchingMatch[1].trim();
              setRealtimeBoards((prev) => ({
                ...prev,
                [name]: {
                  name,
                  status: prev[name]?.status === 'success' ? 'success' : 'searching',
                  jobsFound: prev[name]?.jobsFound ?? 0,
                },
              }));
            }

            if (foundMatch?.[1]) {
              const name = foundMatch[1].trim();
              const jobsFound = Number(foundMatch[2] || 0);
              setRealtimeBoards((prev) => ({
                ...prev,
                [name]: {
                  name,
                  status: 'success',
                  jobsFound,
                },
              }));
            }
          }
        }
      )
      .subscribe((status, err) => {
        addUXLog(
          err ? 'error' : status === 'SUBSCRIBED' ? 'success' : 'info',
          'Realtime',
          `Pipeline events subscription status: ${status}`,
          err ? { error: err.message } : undefined
        );
      });

    return () => {
      addUXLog('info', 'Realtime', 'Cleaning up pipeline events subscription');
      supabase.removeChannel(channel);
    };
  }, [isSearching, candidateId]);

  // Fetch rejection summary from pipeline_events (used after a run, and also on load to explain short result sets)
  const fetchRejectionSummary = useCallback(async () => {
    // Look for the rejection_summary event (not individual rejection events)
    const { data: events } = await supabase
      .from('pipeline_events')
      .select('message, event_type')
      .eq('candidate_id', candidateId)
      .eq('event_type', 'rejection_summary')
      .order('created_at', { ascending: false })
      .limit(1);

    if (!events || events.length === 0) {
      setRejectionSummary([]);
      return;
    }

    try {
      // Parse the JSON message from rejection_summary event
      const summaryData = typeof events[0].message === 'string' 
        ? JSON.parse(events[0].message) 
        : events[0].message;
      
      if (!summaryData?.byReason) {
        setRejectionSummary([]);
        return;
      }

      // Map reason codes to human-readable labels
      const reasonLabels: Record<string, string> = {
        'company_too_large': 'Company too large',
        'job_too_old': 'Job posting too old',
        'low_score': 'Match score below threshold',
        'blocked_url': 'Non-job content filtered',
        'duplicate': 'Duplicate job',
        'company_unknown': 'Company not found',
        'scrape_failed': 'Failed to load job',
        'content_too_short': 'Insufficient job details',
        'location_mismatch': 'Location mismatch',
        'not_job_posting': 'Not a job posting',
        'ai_parse_failed': 'AI parsing failed'
      };

      // Convert byReason object to sorted array, filtering out zero counts
      const summary = Object.entries(summaryData.byReason as Record<string, number>)
        .filter(([, count]) => count > 0)
        .map(([reason, count]) => ({ 
          reason: reasonLabels[reason] || reason, 
          count 
        }))
        .sort((a, b) => b.count - a.count);

      setRejectionSummary(summary);
    } catch (e) {
      console.error('Failed to parse rejection summary:', e);
      setRejectionSummary([]);
    }
  }, [candidateId]);

  // On load (or after returning from /login), pull the latest rejection summary so users can see *why*
  // they got fewer matches than the target—even if the run finished earlier.
  // Also triggers when needsRejectionSummary flag is set by restored search polling.
  useEffect(() => {
    if (!candidateId) return;
    if (needsRejectionSummary) {
      fetchRejectionSummary();
      setNeedsRejectionSummary(false);
    }
  }, [candidateId, needsRejectionSummary, fetchRejectionSummary]);
  
  // Initial load of rejection summary
  useEffect(() => {
    if (!candidateId) return;
    fetchRejectionSummary();
  }, [candidateId, fetchRejectionSummary]);

  // Handle graceful stop of search
  const handleStopSearch = async () => {
    if (!candidateId || !user?.id || isStopping) return;
    
    stopRequestedRef.current = true;
    setIsStopping(true);
    setSearchStatus("Stopping search...");
    
    try {
      // Insert a stop_requested event that the pipeline will check
      await supabase.from('pipeline_events').insert({
        candidate_id: candidateId,
        created_by: user.id,
        event_type: 'stop_requested',
        message: JSON.stringify({
          requestedAt: new Date().toISOString(),
          reason: 'user_requested',
        }),
      });
      
      // CRITICAL: Fetch final matches BEFORE stopping the search state
      // This ensures the grid displays results immediately without waiting for parent refresh
      const { data: finalMatches } = await supabase
        .from('matches')
        .select(`
          id,
          job_id,
          match_score,
          match_reason,
          skills_matched,
          skills_missing,
          status,
          created_at,
          salary_benchmark,
          salary_percentile,
          jobs(id, title, source_url, location, job_type, salary_range, posted_at, companies(id, name, created_by))
        `)
        .eq('candidate_id', candidateId)
        .order('match_score', { ascending: false });
      
      if (finalMatches) {
        setLocalMatches(finalMatches as unknown as Match[]);
      }
      
      // Clear active search state
      clearActiveSearch();
      
      // Stop any polling
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
        pollIntervalRef.current = null;
      }
      if (restoredSearchPollRef.current) {
        clearInterval(restoredSearchPollRef.current);
        restoredSearchPollRef.current = null;
      }
      
      // Update UI state
      setIsSearching(false);
      setSearchComplete(true);
      setSearchStatus("Search stopped by user");
      setNeedsRejectionSummary(true);
      
      // Also trigger parent refresh for consistency
      onMatchUpdated();
      
      toast({
        title: "Search Stopped",
        description: `The job search has been stopped. ${finalMatches?.length || 0} results found so far.`,
      });
    } catch (err) {
      console.error('Failed to stop search:', err);
      toast({
        title: "Error",
        description: "Failed to stop the search. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsStopping(false);
    }
  };

  // Handler for matching against existing database jobs
  const handleMatchExistingJobs = async () => {
    resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    
    addUXLog('info', 'Search', 'Starting match-existing mode - scanning database jobs');
    
    setIsMatchingExisting(true);
    setSearchComplete(false);
    setSearchError(null);
    setFirecrawlQuotaExceeded(false);
    setNewJobsCount(0);
    setSearchStatus('Scanning database for matching jobs...');
    
    try {
      let accessToken = authSession?.access_token;
      
      if (!accessToken) {
        const { data } = await supabase.auth.getSession();
        accessToken = data.session?.access_token;
      }
      
      if (!accessToken) {
        const { data } = await supabase.auth.refreshSession();
        accessToken = data.session?.access_token;
      }
      
      if (!accessToken) {
        toast({
          title: "Session expired",
          description: "Please sign in again.",
          variant: "destructive",
        });
        setIsMatchingExisting(false);
        return;
      }
      
      const { data, error } = await supabase.functions.invoke('run-candidate-pipeline', {
        body: { candidateId, mode: 'match-existing' },
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      
      if (error) {
        console.error('Match existing error:', error);
        setSearchError(error.message || 'Failed to match existing jobs');
        toast({
          title: "Error",
          description: error.message || 'Failed to match existing jobs',
          variant: "destructive",
        });
      } else {
        const matchesSaved = data?.matchesSaved || 0;
        const jobsScored = data?.pendingJobsScored || 0;
        
        setNewJobsCount(matchesSaved);
        setSearchComplete(true);
        setSearchStatus(`Found ${matchesSaved} matches from ${jobsScored} existing jobs`);
        
        toast({
          title: "Database Scan Complete",
          description: `Found ${matchesSaved} new matches from ${jobsScored} jobs in your database.`,
        });
        
        // Refresh matches
        onMatchUpdated();
      }
    } catch (err: any) {
      console.error('Error matching existing jobs:', err);
      setSearchError(err.message || 'Failed to match existing jobs');
      toast({
        title: "Error",
        description: err.message || 'Failed to match existing jobs',
        variant: "destructive",
      });
    } finally {
      setIsMatchingExisting(false);
    }
  };

  const handleFindJobs = async (continueFromBoard?: number, mode: 'scrape' | 'score' = 'scrape') => {
    // Scroll to results section after React renders the banner
    scrollToResults();
    
    addUXLog('info', 'Search', `Starting search: mode=${mode}, continueFrom=${continueFromBoard ?? 'start'}`);
    
    // Reset state (but preserve previous boards if continuing)
    stopRequestedRef.current = false;
    setIsSearching(true);
    setIsStopping(false);
    setSearchComplete(false);
    if (!searchStartedAt) {
      setSearchStartedAt(Date.now());
    }
    setShowProgressModal(true);
    setSearchError(null);
    setFirecrawlQuotaExceeded(false);
    setNewJobsCount(0);
    if (!continueFromBoard && mode !== 'score') {
      // Only reset progress for fresh searches (not score-only phases)
      setSearchProgress(null);
      setRealtimeBoards({});
      setRejectionSummary([]);
      scoreRetryCountRef.current = 0;
      lastPendingCountRef.current = 0;
      chainContinuationCountRef.current = 0;
    }
    
    const modeLabel = mode === 'scrape' ? 'Discovering jobs' : 'Scoring jobs';
    setSearchStatus(continueFromBoard ? `${modeLabel} from position ${continueFromBoard + 1}...` : `${modeLabel}...`);

    try {
      addUXLog('info', 'Auth', `Checking auth session...`, { hasContextSession: Boolean(authSession?.access_token) });
      
      void writeClientDebugEvent({
        type: 'handle_find_jobs_start',
        continueFromBoard,
        mode,
        hasAuthSession: Boolean(authSession?.access_token),
      });

      // Prefer the AuthContext session, but fall back to a fresh read/refresh if needed.
      let accessToken = authSession?.access_token;

      if (!accessToken) {
        const { data } = await supabase.auth.getSession();
        accessToken = data.session?.access_token;
      }

      if (!accessToken) {
        const { data } = await supabase.auth.refreshSession();
        accessToken = data.session?.access_token;
      }

       if (!accessToken) {
          addUXLog('error', 'Auth', 'No access token available after refresh attempts - redirecting to login');
          
          void writeClientDebugEvent({
            type: 'missing_access_token_redirect_login',
            continueFromBoard,
          });
         try {
           let resumeFrom = typeof continueFromBoard === 'number' ? continueFromBoard : undefined;

           if (typeof resumeFrom !== 'number') {
             const { data: events } = await supabase
               .from('pipeline_events')
               .select('message, created_at')
               .eq('candidate_id', candidateId)
               .eq('event_type', 'warning')
               .ilike('message', '%time limit reached%')
               .order('created_at', { ascending: false })
               .limit(1);

             const parsed = parseBoardsFromTimeoutMessage(events?.[0]?.message);
             if (parsed?.boardsSearched) resumeFrom = parsed.boardsSearched;
           }

           window.localStorage.setItem(
             PIPELINE_RESUME_KEY,
             JSON.stringify({
               candidateId,
               continueFromBoard: typeof resumeFrom === 'number' ? resumeFrom : 0,
               candidateName,
             })
           );
         } catch {
           // ignore
         }

        toast({
          title: "Session expired",
          description: "Please sign in again to run the job search.",
          variant: "destructive",
        });
        navigate("/login", { state: { from: location }, replace: true });
        setIsSearching(false);
        return;
      }
      
      const statusMsg = continueFromBoard 
        ? `${modeLabel} from board ${continueFromBoard + 1}...` 
        : `${modeLabel}...`;
      setSearchStatus(statusMsg);
      
      // Persist active search state to sessionStorage
      setActiveSearch(candidateId, statusMsg);

      addUXLog('info', 'Pipeline', `Invoking edge function: mode=${mode}`, { continueFromBoard });
      
      void writeClientDebugEvent({
        type: 'invoke_pipeline_start',
        continueFromBoard,
        mode,
        tokenPresent: true,
      });

      // DECOUPLED ARCHITECTURE: Call scrape then score in sequence
      // Each phase gets its own full 60-second budget
      supabase.functions.invoke('run-candidate-pipeline', {
        body: { candidateId, continueFromBoard, mode },
        headers: { Authorization: `Bearer ${accessToken}` },
      }).then(async (response) => {
        addUXLog(
          response?.error ? 'error' : 'success', 
          'Pipeline', 
          `Edge function returned: ${response?.error ? 'ERROR' : 'OK'}`,
          { 
            hasError: Boolean(response?.error),
            errorMessage: response?.error?.message,
            hasSearchProgress: Boolean(response?.data?.searchProgress)
          }
        );
        
        void writeClientDebugEvent({
          type: 'invoke_pipeline_response',
          continueFromBoard,
          hasError: Boolean(response?.error),
          errorMessage: response?.error?.message,
          searchProgress: response?.data?.searchProgress
            ? {
                stoppedDueToTimeout: response.data.searchProgress.stoppedDueToTimeout,
                nextBoardIndex: response.data.searchProgress.nextBoardIndex,
                totalBoardsAvailable: response.data.searchProgress.totalBoardsAvailable,
                isContinuation: response.data.searchProgress.isContinuation,
                boardsSearchedCount: Array.isArray(response.data.searchProgress.boardsSearched)
                  ? response.data.searchProgress.boardsSearched.length
                  : undefined,
              }
            : null,
        });

        // Clear any polling interval since we got a response
        if (pollIntervalRef.current) {
          clearInterval(pollIntervalRef.current);
          pollIntervalRef.current = null;
        }
        
        // Handle successful completion
        if (response.error) {
          console.error('Pipeline error (background):', response.error);
          setSearchError(response.error.message || 'Pipeline encountered an error');
          setSearchStatus("Search encountered an issue but may have found some jobs");
          // End the search on error so the UI doesn't stay stuck on "Searching…"
          setSearchComplete(true);
          setIsSearching(false);
          clearActiveSearch();
          onMatchUpdated();
          fetchRejectionSummary();
        } else {
          const data = response.data;
          const responseMode = data?.mode || mode;
          
          // Fetch fresh match count AND fresh target setting for accurate auto-continuation check
          const [matchResult, targetResult] = await Promise.all([
            supabase.from('matches').select('id', { count: 'exact' }).eq('candidate_id', candidateId).limit(1),
            supabase.from('app_settings').select('setting_value').eq('setting_key', 'target_matches').maybeSingle()
          ]);
          
          const totalMatchesInDB = matchResult.count || 0;
          const freshTargetMatches = targetResult.data?.setting_value 
            ? parseInt(targetResult.data.setting_value, 10) || targetMatches 
            : targetMatches;
          
          const needsMoreMatches = totalMatchesInDB < freshTargetMatches;
          const hasPendingJobs = data?.searchProgress?.hasPendingJobs === true;
          const stoppedDueToTimeout = data?.searchProgress?.stoppedDueToTimeout === true;
          const quotaExceeded = data?.searchProgress?.firecrawlQuotaExceeded === true;
          if (quotaExceeded) {
            setFirecrawlQuotaExceeded(true);
          }
          const nextBoardIndex = typeof data?.searchProgress?.nextBoardIndex === 'number' ? data.searchProgress.nextBoardIndex : 0;
          const totalBoardsAvailable = typeof data?.searchProgress?.totalBoardsAvailable === 'number' ? data.searchProgress.totalBoardsAvailable : 0;
          const hasMoreBoards = nextBoardIndex > 0 && nextBoardIndex < totalBoardsAvailable;
          
          console.log(`[${responseMode}] Response: matches=${totalMatchesInDB}/${freshTargetMatches}, hasPending=${hasPendingJobs}, hasMoreBoards=${hasMoreBoards} (${nextBoardIndex}/${totalBoardsAvailable}), timeout=${stoppedDueToTimeout}`);
          
          if (data?.searchProgress) {
            // For continuation searches, merge boards from previous progress
            setSearchProgress((prev) => {
              if (prev && data.searchProgress.isContinuation) {
                return {
                  ...data.searchProgress,
                  boardsSearched: [...prev.boardsSearched, ...data.searchProgress.boardsSearched],
                };
              }
              return data.searchProgress;
            });
          }
          
          // Refresh UI with current matches
          onMatchUpdated();
          
          // DECOUPLED PHASE CHAINING LOGIC:
          // 1. After scrape: if we have pending jobs and need more matches, trigger score phase
          // 2. After score: if we still have pending jobs and need more matches, trigger another score phase
          // 3. If no pending jobs but need more matches and boards remain, trigger more scraping
          
          if (needsMoreMatches && !stopRequestedRef.current) {
            if (hasPendingJobs) {
              // Guard against infinite score loops: if pending count hasn't decreased, stop retrying
              const currentPending = data?.searchProgress?.pendingJobsRemaining ?? -1;
              if (responseMode === 'score' && currentPending > 0 && currentPending >= lastPendingCountRef.current) {
                scoreRetryCountRef.current++;
              } else {
                scoreRetryCountRef.current = 0;
              }
              lastPendingCountRef.current = currentPending > 0 ? currentPending : lastPendingCountRef.current;
              
              if (scoreRetryCountRef.current >= 10) {
                console.log(`CHAINING: Score retry limit reached (${scoreRetryCountRef.current} attempts with no progress). Ending search.`);
                scoreRetryCountRef.current = 0;
                // Fall through to complete
              } else {
                console.log(`CHAINING: Triggering score phase (pending jobs exist, retry=${scoreRetryCountRef.current})`);
                setSearchStatus(`Found ${totalMatchesInDB}/${freshTargetMatches} matches - scoring discovered jobs...`);
                
                setTimeout(() => {
                  handleFindJobs(undefined, 'score');
                }, 1000);
                return;
              }
            }
            
            if (hasMoreBoards && chainContinuationCountRef.current < MAX_CHAIN_CONTINUATIONS) {
              chainContinuationCountRef.current++;
              // No pending jobs but boards remain - search more boards
              const remaining = totalBoardsAvailable - nextBoardIndex;
              console.log(`CHAINING: Triggering scrape phase #${chainContinuationCountRef.current} from board ${nextBoardIndex} (${remaining} remaining)`);
              setSearchStatus(`Found ${totalMatchesInDB}/${freshTargetMatches} matches - searching ${remaining} more boards...`);
              
              setTimeout(() => {
                handleFindJobs(nextBoardIndex, 'scrape');
              }, 1000);
              return;
            } else if (chainContinuationCountRef.current >= MAX_CHAIN_CONTINUATIONS) {
              console.log(`CHAINING: MAX continuations (${MAX_CHAIN_CONTINUATIONS}) reached. Stopping search.`);
              // Fall through to complete
            }
            
            // FALLBACK: Score phase doesn't track boards. Check pipeline_events for scrape continuation info.
            // Only use recent events (within last 5 minutes) to avoid resuming from stale data.
            if (responseMode === 'score' && !hasMoreBoards) {
              try {
                const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
                const { data: scrapeEvents } = await supabase
                  .from('pipeline_events')
                  .select('message, created_at')
                  .eq('candidate_id', candidateId)
                  .eq('event_type', 'warning')
                  .ilike('message', '%Scrape paused%')
                  .gte('created_at', fiveMinAgo)
                  .order('created_at', { ascending: false })
                  .limit(1);
                
                const scrapeMsg = scrapeEvents?.[0]?.message;
                const boardMatch = scrapeMsg?.match(/Searched (\d+) of (\d+) boards/);
                if (boardMatch) {
                  const scrapedCount = parseInt(boardMatch[1], 10);
                  const totalCount = parseInt(boardMatch[2], 10);
                  if (scrapedCount < totalCount && chainContinuationCountRef.current < MAX_CHAIN_CONTINUATIONS) {
                    chainContinuationCountRef.current++;
                    const remaining = totalCount - scrapedCount;
                    console.log(`CHAINING (fallback): Resuming scrape #${chainContinuationCountRef.current} from board ${scrapedCount} (${remaining} remaining)`);
                    setSearchStatus(`Found ${totalMatchesInDB}/${freshTargetMatches} matches - searching ${remaining} more boards...`);
                    setTimeout(() => {
                      handleFindJobs(scrapedCount, 'scrape');
                    }, 1000);
                    return;
                  }
                }
              } catch (err) {
                console.error('Error checking scrape continuation:', err);
              }
            }
          }
          
          // Search is truly complete (either target reached or all boards exhausted and no pending jobs)
          setSearchComplete(true);
          setIsSearching(false);
          clearActiveSearch(); // Clear persisted search state
          
          // Fetch rejection summary and refresh matches
          fetchRejectionSummary();
          onMatchUpdated();
          
          // Use totalBoardsAvailable for accurate count across all waves (not just the last wave's boardsSearched)
          const totalBoardsSearched = data?.searchProgress?.totalBoardsAvailable || data?.searchProgress?.boardsSearched?.length || 0;
          
          if (totalMatchesInDB >= freshTargetMatches) {
            setSearchStatus(`Search complete! Found ${totalMatchesInDB} matches.`);
            toast({
              title: "Job Search Complete",
              description: `Found ${totalMatchesInDB} matches from ${totalBoardsSearched} boards for ${candidateName}`,
            });
          } else {
            setSearchStatus(`Search complete - all ${totalBoardsSearched} boards searched. Found ${totalMatchesInDB} matches.`);
            toast({
              title: "Job Search Complete",
              description: `Searched all ${totalBoardsSearched} available boards. Found ${totalMatchesInDB} matches for ${candidateName}`,
            });
          }
        }
      }).catch(async (err) => {
        void writeClientDebugEvent({
          type: 'invoke_pipeline_catch',
          continueFromBoard,
          errorMessage: err instanceof Error ? err.message : String(err),
        });
        // Network/timeout errors - the search may have completed on the server!
        console.log('Pipeline HTTP error (expected for long searches):', err);
        
        // Wait a moment for the server to finish writing pipeline_events
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Check pipeline_events for the latest status to determine if we should auto-continue
        // Only look at recent events (within last 5 minutes) to avoid stale data
        const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
        const { data: latestEvents } = await supabase
          .from('pipeline_events')
          .select('event_type, message, created_at')
          .eq('candidate_id', candidateId)
          .gte('created_at', fiveMinAgo)
          .order('created_at', { ascending: false })
          .limit(5);
        
        // Look for a warning indicating timeout/pause (either scrape or score)
        const scrapeTimeoutEvent = latestEvents?.find(e => 
          e.event_type === 'warning' && e.message?.includes('Scrape paused')
        );
        const scoreTimeoutEvent = latestEvents?.find(e => 
          e.event_type === 'warning' && e.message?.includes('Scoring paused')
        );
        
        // Check for completion event
        const completionEvent = latestEvents?.find(e => 
          e.event_type === 'success' && (e.message?.includes('complete') || e.message?.includes('Target reached'))
        );
        
        // Check for pending jobs in the database
        const { count: pendingCount } = await supabase
          .from('pipeline_pending_jobs')
          .select('id', { count: 'exact' })
          .eq('candidate_id', candidateId)
          .eq('status', 'pending')
          .limit(1);
        
        const hasPendingJobs = (pendingCount || 0) > 0;
        
        // Always fetch fresh data - we need it whether or not we found events
        const [matchResult, targetResult] = await Promise.all([
          supabase.from('matches').select('id', { count: 'exact' }).eq('candidate_id', candidateId).limit(1),
          supabase.from('app_settings').select('setting_value').eq('setting_key', 'target_matches').maybeSingle()
        ]);
        
        const totalMatchesInDB = matchResult.count || 0;
        const freshTargetMatches = targetResult.data?.setting_value 
          ? parseInt(targetResult.data.setting_value, 10) || targetMatches 
          : targetMatches;
        
        const needsMoreMatches = totalMatchesInDB < freshTargetMatches;
        
        // Parse the timeout message to get board info (e.g., "Searched 40 of 101 boards")
        const boardMatch = scrapeTimeoutEvent?.message?.match(/Searched (\d+) of (\d+) boards/);
        const boardsSearched = boardMatch ? parseInt(boardMatch[1]) : 0;
        const totalBoards = boardMatch ? parseInt(boardMatch[2]) : 0;
        const hasMoreBoards = boardsSearched > 0 && boardsSearched < totalBoards;
        
        console.log(`Catch block: matches=${totalMatchesInDB}/${freshTargetMatches}, pending=${pendingCount}, hasMoreBoards=${hasMoreBoards}`);
        
        // KEY FIX: If no pending jobs and no more boards, search is done regardless of events
        if (!hasPendingJobs && !hasMoreBoards) {
          console.log(`CATCH: No pending jobs and no more boards - search is complete`);
          setSearchComplete(true);
          setIsSearching(false);
          clearActiveSearch();
          fetchRejectionSummary();
          onMatchUpdated();
          
          if (totalMatchesInDB >= freshTargetMatches) {
            setSearchStatus(`Search complete! Found ${totalMatchesInDB} matches.`);
          } else {
            setSearchStatus(`Search complete. Found ${totalMatchesInDB} matches.`);
          }
          
          toast({
            title: "Job Search Complete",
            description: `Found ${totalMatchesInDB} matches for ${candidateName}`,
          });
          return;
        }
        
        if (needsMoreMatches && !stopRequestedRef.current) {
          if (hasPendingJobs) {
            // Guard against infinite score loops in catch path
            scoreRetryCountRef.current++;
            if (scoreRetryCountRef.current >= 3) {
              console.log(`CATCH: Score retry limit reached (${scoreRetryCountRef.current}). Ending search.`);
              scoreRetryCountRef.current = 0;
              // Fall through to complete
            } else {
              console.log(`CATCH: Triggering score phase (${pendingCount} pending jobs, retry=${scoreRetryCountRef.current})`);
              setSearchStatus(`Found ${totalMatchesInDB}/${freshTargetMatches} matches - scoring ${pendingCount} discovered jobs...`);
              onMatchUpdated();
              setTimeout(() => handleFindJobs(undefined, 'score'), 1000);
              return;
            }
          }
          
          if (hasMoreBoards) {
            // Trigger more scraping
            const remaining = totalBoards - boardsSearched;
            console.log(`CATCH: Triggering scrape phase from board ${boardsSearched}`);
            setSearchStatus(`Found ${totalMatchesInDB}/${freshTargetMatches} matches - searching ${remaining} more boards...`);
            onMatchUpdated();
            setTimeout(() => handleFindJobs(boardsSearched, 'scrape'), 1000);
            return;
          }
        }
        
        // Search is complete (either got enough matches or exhausted all options)
        setSearchComplete(true);
        setIsSearching(false);
        clearActiveSearch();
        fetchRejectionSummary();
        onMatchUpdated();
        
        if (totalMatchesInDB >= freshTargetMatches) {
          setSearchStatus(`Search complete! Found ${totalMatchesInDB} matches.`);
        } else {
          setSearchStatus(`Search complete. Found ${totalMatchesInDB} matches.`);
        }
        
        toast({
          title: "Job Search Complete",
          description: `Found ${totalMatchesInDB} matches for ${candidateName}`,
        });
        return;
      });
      
    } catch (err: any) {
      console.error('Error initiating pipeline:', err);
      setSearchError(err.message || 'Failed to start job search');
      setSearchStatus("Failed to start search");
      setIsSearching(false);
      clearActiveSearch(); // Clear persisted search state on error
      toast({
        title: "Search Failed",
        description: err.message || 'Failed to start job search',
        variant: "destructive",
      });
    }
  };
  
  // Keep ref in sync so the restore useEffect can call it
  useEffect(() => {
    handleFindJobsRef.current = handleFindJobs;
  });

  const isBelowTarget = matches.length > 0 && matches.length < targetMatches;

  const mergedBoards = (() => {
    const responseBoards = searchProgress?.boardsSearched ?? [];
    const realtime = Object.values(realtimeBoards);

    // Prefer the richer response data when present; fall back to realtime updates while searching.
    if (responseBoards.length > 0) return responseBoards;

    return realtime
      .map((b) => ({
        name: b.name,
        status: b.status as 'success' | 'failed' | 'timeout' | 'searching',
        jobsFound: b.jobsFound,
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  })();

  const handleAddToNextStage = async (matchId: string) => {
    setAddingMatchId(matchId);
    try {
      const { error } = await supabase
        .from("matches")
        .update({ status: "shortlisted" })
        .eq("id", matchId);

      if (error) throw error;

      // FEEDBACK LOOP: Track accepted match for keyword performance
      try {
        const match = effectiveMatches.find(m => m.id === matchId);
        if (match?.jobs?.source_url) {
          const { data: pendingJob } = await supabase
            .from("pipeline_pending_jobs")
            .select("source_query")
            .eq("candidate_id", candidateId)
            .eq("job_url", match.jobs.source_url)
            .maybeSingle();
          
          if (pendingJob?.source_query) {
            const cleanKeyword = pendingJob.source_query.trim();
            if (cleanKeyword.length >= 3) {
              // Fire-and-forget: increment accepted count
              supabase
                .from("keyword_performance")
                .update({ 
                  matches_accepted: 1, // Will be incremented server-side
                  updated_at: new Date().toISOString(),
                })
                .eq("candidate_id", candidateId)
                .eq("keyword", cleanKeyword)
                .then(() => {});
            }
          }
        }
      } catch (fbErr) {
        // Non-critical feedback tracking
        console.log('Feedback tracking skipped:', fbErr);
      }

      toast({
        title: "Added to Shortlist",
        description: "Match has been added to the next stage",
      });
      onMatchUpdated();
    } catch (error) {
      console.error("Error updating match:", error);
      toast({
        title: "Error",
        description: "Failed to update match status",
        variant: "destructive",
      });
    } finally {
      setAddingMatchId(null);
    }
  };


  // Filter to only show matches that haven't been shortlisted yet
  const pendingMatches = effectiveMatches.filter(m => m.status !== "shortlisted");

  const getRejectionChipClass = (index: number) => {
    // UI-only: rotate through semantic status colors so chips are visually distinct.
    const styles = [
      "bg-warning text-warning-foreground border-warning/40",
      "bg-success text-success-foreground border-success/40",
      "bg-primary/15 text-primary border-primary/30",
      "bg-destructive/15 text-destructive border-destructive/30",
      "bg-accent text-accent-foreground border-accent/40",
    ];
    return styles[index % styles.length];
  };

  return (
    <>
      <div className="space-y-6" ref={resultsRef}>
        {/* Search Status Banner */}
        {(isSearching || searchComplete || searchError) && (
          <div 
            className={`rounded-lg border-2 p-4 ${
              searchError 
                ? 'bg-destructive/10 border-destructive text-destructive'
                : isSearching
                ? 'bg-accent/20 border-accent'
                : 'bg-accent/20 border-accent'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                {isSearching ? (
                  <Loader2 className="w-5 h-5 animate-spin text-accent-foreground" />
                ) : searchComplete ? (
                  <CheckCircle2 className="w-5 h-5 text-success" />
                ) : (
                  <Search className="w-5 h-5" />
                )}
                <div>
                  <p className="font-semibold text-accent-foreground">{searchStatus}</p>
                  {isSearching && (pendingJobsCount > 0 || newJobsCount > 0) && (
                    <p className="text-sm text-accent-foreground/70">
                      {pendingJobsCount > 0 && `${pendingJobsCount} job${pendingJobsCount !== 1 ? 's' : ''} in queue to score`}
                      {pendingJobsCount > 0 && newJobsCount > 0 && ' • '}
                      {newJobsCount > 0 && `${newJobsCount} new match${newJobsCount !== 1 ? 'es' : ''} found`}
                    </p>
                  )}
                  {searchError && (
                    <p className="text-sm">{searchError}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {isSearching && (
                  <>
                    <Badge 
                      variant="outline" 
                      className="bg-background text-foreground border-foreground cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors"
                      onClick={() => setShowProgressModal(true)}
                      title="Show progress details"
                    >
                      <Timer className="w-3 h-3 mr-1" />
                      Searching...
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleStopSearch}
                      disabled={isStopping}
                      className="text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground"
                    >
                      {isStopping ? (
                        <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                      ) : (
                        <StopCircle className="w-3 h-3 mr-1" />
                      )}
                      {isStopping ? 'Stopping...' : 'Stop Search'}
                    </Button>
                  </>
                )}
                {/* Auto-continuation indicator - shows when search is continuing automatically */}
                {isSearching && searchProgress?.isContinuation && (
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                    Auto-continuing...
                  </Badge>
                )}
                {searchComplete && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSearchComplete(false);
                      setSearchStatus("");
                      setSearchProgress(null);
                    }}
                    className="text-accent-foreground hover:bg-accent-foreground/10"
                  >
                    Dismiss
                  </Button>
                )}
              </div>
            </div>

            {/* Firecrawl Quota Warning */}
            {firecrawlQuotaExceeded && (
              <div className="flex items-start gap-3 p-3 rounded-md bg-warning/15 border border-warning/40 mt-3">
                <AlertCircle className="w-5 h-5 text-warning shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-sm text-warning">Search API Credits Low or Exhausted</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    The Firecrawl search API is returning quota errors (402). Your search credits may be running low or exhausted.
                    Please check your Firecrawl account to top up credits.
                  </p>
                </div>
              </div>
            )}

            {/* Search Criteria Display */}
            {searchProgress?.searchCriteria && (
              <div className="mb-3 p-2 bg-background/50 rounded-md">
                <p className="text-xs font-medium text-muted-foreground mb-1">Search Criteria:</p>
                <p className="text-sm text-foreground">{searchProgress.searchCriteria}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Match threshold: {searchProgress.matchThreshold}%
                </p>
              </div>
            )}

            {/* Boards Searched Display */}
            {mergedBoards.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">
                  Job Boards Searched ({mergedBoards.filter(b => b.status === 'success').length}/{mergedBoards.length} returned results):
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {mergedBoards.map((board, idx) => (
                    <Badge 
                      key={idx} 
                      variant="outline" 
                      className={`text-xs ${
                        board.status === 'success' 
                          ? 'bg-success text-success-foreground border-success/40' 
                          : board.status === 'searching'
                          ? 'bg-secondary text-secondary-foreground border-secondary/40'
                          : board.status === 'timeout'
                          ? 'bg-warning text-warning-foreground border-warning/40'
                          : 'bg-muted text-muted-foreground border-muted/60'
                      }`}
                    >
                      {board.name}
                      {board.status === 'success' && ` (${board.jobsFound})`}
                      {board.status === 'searching' && ' …'}
                      {board.status === 'timeout' && ' ⏱️'}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Queue Progress Display - shows when boards aren't available but we have pending jobs */}
            {mergedBoards.length === 0 && isSearching && pendingJobsCount > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-3 h-3 animate-spin text-accent-foreground" />
                  <p className="text-xs font-medium text-muted-foreground">
                    Scoring queue: {pendingJobsCount} job{pendingJobsCount !== 1 ? 's' : ''} waiting to be analyzed
                  </p>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-accent rounded-full transition-all duration-500 animate-pulse" 
                    style={{ width: '100%' }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

         {/* Short results explanation (even if the run completed earlier) */}
         {isBelowTarget && (
           <div className="rounded-lg border border-muted bg-muted/30 p-4">
             <div className="flex items-start gap-2">
               <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5" />
               <div className="space-y-1">
                  <p className="text-sm font-medium text-foreground">
                    Found {matches.length} target matches.
                  </p>
               </div>
             </div>
           </div>
         )}

         {/* Rejection / "error" report (filtered-out reasons)
             Show whenever we have data, even if we met/exceeded the target match count. */}
         {rejectionSummary.length > 0 && (
           <div className="rounded-lg border border-muted bg-muted/30 p-4">
             <div className="flex items-center gap-2 mb-3">
               <AlertCircle className="w-4 h-4 text-muted-foreground" />
               <p className="text-sm font-medium text-foreground">Filtered out during search:</p>
             </div>
             <div className="flex flex-wrap gap-2">
               {(searchComplete ? rejectionSummary : rejectionSummary.slice(0, 6)).map((item, idx) => (
                 <Badge
                   key={idx}
                   variant="outline"
                   className={`text-xs ${getRejectionChipClass(idx)}`}
                 >
                   {item.reason}: {item.count}
                 </Badge>
               ))}
             </div>
             {!searchComplete && (
               <p className="mt-2 text-xs text-muted-foreground">
                 This report updates as the search progresses.
               </p>
             )}
           </div>
         )}

         
         {/* Debug feed - hidden by default, can be enabled for troubleshooting */}
         {/* <SearchDebugFeed candidateId={candidateId} isActive={isSearching} alwaysVisible={true} /> */}

        {/* Grid Table - Only show when there are matches or actively searching */}
        {(pendingMatches.length > 0 || isSearching) && (
          <div className="rounded-lg border border-accent overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full accent-grid-table text-sm">
                  <thead>
                    <tr className="bg-accent">
                      <th className="px-2 py-0.5 text-left font-semibold text-black border-r border-accent-foreground/10 whitespace-nowrap text-xs">Company</th>
                      <th className="px-2 py-0.5 text-left font-semibold text-black border-r border-accent-foreground/10 whitespace-nowrap text-xs">Job Title</th>
                      <th className="px-2 py-0.5 text-left font-semibold text-black border-r border-accent-foreground/10 whitespace-nowrap text-xs">Location</th>
                      <th className="px-2 py-0.5 text-left font-semibold text-black border-r border-accent-foreground/10 whitespace-nowrap text-xs">Salary</th>
                      <th className="px-2 py-0.5 text-left font-semibold text-black border-r border-accent-foreground/10 whitespace-nowrap text-xs">Posted</th>
                      <th className="px-2 py-0.5 text-left font-semibold text-black border-r border-accent-foreground/10 whitespace-nowrap text-xs">Match</th>
                      <th className="px-2 py-0.5 text-left font-semibold text-black border-r border-accent-foreground/10 whitespace-nowrap text-xs">Reasoning</th>
                      <th className="px-2 py-0.5 text-left font-semibold text-black whitespace-nowrap text-xs">Link</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pendingMatches.length === 0 && isSearching ? (
                      <tr>
                        <td colSpan={8} className="bg-accent px-4 py-6 text-center text-black">
                          <div className="flex items-center justify-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Searching for matching jobs...
                          </div>
                        </td>
                      </tr>
                    ) : (
                      pendingMatches.map((match) => {
                        const isExternalCompany = match.jobs?.companies?.created_by &&
                          authSession?.user?.id &&
                          match.jobs.companies.created_by !== authSession.user.id;
                        const ownerName = 'Another user';

                        return (
                           <tr key={match.id} className={`border-t border-accent-foreground/10 ${isExternalCompany ? 'bg-warning/20' : 'bg-accent'}`}>
                             <td className="px-2 py-px text-foreground border-r border-accent-foreground/10 align-top">
                               <div className="flex flex-col">
                                 <div className="flex items-center gap-1 leading-tight">
                                   {match.jobs?.companies ? (
                                     <>
                                       {isSearching ? (
                                         <a href={`/companies/${match.jobs.companies.id}`} target="_blank" rel="noopener noreferrer" className="hover:underline font-medium flex items-center gap-1 text-xs leading-tight">
                                           {match.jobs.companies.name}
                                           <ExternalLink className="w-2.5 h-2.5 text-muted-foreground" />
                                         </a>
                                       ) : (
                                         <Link to={`/companies/${match.jobs.companies.id}`} className="hover:underline font-medium text-xs leading-tight">
                                           {match.jobs.companies.name}
                                         </Link>
                                       )}
                                       {isExternalCompany && (
                                         <span className="inline-flex items-center justify-center w-3 h-3 text-[9px] rounded-full bg-warning text-warning-foreground" title={`Owned by ${ownerName}`}>!</span>
                                       )}
                                     </>
                                   ) : <span className="text-xs leading-tight">-</span>}
                                 </div>
                                 <span className="text-[10px] leading-tight mt-px opacity-0 select-none">·</span>
                               </div>
                             </td>
                             <td className="px-2 py-px text-foreground border-r border-accent-foreground/10 align-top">
                               <div className="flex flex-col">
                                 <div className="leading-tight">
                                   {isSearching ? (
                                     <a href={`/jobs/${match.jobs?.id}`} target="_blank" rel="noopener noreferrer" className="hover:underline font-medium flex items-center gap-1 text-xs leading-tight" title="Opens in new tab (search in progress)">
                                       {match.jobs?.title || "-"}
                                       <ExternalLink className="w-2.5 h-2.5 text-muted-foreground" />
                                     </a>
                                   ) : (
                                     <Link to={`/jobs/${match.jobs?.id}`} className="hover:underline font-medium text-xs leading-tight">
                                       {match.jobs?.title || "-"}
                                     </Link>
                                   )}
                                 </div>
                                 <span className="text-[10px] leading-tight mt-px opacity-0 select-none">·</span>
                               </div>
                             </td>
                             <td className="px-2 py-px text-xs text-foreground border-r border-accent-foreground/10 whitespace-nowrap align-top">
                               <div className="flex flex-col">
                                 <span className="leading-tight">{match.jobs?.location || "-"}</span>
                                 <span className="text-[10px] leading-tight mt-px opacity-0 select-none">·</span>
                               </div>
                             </td>
                              <td className="px-2 py-px text-xs text-foreground border-r border-accent-foreground/10 whitespace-nowrap align-top">
                                <div className="flex flex-col">
                                  <span className="leading-tight">{isValidSalaryDisplay(match.jobs?.salary_range) ? match.jobs?.salary_range : "-"}</span>
                                  <span className="text-[10px] leading-tight mt-px opacity-0 select-none">·</span>
                                </div>
                              </td>
                             <td className="px-2 py-px text-xs text-foreground border-r border-accent-foreground/10 whitespace-nowrap align-top">
                               <div className="flex flex-col">
                                 <div className="leading-tight">
                                   {match.jobs?.posted_at ? (
                                     formatDate(match.jobs.posted_at)
                                   ) : match.created_at ? (
                                     <span className="flex items-center gap-1 text-muted-foreground" title="Date found">
                                       {formatDate(match.created_at)}
                                       <AlertCircle className="w-2.5 h-2.5" />
                                     </span>
                                   ) : "-"}
                                 </div>
                                 <span className="text-[10px] leading-tight mt-px opacity-0 select-none">·</span>
                               </div>
                             </td>
                             <td className="px-2 py-px text-foreground border-r border-accent-foreground/10 align-top">
                               <div className="flex flex-col">
                                 <Badge className={`text-xs px-1 py-0 leading-none w-fit border ${
                                   match.match_score >= 80
                                     ? 'bg-emerald-500/15 text-emerald-700 border-emerald-500/40 dark:text-emerald-400'
                                     : match.match_score >= 60
                                     ? 'bg-amber-500/15 text-amber-700 border-amber-500/40 dark:text-amber-400'
                                     : 'bg-red-500/15 text-red-700 border-red-500/40 dark:text-red-400'
                                 }`}>
                                   {match.match_score}%
                                 </Badge>
                                 <span className="text-[10px] leading-tight mt-px opacity-0 select-none">·</span>
                               </div>
                             </td>
                             <td className="px-2 py-px max-w-[200px] border-r border-accent-foreground/10 align-top">
                               <ExpandableReasoning reason={match.match_reason} />
                             </td>
                             <td className="px-2 py-px text-foreground align-top">
                               <div className="flex flex-col">
                                 <div className="leading-tight">
                                   {match.jobs?.source_url ? (
                                     <a href={match.jobs.source_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:underline text-xs">
                                       <ExternalLink className="w-2.5 h-2.5" />
                                     </a>
                                   ) : "-"}
                                 </div>
                                 <span className="text-[10px] leading-tight mt-px opacity-0 select-none">·</span>
                               </div>
                             </td>
                           </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
            </div>
          </div>
        )}

        {/* Cost Estimate & Action Buttons */}
        <div className="flex flex-col gap-4">
          {/* Show cost estimate when not searching */}
          {!isSearching && !searchComplete && activeBoardCount > 0 && (
            <SearchCostEstimate boardCount={activeBoardCount} targetMatches={targetMatches} />
          )}
          
          <Button
            onClick={() => handleFindJobs()}
            disabled={isSearching || isMatchingExisting}
            className="w-full rounded-full bg-accent text-foreground font-semibold hover:bg-accent hover:text-foreground py-6 text-lg"
          >
            {isSearching ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                SEARCHING FOR JOBS...
              </>
            ) : (
              <>
                <Search className="w-5 h-5 mr-2" />
                FIND MORE JOBS ...
              </>
            )}
          </Button>
        </div>
      </div>

      {/* LurqAI Job Matching Progress Modal */}
      <JobMatchingProgressModal
        open={showProgressModal && isSearching}
        onMinimize={() => setShowProgressModal(false)}
        onStop={handleStopSearch}
        isStopping={isStopping}
        searchStatus={searchStatus}
        boardsSearched={mergedBoards}
        totalBoardsAvailable={searchProgress?.totalBoardsAvailable || 0}
        matchesFound={effectiveMatches.length}
        targetMatches={targetMatches}
        pendingJobsCount={pendingJobsCount}
        newJobsCount={newJobsCount}
        startedAt={searchStartedAt}
        searchCriteria={searchProgress?.searchCriteria}
        matchThreshold={searchProgress?.matchThreshold}
        firecrawlQuotaExceeded={firecrawlQuotaExceeded}
      />

      {/* Stakeholder Search Wizard */}
      <StakeholderSearchWizard
        open={showStakeholderWizard}
        onOpenChange={setShowStakeholderWizard}
        candidateId={candidateId}
        candidateName={candidateName}
      />

    </>
  );
}
