import { useEffect, useMemo, useState } from 'react';
import { ChevronDown, ChevronUp, Filter, RefreshCw, Zap } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

type PipelineEvent = {
  id: string;
  event_type: string;
  message: string;
  created_at: string;
};

type CreditSummary = {
  firecrawl_calls: number;
  estimated_credits: number;
  failed_402s: number;
  jobs_discovered: number;
  jobs_scored: number;
  matches_saved: number;
  note?: string;
};

function formatTs(ts: string) {
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return ts;
  return d.toLocaleString();
}

function isJsonLike(s: string) {
  const t = (s || '').trim();
  return (t.startsWith('{') && t.endsWith('}')) || (t.startsWith('[') && t.endsWith(']'));
}

function CreditSummaryCard({ event }: { event: PipelineEvent }) {
  let summary: CreditSummary | null = null;
  try { summary = JSON.parse(event.message); } catch { return null; }
  if (!summary) return null;

  return (
    <div className="rounded-md border border-warning/40 bg-warning/5 p-3" style={{ borderColor: 'hsl(var(--warning, 38 92% 50%) / 0.4)', background: 'hsl(var(--warning, 38 92% 50%) / 0.05)' }}>
      <div className="flex items-center gap-2 mb-2">
        <Zap className="w-4 h-4" style={{ color: 'hsl(38 92% 50%)' }} />
        <span className="text-xs font-semibold" style={{ color: 'hsl(38 80% 42%)' }}>
          Firecrawl Credit Usage — {formatTs(event.created_at)}
        </span>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded px-2 py-1.5 text-center" style={{ background: 'hsl(38 92% 50% / 0.1)' }}>
          <div className="text-lg font-bold" style={{ color: 'hsl(38 80% 42%)' }}>{summary.estimated_credits}</div>
          <div className="text-[10px] text-muted-foreground">Credits used</div>
        </div>
        <div className="rounded bg-muted/50 px-2 py-1.5 text-center">
          <div className="text-lg font-bold text-foreground">{summary.jobs_discovered}</div>
          <div className="text-[10px] text-muted-foreground">Jobs found</div>
        </div>
        <div className="rounded bg-muted/50 px-2 py-1.5 text-center">
          <div className="text-lg font-bold text-foreground">{summary.matches_saved}</div>
          <div className="text-[10px] text-muted-foreground">Matches saved</div>
        </div>
      </div>
      {summary.failed_402s > 0 && (
        <p className="mt-2 text-xs text-destructive">⚠️ {summary.failed_402s} requests failed (credits exhausted)</p>
      )}
      {summary.estimated_credits > 0 && (
        <p className="mt-1 text-[10px] text-muted-foreground">
          ~{(summary.jobs_discovered / Math.max(1, summary.estimated_credits)).toFixed(1)} jobs per credit
        </p>
      )}
    </div>
  );
}

export function SearchDebugFeed({ candidateId, isActive, alwaysVisible = false }: { candidateId: string; isActive: boolean; alwaysVisible?: boolean }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [events, setEvents] = useState<PipelineEvent[]>([]);
  const [onlyErrors, setOnlyErrors] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [hasAutoExpanded, setHasAutoExpanded] = useState(false);

  const fetchEvents = async () => {
    if (!candidateId) return;
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('pipeline_events')
        .select('id,event_type,message,created_at')
        .eq('candidate_id', candidateId)
        .order('created_at', { ascending: false })
        .limit(80);

      if (error) throw error;
      setEvents((data as PipelineEvent[]) || []);
    } catch {
      // Keep silent; this is a debug helper.
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!isExpanded && !alwaysVisible) return;
    fetchEvents();
    if (!isActive && !alwaysVisible) return;
    const t = window.setInterval(fetchEvents, isActive ? 5000 : 15000);
    return () => window.clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [candidateId, isExpanded, isActive, alwaysVisible]);

  useEffect(() => {
    if (alwaysVisible && events.length > 0 && !hasAutoExpanded) {
      setIsExpanded(true);
      setHasAutoExpanded(true);
    }
  }, [alwaysVisible, events.length, hasAutoExpanded]);

  const creditEvent = useMemo(
    () => events.find((e) => e.event_type === 'credit'),
    [events]
  );

  const filtered = useMemo(() => {
    const nonCredit = events.filter((e) => e.event_type !== 'credit');
    if (!onlyErrors) return nonCredit;
    return nonCredit.filter((e) => ['error', 'debug', 'warning'].includes((e.event_type || '').toLowerCase()));
  }, [events, onlyErrors]);

  const debugCount = useMemo(
    () => events.filter((e) => (e.event_type || '').toLowerCase() === 'debug').length,
    [events]
  );

  return (
    <div className="rounded-lg border border-border/50 bg-muted/30 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2">
        <button
          onClick={() => setIsExpanded((v) => !v)}
          className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          type="button"
        >
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          Debug feed
          <Badge variant="outline" className="ml-2">
            {debugCount} debug
          </Badge>
          {creditEvent && (() => {
            try {
              const s: CreditSummary = JSON.parse(creditEvent.message);
              return (
                <Badge variant="outline" className="ml-1 gap-1" style={{ borderColor: 'hsl(38 92% 50% / 0.5)', color: 'hsl(38 80% 42%)' }}>
                  <Zap className="w-3 h-3" />
                  {s.estimated_credits} credits
                </Badge>
              );
            } catch { return null; }
          })()}
        </button>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setOnlyErrors((v) => !v)}
            className="h-8"
          >
            <Filter className="w-4 h-4 mr-2" />
            {onlyErrors ? 'Errors + debug' : 'All events'}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={fetchEvents}
            disabled={!isExpanded || isLoading}
            className="h-8"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {isExpanded && (
        <div className="border-t border-border/50 px-4 py-3 space-y-3">
          {creditEvent && <CreditSummaryCard event={creditEvent} />}

          {filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground">No debug events yet.</p>
          ) : (
            <div className="space-y-2 max-h-[340px] overflow-auto pr-1">
              {filtered.map((e) => {
                const type = (e.event_type || 'info').toLowerCase();
                const badgeVariant = type === 'error' ? 'destructive' : 'outline';
                const msg = e.message || '';
                const pretty = isJsonLike(msg) ? msg : JSON.stringify({ message: msg });
                return (
                  <div key={e.id} className="rounded-md border border-border/60 bg-background/50 p-2">
                    <div className="flex items-center gap-2">
                      <Badge variant={badgeVariant} className="capitalize">
                        {type}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{formatTs(e.created_at)}</span>
                    </div>
                    <pre className="mt-2 whitespace-pre-wrap break-words text-xs text-foreground/90 font-mono">
                      {pretty}
                    </pre>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
