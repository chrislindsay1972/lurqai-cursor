import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Plus, Mail, Clock, Trash2, GripVertical, ArrowUp, ArrowDown, Pencil } from "lucide-react";
import { toast } from "sonner";
import { EmailTemplateEditor } from "./EmailTemplateEditor";

interface CampaignStep {
  id: string;
  campaign_id: string;
  step_order: number;
  step_type: string;
  template_id: string | null;
  delay_minutes: number;
  condition_type: string | null;
  created_at: string;
  template?: {
    id: string;
    name: string;
    subject: string;
  } | null;
}

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
}

interface CampaignStepsManagerProps {
  campaignId: string;
  campaignStatus: string;
}

export function CampaignStepsManager({ campaignId, campaignStatus }: CampaignStepsManagerProps) {
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingStep, setEditingStep] = useState<CampaignStep | null>(null);
  const [isCreateTemplateOpen, setIsCreateTemplateOpen] = useState(false);
  const dialogContentRef = useRef<HTMLDivElement>(null);
  const [formData, setFormData] = useState({
    step_type: "send_email",
    template_id: "",
    delay_minutes: 0,
    condition_type: "",
  });

  const isEditable = campaignStatus === "draft" || campaignStatus === "paused";

  const { data: steps = [], isLoading: stepsLoading } = useQuery({
    queryKey: ["campaign-steps", campaignId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("campaign_steps")
        .select(`
          *,
          template:email_templates(id, name, subject)
        `)
        .eq("campaign_id", campaignId)
        .order("step_order", { ascending: true });

      if (error) throw error;
      return data as CampaignStep[];
    },
  });

  const { data: templates = [] } = useQuery({
    queryKey: ["email-templates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_templates")
        .select("id, name, subject")
        .order("name");

      if (error) throw error;
      return data as EmailTemplate[];
    },
  });

  const addStepMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const nextOrder = steps.length + 1;
      const { error } = await supabase.from("campaign_steps").insert({
        campaign_id: campaignId,
        step_order: nextOrder,
        step_type: data.step_type,
        template_id: data.step_type === "send_email" ? data.template_id || null : null,
        delay_minutes: data.delay_minutes,
        condition_type: data.step_type === "condition" ? data.condition_type || null : null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaign-steps", campaignId] });
      setIsAddDialogOpen(false);
      resetForm();
      toast.success("Step added successfully");
    },
    onError: (error: any) => {
      toast.error("Failed to add step: " + error.message);
    },
  });

  const updateStepMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string } & typeof formData) => {
      const { error } = await supabase
        .from("campaign_steps")
        .update({
          step_type: data.step_type,
          template_id: data.step_type === "send_email" ? data.template_id || null : null,
          delay_minutes: data.delay_minutes,
          condition_type: data.step_type === "condition" ? data.condition_type || null : null,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaign-steps", campaignId] });
      setEditingStep(null);
      resetForm();
      toast.success("Step updated successfully");
    },
    onError: (error: any) => {
      toast.error("Failed to update step: " + error.message);
    },
  });

  const deleteStepMutation = useMutation({
    mutationFn: async (stepId: string) => {
      const { error } = await supabase.from("campaign_steps").delete().eq("id", stepId);
      if (error) throw error;

      // Reorder remaining steps
      const remainingSteps = steps.filter((s) => s.id !== stepId);
      for (let i = 0; i < remainingSteps.length; i++) {
        await supabase
          .from("campaign_steps")
          .update({ step_order: i + 1 })
          .eq("id", remainingSteps[i].id);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaign-steps", campaignId] });
      toast.success("Step deleted successfully");
    },
    onError: (error: any) => {
      toast.error("Failed to delete step: " + error.message);
    },
  });

  const reorderStepMutation = useMutation({
    mutationFn: async ({ stepId, direction }: { stepId: string; direction: "up" | "down" }) => {
      const currentIndex = steps.findIndex((s) => s.id === stepId);
      const targetIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;

      if (targetIndex < 0 || targetIndex >= steps.length) return;

      const currentStep = steps[currentIndex];
      const targetStep = steps[targetIndex];

      // Swap orders
      await supabase
        .from("campaign_steps")
        .update({ step_order: targetStep.step_order })
        .eq("id", currentStep.id);

      await supabase
        .from("campaign_steps")
        .update({ step_order: currentStep.step_order })
        .eq("id", targetStep.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaign-steps", campaignId] });
    },
    onError: (error: any) => {
      toast.error("Failed to reorder steps: " + error.message);
    },
  });

  const resetForm = () => {
    setFormData({
      step_type: "send_email",
      template_id: "",
      delay_minutes: 0,
      condition_type: "",
    });
  };

  const openEditDialog = (step: CampaignStep) => {
    setEditingStep(step);
    setFormData({
      step_type: step.step_type,
      template_id: step.template_id || "",
      delay_minutes: step.delay_minutes,
      condition_type: step.condition_type || "",
    });
  };

  const handleSubmit = () => {
    if (formData.step_type === "send_email" && !formData.template_id) {
      toast.error("Please select an email template");
      return;
    }

    if (editingStep) {
      updateStepMutation.mutate({ id: editingStep.id, ...formData });
    } else {
      addStepMutation.mutate(formData);
    }
  };

  const getStepIcon = (type: string) => {
    switch (type) {
      case "send_email":
        return <Mail className="w-5 h-5 text-accent" />;
      case "wait_delay":
        return <Clock className="w-5 h-5 text-muted-foreground" />;
      default:
        return <Mail className="w-5 h-5" />;
    }
  };

  const formatDelay = (minutes: number) => {
    // Convert minutes to business days (1 business day = 1440 minutes)
    const businessDays = Math.round(minutes / 1440);
    if (businessDays === 0) return "0 days";
    if (businessDays === 1) return "1 day";
    return `${businessDays} days`;
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Campaign Steps</CardTitle>
          <CardDescription>
            Configure the sequence of emails and delays for this campaign
          </CardDescription>
        </div>
        {isEditable && (
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add Step
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {stepsLoading ? (
          <p className="text-muted-foreground text-center py-8">Loading steps...</p>
        ) : steps.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">
              No steps configured yet. Add your first step to get started.
            </p>
            {isEditable && (
              <Button variant="outline" onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add First Step
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {steps.map((step, index) => (
              <div
                key={step.id}
                className="flex items-center gap-4 p-4 border rounded-lg bg-card hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-2 text-muted-foreground">
                  <GripVertical className="w-4 h-4" />
                  <span className="font-mono text-sm w-6">{step.step_order}</span>
                </div>
                
                <div className="flex items-center gap-3 flex-1">
                  {getStepIcon(step.step_type)}
                  <div>
                    <p className="font-medium">
                      {step.step_type === "send_email"
                        ? step.template?.name || "Send Email"
                        : step.step_type === "wait_delay"
                        ? `Wait ${formatDelay(step.delay_minutes)}`
                        : step.step_type}
                    </p>
                    {step.step_type === "send_email" && step.template && (
                      <p className="text-sm text-muted-foreground">
                        Subject: {step.template.subject}
                      </p>
                    )}
                  </div>
                </div>

                {isEditable && (
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      disabled={index === 0}
                      onClick={() => reorderStepMutation.mutate({ stepId: step.id, direction: "up" })}
                    >
                      <ArrowUp className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      disabled={index === steps.length - 1}
                      onClick={() => reorderStepMutation.mutate({ stepId: step.id, direction: "down" })}
                    >
                      <ArrowDown className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => openEditDialog(step)} title="Edit step">
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:text-destructive"
                      onClick={() => deleteStepMutation.mutate(step.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>

      {/* Add/Edit Dialog */}
      <Dialog
        open={isAddDialogOpen || !!editingStep}
        onOpenChange={(open) => {
          if (!open) {
            setIsAddDialogOpen(false);
            setEditingStep(null);
            resetForm();
          }
        }}
      >
        <DialogContent ref={dialogContentRef}>
          <DialogHeader>
            <DialogTitle>{editingStep ? "Edit Step" : "Add Step"}</DialogTitle>
            <DialogDescription>
              Configure the step settings for this campaign sequence.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Step Type</Label>
              <Select
                value={formData.step_type}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, step_type: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent container={dialogContentRef.current}>
                  <SelectItem value="send_email">Send Email</SelectItem>
                  <SelectItem value="wait_delay">Wait/Delay</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.step_type === "send_email" && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Email Template *</Label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setIsCreateTemplateOpen(true)}
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Create Template
                  </Button>
                </div>
                <Select
                  value={formData.template_id}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, template_id: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a template" />
                  </SelectTrigger>
                  <SelectContent container={dialogContentRef.current}>
                    {templates.length === 0 ? (
                      <SelectItem value="__none__" disabled>
                        No templates available
                      </SelectItem>
                    ) : (
                      templates.map((template) => (
                        <SelectItem key={template.id} value={template.id}>
                          {template.name}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
                {templates.length === 0 && (
                  <p className="text-sm text-muted-foreground">
                    Click "Create Template" above to add your first email template.
                  </p>
                )}
              </div>
            )}

            {formData.step_type === "wait_delay" && (
              <div className="space-y-2">
                <Label>Delay (business days)</Label>
                <Input
                  type="number"
                  min={0}
                  value={Math.round(formData.delay_minutes / 1440)}
                  onChange={(e) =>
                    setFormData((prev) => ({ 
                      ...prev, 
                      delay_minutes: (parseInt(e.target.value) || 0) * 1440 
                    }))
                  }
                />
                <p className="text-sm text-muted-foreground">
                  Enter the number of business days to wait before the next step. 
                  Weekends (Sat/Sun) are automatically skipped during execution.
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsAddDialogOpen(false);
                setEditingStep(null);
                resetForm();
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={addStepMutation.isPending || updateStepMutation.isPending}
            >
              {addStepMutation.isPending || updateStepMutation.isPending
                ? "Saving..."
                : editingStep
                ? "Save Changes"
                : "Add Step"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Template Dialog */}
      <EmailTemplateEditor
        open={isCreateTemplateOpen}
        onOpenChange={setIsCreateTemplateOpen}
        onSaved={(newTemplate) => {
          queryClient.invalidateQueries({ queryKey: ["email-templates"] });
          setFormData((prev) => ({ ...prev, template_id: newTemplate.id }));
          setIsCreateTemplateOpen(false);
        }}
      />
    </Card>
  );
}
