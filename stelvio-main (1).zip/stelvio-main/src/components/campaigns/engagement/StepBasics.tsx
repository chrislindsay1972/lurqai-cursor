import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Calendar, AlertTriangle, Users } from "lucide-react";
import { isToday } from "date-fns";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import type { EngagementWizardData } from "./types";
import { GOALS } from "./types";

interface StepBasicsProps {
  data: EngagementWizardData;
  onChange: (updates: Partial<EngagementWizardData>) => void;
}

export function StepBasics({ data, onChange }: StepBasicsProps) {
  const { formatShortDate } = useLocaleFormat();
  const showSmartWarning =
    data.lastContactDate && isToday(new Date(data.lastContactDate));

  return (
    <div className="space-y-6">
      {/* Context: Candidate being discussed */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="flex items-center gap-4 py-4">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg">
            {data.candidateName
              .split(" ")
              .map((n) => n[0])
              .join("")
              .slice(0, 2)
              .toUpperCase()}
          </div>
          <div className="flex-1">
            <p className="font-semibold text-foreground">{data.candidateName}</p>
            <p className="text-sm text-muted-foreground">
              {data.candidateTitle || "No title"} • {data.candidateEmail || "No email"}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline">{data.candidateStatus}</Badge>
            {data.lastContactDate && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Last contact: {formatShortDate(data.lastContactDate)}
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center gap-2 text-muted-foreground bg-muted/50 border rounded-lg p-3 text-sm">
        <Users className="w-4 h-4 flex-shrink-0" />
        This campaign will target <strong>stakeholders</strong> to discuss this candidate. You'll add stakeholders to the campaign after it's created.
      </div>

      {showSmartWarning && (
        <div className="flex items-center gap-2 text-destructive bg-destructive/10 border border-destructive/20 rounded-lg p-3 text-sm">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          Last contact was today — consider starting the campaign tomorrow.
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="campaign-name">Campaign Name</Label>
        <Input
          id="campaign-name"
          value={data.campaignName}
          onChange={(e) => onChange({ campaignName: e.target.value })}
          placeholder="e.g., Sarah Johnson — Senior Developer Prospect Campaign"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="goal">Campaign Goal</Label>
        <Select value={data.goal} onValueChange={(v) => onChange({ goal: v })}>
          <SelectTrigger id="goal">
            <SelectValue placeholder="Select a goal" />
          </SelectTrigger>
          <SelectContent>
            {GOALS.map((g) => (
              <SelectItem key={g.value} value={g.value}>
                {g.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Candidate (subject of campaign)</Label>
        <div className="flex items-center gap-2 p-3 rounded-lg border bg-muted/50">
          <User className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium">{data.candidateName}</span>
          <Badge variant="secondary" className="ml-auto text-xs">
            Read-only
          </Badge>
        </div>
      </div>
    </div>
  );
}
