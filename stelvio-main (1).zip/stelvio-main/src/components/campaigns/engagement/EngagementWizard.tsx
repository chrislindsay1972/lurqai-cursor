import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, Rocket, Save } from "lucide-react";
import { toast } from "sonner";

import { WizardStepper } from "./WizardStepper";
import { StepBasics } from "./StepBasics";
import { StepSchedule } from "./StepSchedule";
import { StepAIStrategy } from "./StepAIStrategy";
import { StepTimeline } from "./StepTimeline";
import { StepReview } from "./StepReview";
import type { EngagementWizardData, GeneratedStep } from "./types";

const STEP_LABELS = ["Basics", "Schedule", "AI Strategy", "Preview", "Review"];

interface EngagementWizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  candidate: {
    id: string;
    name: string;
    email: string | null;
    current_title: string | null;
    status: string;
    updated_at: string;
  };
  selectedStakeholderIds?: string[];
}

function computeTouchpoints(
  duration: number,
  cadence: string,
  customInterval: number,
  avoidWeekends: boolean
): number[] {
  const interval =
    cadence === "daily" ? 1 : cadence === "every_2" ? 2 : cadence === "every_3" ? 3 : cadence === "weekly" ? 7 : customInterval;
  const days: number[] = [0];
  let day = interval;
  while (day <= duration) {
    if (avoidWeekends) {
      const date = new Date();
      date.setDate(date.getDate() + day);
      const dow = date.getDay();
      if (dow === 0) day += 1;
      else if (dow === 6) day += 2;
    }
    if (day <= duration) days.push(day);
    day += interval;
  }
  return days;
}

export function EngagementWizard({ open, onOpenChange, candidate, selectedStakeholderIds = [] }: EngagementWizardProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLaunching, setIsLaunching] = useState(false);
  const [regeneratingIndex, setRegeneratingIndex] = useState<number | null>(null);

  const [wizardData, setWizardData] = useState<EngagementWizardData>(() => ({
    campaignName: `${candidate.name} — ${candidate.current_title || "Role"} Prospect Campaign`,
    candidateId: candidate.id,
    candidateName: candidate.name,
    candidateEmail: candidate.email,
    candidateTitle: candidate.current_title,
    candidateStatus: candidate.status,
    lastContactDate: candidate.updated_at,
    goal: "prospect_candidate",
    durationDays: 14,
    cadence: "every_3",
    customIntervalDays: 3,
    avoidWeekends: true,
    startDate: new Date(Date.now() + 86400000).toISOString().split("T")[0],
    aiProfileId: null,
    voice: "Professional",
    languageStyle: "UK",
    toneChips: ["concise", "confident"],
    primaryCta: "Book a call",
    secondaryCta: "",
    neverMentionSalary: true,
    respectOptOut: true,
    linkedinBrevity: false,
    generatedSteps: [],
    fromIdentity: "",
    complianceFooter: true,
    unsubscribeEnabled: true,
  }));

  const updateData = useCallback(
    (updates: Partial<EngagementWizardData>) => {
      setWizardData((prev) => ({ ...prev, ...updates }));
    },
    []
  );

  const generateSteps = async () => {
    setIsGenerating(true);
    try {
      const touchpoints = computeTouchpoints(
        wizardData.durationDays,
        wizardData.cadence,
        wizardData.customIntervalDays,
        wizardData.avoidWeekends
      );

      const { data, error } = await supabase.functions.invoke("generate-engagement-emails", {
        body: {
          candidateName: wizardData.candidateName,
          candidateTitle: wizardData.candidateTitle,
          candidateEmail: wizardData.candidateEmail,
          goal: wizardData.goal,
          dayOffsets: touchpoints,
          voice: wizardData.voice,
          languageStyle: wizardData.languageStyle,
          toneChips: wizardData.toneChips,
          primaryCta: wizardData.primaryCta,
          secondaryCta: wizardData.secondaryCta,
          neverMentionSalary: wizardData.neverMentionSalary,
          respectOptOut: wizardData.respectOptOut,
          linkedinBrevity: wizardData.linkedinBrevity,
        },
      });

      if (error) throw error;
      if (data?.steps) {
        updateData({ generatedSteps: data.steps });
      }
    } catch (err: any) {
      console.error("Generation error:", err);
      toast.error("Failed to generate emails: " + (err.message || "Unknown error"));
    } finally {
      setIsGenerating(false);
    }
  };

  const regenerateStep = async (index: number) => {
    setRegeneratingIndex(index);
    try {
      const step = wizardData.generatedSteps[index];
      const { data, error } = await supabase.functions.invoke("generate-engagement-emails", {
        body: {
          candidateName: wizardData.candidateName,
          candidateTitle: wizardData.candidateTitle,
          candidateEmail: wizardData.candidateEmail,
          goal: wizardData.goal,
          dayOffsets: [step.dayOffset],
          voice: wizardData.voice,
          languageStyle: wizardData.languageStyle,
          toneChips: wizardData.toneChips,
          primaryCta: wizardData.primaryCta,
          secondaryCta: wizardData.secondaryCta,
          neverMentionSalary: wizardData.neverMentionSalary,
          respectOptOut: wizardData.respectOptOut,
          linkedinBrevity: wizardData.linkedinBrevity,
          singleStepIndex: index,
        },
      });

      if (error) throw error;
      if (data?.steps?.[0]) {
        const updated = [...wizardData.generatedSteps];
        updated[index] = { ...data.steps[0], status: "planned" };
        updateData({ generatedSteps: updated });
        toast.success("Step regenerated");
      }
    } catch (err: any) {
      toast.error("Failed to regenerate: " + (err.message || "Unknown error"));
    } finally {
      setRegeneratingIndex(null);
    }
  };

  const handleNext = async () => {
    if (currentStep === 3) {
      setCurrentStep(4);
      await generateSteps();
    } else if (currentStep < 5) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const launchCampaign = async (asDraft = false) => {
    setIsLaunching(true);
    try {
      const activeSteps = wizardData.generatedSteps.filter((s) => s.status !== "skipped");

      // 1. Create campaign (stakeholders will be added later by the consultant)
      const endDate = new Date(wizardData.startDate);
      endDate.setDate(endDate.getDate() + wizardData.durationDays);

      const { data: campaign, error: campaignErr } = await supabase
        .from("campaigns")
        .insert({
          name: wizardData.campaignName,
          description: `Prospect campaign for candidate ${wizardData.candidateName} — stakeholders to be added`,
          status: asDraft ? "draft" : "draft", // Always draft until stakeholders are added
          campaign_type: "candidate_engagement",
          candidate_id: wizardData.candidateId,
          start_date: wizardData.startDate,
          end_date: endDate.toISOString().split("T")[0],
          created_by: user?.id,
          rules_json: {
            avoidWeekends: wizardData.avoidWeekends,
            neverMentionSalary: wizardData.neverMentionSalary,
            respectOptOut: wizardData.respectOptOut,
            voice: wizardData.voice,
            languageStyle: wizardData.languageStyle,
            toneChips: wizardData.toneChips,
            primaryCta: wizardData.primaryCta,
            secondaryCta: wizardData.secondaryCta,
          },
        })
        .select("id")
        .single();

      if (campaignErr) throw campaignErr;

      // 2. Create email templates and campaign steps
      let stepOrder = 0;
      for (const step of activeSteps) {
        // Convert plain text to HTML paragraphs for the email template
        const toHtml = (text: string) =>
          text
            .split(/\n\s*\n/)
            .map((para) => `<p>${para.replace(/\n/g, "<br>")}</p>`)
            .join("");

        const bodyHtml = toHtml(step.bodyText);

        // Build role variants object if available
        const roleVariants: Record<string, string> | null =
          step.roleVariants
            ? {
                c_suite: toHtml(step.roleVariants.c_suite || step.bodyText),
                hr_talent: toHtml(step.roleVariants.hr_talent || step.bodyText),
              }
            : null;

        const templateName = `ENGAGE — Day ${step.dayOffset} — ${step.intent}`;
        const { data: tmpl, error: tmplErr } = await supabase
          .from("email_templates")
          .insert({
            name: templateName,
            subject: step.subject,
            body_html: bodyHtml,
            include_unsubscribe_link: wizardData.unsubscribeEnabled,
            created_by: user?.id,
            role_variants: roleVariants,
          } as any)
          .select("id")
          .single();

        if (tmplErr) throw tmplErr;

        // Add wait delay step (if not first step)
        if (stepOrder > 0) {
          const prevStep = activeSteps[stepOrder - 1];
          const daysBetween = step.dayOffset - (prevStep?.dayOffset || 0);
          if (daysBetween > 0) {
            await supabase.from("campaign_steps").insert({
              campaign_id: campaign.id,
              step_order: stepOrder * 2,
              step_type: "wait_delay",
              delay_minutes: daysBetween * 1440,
            });
          }
        }

        // Add send email step
        await supabase.from("campaign_steps").insert({
          campaign_id: campaign.id,
          step_order: stepOrder === 0 ? 1 : stepOrder * 2 + 1,
          step_type: "send_email",
          template_id: tmpl.id,
        });

        stepOrder++;
      }

      // 3. Add selected stakeholders to campaign
      if (selectedStakeholderIds.length > 0) {
        const stakeholderRows = selectedStakeholderIds.map((sid) => ({
          campaign_id: campaign.id,
          stakeholder_id: sid,
          status: "pending",
          current_step_order: 0,
        }));
        const { error: stakeholderErr } = await supabase
          .from("stakeholder_campaign_states")
          .insert(stakeholderRows);
        if (stakeholderErr) {
          console.error("Error adding stakeholders to campaign:", stakeholderErr);
          toast.error("Campaign created but failed to add some stakeholders");
        }
      }

      const stakeholderMsg = selectedStakeholderIds.length > 0
        ? `Campaign created with ${selectedStakeholderIds.length} stakeholder${selectedStakeholderIds.length !== 1 ? "s" : ""}`
        : asDraft ? "Campaign saved as draft — add stakeholders to launch" : "Campaign created — add stakeholders to begin sending";
      toast.success(stakeholderMsg);
      onOpenChange(false);
      navigate(`/campaigns/${campaign.id}`);
    } catch (err: any) {
      console.error("Launch error:", err);
      toast.error("Failed to create campaign: " + (err.message || "Unknown error"));
    } finally {
      setIsLaunching(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col p-0">
        {/* Stepper */}
        <div className="px-6 pt-6 pb-4 border-b bg-muted/30">
          <WizardStepper currentStep={currentStep} steps={STEP_LABELS} />
        </div>

        {/* Step Content */}
        <div className="flex-1 overflow-auto px-6 py-6">
          {currentStep === 1 && <StepBasics data={wizardData} onChange={updateData} />}
          {currentStep === 2 && <StepSchedule data={wizardData} onChange={updateData} />}
          {currentStep === 3 && <StepAIStrategy data={wizardData} onChange={updateData} />}
          {currentStep === 4 && (
            <StepTimeline
              data={wizardData}
              onChange={updateData}
              onRegenerateStep={regenerateStep}
              isRegenerating={regeneratingIndex}
            />
          )}
          {currentStep === 5 && <StepReview data={wizardData} onChange={updateData} />}
        </div>

        {/* Footer Navigation */}
        <div className="px-6 py-4 border-t bg-muted/30 flex items-center justify-between">
          <Button variant="outline" onClick={handleBack} disabled={currentStep === 1}>
            Back
          </Button>

          <div className="flex gap-2">
            {currentStep === 5 ? (
              <>
                <Button
                  variant="outline"
                  onClick={() => launchCampaign(true)}
                  disabled={isLaunching}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save as Draft
                </Button>
                <Button
                  onClick={() => launchCampaign(false)}
                  disabled={isLaunching}
                >
                  {isLaunching ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Rocket className="w-4 h-4 mr-2" />
                  )}
                  Create Campaign
                </Button>
              </>
            ) : (
              <Button onClick={handleNext} disabled={isGenerating}>
                {isGenerating ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : null}
                {currentStep === 3 ? "Generate & Preview" : "Next"}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
