import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Brain, Shield, Sparkles } from "lucide-react";
import type { EngagementWizardData } from "./types";
import {
  VOICES,
  LANGUAGE_STYLES,
  TONE_CHIPS,
  PRIMARY_CTAS,
  SECONDARY_CTAS,
} from "./types";

interface StepAIStrategyProps {
  data: EngagementWizardData;
  onChange: (updates: Partial<EngagementWizardData>) => void;
}

export function StepAIStrategy({ data, onChange }: StepAIStrategyProps) {
  const toggleChip = (chip: string) => {
    const current = data.toneChips;
    if (current.includes(chip)) {
      onChange({ toneChips: current.filter((c) => c !== chip) });
    } else {
      onChange({ toneChips: [...current, chip] });
    }
  };

  return (
    <div className="space-y-8">
      {/* Tone & Style */}
      <div className="space-y-4">
        <h3 className="text-base font-semibold flex items-center gap-2">
          <Sparkles className="w-4 h-4" />
          Tone & Style
        </h3>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Voice</Label>
            <Select value={data.voice} onValueChange={(v) => onChange({ voice: v })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {VOICES.map((v) => (
                  <SelectItem key={v} value={v}>
                    {v}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Language variant</Label>
            <Select
              value={data.languageStyle}
              onValueChange={(v) => onChange({ languageStyle: v })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGE_STYLES.map((l) => (
                  <SelectItem key={l} value={l}>
                    {l} English
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Add personality</Label>
          <div className="flex flex-wrap gap-2">
            {TONE_CHIPS.map((chip) => (
              <Badge
                key={chip}
                variant={data.toneChips.includes(chip) ? "default" : "outline"}
                className="cursor-pointer capitalize"
                onClick={() => toggleChip(chip)}
              >
                {chip}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Optimization */}
      <div className="space-y-4">
        <h3 className="text-base font-semibold flex items-center gap-2">
          <Brain className="w-4 h-4" />
          What should the AI optimize for?
        </h3>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Primary CTA</Label>
            <Select
              value={data.primaryCta}
              onValueChange={(v) => onChange({ primaryCta: v })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PRIMARY_CTAS.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Secondary CTA</Label>
            <Select
              value={data.secondaryCta || "__none__"}
              onValueChange={(v) =>
                onChange({ secondaryCta: v === "__none__" ? "" : v })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Optional" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none__">None</SelectItem>
                {SECONDARY_CTAS.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center justify-between rounded-lg border p-4">
          <div>
            <p className="font-medium text-sm">LinkedIn-style brevity</p>
            <p className="text-xs text-muted-foreground">Keep emails short, like DMs</p>
          </div>
          <Switch
            checked={data.linkedinBrevity}
            onCheckedChange={(v) => onChange({ linkedinBrevity: v })}
          />
        </div>
      </div>

      {/* Guardrails */}
      <div className="space-y-4">
        <h3 className="text-base font-semibold flex items-center gap-2">
          <Shield className="w-4 h-4" />
          Guardrails
        </h3>

        <div className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border p-4">
            <div>
              <p className="font-medium text-sm">Never mention salary</p>
              <p className="text-xs text-muted-foreground">
                Unless candidate already discussed it
              </p>
            </div>
            <Switch
              checked={data.neverMentionSalary}
              onCheckedChange={(v) => onChange({ neverMentionSalary: v })}
            />
          </div>

          <div className="flex items-center justify-between rounded-lg border p-4">
            <div>
              <p className="font-medium text-sm">Respect opt-out enforcement</p>
              <p className="text-xs text-muted-foreground">
                Include "reply stop" in every email
              </p>
            </div>
            <Switch
              checked={data.respectOptOut}
              onCheckedChange={(v) => onChange({ respectOptOut: v })}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
