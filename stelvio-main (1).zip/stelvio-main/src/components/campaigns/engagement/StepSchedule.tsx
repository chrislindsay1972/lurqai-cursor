import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar, Clock } from "lucide-react";
import type { EngagementWizardData } from "./types";
import { DURATION_OPTIONS, CADENCE_OPTIONS } from "./types";

interface StepScheduleProps {
  data: EngagementWizardData;
  onChange: (updates: Partial<EngagementWizardData>) => void;
}

function computeTouchpoints(
  duration: number,
  cadence: string,
  customInterval: number,
  avoidWeekends: boolean
): number[] {
  const interval =
    cadence === "daily"
      ? 1
      : cadence === "every_2"
      ? 2
      : cadence === "every_3"
      ? 3
      : cadence === "weekly"
      ? 7
      : customInterval;

  const days: number[] = [0];
  let day = interval;
  while (day <= duration) {
    if (avoidWeekends) {
      // Simple weekend adjustment — push to Monday
      const date = new Date();
      date.setDate(date.getDate() + day);
      const dow = date.getDay();
      if (dow === 0) day += 1;
      else if (dow === 6) day += 2;
    }
    if (day <= duration) days.push(day);
    day += interval;
  }
  return days;
}

export function StepSchedule({ data, onChange }: StepScheduleProps) {
  const touchpoints = computeTouchpoints(
    data.durationDays,
    data.cadence,
    data.customIntervalDays,
    data.avoidWeekends
  );

  return (
    <div className="space-y-8">
      {/* Duration */}
      <div className="space-y-4">
        <Label className="text-base font-semibold flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          How long should the campaign last?
        </Label>
        <div className="px-2">
          <Slider
            value={[data.durationDays]}
            onValueChange={([v]) => onChange({ durationDays: v })}
            min={1}
            max={30}
            step={1}
            className="w-full"
          />
        </div>
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            {DURATION_OPTIONS.map((d) => (
              <Badge
                key={d}
                variant={data.durationDays === d ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => onChange({ durationDays: d })}
              >
                {d} days
              </Badge>
            ))}
          </div>
          <span className="text-sm font-medium text-primary">{data.durationDays} days</span>
        </div>
      </div>

      {/* Cadence */}
      <div className="space-y-4">
        <Label className="text-base font-semibold flex items-center gap-2">
          <Clock className="w-4 h-4" />
          How often should we follow up?
        </Label>
        <RadioGroup
          value={data.cadence}
          onValueChange={(v) => onChange({ cadence: v as any })}
          className="grid grid-cols-2 gap-3"
        >
          {CADENCE_OPTIONS.map((c) => (
            <div key={c.value} className="flex items-center space-x-2">
              <RadioGroupItem value={c.value} id={`cadence-${c.value}`} />
              <Label htmlFor={`cadence-${c.value}`} className="cursor-pointer">
                {c.label}
              </Label>
            </div>
          ))}
        </RadioGroup>

        {data.cadence === "custom" && (
          <div className="flex items-center gap-3 ml-6">
            <Label htmlFor="custom-interval" className="text-sm">
              Every
            </Label>
            <Input
              id="custom-interval"
              type="number"
              min={1}
              max={14}
              value={data.customIntervalDays}
              onChange={(e) =>
                onChange({ customIntervalDays: parseInt(e.target.value) || 2 })
              }
              className="w-20"
            />
            <span className="text-sm text-muted-foreground">days</span>
          </div>
        )}
      </div>

      {/* Avoid Weekends */}
      <div className="flex items-center justify-between rounded-lg border p-4">
        <div>
          <p className="font-medium">Avoid weekends</p>
          <p className="text-sm text-muted-foreground">
            Push Saturday/Sunday sends to the next Monday
          </p>
        </div>
        <Switch
          checked={data.avoidWeekends}
          onCheckedChange={(v) => onChange({ avoidWeekends: v })}
        />
      </div>

      {/* Touchpoint Preview */}
      <div className="rounded-lg border bg-muted/30 p-4">
        <p className="text-sm font-medium mb-3">
          Generated touchpoints ({touchpoints.length} emails)
        </p>
        <div className="flex flex-wrap gap-2">
          {touchpoints.map((day) => (
            <Badge key={day} variant="secondary">
              Day {day}
            </Badge>
          ))}
        </div>
      </div>

      {/* Start Date */}
      <div className="space-y-2">
        <Label htmlFor="start-date">Start Date</Label>
        <Input
          id="start-date"
          type="date"
          value={data.startDate}
          onChange={(e) => onChange({ startDate: e.target.value })}
        />
      </div>
    </div>
  );
}
