import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, AlertCircle, Users } from "lucide-react";
import type { EngagementWizardData } from "./types";

interface StepReviewProps {
  data: EngagementWizardData;
  onChange: (updates: Partial<EngagementWizardData>) => void;
}

interface CheckItem {
  label: string;
  passed: boolean;
  detail?: string;
}

export function StepReview({ data, onChange }: StepReviewProps) {
  const activeSteps = data.generatedSteps.filter((s) => s.status !== "skipped");

  const checks: CheckItem[] = [
    {
      label: "Start date confirmed",
      passed: !!data.startDate,
      detail: data.startDate || "Not set",
    },
    {
      label: "At least one active step",
      passed: activeSteps.length > 0,
      detail: `${activeSteps.length} active steps`,
    },
    {
      label: "All steps have subjects",
      passed: activeSteps.every((s) => s.subject.trim().length > 0),
    },
    {
      label: "All steps have content",
      passed: activeSteps.every((s) => s.bodyText.trim().length > 0),
    },
  ];

  const allPassed = checks.every((c) => c.passed);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-base font-semibold mb-1">Pre-launch checklist</h3>
        <p className="text-sm text-muted-foreground">
          Verify everything looks good before launching.
        </p>
      </div>

      {/* Stakeholder reminder */}
      <div className="flex items-center gap-2 text-muted-foreground bg-muted/50 border rounded-lg p-3 text-sm">
        <Users className="w-4 h-4 flex-shrink-0" />
        Stakeholders will be added to this campaign after creation from the campaign detail page.
      </div>

      <div className="space-y-3">
        {checks.map((check) => (
          <div
            key={check.label}
            className="flex items-center gap-3 p-3 rounded-lg border"
          >
            {check.passed ? (
              <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
            ) : (
              <XCircle className="w-5 h-5 text-destructive flex-shrink-0" />
            )}
            <div className="flex-1">
              <p className="text-sm font-medium">{check.label}</p>
              {check.detail && (
                <p className="text-xs text-muted-foreground">{check.detail}</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Compliance options */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold">Compliance</h3>
        <div className="flex items-center justify-between rounded-lg border p-4">
          <div>
            <p className="font-medium text-sm">Compliance footer</p>
            <p className="text-xs text-muted-foreground">
              Append company address and compliance info
            </p>
          </div>
          <Switch
            checked={data.complianceFooter}
            onCheckedChange={(v) => onChange({ complianceFooter: v })}
          />
        </div>
        <div className="flex items-center justify-between rounded-lg border p-4">
          <div>
            <p className="font-medium text-sm">Unsubscribe / "stop" handling</p>
            <p className="text-xs text-muted-foreground">
              Include unsubscribe link in every email
            </p>
          </div>
          <Switch
            checked={data.unsubscribeEnabled}
            onCheckedChange={(v) => onChange({ unsubscribeEnabled: v })}
          />
        </div>
      </div>

      {/* Summary */}
      <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
        <h3 className="text-sm font-semibold">Campaign Summary</h3>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>
            <span className="text-muted-foreground">Campaign:</span>{" "}
            <span className="font-medium">{data.campaignName}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Candidate (subject):</span>{" "}
            <span className="font-medium">{data.candidateName}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Duration:</span>{" "}
            <span className="font-medium">{data.durationDays} days</span>
          </div>
          <div>
            <span className="text-muted-foreground">Steps:</span>{" "}
            <span className="font-medium">{activeSteps.length} emails</span>
          </div>
          <div>
            <span className="text-muted-foreground">Start:</span>{" "}
            <span className="font-medium">{data.startDate || "Not set"}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Voice:</span>{" "}
            <span className="font-medium">{data.voice}</span>
          </div>
        </div>
      </div>

      {!allPassed && (
        <div className="flex items-center gap-2 text-destructive bg-destructive/10 border border-destructive/20 rounded-lg p-3 text-sm">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          Some checks have not passed. Please resolve them before launching.
        </div>
      )}
    </div>
  );
}
