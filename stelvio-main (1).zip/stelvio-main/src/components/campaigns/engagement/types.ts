export interface EngagementWizardData {
  // Step 1 — Basics
  campaignName: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string | null;
  candidateTitle: string | null;
  candidateStatus: string;
  lastContactDate: string | null;
  goal: string;

  // Step 2 — Schedule
  durationDays: number;
  cadence: "daily" | "every_2" | "every_3" | "weekly" | "custom";
  customIntervalDays: number;
  avoidWeekends: boolean;
  startDate: string; // ISO date

  // Step 3 — AI Strategy
  aiProfileId: string | null;
  voice: string;
  languageStyle: string;
  toneChips: string[];
  primaryCta: string;
  secondaryCta: string;
  neverMentionSalary: boolean;
  respectOptOut: boolean;
  linkedinBrevity: boolean;

  // Step 4 — Generated steps
  generatedSteps: GeneratedStep[];

  // Step 5 — Review
  fromIdentity: string;
  complianceFooter: boolean;
  unsubscribeEnabled: boolean;
}

export interface GeneratedStep {
  dayOffset: number;
  intent: string;
  subject: string;
  bodyText: string;
  status: "planned" | "skipped";
  /** Role-based body variants for personalized outreach */
  roleVariants?: {
    c_suite?: string;
    hr_talent?: string;
  };
}

export const GOALS = [
  { value: "prospect_candidate", label: "Prospect candidate to stakeholder" },
  { value: "warm_intro", label: "Warm intro + schedule call" },
  { value: "role_pitch", label: "Pitch candidate for a specific role" },
  { value: "relationship_build", label: "Build relationship / stay top-of-mind" },
  { value: "custom", label: "Custom" },
];

export const VOICES = ["Professional", "Friendly", "Direct", "Warm"];
export const LANGUAGE_STYLES = ["UK", "US", "AU"];
export const TONE_CHIPS = [
  "concise",
  "confident",
  "consultative",
  "upbeat",
  "formal",
  "empathetic",
  "enthusiastic",
];

export const PRIMARY_CTAS = [
  "Book a call",
  "Reply with availability",
  "Discuss this candidate",
  "Review candidate profile",
];

export const SECONDARY_CTAS = [
  "Share role requirements",
  "Refer to a colleague",
  "Request more candidates",
];

export const DURATION_OPTIONS = [1, 7, 10, 14, 21, 30];

export const CADENCE_OPTIONS = [
  { value: "daily" as const, label: "Every day" },
  { value: "every_2" as const, label: "Every 2 days" },
  { value: "every_3" as const, label: "Every 3 days" },
  { value: "weekly" as const, label: "Weekly" },
  { value: "custom" as const, label: "Custom" },
];
