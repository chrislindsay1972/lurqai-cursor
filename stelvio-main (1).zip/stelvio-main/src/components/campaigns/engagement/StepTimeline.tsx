import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Mail,
  RefreshCw,
  SkipForward,
  Clock,
  Pencil,
  Loader2,
} from "lucide-react";
import type { EngagementWizardData } from "./types";

interface StepTimelineProps {
  data: EngagementWizardData;
  onChange: (updates: Partial<EngagementWizardData>) => void;
  onRegenerateStep: (index: number) => Promise<void>;
  isRegenerating: number | null;
}

const INTENT_LABELS: Record<string, string> = {
  intro: "Intro / Value Proposition",
  nudge: "Nudge / Follow-up",
  social_proof: "Social Proof / Case Study",
  value_add: "Value Add",
  soft_close: "Last Attempt / Soft Close",
  check_in: "Check-in",
  follow_up: "Follow-up",
};

const PLACEHOLDER_VARS = [
  { key: "stakeholder_name", label: "Contact Full Name", category: "Contact" },
  { key: "stakeholder_first_name", label: "Contact First Name", category: "Contact" },
  { key: "stakeholder_title", label: "Contact Job Title", category: "Contact" },
  { key: "stakeholder_company", label: "Company Name", category: "Company" },
  { key: "candidate_name", label: "Candidate Full Name", category: "Candidate" },
  { key: "candidate_first_name", label: "Candidate First Name", category: "Candidate" },
  { key: "candidate_current_title", label: "Current Job Title", category: "Candidate" },
  { key: "candidate_skills", label: "Key Skills", category: "Candidate" },
  { key: "candidate_experience_years", label: "Years of Experience", category: "Candidate" },
  { key: "candidate_ideal_role", label: "Target Role", category: "Candidate" },
  { key: "candidate_desired_location", label: "Preferred Location", category: "Candidate" },
  { key: "consultant_name", label: "Your Name", category: "Recruiter" },
  { key: "booking_link", label: "Booking / Calendar Link", category: "Recruiter" },
];

const PLACEHOLDER_CATEGORIES = ["Contact", "Company", "Candidate", "Recruiter"];

export function StepTimeline({
  data,
  onChange,
  onRegenerateStep,
  isRegenerating,
}: StepTimelineProps) {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editSubject, setEditSubject] = useState("");
  const [editBody, setEditBody] = useState("");
  const [editBodyCsuite, setEditBodyCsuite] = useState("");
  const [editBodyHr, setEditBodyHr] = useState("");
  const [activeVariantTab, setActiveVariantTab] = useState("general");
  // Track which field was last focused so merge field goes to the right place
  const [focusedField, setFocusedField] = useState<"subject" | "body">("body");

  const refSubject = useRef<HTMLInputElement>(null);
  const refGeneral = useRef<HTMLTextAreaElement>(null);
  const refCsuite = useRef<HTMLTextAreaElement>(null);
  const refHr = useRef<HTMLTextAreaElement>(null);

  const insertIntoInput = (
    ref: React.RefObject<HTMLInputElement>,
    value: string,
    setter: (v: string) => void,
    tag: string
  ) => {
    const el = ref.current;
    if (el) {
      const start = el.selectionStart ?? el.value.length;
      const end = el.selectionEnd ?? el.value.length;
      const newVal = el.value.substring(0, start) + tag + el.value.substring(end);
      setter(newVal);
      requestAnimationFrame(() => {
        el.focus();
        el.setSelectionRange(start + tag.length, start + tag.length);
      });
    } else {
      setter(value + tag);
    }
  };

  const insertIntoTextarea = (
    ref: React.RefObject<HTMLTextAreaElement>,
    value: string,
    setter: (v: string) => void,
    tag: string
  ) => {
    const el = ref.current;
    if (el) {
      const start = el.selectionStart ?? el.value.length;
      const end = el.selectionEnd ?? el.value.length;
      const newVal = el.value.substring(0, start) + tag + el.value.substring(end);
      setter(newVal);
      requestAnimationFrame(() => {
        el.focus();
        el.setSelectionRange(start + tag.length, start + tag.length);
      });
    } else {
      setter(value + tag);
    }
  };

  const insertMergeField = (key: string) => {
    const tag = `{{${key}}}`;

    if (focusedField === "subject") {
      insertIntoInput(refSubject, editSubject, setEditSubject, tag);
      return;
    }

    if (activeVariantTab === "csuite") {
      insertIntoTextarea(refCsuite, editBodyCsuite, setEditBodyCsuite, tag);
    } else if (activeVariantTab === "hr") {
      insertIntoTextarea(refHr, editBodyHr, setEditBodyHr, tag);
    } else {
      insertIntoTextarea(refGeneral, editBody, setEditBody, tag);
    }
  };

  const openEditor = (index: number) => {
    const step = data.generatedSteps[index];
    setEditSubject(step.subject);
    setEditBody(step.bodyText);
    setEditBodyCsuite(step.roleVariants?.c_suite || step.bodyText);
    setEditBodyHr(step.roleVariants?.hr_talent || step.bodyText);
    setActiveVariantTab("general");
    setFocusedField("body");
    setEditingIndex(index);
  };

  const saveEdit = () => {
    if (editingIndex === null) return;
    const updated = [...data.generatedSteps];
    updated[editingIndex] = {
      ...updated[editingIndex],
      subject: editSubject,
      bodyText: editBody,
      roleVariants: {
        c_suite: editBodyCsuite,
        hr_talent: editBodyHr,
      },
    };
    onChange({ generatedSteps: updated });
    setEditingIndex(null);
  };

  const toggleSkip = (index: number) => {
    const updated = [...data.generatedSteps];
    updated[index] = {
      ...updated[index],
      status: updated[index].status === "skipped" ? "planned" : "skipped",
    };
    onChange({ generatedSteps: updated });
  };

  const delayStep = (index: number, days: number) => {
    const updated = [...data.generatedSteps];
    updated[index] = {
      ...updated[index],
      dayOffset: updated[index].dayOffset + days,
    };
    onChange({ generatedSteps: updated });
  };

  if (data.generatedSteps.length === 0) {
    return (
      <div className="text-center py-12">
        <Loader2 className="w-8 h-8 animate-spin mx-auto text-muted-foreground mb-4" />
        <p className="text-muted-foreground">Generating your campaign timeline…</p>
      </div>
    );
  }

  const activeFieldLabel =
    focusedField === "subject"
      ? "Subject line"
      : activeVariantTab === "csuite"
      ? "C-Suite body"
      : activeVariantTab === "hr"
      ? "HR / Talent body"
      : "General body";

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Review your campaign timeline. These emails will be sent to stakeholders discussing{" "}
        <strong>{data.candidateName}</strong>. Edit, regenerate, skip, or delay individual steps.
      </p>

      {/* Timeline */}
      <div className="relative">
        <div className="absolute left-5 top-6 bottom-6 w-0.5 bg-border" />
        <div className="space-y-4">
          {data.generatedSteps.map((step, index) => (
            <div
              key={index}
              className={`relative flex gap-4 pl-2 ${step.status === "skipped" ? "opacity-50" : ""}`}
            >
              <div className="relative z-10 flex-shrink-0">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                    step.status === "skipped"
                      ? "bg-muted text-muted-foreground"
                      : "bg-primary text-primary-foreground"
                  }`}
                >
                  <Mail className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="flex-1 border rounded-lg p-4 bg-card">
                <div className="flex items-start justify-between mb-2">
                  <div className="w-full">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="secondary" className="text-xs">
                        Day {step.dayOffset}
                      </Badge>
                      <Badge variant="outline" className="text-xs capitalize">
                        {INTENT_LABELS[step.intent] || step.intent}
                      </Badge>
                      {step.roleVariants && (
                        <Badge variant="outline" className="text-xs text-primary border-primary/40">
                          3 variants
                        </Badge>
                      )}
                      {step.status === "skipped" && (
                        <Badge variant="destructive" className="text-xs">
                          Skipped
                        </Badge>
                      )}
                    </div>
                    <p className="font-medium">{step.subject}</p>

                    {step.roleVariants ? (
                      <Tabs defaultValue="general" className="mt-2">
                        <TabsList className="h-7">
                          <TabsTrigger value="general" className="text-xs px-2 py-1">General</TabsTrigger>
                          <TabsTrigger value="csuite" className="text-xs px-2 py-1">C-Suite</TabsTrigger>
                          <TabsTrigger value="hr" className="text-xs px-2 py-1">HR / Talent</TabsTrigger>
                        </TabsList>
                        <TabsContent value="general" className="mt-1">
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {step.bodyText.slice(0, 140)}…
                          </p>
                        </TabsContent>
                        <TabsContent value="csuite" className="mt-1">
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {(step.roleVariants.c_suite || step.bodyText).slice(0, 140)}…
                          </p>
                        </TabsContent>
                        <TabsContent value="hr" className="mt-1">
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {(step.roleVariants.hr_talent || step.bodyText).slice(0, 140)}…
                          </p>
                        </TabsContent>
                      </Tabs>
                    ) : (
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {step.bodyText.slice(0, 140)}…
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex gap-1 mt-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openEditor(index)}
                    disabled={step.status === "skipped"}
                  >
                    <Pencil className="w-3 h-3 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRegenerateStep(index)}
                    disabled={isRegenerating === index || step.status === "skipped"}
                  >
                    {isRegenerating === index ? (
                      <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                    ) : (
                      <RefreshCw className="w-3 h-3 mr-1" />
                    )}
                    Regenerate
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => toggleSkip(index)}>
                    <SkipForward className="w-3 h-3 mr-1" />
                    {step.status === "skipped" ? "Unskip" : "Skip"}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => delayStep(index, 1)}
                    disabled={step.status === "skipped"}
                  >
                    <Clock className="w-3 h-3 mr-1" />
                    +1 day
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Edit Dialog */}
      <Dialog open={editingIndex !== null} onOpenChange={(o) => !o && setEditingIndex(null)}>
        <DialogContent className="max-w-5xl max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>
              Edit Step — Day{" "}
              {editingIndex !== null ? data.generatedSteps[editingIndex]?.dayOffset : ""}
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-auto grid grid-cols-3 gap-4">
            {/* Left: Editor */}
            <div className="col-span-2 space-y-4">
              <div className="space-y-2">
                <Label>Subject line</Label>
                <Input
                  ref={refSubject}
                  value={editSubject}
                  onChange={(e) => setEditSubject(e.target.value)}
                  onFocus={() => setFocusedField("subject")}
                />
              </div>
              <Tabs value={activeVariantTab} onValueChange={setActiveVariantTab}>
                <TabsList className="w-full">
                  <TabsTrigger value="general" className="flex-1">General</TabsTrigger>
                  <TabsTrigger value="csuite" className="flex-1">C-Suite</TabsTrigger>
                  <TabsTrigger value="hr" className="flex-1">HR / Talent</TabsTrigger>
                </TabsList>
                <TabsContent value="general" className="space-y-1 mt-2">
                  <p className="text-xs text-muted-foreground">Sent to all other stakeholders (default fallback)</p>
                  <Textarea
                    ref={refGeneral}
                    value={editBody}
                    onChange={(e) => setEditBody(e.target.value)}
                    onFocus={() => setFocusedField("body")}
                    rows={14}
                    className="text-sm"
                  />
                </TabsContent>
                <TabsContent value="csuite" className="space-y-1 mt-2">
                  <p className="text-xs text-muted-foreground">Sent to C-suite recipients (CEO, CTO, CFO, MD, Founder…)</p>
                  <Textarea
                    ref={refCsuite}
                    value={editBodyCsuite}
                    onChange={(e) => setEditBodyCsuite(e.target.value)}
                    onFocus={() => setFocusedField("body")}
                    rows={14}
                    className="text-sm"
                  />
                </TabsContent>
                <TabsContent value="hr" className="space-y-1 mt-2">
                  <p className="text-xs text-muted-foreground">Sent to HR/Talent recipients (VP Talent, Head of People, Recruiter…)</p>
                  <Textarea
                    ref={refHr}
                    value={editBodyHr}
                    onChange={(e) => setEditBodyHr(e.target.value)}
                    onFocus={() => setFocusedField("body")}
                    rows={14}
                    className="text-sm"
                  />
                </TabsContent>
              </Tabs>
            </div>

            {/* Right: Merge Fields */}
            <div className="border-l pl-4 flex flex-col gap-2">
              <div>
                <p className="text-sm font-semibold">Insert Merge Fields</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Will insert into:{" "}
                  <span className="font-medium text-foreground">{activeFieldLabel}</span>
                </p>
              </div>
              <ScrollArea className="flex-1 max-h-[420px]">
                <div className="space-y-3 pr-1">
                  {PLACEHOLDER_CATEGORIES.map((cat) => {
                    const vars = PLACEHOLDER_VARS.filter((v) => v.category === cat);
                    return (
                      <div key={cat}>
                        <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">
                          {cat}
                        </p>
                        <div className="flex flex-col gap-1">
                          {vars.map((v) => (
                            <button
                              key={v.key}
                              type="button"
                              onClick={() => insertMergeField(v.key)}
                              className="w-full text-left rounded px-2 py-1.5 text-xs bg-muted/40 hover:bg-accent border border-transparent hover:border-border transition-colors flex items-center justify-between group"
                            >
                              <span className="font-medium">{v.label}</span>
                              <span className="text-[10px] text-muted-foreground opacity-0 group-hover:opacity-100 font-mono transition-opacity">
                                {`{{${v.key}}}`}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingIndex(null)}>
              Cancel
            </Button>
            <Button onClick={saveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
