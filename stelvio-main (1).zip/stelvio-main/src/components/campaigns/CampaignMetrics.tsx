import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Send, CheckCircle, Eye, MousePointer, XCircle, BarChart3, AlertTriangle, MessageSquare } from "lucide-react";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";

interface CampaignMetric {
  id: string;
  campaign_id: string;
  stakeholder_id: string;
  step_id: string | null;
  email_address: string;
  event_type: string;
  event_at: string;
  event_data: any;
}

interface CampaignMetricsProps {
  campaignId: string;
}

function extractErrorReason(metric: CampaignMetric): string | null {
  if (!metric.event_data) return null;
  const data = metric.event_data;

  // Direct error string
  if (typeof data.error === "string") return data.error;

  // Nested in results array
  if (Array.isArray(data.results)) {
    const failed = data.results.find((r: any) => !r.success && r.error);
    if (failed) return failed.error;
  }

  // Graph API error message pattern
  if (data.success === false && typeof data.error === "string") return data.error;

  return null;
}

export function CampaignMetrics({ campaignId }: CampaignMetricsProps) {
  const { formatDateTime } = useLocaleFormat();
  const { data: metrics = [], isLoading } = useQuery({
    queryKey: ["campaign-metrics", campaignId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("campaign_metrics")
        .select("*")
        .eq("campaign_id", campaignId)
        .order("event_at", { ascending: false })
        .limit(100);

      if (error) throw error;
      return data as CampaignMetric[];
    },
  });

  // Calculate summary stats
  const stats = {
    sent: metrics.filter((m) => m.event_type === "sent").length,
    replied: metrics.filter((m) => m.event_type === "reply_detected").length,
    opened: metrics.filter((m) => m.event_type === "opened").length,
    clicked: metrics.filter((m) => m.event_type === "clicked").length,
    bounced: metrics.filter((m) => m.event_type === "bounced").length,
    failed: metrics.filter((m) => m.event_type === "failed").length,
    unsubscribed: metrics.filter((m) => m.event_type === "unsubscribed").length,
  };

  const totalErrors = stats.bounced + stats.failed;
  const replyRate = stats.sent > 0 ? ((stats.replied / stats.sent) * 100).toFixed(1) : "0";
  const openRate = stats.sent > 0 ? ((stats.opened / stats.sent) * 100).toFixed(1) : "0";
  const clickRate = stats.sent > 0 ? ((stats.clicked / stats.sent) * 100).toFixed(1) : "0";

  const getEventIcon = (type: string) => {
    switch (type) {
      case "sent":
        return <Send className="w-4 h-4 text-primary" />;
      case "reply_detected":
        return <MessageSquare className="w-4 h-4 text-primary" />;
      case "opened":
        return <Eye className="w-4 h-4 text-accent" />;
      case "clicked":
        return <MousePointer className="w-4 h-4 text-accent" />;
      case "bounced":
        return <XCircle className="w-4 h-4 text-destructive" />;
      case "failed":
        return <AlertTriangle className="w-4 h-4 text-destructive" />;
      case "unsubscribed":
        return <XCircle className="w-4 h-4 text-muted-foreground" />;
      default:
        return <BarChart3 className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getEventBadge = (type: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      sent: "secondary",
      reply_detected: "default",
      opened: "default",
      clicked: "default",
      bounced: "destructive",
      failed: "destructive",
      unsubscribed: "outline",
    };
    const labels: Record<string, string> = { reply_detected: "replied" };
    return <Badge variant={variants[type] || "secondary"}>{labels[type] || type}</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Send className="w-8 h-8 text-primary" />
              <div>
                <p className="text-2xl font-bold">{stats.sent}</p>
                <p className="text-sm text-muted-foreground">Sent</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Eye className="w-8 h-8 text-accent" />
              <div>
                <p className="text-2xl font-bold">{stats.opened}</p>
                <p className="text-sm text-muted-foreground">Opened ({openRate}%)</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <MousePointer className="w-8 h-8 text-accent" />
              <div>
                <p className="text-2xl font-bold">{stats.clicked}</p>
                <p className="text-sm text-muted-foreground">Clicked ({clickRate}%)</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-8 h-8 text-primary" />
              <div>
                <p className="text-2xl font-bold">{stats.replied}</p>
                <p className="text-sm text-muted-foreground">Replied ({replyRate}%)</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <XCircle className="w-8 h-8 text-destructive" />
              <div>
                <p className="text-2xl font-bold">{stats.bounced}</p>
                <p className="text-sm text-muted-foreground">Bounced</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-8 h-8 text-destructive" />
              <div>
                <p className="text-2xl font-bold">{stats.failed}</p>
                <p className="text-sm text-muted-foreground">Failed</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Delivery Errors Panel */}
      {totalErrors > 0 && (
        <Card className="border-destructive/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-destructive flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Delivery Errors ({totalErrors})
            </CardTitle>
            <CardDescription>Emails that bounced or failed to deliver</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Error Reason</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {metrics
                  .filter((m) => m.event_type === "bounced" || m.event_type === "failed")
                  .map((metric) => {
                    const reason = extractErrorReason(metric);
                    return (
                      <TableRow key={metric.id}>
                        <TableCell>{getEventBadge(metric.event_type)}</TableCell>
                        <TableCell className="text-muted-foreground">{metric.email_address}</TableCell>
                        <TableCell className="max-w-xs">
                          {reason ? (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="text-sm text-destructive truncate block cursor-help">
                                    {reason.length > 80 ? reason.slice(0, 80) + "…" : reason}
                                  </span>
                                </TooltipTrigger>
                                <TooltipContent side="bottom" className="max-w-md">
                                  <p className="text-xs whitespace-pre-wrap break-words">{reason}</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          ) : (
                            <span className="text-sm text-muted-foreground italic">No details available</span>
                          )}
                        </TableCell>
                        <TableCell className="text-muted-foreground whitespace-nowrap">
                          {formatDateTime(metric.event_at)}
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Activity Log */}
      <Card>
        <CardHeader>
          <CardTitle>Activity Log</CardTitle>
          <CardDescription>Recent campaign events and interactions</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-muted-foreground text-center py-8">Loading metrics...</p>
          ) : metrics.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No activity yet. Metrics will appear here once the campaign starts sending emails.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12"></TableHead>
                  <TableHead>Event</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {metrics.map((metric) => {
                  const reason = (metric.event_type === "bounced" || metric.event_type === "failed")
                    ? extractErrorReason(metric)
                    : null;
                  return (
                    <TableRow key={metric.id}>
                      <TableCell>{getEventIcon(metric.event_type)}</TableCell>
                      <TableCell>{getEventBadge(metric.event_type)}</TableCell>
                      <TableCell className="text-muted-foreground">{metric.email_address}</TableCell>
                      <TableCell className="max-w-xs">
                        {reason ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="text-xs text-destructive truncate block cursor-help">
                                  {reason.length > 60 ? reason.slice(0, 60) + "…" : reason}
                                </span>
                              </TooltipTrigger>
                              <TooltipContent side="bottom" className="max-w-md">
                                <p className="text-xs whitespace-pre-wrap break-words">{reason}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground whitespace-nowrap">
                        {formatDateTime(metric.event_at)}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
