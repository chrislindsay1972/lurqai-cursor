import { useState, useEffect, useRef } from "react";
import { sanitizeEmailHtml } from "@/lib/sanitizeHtml";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, Code, Search, Copy } from "lucide-react";
import { toast } from "sonner";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/contexts/AuthContext";

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body_html: string;
  placeholders: string[] | null;
  include_unsubscribe_link: boolean;
  include_cv_attachment: boolean;
  created_at: string;
  created_by: string | null;
}

interface EmailTemplateEditorProps {
  template?: EmailTemplate | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved?: (template?: { id: string; name: string }) => void;
}

// Full placeholder list for stakeholders, companies, candidates, and jobs
const AVAILABLE_PLACEHOLDERS = [
  // Stakeholder fields
  { key: "stakeholder_name", label: "Name", category: "Stakeholder" },
  { key: "stakeholder_first_name", label: "First Name", category: "Stakeholder" },
  { key: "stakeholder_last_name", label: "Last Name", category: "Stakeholder" },
  { key: "stakeholder_email", label: "Email", category: "Stakeholder" },
  { key: "stakeholder_title", label: "Title", category: "Stakeholder" },
  { key: "stakeholder_phone", label: "Phone", category: "Stakeholder" },
  { key: "stakeholder_location", label: "Location", category: "Stakeholder" },
  { key: "stakeholder_linkedin_url", label: "LinkedIn URL", category: "Stakeholder" },
  { key: "stakeholder_gender", label: "Gender", category: "Stakeholder" },
  // Company fields
  { key: "company_name", label: "Company Name", category: "Company" },
  { key: "company_domain", label: "Domain", category: "Company" },
  { key: "company_website", label: "Website", category: "Company" },
  { key: "company_industry", label: "Industry", category: "Company" },
  { key: "company_employee_count", label: "Employee Count", category: "Company" },
  { key: "company_city", label: "City", category: "Company" },
  { key: "company_country", label: "Country", category: "Company" },
  { key: "company_description", label: "Description", category: "Company" },
  { key: "company_linkedin_url", label: "LinkedIn URL", category: "Company" },
  // Candidate fields
  { key: "candidate_name", label: "Name", category: "Candidate" },
  { key: "candidate_first_name", label: "First Name", category: "Candidate" },
  { key: "candidate_last_name", label: "Last Name", category: "Candidate" },
  { key: "candidate_email", label: "Email", category: "Candidate" },
  { key: "candidate_mobile", label: "Mobile", category: "Candidate" },
  { key: "candidate_current_title", label: "Current Title", category: "Candidate" },
  { key: "candidate_experience_years", label: "Years of Experience", category: "Candidate" },
  { key: "candidate_skills", label: "Skills", category: "Candidate" },
  { key: "candidate_education", label: "Education", category: "Candidate" },
  { key: "candidate_desired_salary", label: "Desired Salary", category: "Candidate" },
  { key: "candidate_desired_location", label: "Desired Location", category: "Candidate" },
  { key: "candidate_ideal_role", label: "Ideal Role", category: "Candidate" },
  { key: "candidate_notice_period", label: "Notice Period", category: "Candidate" },
  { key: "candidate_ai_summary", label: "AI Summary", category: "Candidate" },
  // Job fields
  { key: "job_title", label: "Title", category: "Job" },
  { key: "job_description", label: "Description", category: "Job" },
  { key: "job_location", label: "Location", category: "Job" },
  { key: "job_salary_range", label: "Salary Range", category: "Job" },
  { key: "job_type", label: "Type", category: "Job" },
  { key: "job_experience_level", label: "Experience Level", category: "Job" },
  { key: "job_requirements", label: "Requirements", category: "Job" },
  { key: "job_skills_required", label: "Skills Required", category: "Job" },
  { key: "job_source_url", label: "Source URL", category: "Job" },
];

export function EmailTemplateEditor({
  template,
  open,
  onOpenChange,
  onSaved,
}: EmailTemplateEditorProps) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("edit");
  const bodyTextareaRef = useRef<HTMLTextAreaElement>(null);
  const cursorPositionRef = useRef<number | null>(null);
  const [placeholderSearch, setPlaceholderSearch] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    subject: "",
    body_html: "",
    include_unsubscribe_link: true,
    include_cv_attachment: false,
  });

  useEffect(() => {
    if (template) {
      setFormData({
        name: template.name,
        subject: template.subject,
        body_html: template.body_html,
        include_unsubscribe_link: template.include_unsubscribe_link,
        include_cv_attachment: template.include_cv_attachment ?? false,
      });
    } else {
      setFormData({
        name: "",
        subject: "",
        body_html: "",
        include_unsubscribe_link: true,
        include_cv_attachment: false,
      });
    }
  }, [template, open]);

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      // Extract placeholders from content
      const placeholderRegex = /\{\{(\w+)\}\}/g;
      const foundPlaceholders: string[] = [];
      let match;
      const combinedText = `${data.subject} ${data.body_html}`;
      while ((match = placeholderRegex.exec(combinedText)) !== null) {
        if (!foundPlaceholders.includes(match[1])) {
          foundPlaceholders.push(match[1]);
        }
      }

      if (template) {
        const { error } = await supabase
          .from("email_templates")
          .update({
            name: data.name,
            subject: data.subject,
            body_html: data.body_html,
            include_unsubscribe_link: data.include_unsubscribe_link,
            include_cv_attachment: data.include_cv_attachment,
            placeholders: foundPlaceholders,
          })
          .eq("id", template.id);
        if (error) throw error;
        return { id: template.id, name: data.name };
      } else {
        const { data: newTemplate, error } = await supabase
          .from("email_templates")
          .insert({
            name: data.name,
            subject: data.subject,
            body_html: data.body_html,
            include_unsubscribe_link: data.include_unsubscribe_link,
            include_cv_attachment: data.include_cv_attachment,
            placeholders: foundPlaceholders,
            created_by: user?.id,
          })
          .select("id, name")
          .single();
        if (error) throw error;
        return newTemplate;
      }
    },
    onSuccess: (savedTemplate) => {
      queryClient.invalidateQueries({ queryKey: ["email-templates"] });
      onOpenChange(false);
      onSaved?.(savedTemplate);
      toast.success(template ? "Template updated" : "Template created");
    },
    onError: (error: any) => {
      toast.error("Failed to save template: " + error.message);
    },
  });

  const handleSubmit = () => {
    if (!formData.name.trim()) {
      toast.error("Template name is required");
      return;
    }
    if (!formData.subject.trim()) {
      toast.error("Subject is required");
      return;
    }
    if (!formData.body_html.trim()) {
      toast.error("Body content is required");
      return;
    }
    saveMutation.mutate(formData);
  };

  const insertPlaceholder = (key: string) => {
    const placeholder = `{{${key}}}`;
    const textarea = bodyTextareaRef.current;
    const pos = cursorPositionRef.current;
    
    if (textarea && pos !== null) {
      const before = formData.body_html.substring(0, pos);
      const after = formData.body_html.substring(pos);
      const newValue = before + placeholder + after;
      setFormData((prev) => ({ ...prev, body_html: newValue }));
      // Restore cursor after the inserted placeholder
      const newPos = pos + placeholder.length;
      cursorPositionRef.current = newPos;
      requestAnimationFrame(() => {
        textarea.focus();
        textarea.setSelectionRange(newPos, newPos);
      });
    } else {
      setFormData((prev) => ({
        ...prev,
        body_html: prev.body_html + placeholder,
      }));
    }
  };

  // Preview with sample data
  const getPreviewHtml = () => {
    let html = formData.body_html;
    const sampleData: Record<string, string> = {
      stakeholder_name: "John Smith",
      stakeholder_first_name: "John",
      stakeholder_last_name: "Smith",
      stakeholder_email: "john.smith@example.com",
      stakeholder_title: "Head of Engineering",
      stakeholder_phone: "+1 555-123-4567",
      stakeholder_location: "San Francisco, CA",
      stakeholder_linkedin_url: "https://linkedin.com/in/johnsmith",
      stakeholder_gender: "Male",
      company_name: "Acme Corporation",
      company_domain: "acme.com",
      company_website: "https://www.acme.com",
      company_industry: "Technology",
      company_employee_count: "500",
      company_city: "San Francisco",
      company_country: "USA",
      company_description: "Leading technology solutions provider",
      company_linkedin_url: "https://linkedin.com/company/acme",
      candidate_name: "Sarah Johnson",
      candidate_first_name: "Sarah",
      candidate_last_name: "Johnson",
      candidate_email: "sarah.johnson@email.com",
      candidate_mobile: "+1 555-987-6543",
      candidate_current_title: "Senior Software Engineer",
      candidate_experience_years: "8",
      candidate_skills: "React, TypeScript, Node.js, PostgreSQL",
      candidate_education: "BSc Computer Science, MIT",
      candidate_desired_salary: "£85,000 - £100,000",
      candidate_desired_location: "London, UK",
      candidate_ideal_role: "Lead Developer",
      candidate_notice_period: "1 month",
      candidate_ai_summary: "Experienced full-stack developer with strong leadership skills",
      job_title: "Senior Frontend Developer",
      job_description: "Build innovative web applications using React and TypeScript",
      job_location: "London, UK (Hybrid)",
      job_salary_range: "£80,000 - £100,000",
      job_type: "Full-time",
      job_experience_level: "Senior",
      job_requirements: "5+ years experience in frontend development",
      job_skills_required: "React, TypeScript, CSS, Testing",
      job_source_url: "https://careers.acme.com/job/12345",
    };

    Object.entries(sampleData).forEach(([key, value]) => {
      html = html.replace(new RegExp(`\\{\\{${key}\\}\\}`, "g"), value);
    });

    return sanitizeEmailHtml(html);
  };

  const groupedPlaceholders = AVAILABLE_PLACEHOLDERS.reduce(
    (acc, p) => {
      if (!acc[p.category]) acc[p.category] = [];
      acc[p.category].push(p);
      return acc;
    },
    {} as Record<string, typeof AVAILABLE_PLACEHOLDERS>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>{template ? "Edit Template" : "Create Template"}</DialogTitle>
          <DialogDescription>
            Create email templates with placeholders for personalization.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 overflow-hidden">
          <TabsList>
            <TabsTrigger value="edit" className="flex items-center gap-2">
              <Code className="w-4 h-4" />
              Edit
            </TabsTrigger>
            <TabsTrigger value="preview" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Preview
            </TabsTrigger>
          </TabsList>

          <TabsContent value="edit" className="flex-1 overflow-auto space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Template Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Initial Outreach"
                  value={formData.name}
                  onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subject">Subject Line *</Label>
                <Input
                  id="subject"
                  placeholder="e.g., Opportunity at {{company_name}}"
                  value={formData.subject}
                  onChange={(e) => setFormData((prev) => ({ ...prev, subject: e.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="body">Email Body *</Label>
              <div className="grid grid-cols-[1fr_240px] gap-3">
                <div className="space-y-2">
                  <Textarea
                    id="body"
                    ref={bodyTextareaRef}
                    placeholder="Write your email content here. Use {{placeholders}} for personalization..."
                    value={formData.body_html}
                    onChange={(e) => {
                      setFormData((prev) => ({ ...prev, body_html: e.target.value }));
                      cursorPositionRef.current = e.target.selectionStart;
                    }}
                    onSelect={(e) => {
                      cursorPositionRef.current = (e.target as HTMLTextAreaElement).selectionStart;
                    }}
                    onBlur={(e) => {
                      cursorPositionRef.current = e.target.selectionStart;
                    }}
                    rows={14}
                    className="font-mono text-sm"
                  />
                  <p className="text-xs text-muted-foreground">
                    HTML supported. Use {`{{placeholder}}`} syntax for dynamic content.
                  </p>
                </div>

                {/* Variables panel */}
                <div className="border rounded-lg bg-muted/30 flex flex-col overflow-hidden">
                  <div className="px-3 py-2 border-b bg-muted/50">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">
                      Variables
                    </p>
                    <div className="relative">
                      <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input
                        placeholder="Search..."
                        value={placeholderSearch}
                        onChange={(e) => setPlaceholderSearch(e.target.value)}
                        className="h-7 text-xs pl-7 bg-background"
                      />
                    </div>
                  </div>
                  <ScrollArea className="flex-1 max-h-[320px]">
                    <Accordion type="multiple" defaultValue={Object.keys(groupedPlaceholders)} className="px-1">
                      {Object.entries(groupedPlaceholders).map(([category, placeholders]) => {
                        const filtered = placeholders.filter(
                          (p) =>
                            !placeholderSearch ||
                            p.label.toLowerCase().includes(placeholderSearch.toLowerCase()) ||
                            p.key.toLowerCase().includes(placeholderSearch.toLowerCase())
                        );
                        if (filtered.length === 0) return null;
                        return (
                          <AccordionItem key={category} value={category} className="border-b-0">
                            <AccordionTrigger className="py-1.5 px-2 text-xs font-medium text-muted-foreground hover:no-underline">
                              {category}
                              <span className="ml-auto mr-1 text-[10px] tabular-nums opacity-60">{filtered.length}</span>
                            </AccordionTrigger>
                            <AccordionContent className="pb-1.5 px-1">
                              <div className="space-y-0.5">
                                {filtered.map((p) => (
                                  <button
                                    key={p.key}
                                    type="button"
                                    onClick={() => {
                                      insertPlaceholder(p.key);
                                      toast.success(`Inserted {{${p.key}}}`, { duration: 1500 });
                                    }}
                                    className="w-full flex items-center justify-between gap-1 rounded px-2 py-1 text-xs text-left hover:bg-accent group transition-colors"
                                  >
                                    <span className="truncate">{p.label}</span>
                                    <Copy className="w-3 h-3 opacity-0 group-hover:opacity-60 shrink-0 transition-opacity" />
                                  </button>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        );
                      })}
                    </Accordion>
                  </ScrollArea>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="unsubscribe"
                checked={formData.include_unsubscribe_link}
                onCheckedChange={(checked) =>
                  setFormData((prev) => ({ ...prev, include_unsubscribe_link: checked }))
                }
              />
              <Label htmlFor="unsubscribe">Include unsubscribe link (recommended for compliance)</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="cv-attachment"
                checked={formData.include_cv_attachment}
                onCheckedChange={(checked) =>
                  setFormData((prev) => ({ ...prev, include_cv_attachment: checked }))
                }
              />
              <Label htmlFor="cv-attachment">
                Attach sanitised CV (personal details &amp; social links removed)
              </Label>
            </div>
          </TabsContent>

          <TabsContent value="preview" className="flex-1 overflow-auto mt-4">
            <div className="border rounded-lg p-4 bg-white">
              <div className="mb-4 pb-4 border-b">
                <p className="text-sm text-muted-foreground">Subject:</p>
                <p className="font-medium">
                  {formData.subject.replace(/\{\{(\w+)\}\}/g, (_, key) => {
                    const sampleData: Record<string, string> = {
                      company_name: "Acme Corporation",
                      stakeholder_name: "John Smith",
                      candidate_name: "Sarah Johnson",
                      job_title: "Senior Frontend Developer",
                    };
                    return sampleData[key] || `{{${key}}}`;
                  })}
                </p>
              </div>
              <div
                className="prose prose-sm max-w-none"
                dangerouslySetInnerHTML={{ __html: getPreviewHtml() }}
              />
              {formData.include_unsubscribe_link && (
                <div className="mt-6 pt-4 border-t text-center">
                  <a href="#" className="text-sm text-muted-foreground hover:underline">
                    Unsubscribe from these emails
                  </a>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={saveMutation.isPending}>
            {saveMutation.isPending ? "Saving..." : template ? "Save Changes" : "Create Template"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
