import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Plus, Search, Trash2, Building2 } from "lucide-react";
import { toast } from "sonner";

interface StakeholderState {
  id: string;
  stakeholder_id: string;
  campaign_id: string;
  status: string;
  current_step_order: number;
  started_at: string | null;
  completed_at: string | null;
  stakeholder: {
    id: string;
    name: string;
    email: string | null;
    title: string | null;
    company: {
      id: string;
      name: string;
    } | null;
  };
}

interface Stakeholder {
  id: string;
  name: string;
  email: string | null;
  title: string | null;
  company: {
    id: string;
    name: string;
  } | null;
}

interface CampaignStakeholdersProps {
  campaignId: string;
}

export function CampaignStakeholders({ campaignId }: CampaignStakeholdersProps) {
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStakeholders, setSelectedStakeholders] = useState<string[]>([]);

  const { data: enrolledStakeholders = [], isLoading } = useQuery({
    queryKey: ["campaign-stakeholders", campaignId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stakeholder_campaign_states")
        .select(`
          *,
          stakeholder:stakeholders(
            id,
            name,
            email,
            title,
            company:companies(id, name)
          )
        `)
        .eq("campaign_id", campaignId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as StakeholderState[];
    },
  });

  const { data: availableStakeholders = [] } = useQuery({
    queryKey: ["available-stakeholders", campaignId],
    queryFn: async () => {
      // Get IDs of already enrolled stakeholders
      const enrolledIds = enrolledStakeholders.map((s) => s.stakeholder_id);

      const { data, error } = await supabase
        .from("stakeholders")
        .select(`
          id,
          name,
          email,
          title,
          company:companies(id, name)
        `)
        .not("email", "is", null)
        .order("name");

      if (error) throw error;

      // Filter out already enrolled stakeholders
      return (data as Stakeholder[]).filter((s) => !enrolledIds.includes(s.id));
    },
    enabled: isAddDialogOpen,
  });

  const addStakeholdersMutation = useMutation({
    mutationFn: async (stakeholderIds: string[]) => {
      const inserts = stakeholderIds.map((stakeholderId) => ({
        campaign_id: campaignId,
        stakeholder_id: stakeholderId,
        status: "pending",
        current_step_order: 0,
      }));

      const { error } = await supabase.from("stakeholder_campaign_states").insert(inserts);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaign-stakeholders", campaignId] });
      queryClient.invalidateQueries({ queryKey: ["available-stakeholders", campaignId] });
      setIsAddDialogOpen(false);
      setSelectedStakeholders([]);
      toast.success("Stakeholders added to campaign");
    },
    onError: (error: any) => {
      toast.error("Failed to add stakeholders: " + error.message);
    },
  });

  const removeStakeholderMutation = useMutation({
    mutationFn: async (stateId: string) => {
      const { error } = await supabase
        .from("stakeholder_campaign_states")
        .delete()
        .eq("id", stateId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaign-stakeholders", campaignId] });
      toast.success("Stakeholder removed from campaign");
    },
    onError: (error: any) => {
      toast.error("Failed to remove stakeholder: " + error.message);
    },
  });

  const filteredAvailable = availableStakeholders.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.company?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleStakeholder = (id: string) => {
    setSelectedStakeholders((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (selectedStakeholders.length === filteredAvailable.length) {
      setSelectedStakeholders([]);
    } else {
      setSelectedStakeholders(filteredAvailable.map((s) => s.id));
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "outline"> = {
      pending: "secondary",
      in_progress: "default",
      completed: "outline",
      failed: "outline",
    };
    return <Badge variant={variants[status] || "secondary"}>{status}</Badge>;
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Enrolled Stakeholders</CardTitle>
          <CardDescription>
            {enrolledStakeholders.length} stakeholder{enrolledStakeholders.length !== 1 && "s"}{" "}
            enrolled in this campaign
          </CardDescription>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Stakeholders
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <p className="text-muted-foreground text-center py-8">Loading stakeholders...</p>
        ) : enrolledStakeholders.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">
              No stakeholders enrolled yet. Add stakeholders to start the campaign.
            </p>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Stakeholders
            </Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Step</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {enrolledStakeholders.map((state) => (
                <TableRow key={state.id}>
                  <TableCell className="font-medium">{state.stakeholder.name}</TableCell>
                  <TableCell className="text-muted-foreground">
                    {state.stakeholder.email || "-"}
                  </TableCell>
                  <TableCell>
                    {state.stakeholder.company ? (
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-muted-foreground" />
                        {state.stakeholder.company.name}
                      </div>
                    ) : (
                      "-"
                    )}
                  </TableCell>
                  <TableCell>{getStatusBadge(state.status)}</TableCell>
                  <TableCell className="text-muted-foreground">
                    {state.current_step_order}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:text-destructive"
                      onClick={() => removeStakeholderMutation.mutate(state.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      {/* Add Stakeholders Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add Stakeholders</DialogTitle>
            <DialogDescription>
              Select stakeholders with email addresses to add to this campaign.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search stakeholders..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="border rounded-lg max-h-96 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={
                          filteredAvailable.length > 0 &&
                          selectedStakeholders.length === filteredAvailable.length
                        }
                        onCheckedChange={selectAll}
                      />
                    </TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Company</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAvailable.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                        No available stakeholders found.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredAvailable.map((stakeholder) => (
                      <TableRow
                        key={stakeholder.id}
                        className="cursor-pointer"
                        onClick={() => toggleStakeholder(stakeholder.id)}
                      >
                        <TableCell>
                          <Checkbox
                            checked={selectedStakeholders.includes(stakeholder.id)}
                            onCheckedChange={() => toggleStakeholder(stakeholder.id)}
                          />
                        </TableCell>
                        <TableCell className="font-medium">{stakeholder.name}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {stakeholder.email}
                        </TableCell>
                        <TableCell>{stakeholder.company?.name || "-"}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
            {selectedStakeholders.length > 0 && (
              <p className="text-sm text-muted-foreground">
                {selectedStakeholders.length} stakeholder{selectedStakeholders.length !== 1 && "s"}{" "}
                selected
              </p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => addStakeholdersMutation.mutate(selectedStakeholders)}
              disabled={selectedStakeholders.length === 0 || addStakeholdersMutation.isPending}
            >
              {addStakeholdersMutation.isPending
                ? "Adding..."
                : `Add ${selectedStakeholders.length} Stakeholder${
                    selectedStakeholders.length !== 1 ? "s" : ""
                  }`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
