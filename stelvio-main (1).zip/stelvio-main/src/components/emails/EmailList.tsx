import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { Mail, Paperclip, ChevronRight, Reply, Send, Loader2, Plus, X, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useState, useEffect } from "react";
import { useSendEmail } from "@/hooks/useSendEmail";
import { sanitizeEmailHtml } from "@/lib/sanitizeHtml";
interface Email {
  id: string;
  connection_id: string;
  subject: string;
  from_address: string;
  from_name: string | null;
  to_addresses: string[];
  sent_at: string;
  body_text: string | null;
  body_html: string | null;
  folder: string;
  has_attachments: boolean;
  is_read: boolean;
}

interface EmailListProps {
  companyId?: string;
  stakeholderId?: string;
  maxHeight?: string;
  recipientEmail?: string;
  recipientName?: string;
  showComposeButton?: boolean;
  composeButtonOnly?: boolean;
}

interface SignatureSettings {
  // Support both old and new field names for compatibility
  signOff?: string;
  name?: string;
  fullName?: string;
  jobTitle: string;
  company: string;
  email: string;
  phone: string;
  website: string;
  linkedin: string;
  fontFamily: string;
  fontSize: number;
  primaryColor: string;
  secondaryColor: string;
  showLogo: boolean;
  logoUrl: string | null;
  logoSize: number;
  dividerStyle: string;
}

// Available signature fonts - must match SignatureManager
const SIGNATURE_FONTS = [
  { value: "atos-body", label: "ATOS Body", family: "'ATOS Body', sans-serif" },
  // NOTE: "Inter" is not reliably available in email clients; use an email-safe fallback
  // so the in-app preview matches what recipients see.
  { value: "inter", label: "Inter", family: "Arial, sans-serif" },
  { value: "georgia", label: "Georgia", family: "'Georgia', serif" },
  { value: "times", label: "Times New Roman", family: "'Times New Roman', serif" },
  { value: "arial", label: "Arial", family: "'Arial', sans-serif" },
  { value: "helvetica", label: "Helvetica", family: "'Helvetica Neue', 'Helvetica', sans-serif" },
  { value: "verdana", label: "Verdana", family: "'Verdana', sans-serif" },
  { value: "trebuchet", label: "Trebuchet MS", family: "'Trebuchet MS', sans-serif" },
  { value: "palatino", label: "Palatino", family: "'Palatino Linotype', 'Palatino', serif" },
  { value: "garamond", label: "Garamond", family: "'Garamond', serif" },
  { value: "courier", label: "Courier New", family: "'Courier New', monospace" },
];

const getFontFamily = (fontValue: string) => {
  return SIGNATURE_FONTS.find(f => f.value === fontValue)?.family || "'Inter', sans-serif";
};

const generateSignatureText = (settings: SignatureSettings): string => {
  const lines: string[] = [];
  const name = settings.fullName || settings.name || "";
  
  if (settings.dividerStyle === "line") {
    lines.push("\n—————————————————");
  } else if (settings.dividerStyle === "dots") {
    lines.push("\n• • •");
  } else {
    lines.push("\n");
  }
  
  if (name) lines.push(name);
  if (settings.jobTitle) lines.push(settings.jobTitle);
  if (settings.company) lines.push(settings.company);
  if (settings.email) lines.push(`Email: ${settings.email}`);
  if (settings.phone) lines.push(`Phone: ${settings.phone}`);
  if (settings.website) lines.push(`Web: ${settings.website}`);
  if (settings.linkedin) lines.push(`LinkedIn: ${settings.linkedin}`);
  
  return lines.join("\n");
};

// Note: generateSignaturePreviewHtml removed - now using React SignaturePreviewComponent for exact Settings match

// Generate send HTML (for actual emails, uses CDN images with explicit dimensions for email clients)
const generateSignatureHtml = (settings: SignatureSettings): string => {
  const name = settings.fullName || settings.name || "";
  const fontFamily = getFontFamily(settings.fontFamily);
  const fontSize = settings.fontSize || 14;
  const primaryColor = settings.primaryColor || '#6B21A8';
  const secondaryColor = settings.secondaryColor || '#1F2937';
  const signOff = settings.signOff || "";
  
  // Build contact rows with CDN icons - using width/height attributes for email client compatibility
  const iconSize = 16;
  const contactRows: string[] = [];
  
  if (settings.phone) {
    contactRows.push(`
      <tr>
        <td style="padding: 4px 12px 4px 0; vertical-align: middle; width: ${iconSize}px;">
          <img src="https://cdn-icons-png.flaticon.com/512/724/724664.png" alt="Phone" width="${iconSize}" height="${iconSize}" style="display: block; width: ${iconSize}px; height: ${iconSize}px; opacity: 0.6;" />
        </td>
        <td style="padding: 4px 0; vertical-align: middle; font-size: ${fontSize}px; color: ${secondaryColor}; white-space: nowrap;">
          ${settings.phone}
        </td>
      </tr>
    `);
  }
  
  if (settings.email) {
    contactRows.push(`
      <tr>
        <td style="padding: 4px 12px 4px 0; vertical-align: middle; width: ${iconSize}px;">
          <img src="https://cdn-icons-png.flaticon.com/512/542/542689.png" alt="Email" width="${iconSize}" height="${iconSize}" style="display: block; width: ${iconSize}px; height: ${iconSize}px; opacity: 0.6;" />
        </td>
        <td style="padding: 4px 0; vertical-align: middle; font-size: ${fontSize}px; white-space: nowrap;">
          <a href="mailto:${settings.email}" style="color: ${primaryColor}; text-decoration: none;">${settings.email}</a>
        </td>
      </tr>
    `);
  }
  
  if (settings.website) {
    contactRows.push(`
      <tr>
        <td style="padding: 4px 12px 4px 0; vertical-align: middle; width: ${iconSize}px;">
          <img src="https://cdn-icons-png.flaticon.com/512/1006/1006771.png" alt="Website" width="${iconSize}" height="${iconSize}" style="display: block; width: ${iconSize}px; height: ${iconSize}px; opacity: 0.6;" />
        </td>
        <td style="padding: 4px 0; vertical-align: middle; font-size: ${fontSize}px; white-space: nowrap;">
          <a href="${settings.website}" style="color: ${primaryColor}; text-decoration: none;">${settings.website.replace(/^https?:\/\//, "")}</a>
        </td>
      </tr>
    `);
  }
  
  if (settings.linkedin) {
    contactRows.push(`
      <tr>
        <td style="padding: 4px 12px 4px 0; vertical-align: middle; width: ${iconSize}px;">
          <img src="https://cdn-icons-png.flaticon.com/512/174/174857.png" alt="LinkedIn" width="${iconSize}" height="${iconSize}" style="display: block; width: ${iconSize}px; height: ${iconSize}px;" />
        </td>
        <td style="padding: 4px 0; vertical-align: middle; font-size: ${fontSize}px; white-space: nowrap;">
          <a href="${settings.linkedin}" style="color: ${primaryColor}; text-decoration: none;">LinkedIn Profile</a>
        </td>
      </tr>
    `);
  }

  const logoSize = settings.logoSize || 80;
  const logoHtml = settings.showLogo && settings.logoUrl 
    ? `<td style="vertical-align: top; padding-right: 24px; width: ${logoSize}px;">
        <img src="${settings.logoUrl}" alt="Logo" width="${logoSize}" style="display: block; width: ${logoSize}px; height: auto; max-width: ${logoSize}px;" />
       </td>`
    : "";

  const dividerHtml = settings.dividerStyle !== "none"
    ? `<hr style="border: none; border-top: 1px solid #d1d5db; margin: 16px 0; width: 250px;" />`
    : "";

  // Build sign-off HTML - now rendered inside the table, directly above the name
  const signOffHtml = signOff 
    ? `<p style="margin: 0 0 8px 0; font-family: ${fontFamily}; font-size: ${fontSize}px; line-height: 1.2; mso-line-height-rule: exactly; color: ${secondaryColor};">${signOff},</p>`
    : "";

  return `
<table cellpadding="0" cellspacing="0" style="font-family: ${fontFamily}; font-size: ${fontSize}px; line-height: 1.2; mso-line-height-rule: exactly; color: ${secondaryColor};">
  <tr>
    ${logoHtml}
    <td style="vertical-align: top;">
      ${signOffHtml}
      <p style="margin: 0; font-family: ${fontFamily}; font-weight: 700; font-size: ${fontSize + 4}px; line-height: 1.2; mso-line-height-rule: exactly; color: ${secondaryColor};">${name}</p>
      <p style="margin: 4px 0 0 0; font-family: ${fontFamily}; font-size: ${fontSize}px; line-height: 1.2; mso-line-height-rule: exactly; color: ${secondaryColor};">${settings.jobTitle || ''}</p>
      ${settings.company ? `<p style="margin: 2px 0 0 0; font-family: ${fontFamily}; font-size: ${fontSize}px; line-height: 1.2; mso-line-height-rule: exactly; color: ${secondaryColor};">${settings.company}</p>` : ""}
      ${dividerHtml}
      ${contactRows.length > 0 ? `
      <table cellpadding="0" cellspacing="0" style="font-family: ${fontFamily}; font-size: ${fontSize}px; line-height: 1.2; mso-line-height-rule: exactly;">
        ${contactRows.join("")}
      </table>
      ` : ""}
    </td>
  </tr>
</table>
  `.trim();
};

// Wrap email content in a proper HTML document structure for email clients
const wrapInHtmlDocument = (bodyContent: string): string => {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 16px; font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5; color: #333;">
${bodyContent}
</body>
</html>`;
};


interface SignatureData {
  text: string;
  html: string;         // For sending (CDN images)
  settings: SignatureSettings | null;  // Raw settings for React preview component
}

export function EmailList({ 
  companyId, 
  stakeholderId, 
  maxHeight = "400px",
  recipientEmail,
  recipientName,
  showComposeButton = false,
  composeButtonOnly = false,
}: EmailListProps) {
  const { formatShortDate, formatDateTime } = useLocaleFormat();
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [isReplyMode, setIsReplyMode] = useState(false);
  const [isComposeMode, setIsComposeMode] = useState(false);
  const [replySubject, setReplySubject] = useState("");
  const [replyBody, setReplyBody] = useState("");
  const [composeTo, setComposeTo] = useState("");
  const [signatureData, setSignatureData] = useState<SignatureData>({ text: "", html: "", settings: null });
  const [defaultConnectionId, setDefaultConnectionId] = useState<string | null>(null);
  const { sendEmail, isSending } = useSendEmail();

  // Fetch default email connection
  useEffect(() => {
    const fetchDefaultConnection = async () => {
      const { data } = await supabase
        .from("email_connections")
        .select("id")
        .eq("is_active", true)
        .limit(1)
        .single();
      
      if (data) {
        setDefaultConnectionId(data.id);
      }
    };
    
    fetchDefaultConnection();
  }, []);

  // Fetch email signature settings
  useEffect(() => {
    const fetchSignature = async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "email_signature")
        .single();
      
      if (data?.setting_value) {
        try {
          const rawSettings = JSON.parse(data.setting_value);
          // Merge with defaults to ensure new fields like signOff are present
          const settings: SignatureSettings = {
            signOff: "Best Regards",
            fullName: "",
            jobTitle: "",
            company: "",
            email: "",
            phone: "",
            website: "",
            linkedin: "",
            fontFamily: "inter",
            fontSize: 14,
            primaryColor: "#6B21A8",
            secondaryColor: "#1F2937",
            showLogo: true,
            logoUrl: null,
            logoSize: 80,
            dividerStyle: "line",
            ...rawSettings,
          };
          setSignatureData({
            text: generateSignatureText(settings),
            html: generateSignatureHtml(settings),
            settings: settings,
          });
        } catch (e) {
          console.error("Failed to parse signature settings:", e);
        }
      }
    };
    
    fetchSignature();
  }, []);

  const { data: emails, isLoading } = useQuery({
    queryKey: ["emails", companyId, stakeholderId],
    queryFn: async () => {
      let query = supabase
        .from("emails")
        .select("*")
        .order("sent_at", { ascending: false })
        .limit(50);

      if (companyId) {
        query = query.eq("company_id", companyId);
      }
      if (stakeholderId) {
        query = query.eq("stakeholder_id", stakeholderId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Email[];
    },
    enabled: !!companyId || !!stakeholderId,
  });

  const handleReplyClick = (email: Email) => {
    setSelectedEmail(email);
    setIsReplyMode(true);
    setReplySubject(email.subject?.startsWith("Re:") ? email.subject : `Re: ${email.subject || "(No Subject)"}`);
    
    // Build reply body - never inline text signature to prevent duplication.
    // The HTML signature is always appended on send.
    const originalDate = format(new Date(email.sent_at), "PPpp");
    const quotedContent = `\n\n---\nOn ${originalDate}, ${email.from_name || email.from_address} wrote:\n\n${email.body_text || ""}`;
    
    // Only include the quoted content - signature is appended as HTML on send
    setReplyBody(quotedContent.trimStart());
  };

  const handleSendReply = async () => {
    if (!selectedEmail) return;

    // Validate subject - use a default if empty
    const subjectToSend = replySubject.trim() || "(No Subject)";

    // Always send as HTML with signature appended to prevent duplication
    const textBodyHtml = replyBody
      .split("\n")
      .map(line => `<p style="margin: 0;">${line || "&nbsp;"}</p>`)
      .join("");
    // Wrap in proper HTML document structure for email clients
    const bodyToSend = wrapInHtmlDocument(textBodyHtml + signatureData.html);

    const success = await sendEmail({
      connectionId: selectedEmail.connection_id,
      to: [selectedEmail.from_address],
      subject: subjectToSend,
      body: bodyToSend || " ",
      isHtml: true,
    });

    if (success) {
      setIsReplyMode(false);
      setSelectedEmail(null);
      setReplySubject("");
      setReplyBody("");
    }
  };

  const handleCloseDialog = () => {
    setSelectedEmail(null);
    setIsReplyMode(false);
    setIsComposeMode(false);
    setReplySubject("");
    setReplyBody("");
    setComposeTo("");
  };

  const handleComposeClick = () => {
    setIsComposeMode(true);
    setComposeTo(recipientEmail || "");
    setReplySubject("");
    // Never inline text signature - HTML signature is appended on send
    setReplyBody("");
  };

  const handleSendCompose = async () => {
    if (!composeTo || !defaultConnectionId) return;

    // Validate subject - use a default if empty
    const subjectToSend = replySubject.trim() || "(No Subject)";

    // Always send as HTML with signature appended to prevent duplication
    const textBodyHtml = replyBody
      .split("\n")
      .map(line => `<p style="margin: 0;">${line || "&nbsp;"}</p>`)
      .join("");
    // Wrap in proper HTML document structure for email clients
    const bodyToSend = wrapInHtmlDocument(textBodyHtml + signatureData.html);

    const success = await sendEmail({
      connectionId: defaultConnectionId,
      to: [composeTo],
      subject: subjectToSend,
      body: bodyToSend || " ",
      isHtml: true,
    });

    if (success) {
      handleCloseDialog();
    }
  };

  // If composeButtonOnly mode, just render the button and compose dialog
  if (composeButtonOnly) {
    return (
      <>
        <Button 
          onClick={handleComposeClick}
          disabled={!defaultConnectionId}
          size="sm"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Email
        </Button>
        <ComposeDialog
          isOpen={isComposeMode}
          onClose={handleCloseDialog}
          composeTo={composeTo}
          setComposeTo={setComposeTo}
          replySubject={replySubject}
          setReplySubject={setReplySubject}
          replyBody={replyBody}
          setReplyBody={setReplyBody}
          isSending={isSending}
          onSend={handleSendCompose}
          recipientName={recipientName}
          signatureHtml={signatureData.html}
          signatureSettings={signatureData.settings}
        />
      </>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="p-4 border rounded-lg">
            <Skeleton className="h-4 w-3/4 mb-2" />
            <Skeleton className="h-3 w-1/2 mb-2" />
            <Skeleton className="h-3 w-1/4" />
          </div>
        ))}
      </div>
    );
  }

  if (!emails || emails.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <Mail className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>No emails found</p>
        <p className="text-sm">
          Emails will appear here once synced from your connected email accounts
        </p>
      </div>
    );
  }

  return (
    <>
      <ScrollArea style={{ maxHeight }}>
        <div className="space-y-2">
          {emails.map((email) => (
            <div
              key={email.id}
              className={`p-4 border rounded-lg cursor-pointer transition-all hover:shadow-md hover:border-primary/30 ${
                !email.is_read ? "bg-primary/5 border-primary/20" : "bg-background"
              }`}
              onClick={() => {
                setSelectedEmail(email);
                setIsReplyMode(false);
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-xs">
                      {email.folder}
                    </Badge>
                    {email.has_attachments && (
                      <Paperclip className="w-3 h-3 text-muted-foreground" />
                    )}
                  </div>
                  <h4 className={`text-sm truncate ${!email.is_read ? "font-semibold" : ""}`}>
                    {email.subject || "(No Subject)"}
                  </h4>
                  <p className="text-xs text-muted-foreground truncate">
                    {email.folder === "Sent" ? "To: " : "From: "}
                    {email.from_name || email.from_address}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {formatShortDate(email.sent_at)}
                  </span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </div>
              {email.body_text && (
                <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                  {email.body_text.substring(0, 150)}...
                </p>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Email Detail / Reply Dialog */}
      <Dialog open={!!selectedEmail} onOpenChange={handleCloseDialog}>
        <DialogContent className="max-w-4xl w-[90vw] h-[90vh] max-h-[90vh] overflow-hidden flex flex-col">
          {selectedEmail && !isReplyMode && (
            <>
              <DialogHeader>
                <DialogTitle className="text-lg">
                  {selectedEmail.subject || "(No Subject)"}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 flex-1 overflow-auto">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="font-medium w-16">From:</span>
                    <span>{selectedEmail.from_name ? `${selectedEmail.from_name} <${selectedEmail.from_address}>` : selectedEmail.from_address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium w-16">To:</span>
                    <span>{selectedEmail.to_addresses.join(", ")}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium w-16">Date:</span>
                    <span>{formatDateTime(selectedEmail.sent_at)}</span>
                  </div>
                  {selectedEmail.has_attachments && (
                    <div className="flex items-center gap-2">
                      <Paperclip className="w-4 h-4" />
                      <span className="text-muted-foreground">Has attachments</span>
                    </div>
                  )}
                </div>
                <div className="border-t pt-4">
                {selectedEmail.body_html ? (
                    <div
                      className="prose prose-sm max-w-none"
                      dangerouslySetInnerHTML={{ __html: sanitizeEmailHtml(selectedEmail.body_html) }}
                    />
                  ) : (
                    <pre className="whitespace-pre-wrap text-sm font-sans">
                      {selectedEmail.body_text}
                    </pre>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => handleReplyClick(selectedEmail)}
                >
                  <Reply className="w-4 h-4 mr-2" />
                  Reply
                </Button>
              </DialogFooter>
            </>
          )}

          {selectedEmail && isReplyMode && (
            <div className="flex flex-col h-full -m-6">
              {/* Outlook-style header bar */}
              <div className="flex items-center justify-between px-4 py-3 bg-primary border-b">
                <div className="flex items-center gap-3">
                  <Reply className="w-5 h-5 text-primary-foreground" />
                  <span className="font-semibold text-primary-foreground">Reply</span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={handleSendReply}
                    disabled={isSending}
                    className="gap-2"
                  >
                    {isSending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                    Send
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setIsReplyMode(false)}
                    className="text-primary-foreground hover:bg-primary/80"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Recipient fields */}
              <div className="border-b bg-muted/30">
                <div className="flex items-center border-b px-4 py-2">
                  <span className="text-sm font-medium text-muted-foreground w-16">To</span>
                  <div className="flex-1">
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-muted rounded text-sm">
                      {selectedEmail.from_name || selectedEmail.from_address}
                    </span>
                  </div>
                </div>
                <div className="flex items-center px-4 py-2">
                  <span className="text-sm font-medium text-muted-foreground w-16">Subject</span>
                  <Input
                    value={replySubject}
                    onChange={(e) => setReplySubject(e.target.value)}
                    className="border-0 bg-transparent shadow-none focus-visible:ring-0 px-0 h-auto"
                    placeholder="Add a subject"
                  />
                </div>
              </div>

              {/* Message body */}
              <div className="flex-1 overflow-auto p-4">
                <Textarea
                  value={replyBody}
                  onChange={(e) => setReplyBody(e.target.value)}
                  className="min-h-[300px] border-0 shadow-none focus-visible:ring-0 resize-none text-sm bg-transparent"
                  placeholder="Write your message..."
                />
              </div>

              {/* Bottom toolbar */}
              <div className="flex items-center justify-between px-4 py-2 border-t bg-muted/30">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" className="text-muted-foreground" disabled>
                    <Paperclip className="w-4 h-4" />
                  </Button>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsReplyMode(false)}
                  className="text-destructive hover:text-destructive"
                  disabled={isSending}
                >
                  <Trash2 className="w-4 h-4 mr-1" />
                  Discard
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Compose New Email Dialog */}
      {showComposeButton && (
        <ComposeDialog
          isOpen={isComposeMode && !selectedEmail}
          onClose={handleCloseDialog}
          composeTo={composeTo}
          setComposeTo={setComposeTo}
          replySubject={replySubject}
          setReplySubject={setReplySubject}
          replyBody={replyBody}
          setReplyBody={setReplyBody}
          isSending={isSending}
          onSend={handleSendCompose}
          recipientName={recipientName}
          signatureHtml={signatureData.html}
          signatureSettings={signatureData.settings}
        />
      )}
    </>
  );
}

// Outlook-style Compose Dialog component
interface ComposeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  composeTo: string;
  setComposeTo: (value: string) => void;
  replySubject: string;
  setReplySubject: (value: string) => void;
  replyBody: string;
  setReplyBody: (value: string) => void;
  isSending: boolean;
  onSend: () => void;
  recipientName?: string;
  signatureHtml?: string;
  signatureSettings?: SignatureSettings | null;
}

function ComposeDialog({
  isOpen,
  onClose,
  composeTo,
  setComposeTo,
  replySubject,
  setReplySubject,
  replyBody,
  setReplyBody,
  isSending,
  onSend,
  recipientName,
  signatureSettings,
}: ComposeDialogProps) {
  const hasSignature = signatureSettings && (signatureSettings.fullName || signatureSettings.name);
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      {/* 30% bigger: was max-w-4xl w-[90vw] h-[90vh], now max-w-6xl w-[95vw] h-[95vh] */}
      <DialogContent className="max-w-6xl w-[95vw] h-[95vh] max-h-[95vh] overflow-hidden flex flex-col p-0">
        <div className="flex flex-col h-full">
          {/* Outlook-style header bar */}
          <div className="flex items-center justify-between px-4 py-3 bg-primary border-b">
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-primary-foreground" />
              <span className="font-semibold text-primary-foreground">
                New Message{recipientName ? ` to ${recipientName}` : ""}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="secondary"
                onClick={onSend}
                disabled={isSending || !composeTo}
                className="gap-2"
              >
                {isSending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                Send
              </Button>
              <Button
                size="icon"
                variant="ghost"
                onClick={onClose}
                className="text-primary-foreground hover:bg-primary/80"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Recipient fields */}
          <div className="border-b bg-muted/30">
            <div className="flex items-center border-b px-4 py-2">
              <span className="text-sm font-medium text-muted-foreground w-16">To</span>
              <Input
                value={composeTo}
                onChange={(e) => setComposeTo(e.target.value)}
                className="border-0 bg-transparent shadow-none focus-visible:ring-0 px-0 h-auto"
                placeholder="Enter recipient email..."
              />
            </div>
            <div className="flex items-center px-4 py-2">
              <span className="text-sm font-medium text-muted-foreground w-16">Subject</span>
              <Input
                value={replySubject}
                onChange={(e) => setReplySubject(e.target.value)}
                className="border-0 bg-transparent shadow-none focus-visible:ring-0 px-0 h-auto"
                placeholder="Add a subject"
              />
            </div>
          </div>

          {/* Message body with embedded signature */}
          <div className="flex-1 flex flex-col overflow-auto p-4">
            <Textarea
              value={replyBody}
              onChange={(e) => setReplyBody(e.target.value)}
              className="flex-1 min-h-[200px] border-0 shadow-none focus-visible:ring-0 resize-none text-sm bg-transparent"
              placeholder="Write your message..."
            />
            
            {/* Embedded signature with proper spacing (32px gap between body and signature) */}
            {hasSignature && signatureSettings && (
              <div className="mt-8 pt-4">
                <SignaturePreviewComponent settings={signatureSettings} />
              </div>
            )}
          </div>

          {/* Bottom toolbar */}
          <div className="flex items-center justify-between px-4 py-2 border-t bg-muted/30">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="text-muted-foreground" disabled>
                <Paperclip className="w-4 h-4" />
              </Button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-destructive hover:text-destructive"
              disabled={isSending}
            >
              <Trash2 className="w-4 h-4 mr-1" />
              Discard
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Signature preview component - renders exactly like Settings page
function SignaturePreviewComponent({ settings }: { settings: SignatureSettings }) {
  const name = settings.fullName || settings.name || "";
  const fontFamily = getFontFamily(settings.fontFamily);
  const fontSize = settings.fontSize || 14;
  const primaryColor = settings.primaryColor || '#6B21A8';
  const secondaryColor = settings.secondaryColor || '#1F2937';
  const logoSize = settings.logoSize || 80;
  const signOff = settings.signOff || "";

  return (
    <div style={{ fontFamily, fontSize, color: secondaryColor, lineHeight: 1.2 }}>
      <table cellPadding={0} cellSpacing={0}>
        <tbody>
          <tr>
            {settings.showLogo && settings.logoUrl && (
              <td style={{ verticalAlign: "top", paddingRight: 24 }}>
                <img 
                  src={settings.logoUrl} 
                  alt="Logo" 
                  style={{ width: logoSize, height: "auto", display: "block" }}
                />
              </td>
            )}
            <td style={{ verticalAlign: "top" }}>
              {/* Sign-off greeting - directly above name */}
              {signOff && (
                <p style={{ 
                  margin: "0 0 8px 0", 
                  color: secondaryColor,
                  fontSize: fontSize,
                  lineHeight: 1.2,
                }}>
                  {signOff},
                </p>
              )}
              <p style={{ 
                margin: 0, 
                fontWeight: 700, 
                fontSize: fontSize + 4, 
                color: secondaryColor,
                lineHeight: 1.2,
              }}>
                {name}
              </p>
              {settings.jobTitle && (
                <p style={{ margin: "4px 0 0 0", color: secondaryColor, fontSize, lineHeight: 1.2 }}>
                  {settings.jobTitle}
                </p>
              )}
              {settings.company && (
                <p style={{ margin: "2px 0 0 0", color: secondaryColor, fontSize, lineHeight: 1.2 }}>
                  {settings.company}
                </p>
              )}
              
              {settings.dividerStyle !== "none" && (
                <hr style={{ 
                  border: "none", 
                  borderTop: "1px solid #d1d5db", 
                  margin: "16px 0", 
                  width: 250 
                }} />
              )}
              
              {/* Contact info with Lucide-style SVG icons - exactly like Settings */}
              <table cellPadding={0} cellSpacing={0} style={{ fontFamily }}>
                <tbody>
                  {settings.phone && (
                    <tr>
                      <td style={{ padding: "4px 12px 4px 0", verticalAlign: "middle" }}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                        </svg>
                      </td>
                      <td style={{ padding: "4px 0", verticalAlign: "middle", color: secondaryColor, fontSize }}>
                        {settings.phone}
                      </td>
                    </tr>
                  )}
                  {settings.email && (
                    <tr>
                      <td style={{ padding: "4px 12px 4px 0", verticalAlign: "middle" }}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <rect width="20" height="16" x="2" y="4" rx="2"/>
                          <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                        </svg>
                      </td>
                      <td style={{ padding: "4px 0", verticalAlign: "middle", fontSize }}>
                        <a href={`mailto:${settings.email}`} style={{ color: primaryColor, textDecoration: "none" }}>
                          {settings.email}
                        </a>
                      </td>
                    </tr>
                  )}
                  {settings.website && (
                    <tr>
                      <td style={{ padding: "4px 12px 4px 0", verticalAlign: "middle" }}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10"/>
                          <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
                          <path d="M2 12h20"/>
                        </svg>
                      </td>
                      <td style={{ padding: "4px 0", verticalAlign: "middle", fontSize }}>
                        <a href={settings.website} style={{ color: primaryColor, textDecoration: "none" }}>
                          {settings.website.replace(/^https?:\/\//, "")}
                        </a>
                      </td>
                    </tr>
                  )}
                  {settings.linkedin && (
                    <tr>
                      <td style={{ padding: "4px 12px 4px 0", verticalAlign: "middle" }}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/>
                          <rect width="4" height="12" x="2" y="9"/>
                          <circle cx="4" cy="4" r="2"/>
                        </svg>
                      </td>
                      <td style={{ padding: "4px 0", verticalAlign: "middle", fontSize }}>
                        <a href={settings.linkedin} style={{ color: primaryColor, textDecoration: "none" }}>
                          LinkedIn Profile
                        </a>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
