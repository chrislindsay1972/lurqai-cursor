import { cn } from "@/lib/utils";
import {
  FileText,
  Search,
  Building2,
  Users,
  CheckCircle2,
} from "lucide-react";

const steps = [
  { label: "CV Parsed", icon: FileText, description: "Extract skills & goals" },
  { label: "Jobs Matched", icon: Search, description: "AI-scored opportunities" },
  { label: "Enriched", icon: Building2, description: "Company intelligence" },
  { label: "Shortlist", icon: Users, description: "Select stakeholders" },
];

interface PipelineStepperProps {
  currentStep: number; // 0-indexed
}

export function PipelineStepper({ currentStep }: PipelineStepperProps) {
  return (
    <div className="bg-card rounded-2xl border border-border p-6 shadow-sm">
      <div className="flex items-center justify-between relative">
        {/* Connecting line */}
        <div className="absolute top-5 left-0 right-0 h-0.5 bg-border" />
        <div
          className="absolute top-5 left-0 h-0.5 bg-primary transition-all duration-700 ease-out"
          style={{
            width: `${(Math.min(currentStep, steps.length - 1) / (steps.length - 1)) * 100}%`,
          }}
        />

        {steps.map((step, index) => {
          const isCompleted = index < currentStep;
          const isActive = index === currentStep;
          const isPending = index > currentStep;

          return (
            <div
              key={step.label}
              className="flex flex-col items-center relative z-10 flex-1"
            >
              {/* Circle */}
              <div
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 border-2",
                  isCompleted &&
                    "bg-primary border-primary text-primary-foreground shadow-md",
                  isActive &&
                    "bg-card border-primary text-primary shadow-md ring-4 ring-primary/20",
                  isPending &&
                    "bg-card border-border text-muted-foreground"
                )}
              >
                {isCompleted ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : (
                  <step.icon className="w-4 h-4" />
                )}
              </div>

              {/* Label */}
              <span
                className={cn(
                  "text-xs font-semibold mt-2 text-center",
                  isCompleted && "text-primary",
                  isActive && "text-card-foreground",
                  isPending && "text-muted-foreground"
                )}
              >
                {step.label}
              </span>

              {/* Description */}
              <span className="text-[10px] text-muted-foreground text-center mt-0.5 hidden sm:block">
                {step.description}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
