import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import {
  ChevronDown,
  ChevronUp,
  Building2,
  Users,
  MapPin,
  Star,
  TrendingUp,
  BadgeCheck,
  ShieldAlert,
  ShieldQuestion,
  ExternalLink,
  Linkedin,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

import type { PipelineCompany } from "@/hooks/usePipelineData";

interface CompanyCardProps {
  company: PipelineCompany;
  isExpanded: boolean;
  onToggleExpand: () => void;
  selectedStakeholders: Set<string>;
  onToggleStakeholder: (id: string) => void;
  onSelectAll: () => void;
  animationDelay: number;
}

function getEmailStatusIcon(status: string) {
  switch (status) {
    case "verified":
      return <BadgeCheck className="w-3.5 h-3.5 text-emerald-500" />;
    case "catchall":
      return <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />;
    case "risky":
      return <ShieldAlert className="w-3.5 h-3.5 text-orange-500" />;
    default:
      return <ShieldQuestion className="w-3.5 h-3.5 text-muted-foreground" />;
  }
}

function getEmailStatusLabel(status: string) {
  switch (status) {
    case "verified": return "Verified";
    case "catchall": return "Catch-all";
    case "risky": return "Risky";
    default: return "Unknown";
  }
}

function getConfidenceColor(confidence: number) {
  if (confidence >= 85) return "text-emerald-500";
  if (confidence >= 60) return "text-amber-500";
  return "text-red-400";
}

function formatEmployeeCount(count: number) {
  if (count >= 1000) return `${(count / 1000).toFixed(1).replace(/\.0$/, "")}k`;
  return count.toString();
}

export function CompanyCard({
  company,
  isExpanded,
  onToggleExpand,
  selectedStakeholders,
  onToggleStakeholder,
  onSelectAll,
  animationDelay,
}: CompanyCardProps) {
  const selectedCount = company.stakeholders.filter((s) =>
    selectedStakeholders.has(s.id)
  ).length;
  const allSelected = selectedCount === company.stakeholders.length;

  return (
    <div
      className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden animate-slide-up transition-shadow hover:shadow-md"
      style={{ animationDelay: `${animationDelay}ms` }}
    >
      {/* Company Header */}
      <button
        onClick={onToggleExpand}
        className="w-full p-4 flex items-center gap-4 text-left hover:bg-muted/30 transition-colors"
      >
        {/* Logo / Initial */}
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 border border-border">
          <Building2 className="w-6 h-6 text-primary" />
        </div>

        {/* Company Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="text-sm font-bold text-card-foreground truncate">
              {company.name}
            </h4>
            <Badge
              variant="outline"
              className="text-[10px] px-1.5 py-0 h-5 rounded-md flex-shrink-0"
            >
              {company.matchScore}% match
            </Badge>
          </div>

          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-[11px] text-muted-foreground">
            <span>{company.industry}</span>
            <span className="flex items-center gap-0.5">
              <Users className="w-3 h-3" />
              {formatEmployeeCount(company.employeeCount)}
            </span>
            <span className="flex items-center gap-0.5">
              <MapPin className="w-3 h-3" />
              {company.location}
            </span>
            <span className="flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3" />
              {company.fundingStage}
            </span>
            {company.glassdoorRating > 0 && (
              <span className="flex items-center gap-0.5">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                {company.glassdoorRating}
              </span>
            )}
          </div>

          <p className="text-[11px] text-primary font-medium mt-1 truncate">
            🎯 {company.matchedJobTitle}
          </p>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3 flex-shrink-0">
          {selectedCount > 0 && (
            <Badge className="text-[10px] px-2 py-0.5 rounded-full bg-primary text-primary-foreground">
              {selectedCount}/{company.stakeholders.length}
            </Badge>
          )}
          {isExpanded ? (
            <ChevronUp className="w-4 h-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          )}
        </div>
      </button>

      {/* Stakeholders Panel */}
      {isExpanded && (
        <div className="border-t border-border bg-muted/20">
          {/* Select all bar */}
          <div className="px-4 py-2 flex items-center justify-between border-b border-border/50">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onSelectAll();
              }}
              className="flex items-center gap-2 text-xs text-muted-foreground hover:text-card-foreground transition-colors"
            >
              <Checkbox
                checked={allSelected}
                className="h-3.5 w-3.5"
                onClick={(e) => e.stopPropagation()}
                onCheckedChange={() => onSelectAll()}
              />
              <span>
                {allSelected ? "Deselect all" : "Select all"} ({company.stakeholders.length})
              </span>
            </button>
          </div>

          {/* Stakeholder rows */}
          <div className="divide-y divide-border/30">
            {company.stakeholders.map((stakeholder) => {
              const isSelected = selectedStakeholders.has(stakeholder.id);
              return (
                <div
                  key={stakeholder.id}
                  onClick={() => onToggleStakeholder(stakeholder.id)}
                  className={cn(
                    "px-4 py-1.5 flex items-center gap-3 cursor-pointer transition-colors",
                    isSelected
                      ? "bg-primary/5"
                      : "hover:bg-muted/40"
                  )}
                >
                  <Checkbox
                    checked={isSelected}
                    onCheckedChange={() => onToggleStakeholder(stakeholder.id)}
                    onClick={(e) => e.stopPropagation()}
                    className="h-4 w-4 flex-shrink-0"
                  />

                  {/* Avatar */}
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 text-xs font-bold text-primary">
                    {stakeholder.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-card-foreground truncate">
                        {stakeholder.name}
                      </span>
                      {stakeholder.linkedinUrl && (
                        <a
                          href={stakeholder.linkedinUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-muted-foreground hover:text-link transition-colors"
                        >
                          <Linkedin className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                    <p className="text-[11px] text-muted-foreground truncate">
                      {stakeholder.title}
                    </p>
                  </div>

                  {/* Email + Status */}
                  <div className="hidden sm:flex items-center gap-2 flex-shrink-0">
                    {stakeholder.email ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                            {getEmailStatusIcon(stakeholder.emailStatus)}
                            <span className="max-w-[140px] truncate">{stakeholder.email}</span>
                          </span>
                        </TooltipTrigger>
                        <TooltipContent side="top" className="text-xs">
                          {getEmailStatusLabel(stakeholder.emailStatus)}
                        </TooltipContent>
                      </Tooltip>
                    ) : (
                      <span className="text-[11px] text-muted-foreground italic">
                        No email
                      </span>
                    )}
                  </div>

                  {/* Confidence */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span
                        className={cn(
                          "text-xs font-semibold tabular-nums flex-shrink-0",
                          getConfidenceColor(stakeholder.confidence)
                        )}
                      >
                        {stakeholder.confidence}%
                      </span>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="text-xs">
                      AI confidence score
                    </TooltipContent>
                  </Tooltip>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
