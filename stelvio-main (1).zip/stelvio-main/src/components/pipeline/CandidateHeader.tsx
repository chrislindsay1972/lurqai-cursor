import { Badge } from "@/components/ui/badge";
import { MapPin, Briefcase, Clock } from "lucide-react";

interface CandidateHeaderProps {
  candidate: {
    name: string;
    currentTitle: string;
    skills: string[];
    idealRole: string;
    location: string;
    experienceYears: number;
  };
}

export function CandidateHeader({ candidate }: CandidateHeaderProps) {
  return (
    <div className="bg-card rounded-2xl border border-border p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-start gap-4">
        {/* Avatar */}
        <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <span className="text-xl font-bold text-primary">
            {candidate.name
              .split(" ")
              .map((n) => n[0])
              .join("")
              .slice(0, 2)}
          </span>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <h2 className="text-lg font-bold text-card-foreground font-display truncate">
              {candidate.name}
            </h2>
            <Badge variant="outline" className="text-xs w-fit">
              Pipeline Active
            </Badge>
          </div>

          <p className="text-sm text-muted-foreground mt-0.5">
            {candidate.currentTitle}
          </p>

          {/* Meta row */}
          <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-muted-foreground">
            {candidate.idealRole && candidate.idealRole !== "Not specified" && (
              <span className="flex items-center gap-1">
                <Briefcase className="w-3.5 h-3.5" />
                Targeting: <span className="text-card-foreground font-medium truncate max-w-[200px]">{candidate.idealRole}</span>
              </span>
            )}
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              {candidate.location}
            </span>
            {candidate.experienceYears > 0 && (
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {candidate.experienceYears} years exp.
              </span>
            )}
          </div>

          {/* Skills */}
          {candidate.skills.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-3">
              {candidate.skills.slice(0, 8).map((skill) => (
                <Badge key={skill} variant="secondary" className="text-[10px] px-2 py-0.5 rounded-md">
                  {skill}
                </Badge>
              ))}
              {candidate.skills.length > 8 && (
                <Badge variant="secondary" className="text-[10px] px-2 py-0.5 rounded-md">
                  +{candidate.skills.length - 8}
                </Badge>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
