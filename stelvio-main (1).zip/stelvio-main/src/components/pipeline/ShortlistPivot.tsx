import { useState, useEffect } from "react";
import { Loader2, CheckCircle2, Timer } from "lucide-react";
import { CompanyCard } from "./CompanyCard";
import { Progress } from "@/components/ui/progress";
import type { PipelineCompany } from "@/hooks/usePipelineData";

interface ShortlistPivotProps {
  companies: PipelineCompany[];
  selectedStakeholders: Set<string>;
  onToggleStakeholder: (id: string) => void;
  onSelectAllForCompany: (stakeholderIds: string[]) => void;
  /** Total companies from matches (before enrichment filtering) */
  totalMatchedCompanies?: number;
  /** Number of companies still being enriched */
  pendingEnrichmentCount?: number;
  /** Total number of matched jobs */
  totalMatchedJobs?: number;
  /** End-to-end pipeline duration in seconds (CV upload → last enrichment) */
  pipelineDurationSeconds?: number;
}

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  if (mins < 60) return secs > 0 ? `${mins}m ${secs}s` : `${mins}m`;
  const hrs = Math.floor(mins / 60);
  const remainMins = mins % 60;
  return remainMins > 0 ? `${hrs}h ${remainMins}m` : `${hrs}h`;
}

export function ShortlistPivot({
  companies,
  selectedStakeholders,
  onToggleStakeholder,
  onSelectAllForCompany,
  totalMatchedCompanies = 0,
  pendingEnrichmentCount = 0,
  totalMatchedJobs = 0,
  pipelineDurationSeconds,
}: ShortlistPivotProps) {
  const [expandedCompanies, setExpandedCompanies] = useState<Set<string>>(new Set());

  // Auto-expand all companies when data loads
  useEffect(() => {
    if (companies.length > 0) {
      setExpandedCompanies(new Set(companies.map((c) => c.id)));
    }
  }, [companies.length]);

  const toggleExpand = (companyId: string) => {
    setExpandedCompanies((prev) => {
      const next = new Set(prev);
      if (next.has(companyId)) next.delete(companyId);
      else next.add(companyId);
      return next;
    });
  };

  const totalStakeholders = companies.reduce((acc, c) => acc + c.stakeholders.length, 0);
  const isEnriching = pendingEnrichmentCount > 0;
  const enrichedCount = totalMatchedCompanies - pendingEnrichmentCount;
  const enrichmentProgress = totalMatchedCompanies > 0 
    ? Math.round((enrichedCount / totalMatchedCompanies) * 100) 
    : 100;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-lg font-bold text-foreground font-display">
              Shortlist
            </h3>
            {isEnriching ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                <Loader2 className="w-3 h-3 animate-spin" />
                Enriching…
              </span>
            ) : companies.length > 0 ? (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                <CheckCircle2 className="w-3 h-3" />
                Ready
              </span>
            ) : null}
            {!isEnriching && pipelineDurationSeconds != null && pipelineDurationSeconds > 0 && (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                <Timer className="w-3 h-3" />
                {formatDuration(pipelineDurationSeconds)} end-to-end
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {companies.length} companies · {totalStakeholders} stakeholders discovered
            {totalMatchedJobs > 0 && totalMatchedJobs !== companies.length && (
              <span className="ml-1 text-muted-foreground/70">
                (from {totalMatchedJobs} matched jobs — multiple jobs can map to the same company)
              </span>
            )}
          </p>
          {isEnriching && totalMatchedCompanies > 0 && (
            <div className="mt-2 max-w-xs">
              <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                <span>Enriching companies</span>
                <span>{enrichedCount}/{totalMatchedCompanies}</span>
              </div>
              <Progress value={enrichmentProgress} className="h-1.5" />
            </div>
          )}
        </div>
      </div>

      <div className="space-y-3">
        {companies.map((company, index) => (
          <CompanyCard
            key={company.id}
            company={company}
            isExpanded={expandedCompanies.has(company.id)}
            onToggleExpand={() => toggleExpand(company.id)}
            selectedStakeholders={selectedStakeholders}
            onToggleStakeholder={onToggleStakeholder}
            onSelectAll={() =>
              onSelectAllForCompany(company.stakeholders.map((s) => s.id))
            }
            animationDelay={index * 80}
          />
        ))}
      </div>
    </div>
  );
}
