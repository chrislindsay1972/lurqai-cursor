import { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { SplashScreen } from "@/components/SplashScreen";
import { applySavedTheme } from "@/lib/theme";
import Dashboard from "./pages/Dashboard";
import Candidates from "./pages/Candidates";
import CandidateDetail from "./pages/CandidateDetail";
import Jobs from "./pages/Jobs";
import JobDetail from "./pages/JobDetail";
import Companies from "./pages/Companies";
import CompanyDetail from "./pages/CompanyDetail";
import JobBoards from "./pages/JobBoards";
import Stakeholders from "./pages/Stakeholders";
import StakeholderDetail from "./pages/StakeholderDetail";

import Campaigns from "./pages/Campaigns";
import CampaignDetail from "./pages/CampaignDetail";
import EmailTemplates from "./pages/EmailTemplates";
import Settings from "./pages/Settings";
import RecycleBin from "./pages/RecycleBin";
import Users from "./pages/Users";
import Login from "./pages/Login";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Issues from "./pages/Issues";
import Pipeline from "./pages/Pipeline";
import PipelineAnalytics from "./pages/PipelineAnalytics";
import PipelineDiagnostics from "./pages/PipelineDiagnostics";
import EnrichmentInbox from "./pages/EnrichmentInbox";
import EnrichmentCompany from "./pages/EnrichmentCompany";
import EnrichmentTimeline from "./pages/EnrichmentTimeline";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
    },
  },
});

const App = () => {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    applySavedTheme();
  }, []);

  return (
    <>
      {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AuthProvider>
              <Routes>
                {/* Public routes */}
                <Route path="/login" element={<Login />} />
                <Route path="/forgot-password" element={<ForgotPassword />} />
                <Route path="/reset-password" element={<ResetPassword />} />

                {/* Protected routes - any authenticated user */}
                <Route
                  path="/"
                  element={
                    <ProtectedRoute>
                      <Dashboard />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/candidates"
                  element={
                    <ProtectedRoute>
                      <Candidates />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/candidates/:id"
                  element={
                    <ProtectedRoute>
                      <CandidateDetail />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/jobs"
                  element={
                    <ProtectedRoute>
                      <Jobs />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/jobs/:id"
                  element={
                    <ProtectedRoute>
                      <JobDetail />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/companies"
                  element={
                    <ProtectedRoute>
                      <Companies />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/companies/:id"
                  element={
                    <ProtectedRoute>
                      <CompanyDetail />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/job-boards"
                  element={
                    <ProtectedRoute>
                      <JobBoards />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/stakeholders"
                  element={
                    <ProtectedRoute>
                      <Stakeholders />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/stakeholders/:id"
                  element={
                    <ProtectedRoute>
                      <StakeholderDetail />
                    </ProtectedRoute>
                  }
                />
                {/* /communications redirects to settings */}
                <Route
                  path="/campaigns"
                  element={
                    <ProtectedRoute>
                      <Campaigns />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/campaigns/:id"
                  element={
                    <ProtectedRoute>
                      <CampaignDetail />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/email-templates"
                  element={
                    <ProtectedRoute>
                      <EmailTemplates />
                    </ProtectedRoute>
                  }
                />

        <Route
          path="/pipeline"
          element={
            <ProtectedRoute>
              <Pipeline />
            </ProtectedRoute>
          }
        />
        <Route
          path="/pipeline-analytics"
          element={
            <ProtectedRoute>
              <PipelineAnalytics />
            </ProtectedRoute>
          }
        />
        <Route
          path="/pipeline-diagnostics"
          element={
            <ProtectedRoute>
              <PipelineDiagnostics />
            </ProtectedRoute>
          }
        />
        <Route
          path="/enrichment/inbox"
          element={
            <ProtectedRoute>
              <EnrichmentInbox />
            </ProtectedRoute>
          }
        />
        <Route
          path="/enrichment/company/:companyId"
          element={
            <ProtectedRoute>
              <EnrichmentCompany />
            </ProtectedRoute>
          }
        />
        <Route
          path="/enrichment/stakeholder/:stakeholderId"
          element={
            <ProtectedRoute>
              <EnrichmentTimeline />
            </ProtectedRoute>
          }
        />
                <Route
                  path="/issues"
                  element={
                    <ProtectedRoute>
                      <Issues />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/recycle-bin"
                  element={
                    <ProtectedRoute>
                      <RecycleBin />
                    </ProtectedRoute>
                  }
                />

                {/* Admin-only routes */}
                <Route
                  path="/users"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Users />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/settings"
                  element={
                    <ProtectedRoute>
                      <Settings />
                    </ProtectedRoute>
                  }
                />

                {/* Catch-all */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </AuthProvider>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </>
  );
};

export default App;
