import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  ChevronLeft,
  RefreshCw,
  Copy,
  CheckCircle2,
  XCircle,
  Clock,
  Linkedin,
  Building2,
  Mail,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

interface TraceStep {
  tier: string;
  input?: any;
  output?: any;
  duration_ms?: number;
  error?: string;
  skipped?: boolean;
  [key: string]: any;
}

function AttemptStatusIcon({ status }: { status: string }) {
  switch (status) {
    case "succeeded":
      return <CheckCircle2 className="w-5 h-5 text-success" />;
    case "failed":
      return <XCircle className="w-5 h-5 text-destructive" />;
    case "running":
    case "pending_async":
      return <Clock className="w-5 h-5 text-warning animate-pulse" />;
    default:
      return <Zap className="w-5 h-5 text-muted-foreground" />;
  }
}

function TierTimeline({ steps }: { steps: TraceStep[] }) {
  if (!steps.length) {
    return <p className="text-sm text-muted-foreground italic">No trace steps recorded.</p>;
  }

  return (
    <div className="relative pl-6 space-y-4">
      {/* Vertical line */}
      <div className="absolute left-[11px] top-2 bottom-2 w-px bg-border" />
      {steps.map((step, i) => {
        const success = !step.error && !step.skipped && step.output;
        return (
          <div key={i} className="relative">
            {/* Dot */}
            <div className={`absolute -left-6 top-1 w-[10px] h-[10px] rounded-full border-2 ${
              step.skipped ? "bg-muted border-muted-foreground/30" :
              step.error ? "bg-destructive border-destructive" :
              success ? "bg-success border-success" :
              "bg-muted-foreground/30 border-muted-foreground/30"
            }`} />
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">{step.tier}</span>
                {step.duration_ms !== undefined && (
                  <span className="text-xs text-muted-foreground">{step.duration_ms}ms</span>
                )}
                {step.skipped && <Badge variant="secondary" className="text-[10px]">Skipped</Badge>}
                {step.error && <Badge variant="destructive" className="text-[10px]">Error</Badge>}
                {success && <Badge variant="default" className="text-[10px]">OK</Badge>}
              </div>
              {step.error && (
                <p className="text-xs text-destructive font-mono bg-destructive/10 rounded px-2 py-1">{step.error}</p>
              )}
              {step.input && (
                <details className="text-xs">
                  <summary className="text-muted-foreground cursor-pointer hover:text-foreground">Input</summary>
                  <pre className="bg-muted/50 p-2 rounded mt-1 overflow-x-auto max-h-32 font-mono text-[11px]">
                    {JSON.stringify(step.input, null, 2)}
                  </pre>
                </details>
              )}
              {step.output && (
                <details className="text-xs">
                  <summary className="text-muted-foreground cursor-pointer hover:text-foreground">Output</summary>
                  <pre className="bg-muted/50 p-2 rounded mt-1 overflow-x-auto max-h-32 font-mono text-[11px]">
                    {JSON.stringify(step.output, null, 2)}
                  </pre>
                </details>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function EnrichmentTimeline() {
  const { stakeholderId } = useParams<{ stakeholderId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: stakeholder, isLoading: loadingSH } = useQuery({
    queryKey: ["enrichment-stakeholder", stakeholderId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stakeholders")
        .select("id, name, title, email, email_confidence, email_status, company_id, linkedin_url, bettercontact_status, bettercontact_task_id, enrichment_source")
        .eq("id", stakeholderId!)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!stakeholderId,
  });

  const { data: company } = useQuery({
    queryKey: ["enrichment-stakeholder-company", stakeholder?.company_id],
    queryFn: async () => {
      const { data } = await supabase
        .from("companies")
        .select("id, name, domain, domain_status")
        .eq("id", stakeholder!.company_id!)
        .single();
      return data;
    },
    enabled: !!stakeholder?.company_id,
  });

  const { data: attempts, isLoading: loadingAttempts } = useQuery({
    queryKey: ["enrichment-attempts", stakeholderId],
    queryFn: async () => {
      const { data } = await supabase
        .from("stakeholder_enrichment_attempts")
        .select("*")
        .eq("stakeholder_id", stakeholderId!)
        .order("started_at", { ascending: false })
        .limit(10);
      return data || [];
    },
    enabled: !!stakeholderId,
  });

  const rerunMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke("enrich-contact-bettercontact", {
        body: { stakeholder_id: stakeholderId, mode: "debug" },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success("Re-run triggered");
      queryClient.invalidateQueries({ queryKey: ["enrichment-attempts", stakeholderId] });
    },
    onError: (e) => toast.error(`Failed: ${e.message}`),
  });

  const copyDebugBundle = () => {
    const bundle = {
      stakeholder,
      company,
      attempts,
    };
    navigator.clipboard.writeText(JSON.stringify(bundle, null, 2));
    toast.success("Debug bundle copied to clipboard");
  };

  const parseTrace = (trace: any): TraceStep[] => {
    if (!trace) return [];
    if (Array.isArray(trace)) return trace;
    if (trace.steps && Array.isArray(trace.steps)) return trace.steps;
    // Try to extract steps from object keys
    return Object.entries(trace).map(([key, val]: [string, any]) => ({
      tier: key,
      ...((typeof val === "object" && val !== null) ? val : { output: val }),
    }));
  };

  return (
    <DashboardLayout title="Stakeholder Timeline">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            {loadingSH ? (
              <Skeleton className="h-8 w-48" />
            ) : (
              <>
                <h1 className="text-2xl font-bold text-foreground">{stakeholder?.name}</h1>
                <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                  {stakeholder?.title && <span>{stakeholder.title}</span>}
                  {company && (
                    <button onClick={() => navigate(`/enrichment/company/${company.id}`)} className="flex items-center gap-1 hover:text-primary">
                      <Building2 className="w-3.5 h-3.5" />
                      {company.name}
                    </button>
                  )}
                  {stakeholder?.linkedin_url && (
                    <a href={stakeholder.linkedin_url} target="_blank" rel="noopener noreferrer" className="hover:text-primary">
                      <Linkedin className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={copyDebugBundle}>
              <Copy className="w-3.5 h-3.5 mr-1" /> Copy Debug
            </Button>
            <Button size="sm" onClick={() => rerunMutation.mutate()} disabled={rerunMutation.isPending}>
              <RefreshCw className="w-3.5 h-3.5 mr-1" /> Re-run
            </Button>
          </div>
        </div>

        {/* Current state summary */}
        {stakeholder && (
          <Card>
            <CardContent className="py-4">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">Email</p>
                  <p className="font-mono">{stakeholder.email || <span className="text-muted-foreground italic">None</span>}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Confidence</p>
                  <p className={stakeholder.email_confidence !== null && stakeholder.email_confidence < 0.5 ? "text-destructive font-medium" : "text-success font-medium"}>
                    {stakeholder.email_confidence !== null ? `${(stakeholder.email_confidence * 100).toFixed(0)}%` : "—"}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <p>{stakeholder.email_status || "—"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Source</p>
                  <p>{stakeholder.enrichment_source || "—"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">BetterContact</p>
                  <Badge variant={stakeholder.bettercontact_status === "done" ? "default" : stakeholder.bettercontact_status === "pending" ? "outline" : "secondary"}>
                    {stakeholder.bettercontact_status || "—"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Attempts */}
        <Card>
          <CardHeader>
            <CardTitle>Enrichment Attempts ({attempts?.length || 0})</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingAttempts ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-24" />)}
              </div>
            ) : !attempts?.length ? (
              <p className="text-sm text-muted-foreground italic">No enrichment attempts recorded for this stakeholder.</p>
            ) : (
              <Tabs defaultValue={attempts[0]?.id} className="space-y-4">
                <TabsList className="flex-wrap h-auto gap-1">
                  {attempts.map((a, i) => (
                    <TabsTrigger key={a.id} value={a.id} className="gap-1.5 text-xs">
                      <AttemptStatusIcon status={a.status} />
                      {format(new Date(a.started_at), "MMM d HH:mm")}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {attempts.map((a) => {
                  const steps = parseTrace(a.trace);
                  return (
                    <TabsContent key={a.id} value={a.id} className="space-y-4">
                      {/* Attempt header */}
                      <div className="flex items-center gap-4 text-sm">
                        <AttemptStatusIcon status={a.status} />
                        <div>
                          <span className="font-medium capitalize">{a.status}</span>
                          {a.final_email && (
                            <span className="ml-2 text-muted-foreground">→ {a.final_email}</span>
                          )}
                          {a.final_source && (
                            <Badge variant="outline" className="ml-2 text-[10px]">{a.final_source}</Badge>
                          )}
                        </div>
                        <div className="ml-auto text-xs text-muted-foreground">
                          {format(new Date(a.started_at), "PPpp")}
                          {a.finished_at && (
                            <span className="ml-2">
                              ({Math.round((new Date(a.finished_at).getTime() - new Date(a.started_at).getTime()) / 1000)}s)
                            </span>
                          )}
                        </div>
                      </div>

                      {a.error && (
                        <div className="text-sm text-destructive bg-destructive/10 rounded px-3 py-2 font-mono">
                          {a.error}
                        </div>
                      )}

                      <Separator />

                      {/* Timeline */}
                      <TierTimeline steps={steps} />
                    </TabsContent>
                  );
                })}
              </Tabs>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
