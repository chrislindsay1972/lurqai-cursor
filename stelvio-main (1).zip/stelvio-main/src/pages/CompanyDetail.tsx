import { useState, useEffect } from "react";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { useParams, useNavigate, Link } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ArrowLeft,
  Building2,
  Globe,
  Phone,
  MapPin,
  Users,
  Linkedin,
  Sparkles,
  Loader2,
  Pencil,
  Save,
  X,
  Mail,
  Briefcase,
  Star,
  TrendingUp,
  Newspaper,
  Twitter,
  Facebook,
  Calendar,
  DollarSign,
  Cpu,
  ExternalLink,
  Building,
  Hash,
  Globe2,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { NotesSection } from "@/components/notes/NotesSection";
import { EmailList } from "@/components/emails/EmailList";

interface Company {
  id: string;
  name: string;
  domain: string | null;
  website_url: string | null;
  description: string | null;
  short_description: string | null;
  seo_description: string | null;
  phone: string | null;
  address: string | null;
  employee_count: number | null;
  industry: string | null;
  linkedin_url: string | null;
  enrichment_status: string;
  enrichment_source: string | null;
  enriched_at: string | null;
  created_at: string;
  updated_at: string;
  // Quality signals
  glassdoor_rating: number | null;
  funding_status: string | null;
  recent_news: string[] | null;
  quality_signals: unknown | null;
  quality_enriched_at: string | null;
  // Social & Web Presence
  blog_url: string | null;
  twitter_url: string | null;
  facebook_url: string | null;
  crunchbase_url: string | null;
  angellist_url: string | null;
  logo_url: string | null;
  // Company Details
  founded_year: number | null;
  keywords: string[] | null;
  languages: string[] | null;
  // Location Details
  street_address: string | null;
  city: string | null;
  state: string | null;
  postal_code: string | null;
  country: string | null;
  // Financial & Market Data
  annual_revenue: number | null;
  annual_revenue_printed: string | null;
  total_funding: number | null;
  total_funding_printed: string | null;
  latest_funding_stage: string | null;
  latest_funding_round_date: string | null;
  publicly_traded_symbol: string | null;
  publicly_traded_exchange: string | null;
  // Technology Stack
  technology_names: string[] | null;
  // Organizational
  industries: string[] | null;
  retail_location_count: number | null;
  num_suborganizations: number | null;
  alexa_ranking: number | null;
}

interface Stakeholder {
  id: string;
  name: string;
  title: string | null;
  email: string | null;
  phone: string | null;
  linkedin_url: string | null;
  location: string | null;
  contacted: boolean;
  source: string | null;
}

interface Job {
  id: string;
  title: string;
  status: string;
  location: string | null;
  created_at: string;
}

function isSafeUrl(url: string | null): boolean {
  if (!url) return false;
  try {
    const parsed = new URL(url.startsWith('http') ? url : `https://${url}`);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function formatCurrency(amount: number | null): string {
  if (!amount) return '';
  if (amount >= 1_000_000_000) return `$${(amount / 1_000_000_000).toFixed(1)}B`;
  if (amount >= 1_000_000) return `$${(amount / 1_000_000).toFixed(1)}M`;
  if (amount >= 1_000) return `$${(amount / 1_000).toFixed(0)}K`;
  return `$${amount.toLocaleString()}`;
}

function formatLocation(company: Company): string | null {
  const parts = [company.city, company.state, company.country].filter(Boolean);
  return parts.length > 0 ? parts.join(', ') : company.address;
}

export default function CompanyDetail() {
  const { formatDate } = useLocaleFormat();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [company, setCompany] = useState<Company | null>(null);
  const [stakeholders, setStakeholders] = useState<Stakeholder[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState<Partial<Company>>({});

  useEffect(() => {
    if (id) {
      fetchData();
    }
  }, [id]);

  const fetchData = async () => {
    try {
      const [companyRes, stakeholdersRes, jobsRes] = await Promise.all([
        supabase.from("companies").select("*").eq("id", id).maybeSingle(),
        supabase.from("stakeholders").select("id, name, title, email, phone, linkedin_url, location, contacted, source").eq("company_id", id).order("name"),
        supabase.from("jobs").select("id, title, status, location, created_at").eq("company_id", id).order("created_at", { ascending: false }),
      ]);

      if (companyRes.error) throw companyRes.error;
      if (!companyRes.data) {
        toast({
          title: "Not Found",
          description: "Company not found",
          variant: "destructive",
        });
        navigate("/companies");
        return;
      }

      setCompany(companyRes.data);
      setFormData(companyRes.data);
      setStakeholders(stakeholdersRes.data || []);
      setJobs(jobsRes.data || []);
    } catch (error) {
      console.error("Error fetching company:", error);
      toast({
        title: "Error",
        description: "Failed to load company details",
        variant: "destructive",
      });
      navigate("/companies");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!id) return;
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from("companies")
        .update({
          name: formData.name,
          domain: formData.domain || null,
          website_url: formData.website_url || null,
          description: formData.description || null,
          phone: formData.phone || null,
          address: formData.address || null,
          employee_count: formData.employee_count || null,
          industry: formData.industry || null,
          linkedin_url: formData.linkedin_url || null,
        })
        .eq("id", id);

      if (error) throw error;

      setCompany({ ...company, ...formData } as Company);
      setIsEditing(false);
      toast({
        title: "Company Updated",
        description: "Changes saved successfully",
      });
    } catch (error) {
      console.error("Error updating company:", error);
      toast({
        title: "Error",
        description: "Failed to save changes",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setFormData(company || {});
    setIsEditing(false);
  };

  if (isLoading) {
    return (
      <DashboardLayout title="Company Details" subtitle="Loading...">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  if (!company) {
    return (
      <DashboardLayout title="Company Not Found" subtitle="">
        <div className="text-center py-12">
          <p className="text-muted-foreground">Company not found</p>
          <Button variant="outline" className="mt-4" onClick={() => navigate("/companies")}>
            Back to Companies
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const locationStr = formatLocation(company);
  const hasSocialLinks = company.linkedin_url || company.twitter_url || company.facebook_url || company.crunchbase_url;
  const hasFinancialData = company.annual_revenue || company.total_funding || company.latest_funding_stage || company.publicly_traded_symbol;
  const hasTechStack = company.technology_names && company.technology_names.length > 0;

  return (
    <DashboardLayout
      title={company.name}
      subtitle="Company Details"
    >
      <div className="space-y-6">
        {/* Header Actions */}
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate("/companies")} className="bg-accent text-accent-foreground hover:bg-accent hover:text-accent-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Companies
          </Button>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button variant="outline" onClick={handleCancel} disabled={isSaving}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={isSaving}>
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Save Changes
                </Button>
              </>
            ) : (
              <Button onClick={() => setIsEditing(true)}>
                <Pencil className="w-4 h-4 mr-2" />
                Edit Company
              </Button>
            )}
          </div>
        </div>

        {/* Company Header Card */}
        <Card className="bg-gradient-to-br from-card to-muted/30">
          <CardContent className="pt-6">
            <div className="flex items-start gap-6">
              {/* Logo */}
              <Avatar className="w-20 h-20 rounded-lg border-2 border-border">
                {company.logo_url ? (
                  <AvatarImage src={company.logo_url} alt={company.name} className="object-contain" />
                ) : null}
                <AvatarFallback className="rounded-lg bg-primary/10 text-primary text-2xl font-bold">
                  {company.name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h1 className="text-2xl font-bold text-card-foreground">{company.name}</h1>
                    {company.short_description && (
                      <p className="text-muted-foreground mt-1 line-clamp-2">{company.short_description}</p>
                    )}
                  </div>
                  
                  {/* Status Badges */}
                  <div className="flex flex-wrap gap-2">
                    {company.enrichment_status === "enriched" ? (
                      <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                        <Sparkles className="w-3 h-3 mr-1" />
                        Enriched
                      </Badge>
                    ) : company.enrichment_status === "exceeds_size" ? (
                      <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                        Exceeds Size Limit
                      </Badge>
                    ) : company.enrichment_status === "failed" ? (
                      <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                        Failed
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-muted text-muted-foreground">
                        Pending
                      </Badge>
                    )}
                    {company.publicly_traded_symbol && (
                      <Badge variant="secondary" className="font-mono">
                        {company.publicly_traded_exchange}:{company.publicly_traded_symbol}
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Quick Stats Row */}
                <div className="flex flex-wrap items-center gap-4 mt-4 text-sm">
                  {company.employee_count && (
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Users className="w-4 h-4" />
                      <span className="font-medium text-foreground">{company.employee_count.toLocaleString()}</span>
                      <span>employees</span>
                    </div>
                  )}
                  {company.founded_year && (
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>Founded <span className="font-medium text-foreground">{company.founded_year}</span></span>
                    </div>
                  )}
                  {company.industry && (
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Building className="w-4 h-4" />
                      <span className="font-medium text-foreground">{company.industry}</span>
                    </div>
                  )}
                  {locationStr && (
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{locationStr}</span>
                    </div>
                  )}
                </div>

                {/* Social Links Row */}
                {hasSocialLinks && (
                  <div className="flex items-center gap-3 mt-4">
                    {company.website_url && isSafeUrl(company.website_url) && (
                      <a href={company.website_url} target="_blank" rel="noopener noreferrer" 
                        className="p-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors" title="Website">
                        <Globe className="w-4 h-4 text-muted-foreground" />
                      </a>
                    )}
                    {company.linkedin_url && isSafeUrl(company.linkedin_url) && (
                      <a href={company.linkedin_url} target="_blank" rel="noopener noreferrer"
                        className="p-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors" title="LinkedIn">
                        <Linkedin className="w-4 h-4 text-muted-foreground" />
                      </a>
                    )}
                    {company.twitter_url && isSafeUrl(company.twitter_url) && (
                      <a href={company.twitter_url} target="_blank" rel="noopener noreferrer"
                        className="p-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors" title="Twitter">
                        <Twitter className="w-4 h-4 text-muted-foreground" />
                      </a>
                    )}
                    {company.facebook_url && isSafeUrl(company.facebook_url) && (
                      <a href={company.facebook_url} target="_blank" rel="noopener noreferrer"
                        className="p-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors" title="Facebook">
                        <Facebook className="w-4 h-4 text-muted-foreground" />
                      </a>
                    )}
                    {company.crunchbase_url && isSafeUrl(company.crunchbase_url) && (
                      <a href={company.crunchbase_url} target="_blank" rel="noopener noreferrer"
                        className="p-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors" title="Crunchbase">
                        <ExternalLink className="w-4 h-4 text-muted-foreground" />
                      </a>
                    )}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - 2/3 width */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information - Editable */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="w-5 h-5" />
                  Basic Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Company Name</Label>
                    {isEditing ? (
                      <Input
                        value={formData.name || ""}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      />
                    ) : (
                      <p className="text-card-foreground font-medium">{company.name}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Domain</Label>
                    {isEditing ? (
                      <Input
                        value={formData.domain || ""}
                        onChange={(e) => setFormData({ ...formData, domain: e.target.value })}
                        placeholder="example.com"
                      />
                    ) : company.domain && isSafeUrl(company.domain) ? (
                      <a
                        href={`https://${company.domain}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-link hover:underline flex items-center gap-1"
                      >
                        <Globe className="w-4 h-4" />
                        {company.domain}
                      </a>
                    ) : (
                      <p className="text-muted-foreground">{company.domain || "Not set"}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Industry</Label>
                    {isEditing ? (
                      <Input
                        value={formData.industry || ""}
                        onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                        placeholder="Technology"
                      />
                    ) : (
                      <p className="text-card-foreground">{company.industry || "Not set"}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Employee Count</Label>
                    {isEditing ? (
                      <Input
                        type="number"
                        value={formData.employee_count || ""}
                        onChange={(e) => setFormData({ ...formData, employee_count: parseInt(e.target.value) || null })}
                        placeholder="100"
                      />
                    ) : (
                      <p className="flex items-center gap-2 text-card-foreground">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        {company.employee_count?.toLocaleString() || "Unknown"}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Phone</Label>
                    {isEditing ? (
                      <Input
                        value={formData.phone || ""}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+1 (555) 000-0000"
                      />
                    ) : company.phone ? (
                      <p className="flex items-center gap-2 text-card-foreground">
                        <Phone className="w-4 h-4 text-muted-foreground" />
                        {company.phone}
                      </p>
                    ) : (
                      <p className="text-muted-foreground">Not set</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>LinkedIn</Label>
                    {isEditing ? (
                      <Input
                        value={formData.linkedin_url || ""}
                        onChange={(e) => setFormData({ ...formData, linkedin_url: e.target.value })}
                        placeholder="https://linkedin.com/company/..."
                      />
                    ) : company.linkedin_url && isSafeUrl(company.linkedin_url) ? (
                      <a
                        href={company.linkedin_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-link hover:underline flex items-center gap-1"
                      >
                        <Linkedin className="w-4 h-4" />
                        View Profile
                      </a>
                    ) : (
                      <p className="text-muted-foreground">Not set</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>Description</CardTitle>
              </CardHeader>
              <CardContent>
                {isEditing ? (
                  <Textarea
                    value={formData.description || ""}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Company description..."
                    rows={4}
                  />
                ) : (
                  <p className="text-card-foreground whitespace-pre-wrap">
                    {company.description || company.seo_description || "No description available"}
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Industries & Keywords */}
            {(company.industries?.length || company.keywords?.length) && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Hash className="w-5 h-5" />
                    Industries & Keywords
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {company.industries && company.industries.length > 0 && (
                    <div>
                      <Label className="text-muted-foreground text-xs uppercase tracking-wide">Industries</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {company.industries.map((industry, idx) => (
                          <Badge key={idx} variant="secondary">{industry}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  {company.keywords && company.keywords.length > 0 && (
                    <div>
                      <Label className="text-muted-foreground text-xs uppercase tracking-wide">Keywords</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {company.keywords.slice(0, 20).map((keyword, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">{keyword}</Badge>
                        ))}
                        {company.keywords.length > 20 && (
                          <Badge variant="outline" className="text-xs text-muted-foreground">
                            +{company.keywords.length - 20} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Technology Stack */}
            {hasTechStack && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="w-5 h-5" />
                    Technology Stack
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {company.technology_names!.slice(0, 30).map((tech, idx) => (
                      <Badge key={idx} variant="outline" className="bg-primary/5 border-primary/20 text-primary">
                        {tech}
                      </Badge>
                    ))}
                    {company.technology_names!.length > 30 && (
                      <Badge variant="outline" className="text-muted-foreground">
                        +{company.technology_names!.length - 30} more
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Stakeholders */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Stakeholders ({stakeholders.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {stakeholders.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No stakeholders associated with this company</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Title</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {stakeholders.map((stakeholder) => (
                        <TableRow key={stakeholder.id}>
                          <TableCell>
                            <Link
                              to={`/stakeholders/${stakeholder.id}`}
                              className="flex items-center gap-2 hover:text-link transition-colors"
                            >
                              <Avatar className="w-8 h-8">
                                <AvatarFallback className="bg-accent/10 text-accent text-xs">
                                  {stakeholder.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium hover:underline">{stakeholder.name}</span>
                            </Link>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {stakeholder.title || "-"}
                          </TableCell>
                          <TableCell>
                            {stakeholder.email ? (
                              <a href={`mailto:${stakeholder.email}`} className="text-sm flex items-center gap-1 hover:text-link transition-colors">
                                <Mail className="w-3 h-3" />
                                <span className="truncate max-w-[150px]">{stakeholder.email}</span>
                              </a>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={stakeholder.contacted ? "bg-emerald-500/15 text-emerald-600 border-emerald-500/30" : "bg-amber-500/15 text-amber-600 border-amber-500/30"}>
                              {stakeholder.contacted ? "Contacted" : "Not Contacted"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>

            {/* Jobs */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5" />
                  Jobs ({jobs.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {jobs.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No jobs associated with this company</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Title</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Created</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {jobs.map((job) => (
                        <TableRow key={job.id}>
                          <TableCell>
                            <Link
                              to={`/jobs/${job.id}`}
                              className="font-medium text-foreground hover:text-link hover:underline transition-colors"
                            >
                              {job.title}
                            </Link>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {job.location || "-"}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={job.status === "active" ? "bg-emerald-500/15 text-emerald-600 border-emerald-500/30" : job.status === "closed" ? "bg-red-500/15 text-red-600 border-red-500/30" : ""}>
                              {job.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {formatDate(job.created_at)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>

            {/* Emails */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="w-5 h-5" />
                  Emails
                </CardTitle>
              </CardHeader>
              <CardContent>
                <EmailList companyId={company.id} maxHeight="300px" />
              </CardContent>
            </Card>

            {/* Notes */}
            <NotesSection entityType="company" entityId={company.id} />
          </div>

          {/* Right Column - 1/3 width */}
          <div className="space-y-6">
            {/* Financial & Market Data */}
            {hasFinancialData && (
              <Card className="bg-gradient-to-br from-emerald-500/5 to-emerald-500/10 border-emerald-500/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400">
                    <DollarSign className="w-5 h-5" />
                    Financial Data
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(company.annual_revenue || company.annual_revenue_printed) && (
                    <div>
                      <Label className="text-muted-foreground text-xs uppercase tracking-wide">Annual Revenue</Label>
                      <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-400">
                        {company.annual_revenue_printed || formatCurrency(company.annual_revenue)}
                      </p>
                    </div>
                  )}
                  
                  {(company.total_funding || company.total_funding_printed) && (
                    <div>
                      <Label className="text-muted-foreground text-xs uppercase tracking-wide">Total Funding</Label>
                      <p className="text-xl font-semibold text-card-foreground">
                        {company.total_funding_printed || formatCurrency(company.total_funding)}
                      </p>
                    </div>
                  )}
                  
                  {company.latest_funding_stage && (
                    <div>
                      <Label className="text-muted-foreground text-xs uppercase tracking-wide">Latest Round</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-emerald-500/30">
                          <TrendingUp className="w-3 h-3 mr-1" />
                          {company.latest_funding_stage}
                        </Badge>
                        {company.latest_funding_round_date && (
                          <span className="text-xs text-muted-foreground">
                            {formatDate(company.latest_funding_round_date)}
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {company.publicly_traded_symbol && (
                    <div>
                      <Label className="text-muted-foreground text-xs uppercase tracking-wide">Stock</Label>
                      <Badge variant="secondary" className="font-mono text-sm mt-1">
                        {company.publicly_traded_exchange}:{company.publicly_traded_symbol}
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Quality Signals */}
            {(company.glassdoor_rating || company.funding_status || (company.recent_news && company.recent_news.length > 0)) && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5" />
                    Quality Signals
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {company.glassdoor_rating && (
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-warning/10">
                        <Star className="w-6 h-6 text-warning fill-warning" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{company.glassdoor_rating.toFixed(1)}</p>
                        <p className="text-xs text-muted-foreground">Glassdoor Rating</p>
                      </div>
                    </div>
                  )}
                  
                  {company.funding_status && !hasFinancialData && (
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                        <TrendingUp className="w-3 h-3 mr-1" />
                        {company.funding_status}
                      </Badge>
                    </div>
                  )}
                  
                  {company.recent_news && company.recent_news.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Newspaper className="w-4 h-4" />
                        Recent News
                      </div>
                      <ul className="space-y-2">
                        {company.recent_news.slice(0, 3).map((headline, idx) => (
                          <li key={idx} className="text-sm text-card-foreground line-clamp-2 pl-2 border-l-2 border-muted">
                            {headline}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Location */}
            {(company.street_address || company.city || company.country) && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5" />
                    Location
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1 text-sm">
                    {company.street_address && <p className="text-card-foreground">{company.street_address}</p>}
                    <p className="text-card-foreground">
                      {[company.city, company.state, company.postal_code].filter(Boolean).join(', ')}
                    </p>
                    {company.country && <p className="text-muted-foreground">{company.country}</p>}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Languages */}
            {company.languages && company.languages.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe2 className="w-5 h-5" />
                    Languages
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {company.languages.map((lang, idx) => (
                      <Badge key={idx} variant="outline">{lang}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Record Metadata */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground">Record Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created</span>
                    <span>{formatDate(company.created_at)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Updated</span>
                    <span>{formatDate(company.updated_at)}</span>
                  </div>
                  {company.enriched_at && (
                    <>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Enriched</span>
                        <span>{formatDate(company.enriched_at)}</span>
                      </div>
                    </>
                  )}
                  {company.enrichment_source && (
                    <>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Source</span>
                        <span className="text-xs font-mono">{company.enrichment_source}</span>
                      </div>
                    </>
                  )}
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">ID</span>
                    <span className="font-mono text-xs">{company.id.slice(0, 8)}...</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}