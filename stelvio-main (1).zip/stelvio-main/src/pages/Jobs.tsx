import { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useListPagination } from "@/hooks/useListPagination";
import { ListPagination } from "@/components/ui/list-pagination";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Search,
  Plus,
  MapPin,
  Building2,
  Clock,
  Users,
  ExternalLink,
  Briefcase,
  Loader2,
  Sparkles,
  Trash2,
  LayoutGrid,
  List,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useRecycleBin } from "@/hooks/useRecycleBin";

interface Company {
  id: string;
  name: string;
}

interface Job {
  id: string;
  title: string;
  company_id: string | null;
  companies?: { name: string } | null;
  description: string | null;
  requirements: string | null;
  location: string | null;
  salary_range: string | null;
  job_type: string | null;
  experience_level: string | null;
  skills_required: string[];
  source_url: string | null;
  status: string;
  created_at: string;
  updated_at: string;
  posted_at: string | null;
  match_count?: number;
}

interface Match {
  id: string;
  candidate_id: string;
  match_score: number;
  match_reason: string | null;
  skills_matched: string[];
  skills_missing: string[];
  status: string;
  candidates: {
    id: string;
    name: string;
    email: string | null;
    current_title: string | null;
  };
}

const statusColors: Record<string, string> = {
  active: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
  paused: "bg-amber-500/15 text-amber-600 border-amber-500/30",
  closed: "bg-red-500/15 text-red-600 border-red-500/30",
  filled: "bg-muted text-muted-foreground border-border",
};

export default function Jobs() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("all");
  const [ownershipFilter, setOwnershipFilter] = useState<"my" | "all">("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("list");
  const [jobs, setJobs] = useState<Job[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isMatchOpen, setIsMatchOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [matches, setMatches] = useState<Match[]>([]);
  const [isMatching, setIsMatching] = useState(false);
  const [isLoadingMatches, setIsLoadingMatches] = useState(false);
  const [newJob, setNewJob] = useState({
    title: '',
    company_id: '',
    description: '',
    requirements: '',
    location: '',
    salary_range: '',
    job_type: 'full-time',
    experience_level: 'mid',
    skills_required: '',
    source_url: '',
  });
  const [isAdding, setIsAdding] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const { moveToRecycleBin } = useRecycleBin();

  useEffect(() => {
    fetchJobs();
    fetchCompanies();
  }, []);

  // Real-time subscription for jobs and matches updates
  useEffect(() => {
    // Subscribe to new jobs being added
    const jobsChannel = supabase
      .channel('jobs-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'jobs',
        },
        (payload) => {
          console.log('New job received via realtime:', payload);
          // Fetch the full job with company data
          fetchJobs();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'jobs',
        },
        () => {
          fetchJobs();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'jobs',
        },
        () => {
          fetchJobs();
        }
      )
      .subscribe((status, err) => {
        console.log('Jobs realtime subscription status:', status, err);
      });

    // Subscribe to matches updates (to update match counts)
    const matchesChannel = supabase
      .channel('matches-jobs-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'matches',
        },
        () => {
          console.log('New match received - refreshing jobs list');
          fetchJobs();
        }
      )
      .subscribe((status, err) => {
        console.log('Matches realtime subscription status:', status, err);
      });

    return () => {
      supabase.removeChannel(jobsChannel);
      supabase.removeChannel(matchesChannel);
    };
  }, []);

  const fetchJobs = async () => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          companies(name)
        `)
        .order('updated_at', { ascending: false });

      if (error) throw error;

      // Fetch match counts
      const jobsWithCounts = await Promise.all(
        (data || []).map(async (job) => {
          const { count } = await supabase
            .from('matches')
            .select('*', { count: 'exact', head: true })
            .eq('job_id', job.id);
          return { ...job, match_count: count || 0 };
        })
      );

      setJobs(jobsWithCounts);
    } catch (error) {
      console.error('Error fetching jobs:', error);
      toast({
        title: "Error",
        description: "Failed to load jobs",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCompanies = async () => {
    try {
      const { data } = await supabase
        .from('companies')
        .select('id, name')
        .order('name');
      setCompanies(data || []);
    } catch (error) {
      console.error('Error fetching companies:', error);
    }
  };

  const addJob = async () => {
    if (!newJob.title.trim()) {
      toast({
        title: "Validation Error",
        description: "Job title is required",
        variant: "destructive",
      });
      return;
    }

    setIsAdding(true);
    try {
      const skillsArray = newJob.skills_required
        .split(',')
        .map(s => s.trim())
        .filter(s => s.length > 0);

      const { data, error } = await supabase
        .from('jobs')
        .insert({
          title: newJob.title.trim(),
          company_id: newJob.company_id || null,
          description: newJob.description.trim() || null,
          requirements: newJob.requirements.trim() || null,
          location: newJob.location.trim() || null,
          salary_range: newJob.salary_range.trim() || null,
          job_type: newJob.job_type,
          experience_level: newJob.experience_level,
          skills_required: skillsArray,
          source_url: newJob.source_url.trim() || null,
          status: 'active',
          created_by: user?.id,
        })
        .select(`*, companies(name)`)
        .single();

      if (error) throw error;

      setJobs(prev => [{ ...data, match_count: 0 }, ...prev]);
      setNewJob({
        title: '',
        company_id: '',
        description: '',
        requirements: '',
        location: '',
        salary_range: '',
        job_type: 'full-time',
        experience_level: 'mid',
        skills_required: '',
        source_url: '',
      });
      setIsAddOpen(false);

      toast({
        title: "Job Added",
        description: `${data.title} has been added successfully`,
      });
    } catch (error) {
      console.error('Error adding job:', error);
      toast({
        title: "Error",
        description: "Failed to add job",
        variant: "destructive",
      });
    } finally {
      setIsAdding(false);
    }
  };

  const openMatchDialog = async (job: Job) => {
    setSelectedJob(job);
    setIsMatchOpen(true);
    setIsLoadingMatches(true);

    try {
      const { data, error } = await supabase
        .from('matches')
        .select(`
          *,
          candidates(id, name, email, current_title)
        `)
        .eq('job_id', job.id)
        .order('match_score', { ascending: false });

      if (error) throw error;
      setMatches(data || []);
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setIsLoadingMatches(false);
    }
  };

  const runMatching = async () => {
    if (!selectedJob) return;

    setIsMatching(true);
    try {
      const { data, error } = await supabase.functions.invoke('match-candidates', {
        body: { jobId: selectedJob.id },
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      toast({
        title: "Matching Complete",
        description: `Found ${data.matches?.length || 0} candidate matches`,
      });

      // Refresh matches
      const { data: updatedMatches } = await supabase
        .from('matches')
        .select(`*, candidates(id, name, email, current_title)`)
        .eq('job_id', selectedJob.id)
        .order('match_score', { ascending: false });

      setMatches(updatedMatches || []);

      // Update job match count
      setJobs(prev =>
        prev.map(j =>
          j.id === selectedJob.id
            ? { ...j, match_count: updatedMatches?.length || 0 }
            : j
        )
      );
    } catch (error) {
      console.error('Error running matching:', error);
      toast({
        title: "Matching Failed",
        description: (error as Error).message || "Failed to match candidates",
        variant: "destructive",
      });
    } finally {
      setIsMatching(false);
    }
  };

  const deleteJob = async (job: Job) => {
    // Create a copy of job data for recycle bin
    const jobData = {
      id: job.id,
      title: job.title,
      company_id: job.company_id,
      description: job.description,
      requirements: job.requirements,
      location: job.location,
      salary_range: job.salary_range,
      job_type: job.job_type,
      experience_level: job.experience_level,
      skills_required: job.skills_required,
      source_url: job.source_url,
      status: job.status,
      created_at: job.created_at,
      posted_at: job.posted_at,
    };

    moveToRecycleBin.mutate(
      { entityType: 'jobs', entityId: job.id, entityData: jobData },
      {
        onSuccess: () => {
          setJobs(prev => prev.filter(j => j.id !== job.id));
        },
      }
    );
  };

  const getDaysAgo = (dateStr: string) => {
    const days = Math.floor(
      (Date.now() - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24)
    );
    return days === 0 ? 'Today' : `${days}d ago`;
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-success';
    if (score >= 60) return 'text-accent';
    if (score >= 40) return 'text-warning';
    return 'text-destructive';
  };

  const filteredJobs = jobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (job.companies?.name && job.companies.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (job.skills_required && job.skills_required.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())));
    const matchesFilter = activeFilter === "all" || job.status === activeFilter;
    const matchesOwnership = ownershipFilter === "all" || (job as any).created_by === user?.id;
    return matchesSearch && matchesFilter && matchesOwnership;
  });

  // Sort filtered jobs by updated_at (most recently modified first)
  const sortedFilteredJobs = useMemo(() => {
    return [...filteredJobs].sort((a, b) => {
      const aTime = new Date(a.updated_at || a.created_at).getTime();
      const bTime = new Date(b.updated_at || b.created_at).getTime();
      return bTime - aTime;
    });
  }, [filteredJobs]);

  // Pagination
  const jobsPagination = useListPagination(sortedFilteredJobs, {
    storageKey: 'jobs',
  });

  return (
    <DashboardLayout
      title="Job Vacancies"
      subtitle="Track and manage job opportunities"
    >
      <div className="space-y-6">
        {/* Actions Bar */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black" />
            <Input
              placeholder="Search jobs, companies, or skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-accent text-accent-foreground placeholder:text-black/50 border-accent"
            />
          </div>
          <div className="flex gap-2">
            {/* Ownership Toggle */}
            <div className="flex bg-muted rounded-lg p-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setOwnershipFilter("my")}
                className={cn("px-3", ownershipFilter === "my" && "bg-card shadow-sm")}
              >
                My Vacancies
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setOwnershipFilter("all")}
                className={cn("px-3", ownershipFilter === "all" && "bg-card shadow-sm")}
              >
                All Vacancies
              </Button>
            </div>
            {/* View Toggle */}
            <div className="flex bg-muted rounded-lg p-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setViewMode("list")}
                className={cn("px-2", viewMode === "list" && "bg-card shadow-sm")}
              >
                <List className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setViewMode("grid")}
                className={cn("px-2", viewMode === "grid" && "bg-card shadow-sm")}
              >
                <LayoutGrid className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex bg-muted rounded-lg p-1">
              {["all", "active", "paused", "closed"].map((filter) => (
                <Button
                  key={filter}
                  variant="ghost"
                  size="sm"
                  onClick={() => setActiveFilter(filter)}
                  className={cn(
                    "capitalize px-3",
                    activeFilter === filter && "bg-card shadow-sm"
                  )}
                >
                  {filter}
                </Button>
              ))}
            </div>
            <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="ghost" className="accent-gradient border-0 text-black hover:text-black">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Job
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="font-display">Add New Job</DialogTitle>
                  <DialogDescription>
                    Create a new job vacancy to match with candidates.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Job Title *</Label>
                    <Input
                      placeholder="e.g., Senior React Developer"
                      value={newJob.title}
                      onChange={(e) => setNewJob(prev => ({ ...prev, title: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Company</Label>
                    <Select
                      value={newJob.company_id}
                      onValueChange={(v) => setNewJob(prev => ({ ...prev, company_id: v }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select company" />
                      </SelectTrigger>
                      <SelectContent>
                        {companies.map(c => (
                          <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Job Type</Label>
                      <Select
                        value={newJob.job_type}
                        onValueChange={(v) => setNewJob(prev => ({ ...prev, job_type: v }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="full-time">Full-time</SelectItem>
                          <SelectItem value="part-time">Part-time</SelectItem>
                          <SelectItem value="contract">Contract</SelectItem>
                          <SelectItem value="internship">Internship</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Experience Level</Label>
                      <Select
                        value={newJob.experience_level}
                        onValueChange={(v) => setNewJob(prev => ({ ...prev, experience_level: v }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="entry">Entry Level</SelectItem>
                          <SelectItem value="mid">Mid Level</SelectItem>
                          <SelectItem value="senior">Senior</SelectItem>
                          <SelectItem value="lead">Lead/Principal</SelectItem>
                          <SelectItem value="executive">Executive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Location</Label>
                      <Input
                        placeholder="e.g., San Francisco, CA"
                        value={newJob.location}
                        onChange={(e) => setNewJob(prev => ({ ...prev, location: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Salary Range</Label>
                      <Input
                        placeholder="e.g., $120k - $150k"
                        value={newJob.salary_range}
                        onChange={(e) => setNewJob(prev => ({ ...prev, salary_range: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Required Skills (comma-separated)</Label>
                    <Input
                      placeholder="e.g., React, TypeScript, Node.js"
                      value={newJob.skills_required}
                      onChange={(e) => setNewJob(prev => ({ ...prev, skills_required: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      placeholder="Job description..."
                      value={newJob.description}
                      onChange={(e) => setNewJob(prev => ({ ...prev, description: e.target.value }))}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Requirements</Label>
                    <Textarea
                      placeholder="Job requirements..."
                      value={newJob.requirements}
                      onChange={(e) => setNewJob(prev => ({ ...prev, requirements: e.target.value }))}
                      rows={3}
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>
                      Cancel
                    </Button>
                    <Button
                      type="button"
                      className="accent-gradient border-0"
                      onClick={addJob}
                      disabled={isAdding}
                    >
                      {isAdding ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Adding...
                        </>
                      ) : (
                        'Add Job'
                      )}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Jobs Display */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : filteredJobs.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Briefcase className="w-12 h-12 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">No jobs found</p>
            <p className="text-sm text-muted-foreground/70 mt-1">
              Add jobs to start matching candidates
            </p>
          </div>
        ) : viewMode === "list" ? (
          /* List View */
          <div className="bg-card rounded-xl border border-border/50 shadow-sm overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-accent text-black">
                  <TableHead className="font-semibold">Job Title</TableHead>
                  <TableHead className="font-semibold">Company</TableHead>
                  <TableHead className="font-semibold">Location</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold">Matches</TableHead>
                  <TableHead className="font-semibold">Added</TableHead>
                  <TableHead className="w-[100px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {jobsPagination.paginatedItems.map((job, index) => (
                  <TableRow
                    key={job.id}
                    className="hover:bg-muted/30 transition-colors animate-slide-up"
                    style={{ animationDelay: `${index * 30}ms` }}
                  >
                    <TableCell>
                      <div className="flex flex-col">
                        <Link
                          to={`/jobs/${job.id}`}
                          className="font-medium hover:underline text-black"
                        >
                          {job.title}
                        </Link>
                        {job.source_url && (
                          <a
                            href={job.source_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-muted-foreground hover:underline flex items-center gap-1"
                          >
                            <ExternalLink className="w-3 h-3" />
                            Source
                          </a>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-muted-foreground" />
                        {job.companies?.name && job.company_id ? (
                          <Link
                            to={`/companies/${job.company_id}`}
                            className="text-black hover:underline"
                          >
                            {job.companies.name}
                          </Link>
                        ) : '-'}
                      </div>
                    </TableCell>
                    <TableCell className="text-black">
                      {job.location ? (
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-muted-foreground" />
                          {job.location}
                        </div>
                      ) : '-'}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={cn("capitalize", statusColors[job.status])}
                      >
                        {job.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Link
                        to={`/candidates?jobId=${job.id}`}
                        className="flex items-center gap-1.5 hover:underline transition-colors"
                      >
                        <Users className="w-3.5 h-3.5" style={{ color: 'hsl(270 60% 50%)' }} />
                        <span className="font-semibold" style={{ color: 'hsl(270 60% 50%)' }}>{job.match_count || 0}</span>
                      </Link>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {getDaysAgo(job.posted_at || job.created_at)}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="gap-1"
                          onClick={() => openMatchDialog(job)}
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          Match
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8 text-destructive hover:text-destructive"
                          onClick={() => deleteJob(job)}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {/* Pagination */}
            <ListPagination
              currentPage={jobsPagination.currentPage}
              totalPages={jobsPagination.totalPages}
              pageSize={jobsPagination.pageSize}
              totalItems={jobsPagination.totalItems}
              startIndex={jobsPagination.startIndex}
              endIndex={jobsPagination.endIndex}
              hasNextPage={jobsPagination.hasNextPage}
              hasPreviousPage={jobsPagination.hasPreviousPage}
              onPageChange={jobsPagination.goToPage}
              onPageSizeChange={jobsPagination.setPageSize}
            />
          </div>
        ) : (
          /* Grid View */
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {jobsPagination.paginatedItems.map((job, index) => (
              <Card
                key={job.id}
                className="hover:shadow-md transition-all duration-300 animate-scale-in group relative"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1 flex-1 pr-2">
                      <Link to={`/jobs/${job.id}`}>
                        <CardTitle className="text-lg font-display group-hover:text-link transition-colors hover:underline">
                          {job.title}
                        </CardTitle>
                      </Link>
                      <CardDescription className="flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5" />
                        {job.companies?.name && job.company_id ? (
                          <Link
                            to={`/companies/${job.company_id}`}
                            className="text-foreground hover:underline font-medium"
                          >
                            {job.companies.name}
                          </Link>
                        ) : 'No company'}
                      </CardDescription>
                    </div>
                    <Badge
                      variant="outline"
                      className={cn("capitalize", statusColors[job.status])}
                    >
                      {job.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                    {job.location && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" />
                        {job.location}
                      </span>
                    )}
                    {job.job_type && (
                      <span className="flex items-center gap-1">
                        <Briefcase className="w-3.5 h-3.5" />
                        {job.job_type}
                      </span>
                    )}
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {getDaysAgo(job.posted_at || job.created_at)}
                    </span>
                  </div>

                  {job.salary_range && (
                    <p className="text-sm font-medium text-foreground">
                      {job.salary_range}
                    </p>
                  )}

                  {job.skills_required && job.skills_required.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {job.skills_required.slice(0, 4).map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {job.skills_required.length > 4 && (
                        <Badge variant="secondary" className="text-xs bg-muted">
                          +{job.skills_required.length - 4}
                        </Badge>
                      )}
                    </div>
                  )}

                    <div className="flex items-center justify-between pt-2 border-t border-border">
                      <Link
                        to={`/candidates?jobId=${job.id}`}
                        className="flex items-center gap-2 text-sm hover:underline transition-colors"
                      >
                        <Users className="w-4 h-4 text-accent" />
                        <span className="font-semibold text-accent">
                          {job.match_count || 0}
                        </span>
                        <span className="text-muted-foreground">matched</span>
                      </Link>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="gap-1"
                        onClick={() => openMatchDialog(job)}
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        Match
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 text-destructive hover:text-destructive"
                        onClick={() => deleteJob(job)}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            </div>
          
          {/* Pagination for Grid View */}
          <ListPagination
            currentPage={jobsPagination.currentPage}
            totalPages={jobsPagination.totalPages}
            pageSize={jobsPagination.pageSize}
            totalItems={jobsPagination.totalItems}
            startIndex={jobsPagination.startIndex}
            endIndex={jobsPagination.endIndex}
            hasNextPage={jobsPagination.hasNextPage}
            hasPreviousPage={jobsPagination.hasPreviousPage}
            onPageChange={jobsPagination.goToPage}
            onPageSizeChange={jobsPagination.setPageSize}
          />
          </>
        )}

        {/* Match Dialog */}
        <Dialog open={isMatchOpen} onOpenChange={setIsMatchOpen}>
          <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-display">
                AI Candidate Matching
              </DialogTitle>
              <DialogDescription>
                {selectedJob?.title} {selectedJob?.companies?.name && `at ${selectedJob.companies.name}`}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 mt-4">
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  {matches.length} candidate{matches.length !== 1 ? 's' : ''} matched
                </p>
                <Button
                  onClick={runMatching}
                  disabled={isMatching}
                  className="accent-gradient border-0"
                >
                  {isMatching ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Matching...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Run AI Matching
                    </>
                  )}
                </Button>
              </div>

              {isLoadingMatches ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                </div>
              ) : matches.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
                  <p className="text-muted-foreground">No matches yet</p>
                  <p className="text-sm text-muted-foreground/70 mt-1">
                    Click "Run AI Matching" to find candidates
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {matches.map((match) => (
                    <div
                      key={match.id}
                      className="p-4 rounded-lg border border-border bg-card hover:bg-muted/30 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "text-2xl font-bold",
                              getScoreColor(match.match_score)
                            )}>
                              {match.match_score}%
                            </div>
                            <div>
                              <p className="font-medium">{match.candidates.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {match.candidates.current_title || match.candidates.email || 'No details'}
                              </p>
                            </div>
                          </div>
                          {match.match_reason && (
                            <p className="text-sm text-muted-foreground mt-2">
                              {match.match_reason}
                            </p>
                          )}
                          {match.skills_matched && match.skills_matched.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {match.skills_matched.slice(0, 5).map((skill) => (
                                <Badge
                                  key={skill}
                                  variant="outline"
                                  className="text-xs bg-success/10 text-success border-success/20"
                                >
                                  {skill}
                                </Badge>
                              ))}
                              {match.skills_missing && match.skills_missing.slice(0, 3).map((skill) => (
                                <Badge
                                  key={skill}
                                  variant="outline"
                                  className="text-xs bg-destructive/10 text-destructive border-destructive/20"
                                >
                                  Missing: {skill}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setIsMatchOpen(false);
                            window.location.href = `/candidates?search=${encodeURIComponent(match.candidates.name)}`;
                          }}
                        >
                          <ExternalLink className="w-3.5 h-3.5 mr-1" />
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
