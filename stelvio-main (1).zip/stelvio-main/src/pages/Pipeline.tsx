import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { PipelineStepper } from "@/components/pipeline/PipelineStepper";
import { CandidateHeader } from "@/components/pipeline/CandidateHeader";
import { ShortlistPivot } from "@/components/pipeline/ShortlistPivot";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Rocket, ArrowLeft, Loader2, Users } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { usePipelineData } from "@/hooks/usePipelineData";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Pipeline() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const candidateId = searchParams.get("candidateId") || undefined;

  const { candidate, companies, currentStep, candidateList, isLoading, isLoadingList } =
    usePipelineData(candidateId);

  const [selectedStakeholders, setSelectedStakeholders] = useState<Set<string>>(new Set());

  const toggleStakeholder = (id: string) => {
    setSelectedStakeholders((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAllForCompany = (stakeholderIds: string[]) => {
    setSelectedStakeholders((prev) => {
      const next = new Set(prev);
      const allSelected = stakeholderIds.every((id) => next.has(id));
      if (allSelected) {
        stakeholderIds.forEach((id) => next.delete(id));
      } else {
        stakeholderIds.forEach((id) => next.add(id));
      }
      return next;
    });
  };

  const handleCandidateChange = (id: string) => {
    setSelectedStakeholders(new Set());
    setSearchParams({ candidateId: id });
  };

  return (
    <DashboardLayout title="Pipeline" subtitle="CV to Campaign in one flow">
      <div className="space-y-6 max-w-6xl mx-auto">
        {/* Back button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(-1)}
          className="text-muted-foreground hover:text-foreground -ml-2"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back
        </Button>

        {/* Candidate Selector */}
        <div className="bg-card rounded-2xl border border-border p-4 shadow-sm">
          <label className="text-xs font-medium text-muted-foreground mb-2 block">
            Select Candidate
          </label>
          <Select value={candidateId || ""} onValueChange={handleCandidateChange}>
            <SelectTrigger className="w-full max-w-md">
              <SelectValue placeholder={isLoadingList ? "Loading candidates..." : "Choose a candidate to view pipeline"} />
            </SelectTrigger>
            <SelectContent>
              {candidateList.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.name} — {c.current_title || "No title"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Loading state */}
        {candidateId && isLoading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        )}

        {/* No candidate selected */}
        {!candidateId && (
          <div className="bg-card rounded-2xl border border-border p-12 shadow-sm text-center">
            <Users className="w-12 h-12 mx-auto text-muted-foreground/40 mb-4" />
            <h3 className="text-lg font-semibold text-card-foreground mb-1">Select a Candidate</h3>
            <p className="text-sm text-muted-foreground">
              Choose a parsed candidate above to view their pipeline from CV to campaign.
            </p>
          </div>
        )}

        {/* Pipeline content */}
        {candidate && !isLoading && (
          <>
            {/* Candidate Context Header */}
            <CandidateHeader candidate={candidate} />

            {/* Pipeline Stepper */}
            <PipelineStepper currentStep={currentStep} />

            {/* Shortlist Pivot View */}
            {companies.length > 0 ? (
              <ShortlistPivot
                companies={companies}
                selectedStakeholders={selectedStakeholders}
                onToggleStakeholder={toggleStakeholder}
                onSelectAllForCompany={selectAllForCompany}
              />
            ) : (
              <div className="bg-card rounded-2xl border border-border p-8 shadow-sm text-center">
                <p className="text-sm text-muted-foreground">
                  No matched companies yet. Run a job search from the candidate's detail page to populate the pipeline.
                </p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => navigate(`/candidates/${candidateId}`)}
                >
                  Go to Candidate
                </Button>
              </div>
            )}

            {/* Sticky Launch Bar */}
            {selectedStakeholders.size > 0 && (
              <div className="sticky bottom-4 z-30">
                <div className="bg-card border border-border rounded-2xl p-4 shadow-lg flex items-center justify-between animate-slide-up">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <Rocket className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-card-foreground">
                        {selectedStakeholders.size} stakeholder{selectedStakeholders.size !== 1 ? "s" : ""} selected
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Ready to launch campaign
                      </p>
                    </div>
                  </div>
                  <Button className="rounded-xl px-6 gap-2">
                    <Rocket className="w-4 h-4" />
                    Launch Campaign
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
