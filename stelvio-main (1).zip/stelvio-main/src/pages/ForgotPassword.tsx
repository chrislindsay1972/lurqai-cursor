import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Loader2, Mail, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { LurqLogo } from "@/components/LurqLogo";
import { z } from "zod";

const emailSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState("");
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const result = emailSchema.safeParse({ email });
    if (!result.success) {
      setError(result.error.errors[0]?.message || "Invalid email");
      return;
    }

    setIsLoading(true);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      setIsSubmitted(true);
    } catch (err) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-8 sidebar-gradient">
        <div className="w-full max-w-md space-y-8 animate-slide-up text-center">
          <div className="flex items-center justify-center mb-8">
            <LurqLogo size="md" textClassName="text-sidebar-accent-foreground" />
          </div>

          <div className="bg-sidebar-accent/20 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
            <CheckCircle className="w-8 h-8 text-accent" />
          </div>

          <div>
            <h2 className="font-display text-2xl font-bold text-sidebar-accent-foreground">
              Check your email
            </h2>
            <p className="text-sidebar-foreground/80 mt-2">
              We've sent a password reset link to <strong className="text-sidebar-accent-foreground">{email}</strong>
            </p>
          </div>

          <p className="text-sm text-sidebar-foreground/60">
            Didn't receive the email? Check your spam folder or{" "}
            <button
              type="button"
              onClick={() => setIsSubmitted(false)}
              className="text-accent font-medium hover:underline"
            >
              try again
            </button>
          </p>

          <Link
            to="/login"
            className="inline-flex items-center text-sm text-accent hover:underline"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to sign in
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-8 sidebar-gradient">
      <div className="w-full max-w-md space-y-8 animate-slide-up">
        <div className="flex items-center justify-center mb-8">
          <LurqLogo size="md" textClassName="text-sidebar-accent-foreground" />
        </div>

        <div className="text-center">
          <div className="bg-sidebar-accent/20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <Mail className="w-8 h-8 text-accent" />
          </div>
          <h2 className="font-display text-2xl font-bold text-sidebar-accent-foreground">
            Forgot your password?
          </h2>
          <p className="text-sidebar-foreground/80 mt-2">
            No worries, we'll send you reset instructions.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-sidebar-accent-foreground">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={`bg-sidebar-accent/20 border-sidebar-border text-sidebar-accent-foreground placeholder:text-sidebar-foreground/50 ${error ? "border-destructive" : ""}`}
            />
            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full accent-gradient border-0 h-11"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Sending...
              </>
            ) : (
              "Reset password"
            )}
          </Button>
        </form>

        <div className="text-center">
          <Link
            to="/login"
            className="inline-flex items-center text-sm text-accent hover:underline"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to sign in
          </Link>
        </div>
      </div>
    </div>
  );
}