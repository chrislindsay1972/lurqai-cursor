import { useSearchParams } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  User,
  Bell,
  Link,
  Users,
  Check,
  Palette,
  Settings2,
  Database,
  Sparkles,
  Globe,
  Globe2,
  Mail,
  FileText,
} from "lucide-react";
import { FieldManagement } from "@/components/settings/FieldManagement";
import { TargetMatchesSetting } from "@/components/settings/TargetMatchesSetting";
import { ModuleAccessControl } from "@/components/settings/ModuleAccessControl";
import { AIInstructionsManager } from "@/components/settings/AIInstructionsManager";
import { RefinementHistory } from "@/components/settings/RefinementHistory";
import { ThemeCustomizer } from "@/components/settings/ThemeCustomizer";
import { ApiKeysManager } from "@/components/settings/ApiKeysManager";
import { JobBoardsManager } from "@/components/settings/JobBoardsManager";
import { JobBoardPerformance } from "@/components/settings/JobBoardPerformance";
import { PreSearchQuestionsManager } from "@/components/settings/PreSearchQuestionsManager";
import { MatchThresholdSetting } from "@/components/settings/MatchThresholdSetting";
import { MaxCompanySizeSetting } from "@/components/settings/MaxCompanySizeSetting";
import { MaxJobAgeSetting } from "@/components/settings/MaxJobAgeSetting";
import { ScrapingCapsSetting } from "@/components/settings/ScrapingCapsSetting";
import { ImapConnectionManager } from "@/components/settings/ImapConnectionManager";
import { SignatureManager } from "@/components/settings/SignatureManager";
import { TemplatesManager } from "@/components/settings/TemplatesManager";
import { LocaleSettings } from "@/components/settings/LocaleSettings";
import { useAuth } from "@/contexts/AuthContext";

const integrations = [
  {
    name: "Firecrawl",
    description: "Job board scraping & search",
    status: "connected",
    icon: "🔥",
  },
  {
    name: "Apollo",
    description: "Company & contact enrichment",
    status: "connected",
    icon: "🚀",
  },
  {
    name: "Microsoft 365",
    description: "Email sending via SMTP",
    status: "connected",
    icon: "📧",
  },
  {
    name: "LurqAI",
    description: "CV parsing, matching & engagement emails",
    status: "connected",
    icon: "🤖",
  },
];

// Define which tabs are available to each role
const settingsTabs = [
  { value: "general", label: "General", icon: Settings2, adminOnly: true },
  { value: "appearance", label: "Appearance", icon: Palette, adminOnly: false },
  { value: "locale", label: "Locale", icon: Globe2, adminOnly: true },
  { value: "data", label: "Data & Fields", icon: Database, adminOnly: true },
  { value: "job-boards", label: "Job Boards", icon: Globe, adminOnly: true },
  { value: "email", label: "Email (IMAP)", icon: Mail, adminOnly: true },
  { value: "integrations", label: "Integrations", icon: Link, adminOnly: true },
  { value: "ai", label: "AI Settings", icon: Sparkles, adminOnly: true },
  { value: "templates", label: "Templates", icon: FileText, adminOnly: true },
];

export default function Settings() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { role } = useAuth();
  const isAdmin = role === "admin";
  
  // Filter tabs based on role
  const visibleTabs = settingsTabs.filter((tab) => !tab.adminOnly || isAdmin);
  const defaultTab = isAdmin ? "general" : "appearance";
  const activeTab = searchParams.get("tab") || defaultTab;

  const handleTabChange = (value: string) => {
    setSearchParams({ tab: value }, { replace: true });
  };

  return (
    <DashboardLayout
      title="Settings"
      subtitle={isAdmin ? "Configure your recruitment portal" : "Customize your experience"}
    >
      <div className="max-w-5xl">
        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
          {/* Tab Navigation */}
          <TabsList className="inline-flex h-12 items-center justify-start gap-1 rounded-xl bg-black p-1.5 text-white w-full sm:w-auto overflow-x-auto">
            {visibleTabs.map((tab) => (
              <TabsTrigger
                key={tab.value}
                value={tab.value}
                className="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium text-white/70 transition-all duration-200 data-[state=active]:bg-accent data-[state=active]:text-black data-[state=active]:shadow-md hover:text-white whitespace-nowrap"
              >
                <tab.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {isAdmin && (
            <>
              {/* General Settings Tab */}
              <TabsContent value="general" className="space-y-6 animate-fade-in">
                {/* Profile Settings */}
                <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
                  <CardHeader className="border-b border-black/10">
                    <div className="flex items-center gap-2">
                      <User className="w-5 h-5 text-black" />
                      <CardTitle className="font-display text-black">Profile Settings</CardTitle>
                    </div>
                    <CardDescription className="text-black/60">
                      Manage your account information
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 pt-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-black font-medium">First Name</Label>
                        <Input
                          defaultValue="John"
                          className="bg-white border-black/20 text-black placeholder:text-black/40 focus:border-purple-500 focus:ring-purple-500/20 transition-all duration-200"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-black font-medium">Last Name</Label>
                        <Input
                          defaultValue="Doe"
                          className="bg-white border-black/20 text-black placeholder:text-black/40 focus:border-purple-500 focus:ring-purple-500/20 transition-all duration-200"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-black font-medium">Email</Label>
                      <Input
                        type="email"
                        defaultValue="john.doe@lurqai.com"
                        className="bg-white border-black/20 text-black placeholder:text-black/40 focus:border-purple-500 focus:ring-purple-500/20 transition-all duration-200"
                      />
                    </div>
                    <Button
                      className="bg-purple-600 hover:bg-purple-700 text-white border-0 transition-all duration-200 shadow-md hover:shadow-lg"
                      onClick={() => alert('Profile settings saved! (Demo)')}
                    >
                      Save Changes
                    </Button>
                  </CardContent>
                </Card>

                {/* Module Access Control */}
                <ModuleAccessControl />

                {/* User Management */}
                <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
                  <CardHeader className="border-b border-black/10">
                    <div className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-black" />
                      <CardTitle className="font-display text-black">User Management</CardTitle>
                    </div>
                    <CardDescription className="text-black/60">
                      Manage team members and their permissions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/50 border border-black/10 transition-all duration-200 hover:bg-white/80 hover:shadow-md group">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center text-white text-sm font-semibold shadow-md">
                            JD
                          </div>
                          <div>
                            <p className="font-semibold text-sm text-black">John Doe</p>
                            <p className="text-xs text-black/60">john.doe@lurqai.com</p>
                          </div>
                        </div>
                        <Badge className="bg-purple-100 text-purple-700 border-purple-200 hover:bg-purple-100">
                          Admin
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/50 border border-black/10 transition-all duration-200 hover:bg-white/80 hover:shadow-md group">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-black/80 flex items-center justify-center text-white text-sm font-semibold shadow-md">
                            JS
                          </div>
                          <div>
                            <p className="font-semibold text-sm text-black">Jane Smith</p>
                            <p className="text-xs text-black/60">jane.smith@lurqai.com</p>
                          </div>
                        </div>
                        <Badge className="bg-black/10 text-black border-black/20 hover:bg-black/10">
                          Recruiter
                        </Badge>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2 border-black/20 text-black hover:bg-black/5 transition-all duration-200"
                        onClick={() => alert('User invitation coming soon!')}
                      >
                        <Users className="w-4 h-4 mr-2" />
                        Invite User
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Notifications */}
                <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
                  <CardHeader className="border-b border-black/10">
                    <div className="flex items-center gap-2">
                      <Bell className="w-5 h-5 text-black" />
                      <CardTitle className="font-display text-black">Notifications</CardTitle>
                    </div>
                    <CardDescription className="text-black/60">
                      Configure how you receive updates
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-1 pt-6">
                    <div className="flex items-center justify-between p-4 rounded-xl hover:bg-white/50 transition-all duration-200 group">
                      <div>
                        <p className="font-semibold text-sm text-black">New candidate matches</p>
                        <p className="text-xs text-black/60">Get notified when candidates are matched to jobs</p>
                      </div>
                      <Switch defaultChecked className="data-[state=checked]:bg-purple-600" />
                    </div>
                    <Separator className="bg-black/10" />
                    <div className="flex items-center justify-between p-4 rounded-xl hover:bg-white/50 transition-all duration-200 group">
                      <div>
                        <p className="font-semibold text-sm text-black">Resume parsing completed</p>
                        <p className="text-xs text-black/60">Notification when bulk resume uploads are processed</p>
                      </div>
                      <Switch defaultChecked className="data-[state=checked]:bg-purple-600" />
                    </div>
                    <Separator className="bg-black/10" />
                    <div className="flex items-center justify-between p-4 rounded-xl hover:bg-white/50 transition-all duration-200 group">
                      <div>
                        <p className="font-semibold text-sm text-black">Company enrichment updates</p>
                        <p className="text-xs text-black/60">When company data is fetched from BetterContact</p>
                      </div>
                      <Switch className="data-[state=checked]:bg-purple-600" />
                    </div>
                    <Separator className="bg-black/10" />
                    <div className="flex items-center justify-between p-4 rounded-xl hover:bg-white/50 transition-all duration-200 group">
                      <div>
                        <p className="font-semibold text-sm text-black">Email campaign reports</p>
                        <p className="text-xs text-black/60">Daily summary of email campaign performance</p>
                      </div>
                      <Switch defaultChecked className="data-[state=checked]:bg-purple-600" />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </>
          )}

          {/* Appearance Tab */}
          <TabsContent value="appearance" className="space-y-6 animate-fade-in">
            <ThemeCustomizer />
          </TabsContent>

          {isAdmin && (
            <>
              {/* Locale Tab */}
              <TabsContent value="locale" className="space-y-6 animate-fade-in">
                <LocaleSettings />
              </TabsContent>

              {/* Data & Fields Tab */}
              <TabsContent value="data" className="space-y-6 animate-fade-in">
                <TargetMatchesSetting />
                <MatchThresholdSetting />
                <MaxCompanySizeSetting />
                <MaxJobAgeSetting />
                <ScrapingCapsSetting />
                <FieldManagement />
                <PreSearchQuestionsManager />
              </TabsContent>

              {/* Job Boards Tab */}
              <TabsContent value="job-boards" className="space-y-6 animate-fade-in">
                <JobBoardPerformance />
                <JobBoardsManager />
              </TabsContent>

              {/* Email (IMAP) Tab */}
              <TabsContent value="email" className="space-y-6 animate-fade-in">
                <SignatureManager />
                <ImapConnectionManager />
              </TabsContent>

              {/* Integrations Tab */}
              <TabsContent value="integrations" className="space-y-6 animate-fade-in">
                {/* Integrations */}
                <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
                  <CardHeader className="border-b border-black/10">
                    <div className="flex items-center gap-2">
                      <Link className="w-5 h-5 text-black" />
                      <CardTitle className="font-display text-black">Connected Services</CardTitle>
                    </div>
                    <CardDescription className="text-black/60">
                      Connect to external services for data enrichment and job scraping
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {integrations.map((integration) => (
                        <div
                          key={integration.name}
                          className="flex items-center justify-between p-5 rounded-xl border-2 border-black/10 bg-white/50 transition-all duration-200 hover:border-black/20 hover:shadow-lg hover:bg-white group"
                        >
                          <div className="flex items-center gap-4">
                            <span className="text-3xl group-hover:scale-110 transition-transform duration-200">{integration.icon}</span>
                            <div>
                              <p className="font-semibold text-black">{integration.name}</p>
                              <p className="text-xs text-black/60">{integration.description}</p>
                            </div>
                          </div>
                          {integration.status === "connected" ? (
                            <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100">
                              <Check className="w-3 h-3 mr-1" />
                              Connected
                            </Badge>
                          ) : (
                            <Button
                              size="sm"
                              className="bg-purple-600 hover:bg-purple-700 text-white border-0 transition-all duration-200"
                              onClick={() => alert(`Connect ${integration.name} coming soon!`)}
                            >
                              Connect
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* API Keys Manager */}
                <ApiKeysManager />
              </TabsContent>

              {/* AI Settings Tab */}
              <TabsContent value="ai" className="space-y-6 animate-fade-in">
                <RefinementHistory />
                <AIInstructionsManager />
              </TabsContent>

              {/* Templates Tab */}
              <TabsContent value="templates" className="space-y-6 animate-fade-in">
                <TemplatesManager />
              </TabsContent>
            </>
          )}
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
