import { useState, useEffect } from "react";
import { isValidSalaryDisplay } from "@/lib/salaryValidation";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { useParams, useNavigate, Link } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft,
  Briefcase,
  MapPin,
  Building2,
  Calendar,
  Loader2,
  Pencil,
  Save,
  X,
  ExternalLink,
  Users,
  DollarSign,
  Target,
  Sparkles,
  AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { NotesSection } from "@/components/notes/NotesSection";
import { FormattedDescription } from "@/components/jobs/FormattedDescription";

interface Job {
  id: string;
  title: string;
  company_id: string | null;
  companies?: { id: string; name: string } | null;
  description: string | null;
  requirements: string | null;
  location: string | null;
  salary_range: string | null;
  job_type: string | null;
  experience_level: string | null;
  skills_required: string[] | null;
  source_url: string | null;
  status: string;
  posted_at: string | null;
  created_at: string;
  updated_at: string;
}

interface Company {
  id: string;
  name: string;
}

interface Match {
  id: string;
  candidate_id: string;
  match_score: number;
  match_reason: string | null;
  skills_matched: string[] | null;
  skills_missing: string[] | null;
  status: string;
  candidates: {
    id: string;
    name: string;
    email: string | null;
    current_title: string | null;
  };
}

const statusColors: Record<string, string> = {
  active: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
  paused: "bg-amber-500/15 text-amber-600 border-amber-500/30",
  closed: "bg-red-500/15 text-red-600 border-red-500/30",
  filled: "bg-muted text-muted-foreground border-border",
};

function getScoreColor(score: number): string {
  if (score >= 80) return "bg-success/10 text-success border-success/20";
  if (score >= 60) return "bg-warning/10 text-warning border-warning/20";
  return "bg-muted text-muted-foreground";
}

export default function JobDetail() {
  const { formatDate } = useLocaleFormat();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [job, setJob] = useState<Job | null>(null);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isMatching, setIsMatching] = useState(false);
  const [formData, setFormData] = useState<Partial<Job>>({});
  const [skillsInput, setSkillsInput] = useState("");

  useEffect(() => {
    if (id) {
      fetchData();
    }
  }, [id]);

  const fetchData = async () => {
    try {
      const [jobRes, matchesRes, companiesRes] = await Promise.all([
        supabase
          .from("jobs")
          .select(`*, companies(id, name)`)
          .eq("id", id)
          .maybeSingle(),
        supabase
          .from("matches")
          .select(`
            id,
            candidate_id,
            match_score,
            match_reason,
            skills_matched,
            skills_missing,
            status,
            candidates(id, name, email, current_title)
          `)
          .eq("job_id", id)
          .order("match_score", { ascending: false }),
        supabase.from("companies").select("id, name").order("name"),
      ]);

      if (jobRes.error) throw jobRes.error;
      if (!jobRes.data) {
        toast({
          title: "Not Found",
          description: "Job not found",
          variant: "destructive",
        });
        navigate("/jobs");
        return;
      }

      setJob(jobRes.data);
      setFormData(jobRes.data);
      setSkillsInput(jobRes.data.skills_required?.join(", ") || "");
      setMatches((matchesRes.data as unknown as Match[]) || []);
      setCompanies(companiesRes.data || []);
    } catch (error) {
      console.error("Error fetching job:", error);
      toast({
        title: "Error",
        description: "Failed to load job details",
        variant: "destructive",
      });
      navigate("/jobs");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!id) return;
    setIsSaving(true);
    try {
      const skills = skillsInput
        .split(",")
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      const { error } = await supabase
        .from("jobs")
        .update({
          title: formData.title,
          company_id: formData.company_id || null,
          description: formData.description || null,
          requirements: formData.requirements || null,
          location: formData.location || null,
          salary_range: formData.salary_range || null,
          job_type: formData.job_type || null,
          experience_level: formData.experience_level || null,
          skills_required: skills.length > 0 ? skills : null,
          source_url: formData.source_url || null,
          status: formData.status,
        })
        .eq("id", id);

      if (error) throw error;

      // Refetch to get updated company name
      const { data: updatedJob } = await supabase
        .from("jobs")
        .select(`*, companies(id, name)`)
        .eq("id", id)
        .single();

      if (updatedJob) {
        setJob(updatedJob);
        setFormData(updatedJob);
      }

      setIsEditing(false);
      toast({
        title: "Job Updated",
        description: "Changes saved successfully",
      });
    } catch (error) {
      console.error("Error updating job:", error);
      toast({
        title: "Error",
        description: "Failed to save changes",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setFormData(job || {});
    setSkillsInput(job?.skills_required?.join(", ") || "");
    setIsEditing(false);
  };

  const runMatching = async () => {
    if (!id) return;
    setIsMatching(true);
    try {
      const { data, error } = await supabase.functions.invoke("match-candidates", {
        body: { jobId: id },
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      toast({
        title: "Matching Complete",
        description: `Found ${data.matches?.length || 0} candidate matches`,
      });

      // Refresh matches
      const { data: updatedMatches } = await supabase
        .from("matches")
        .select(`*, candidates(id, name, email, current_title)`)
        .eq("job_id", id)
        .order("match_score", { ascending: false });

      setMatches((updatedMatches as unknown as Match[]) || []);
    } catch (error) {
      console.error("Error running matching:", error);
      toast({
        title: "Matching Failed",
        description: (error as Error).message || "Failed to match candidates",
        variant: "destructive",
      });
    } finally {
      setIsMatching(false);
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout title="Job Details" subtitle="Loading...">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  if (!job) {
    return (
      <DashboardLayout title="Job Not Found" subtitle="">
        <div className="text-center py-12">
          <p className="text-muted-foreground">Job not found</p>
          <Button variant="outline" className="mt-4" onClick={() => navigate("/jobs")}>
            Back to Jobs
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title={job.title} subtitle="Job Details">
      <div className="space-y-6">
        {/* Header Actions */}
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate("/jobs")} className="bg-accent text-accent-foreground hover:bg-accent hover:text-accent-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Jobs
          </Button>
          <div className="flex gap-2">
            {job.source_url && (
              <Button variant="outline" asChild className="bg-accent text-accent-foreground border-accent hover:bg-accent hover:text-accent-foreground">
                <a href={job.source_url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View Source
                </a>
              </Button>
            )}
            {isEditing ? (
              <>
                <Button variant="outline" onClick={handleCancel} disabled={isSaving}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={isSaving}>
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Save Changes
                </Button>
              </>
            ) : (
              <Button onClick={() => setIsEditing(true)}>
                <Pencil className="w-4 h-4 mr-2" />
                Edit Job
              </Button>
            )}
          </div>
        </div>

        {/* Status Badge */}
        <div>
          <Badge variant="outline" className={cn("capitalize", statusColors[job.status])}>
            {job.status}
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Basic Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Job Title</Label>
                {isEditing ? (
                  <Input
                    value={formData.title || ""}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                ) : (
                  <p className="text-foreground font-medium">{job.title}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Company</Label>
                {isEditing ? (
                  <Select
                    value={formData.company_id || ""}
                    onValueChange={(v) => setFormData({ ...formData, company_id: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select company" />
                    </SelectTrigger>
                    <SelectContent>
                      {companies.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <p className="flex items-center gap-2 text-foreground">
                    <Building2 className="w-4 h-4 text-muted-foreground" />
                    {job.companies?.name ? (
                      <Link
                        to={`/companies/${job.companies.id}`}
                        className="text-foreground hover:underline font-medium"
                      >
                        {job.companies.name}
                      </Link>
                    ) : (
                      "Not set"
                    )}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Location</Label>
                {isEditing ? (
                  <Input
                    value={formData.location || ""}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="City, State"
                  />
                ) : (
                  <p className="flex items-center gap-2 text-foreground">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    {job.location || "Not set"}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Salary Range</Label>
                {isEditing ? (
                  <Input
                    value={formData.salary_range || ""}
                    onChange={(e) => setFormData({ ...formData, salary_range: e.target.value })}
                    placeholder="$100k - $150k"
                  />
                ) : (
                  <p className="flex items-center gap-2 text-foreground">
                    <DollarSign className="w-4 h-4 text-muted-foreground" />
                    {isValidSalaryDisplay(job.salary_range) ? job.salary_range : "Not set"}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Job Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Job Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Job Type</Label>
                {isEditing ? (
                  <Select
                    value={formData.job_type || ""}
                    onValueChange={(v) => setFormData({ ...formData, job_type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="full-time">Full-time</SelectItem>
                      <SelectItem value="part-time">Part-time</SelectItem>
                      <SelectItem value="contract">Contract</SelectItem>
                      <SelectItem value="internship">Internship</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <Badge variant="secondary" className="capitalize">
                    {job.job_type || "Not set"}
                  </Badge>
                )}
              </div>

              <div className="space-y-2">
                <Label>Experience Level</Label>
                {isEditing ? (
                  <Select
                    value={formData.experience_level || ""}
                    onValueChange={(v) => setFormData({ ...formData, experience_level: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="entry">Entry Level</SelectItem>
                      <SelectItem value="mid">Mid Level</SelectItem>
                      <SelectItem value="senior">Senior</SelectItem>
                      <SelectItem value="lead">Lead/Principal</SelectItem>
                      <SelectItem value="executive">Executive</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <Badge variant="secondary" className="capitalize">
                    {job.experience_level || "Not set"}
                  </Badge>
                )}
              </div>

              <div className="space-y-2">
                <Label>Status</Label>
                {isEditing ? (
                  <Select
                    value={formData.status || "active"}
                    onValueChange={(v) => setFormData({ ...formData, status: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="paused">Paused</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                      <SelectItem value="filled">Filled</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <Badge variant="outline" className={cn("capitalize", statusColors[job.status])}>
                    {job.status}
                  </Badge>
                )}
              </div>

              <div className="space-y-2">
                <Label>Source URL</Label>
                {isEditing ? (
                  <Input
                    value={formData.source_url || ""}
                    onChange={(e) => setFormData({ ...formData, source_url: e.target.value })}
                    placeholder="https://..."
                  />
                ) : job.source_url ? (
                  <a
                    href={job.source_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-foreground hover:underline text-sm flex items-center gap-1 font-medium"
                  >
                    <ExternalLink className="w-3 h-3" />
                    View original posting
                  </a>
                ) : (
                  <p className="text-muted-foreground text-sm">Not set</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Posted Date</Label>
                {job.posted_at ? (
                  <p className="flex items-center gap-2 text-foreground">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    {formatDate(job.posted_at)}
                  </p>
                ) : (
                  <p className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    {formatDate(job.created_at)}
                    <span className="flex items-center gap-1 text-xs" title="Date added to system (not from job site)">
                      <AlertCircle className="w-3 h-3" />
                      (added)
                    </span>
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Description */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <Textarea
                  value={formData.description || ""}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Job description..."
                  rows={8}
                />
              ) : (
                <FormattedDescription content={job.description || ""} />
              )}
            </CardContent>
          </Card>

          {/* Requirements */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Requirements</CardTitle>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <Textarea
                  value={formData.requirements || ""}
                  onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                  placeholder="Job requirements..."
                  rows={6}
                />
              ) : (
                <p className="text-foreground whitespace-pre-wrap">
                  {job.requirements || "No requirements specified"}
                </p>
              )}
            </CardContent>
          </Card>

          {/* Skills */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Required Skills</CardTitle>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <div className="space-y-2">
                  <Input
                    value={skillsInput}
                    onChange={(e) => setSkillsInput(e.target.value)}
                    placeholder="JavaScript, React, Node.js (comma-separated)"
                  />
                  <p className="text-xs text-muted-foreground">Separate skills with commas</p>
                </div>
              ) : job.skills_required && job.skills_required.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {job.skills_required.map((skill, index) => (
                    <Badge key={index} variant="skill">
                      {skill}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No skills specified</p>
              )}
            </CardContent>
          </Card>

          {/* Candidate Matches */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Candidate Matches ({matches.length})
              </CardTitle>
              <Button
                onClick={runMatching}
                disabled={isMatching}
                size="sm"
                className="accent-gradient border-0"
              >
                {isMatching ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Matching...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Run AI Matching
                  </>
                )}
              </Button>
            </CardHeader>
            <CardContent>
              {matches.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
                  <p className="text-muted-foreground">No candidate matches found</p>
                  <p className="text-sm text-muted-foreground/70 mt-1">
                    Click "Run AI Matching" to find candidates
                  </p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Score</TableHead>
                      <TableHead>Candidate</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Skills Matched</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {matches.map((match) => (
                      <TableRow key={match.id}>
                        <TableCell>
                          <Badge variant="outline" className={getScoreColor(match.match_score)}>
                            {match.match_score}%
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Link
                            to={`/candidates/${match.candidates.id}`}
                            className="text-foreground hover:underline font-medium"
                          >
                            {match.candidates.name}
                          </Link>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {match.candidates.current_title || "-"}
                        </TableCell>
                        <TableCell>
                          {match.skills_matched && match.skills_matched.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {match.skills_matched.slice(0, 3).map((skill) => (
                                <Badge
                                  key={skill}
                                  variant="outline"
                                  className="text-xs bg-success/10 text-success border-success/20"
                                >
                                  {skill}
                                </Badge>
                              ))}
                              {match.skills_matched.length > 3 && (
                                <Badge variant="secondary" className="text-xs">
                                  +{match.skills_matched.length - 3}
                                </Badge>
                              )}
                            </div>
                          ) : (
                            "-"
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="capitalize">
                            {match.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" asChild>
                            <Link to={`/candidates/${match.candidates.id}`}>
                              <ExternalLink className="w-3.5 h-3.5" />
                            </Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Notes Section */}
          <div className="lg:col-span-2">
            <NotesSection entityType="job" entityId={job.id} />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
