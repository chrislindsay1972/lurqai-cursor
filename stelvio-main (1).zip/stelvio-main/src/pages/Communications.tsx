import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Plus,
  Mail,
  Clock,
  CheckCircle2,
  Send,
  FileText,
  Loader2,
  Pencil,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useSendEmail } from "@/hooks/useSendEmail";
import { EmailTemplateEditor } from "@/components/campaigns/EmailTemplateEditor";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body_html: string;
  placeholders: string[] | null;
  include_unsubscribe_link: boolean;
  include_cv_attachment: boolean;
  created_at: string;
  created_by: string | null;
}

interface Campaign {
  id: string;
  name: string;
  status: string;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
}

export default function Communications() {
  const { formatDate, formatShortDate } = useLocaleFormat();
  const [searchQuery, setSearchQuery] = useState("");
  const [isTemplateOpen, setIsTemplateOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);
  const [isSendEmailOpen, setIsSendEmailOpen] = useState(false);
  const [emailTo, setEmailTo] = useState("");
  const [emailSubject, setEmailSubject] = useState("");
  const [emailBody, setEmailBody] = useState("");
  const { sendEmail, isSending } = useSendEmail();

  // Fetch live email templates
  const { data: templates = [], isLoading: templatesLoading } = useQuery({
    queryKey: ["email-templates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_templates")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as EmailTemplate[];
    },
  });

  // Fetch live campaigns with metrics
  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery({
    queryKey: ["campaigns-with-metrics"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("campaigns")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(10);
      if (error) throw error;
      return data as Campaign[];
    },
  });

  // Fetch campaign metrics for stats
  const { data: campaignStats } = useQuery({
    queryKey: ["campaign-stats"],
    queryFn: async () => {
      const { data: metrics, error } = await supabase
        .from("campaign_metrics")
        .select("event_type");
      if (error) throw error;

      const sent = metrics?.filter((m) => m.event_type === "sent").length || 0;
      const opened = metrics?.filter((m) => m.event_type === "opened").length || 0;
      const replied = metrics?.filter((m) => m.event_type === "replied").length || 0;

      return {
        totalSent: sent,
        openRate: sent > 0 ? Math.round((opened / sent) * 100) : 0,
        replyRate: sent > 0 ? Math.round((replied / sent) * 100) : 0,
      };
    },
  });

  // Fetch stakeholder states for campaign metrics
  const { data: campaignStates = [] } = useQuery({
    queryKey: ["stakeholder-campaign-states"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stakeholder_campaign_states")
        .select("campaign_id, status");
      if (error) throw error;
      return data;
    },
  });

  const handleSendEmail = async () => {
    if (!emailTo || !emailSubject || !emailBody) return;

    const success = await sendEmail({
      to: emailTo.split(",").map((e) => e.trim()),
      subject: emailSubject,
      body: emailBody,
      isHtml: true,
    });

    if (success) {
      setIsSendEmailOpen(false);
      setEmailTo("");
      setEmailSubject("");
      setEmailBody("");
    }
  };

  const openTemplateEditor = (template?: EmailTemplate) => {
    setEditingTemplate(template || null);
    setIsTemplateOpen(true);
  };

  // Get campaign recipient counts
  const getCampaignMetrics = (campaignId: string) => {
    const states = campaignStates.filter((s) => s.campaign_id === campaignId);
    return {
      recipients: states.length,
      completed: states.filter((s) => s.status === "completed").length,
      inProgress: states.filter((s) => s.status === "in_progress").length,
    };
  };

  return (
    <DashboardLayout
      title="Communications"
      subtitle="Manage email templates and campaigns"
    >
      <div className="space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-card rounded-lg p-4 border border-border/50">
            <div className="flex items-center gap-2 mb-2">
              <Mail className="w-4 h-4 text-accent" />
              <p className="text-sm text-muted-foreground">Total Sent</p>
            </div>
            <p className="text-2xl font-display font-bold">
              {campaignStats?.totalSent || 0}
            </p>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border/50">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle2 className="w-4 h-4 text-success" />
              <p className="text-sm text-muted-foreground">Open Rate</p>
            </div>
            <p className="text-2xl font-display font-bold text-success">
              {campaignStats?.openRate || 0}%
            </p>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border/50">
            <div className="flex items-center gap-2 mb-2">
              <Send className="w-4 h-4 text-accent" />
              <p className="text-sm text-muted-foreground">Reply Rate</p>
            </div>
            <p className="text-2xl font-display font-bold text-accent">
              {campaignStats?.replyRate || 0}%
            </p>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border/50">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="w-4 h-4 text-primary" />
              <p className="text-sm text-muted-foreground">Templates</p>
            </div>
            <p className="text-2xl font-display font-bold">{templates.length}</p>
          </div>
        </div>

        {/* Send Email Button */}
        <div className="flex justify-end">
          <Dialog open={isSendEmailOpen} onOpenChange={setIsSendEmailOpen}>
            <DialogTrigger asChild>
              <Button>
                <Send className="w-4 h-4 mr-2" />
                Send Email
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-2xl">
              <DialogHeader>
                <DialogTitle className="font-display">
                  Send Email
                </DialogTitle>
                <DialogDescription>
                  Compose and send an email.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>To (comma-separated for multiple)</Label>
                  <Input
                    placeholder="email@example.com"
                    value={emailTo}
                    onChange={(e) => setEmailTo(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Subject</Label>
                  <Input
                    placeholder="Email subject"
                    value={emailSubject}
                    onChange={(e) => setEmailSubject(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email Body (HTML supported)</Label>
                  <Textarea
                    placeholder="Write your email content here..."
                    className="min-h-[200px]"
                    value={emailBody}
                    onChange={(e) => setEmailBody(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button
                  variant="outline"
                  onClick={() => setIsSendEmailOpen(false)}
                  disabled={isSending}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleSendEmail}
                  disabled={isSending || !emailTo || !emailSubject || !emailBody}
                >
                  {isSending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Send Email
                    </>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Templates Section */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-lg">Email Templates</h2>
            <Button size="sm" onClick={() => openTemplateEditor()}>
              <Plus className="w-4 h-4 mr-2" />
              New Template
            </Button>
          </div>

          {templatesLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : templates.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-8">
                <FileText className="w-12 h-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground text-center mb-4">
                  No email templates yet. Create your first template to get started.
                </p>
                <Button onClick={() => openTemplateEditor()}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Template
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {templates.map((template, index) => (
                <Card
                  key={template.id}
                  className="hover:shadow-md transition-all duration-300 animate-scale-in cursor-pointer group"
                  style={{ animationDelay: `${index * 50}ms` }}
                  onClick={() => openTemplateEditor(template)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-base font-display">
                        {template.name}
                      </CardTitle>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                        onClick={(e) => {
                          e.stopPropagation();
                          openTemplateEditor(template);
                        }}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                    </div>
                    <CardDescription className="text-xs truncate">
                      {template.subject}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {template.body_html.replace(/<[^>]*>/g, "").slice(0, 100)}
                      {template.body_html.length > 100 ? "..." : ""}
                    </p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {template.placeholders?.length || 0} placeholders
                      </span>
                      <Badge variant="secondary">
                        {formatShortDate(template.created_at)}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Recent Campaigns */}
        <div>
          <h2 className="font-display font-semibold text-lg mb-4">Recent Campaigns</h2>
          {campaignsLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : campaigns.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-8">
                <Mail className="w-12 h-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground text-center">
                  No campaigns yet. Create your first campaign to start sending emails.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="bg-card rounded-xl border border-border/50 shadow-sm overflow-hidden">
              <div className="divide-y divide-border">
                {campaigns.map((campaign, index) => {
                  const metrics = getCampaignMetrics(campaign.id);
                  return (
                    <div
                      key={campaign.id}
                      className="p-4 hover:bg-muted/30 transition-colors animate-slide-up"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                            <Mail className="w-5 h-5 text-accent" />
                          </div>
                          <div>
                            <p className="font-medium">{campaign.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {formatDate(campaign.created_at)}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="text-sm font-medium">{metrics.recipients}</p>
                            <p className="text-xs text-muted-foreground">Recipients</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-success">
                              {metrics.completed}
                            </p>
                            <p className="text-xs text-muted-foreground">Completed</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-accent">
                              {metrics.inProgress}
                            </p>
                            <p className="text-xs text-muted-foreground">In Progress</p>
                          </div>
                          <Badge
                            variant="outline"
                            className={cn(
                              campaign.status === "completed"
                                ? "bg-success/10 text-success border-success/20"
                                : campaign.status === "active"
                                  ? "bg-accent/10 text-accent border-accent/20"
                                  : "bg-muted text-muted-foreground"
                            )}
                          >
                            {campaign.status === "completed" ? (
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                            ) : campaign.status === "active" ? (
                              <Clock className="w-3 h-3 mr-1" />
                            ) : null}
                            {campaign.status.charAt(0).toUpperCase() +
                              campaign.status.slice(1)}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Template Editor Dialog */}
      <EmailTemplateEditor
        template={editingTemplate}
        open={isTemplateOpen}
        onOpenChange={setIsTemplateOpen}
        onSaved={() => setEditingTemplate(null)}
      />
    </DashboardLayout>
  );
}