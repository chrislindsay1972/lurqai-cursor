import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import {
  Globe,
  Lock,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  XCircle,
  Shield,
  Linkedin,
  ChevronLeft,
  Trash2,
  Mail,
  Clock,
  AlertTriangle,
} from "lucide-react";
import { toast } from "sonner";

function DomainStatusBadge({ status, score }: { status: string | null; score: number | null }) {
  if (!status) return <Badge variant="secondary">Unknown</Badge>;
  // Tightened rule: only show "Resolved" if score >= 0.70
  const isActuallyResolved = status === "resolved" && (score === null || score >= 0.70);
  const map: Record<string, { variant: "default" | "destructive" | "outline" | "secondary"; label: string }> = {
    resolved: { variant: isActuallyResolved ? "default" : "outline", label: isActuallyResolved ? "✅ Resolved" : "⚠️ Resolved (low score)" },
    low_confidence: { variant: "outline", label: "⚠️ Low Confidence" },
    unresolved: { variant: "destructive", label: "❌ Unresolved" },
  };
  const m = map[status] || { variant: "secondary", label: status };
  return <Badge variant={m.variant}>{m.label}</Badge>;
}

export default function EnrichmentCompany() {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [overrideDomain, setOverrideDomain] = useState("");

  const { data: company, isLoading: loadingCompany } = useQuery({
    queryKey: ["enrichment-company", companyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("companies")
        .select("*")
        .eq("id", companyId!)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });

  const { data: emailIntel } = useQuery({
    queryKey: ["company-email-intel", companyId],
    queryFn: async () => {
      const { data } = await supabase
        .from("company_email_intel")
        .select("*")
        .eq("company_id", companyId!)
        .maybeSingle();
      return data;
    },
    enabled: !!companyId,
  });

  const { data: stakeholders } = useQuery({
    queryKey: ["company-stakeholders-enrichment", companyId],
    queryFn: async () => {
      const { data } = await supabase
        .from("stakeholders")
        .select("id, name, title, email, email_confidence, email_status, enrichment_source, bettercontact_status, linkedin_url")
        .eq("company_id", companyId!)
        .order("name");
      
      if (!data?.length) return [];

      // Get latest attempt for each
      const { data: attempts } = await supabase
        .from("stakeholder_enrichment_attempts")
        .select("stakeholder_id, status, started_at, final_email, final_source")
        .in("stakeholder_id", data.map(s => s.id))
        .order("started_at", { ascending: false });

      const attemptMap = new Map<string, any>();
      attempts?.forEach(a => {
        if (!attemptMap.has(a.stakeholder_id)) attemptMap.set(a.stakeholder_id, a);
      });

      return data.map(s => ({ ...s, latest_attempt: attemptMap.get(s.id) || null }));
    },
    enabled: !!companyId,
  });

  const rerunDomainMutation = useMutation({
    mutationFn: async (quick: boolean) => {
      const { data, error } = await supabase.functions.invoke("lookup-company-domain", {
        body: { companyName: company!.name, companyId: company!.id, quickMode: quick, force: true },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      toast.success(`Domain lookup complete: ${data?.data?.domain || "unresolved"}`);
      queryClient.invalidateQueries({ queryKey: ["enrichment-company", companyId] });
    },
    onError: (e) => toast.error(`Lookup failed: ${e.message}`),
  });

  const setDomainMutation = useMutation({
    mutationFn: async ({ domain, lock }: { domain: string; lock: boolean }) => {
      // Update company
      const { error: updateError } = await supabase
        .from("companies")
        .update({
          domain,
          website_url: `https://${domain}`,
          domain_status: "resolved",
          domain_quality_score: 1.0,
          domain_quality_reasons: { source: "manual_override", locked: lock },
        })
        .eq("id", companyId!);
      if (updateError) throw updateError;

      // Insert alias if locking
      if (lock && company) {
        const normName = company.name.toLowerCase().replace(/\b(inc|ltd|llc|gmbh|plc|limited|corp|co)\b\.?/gi, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
        await supabase.from("company_domain_aliases").upsert({
          company_name_alias: normName,
          domain,
          confidence: 1.0,
          locked: true,
        }, { onConflict: "company_name_alias" });
      }
    },
    onSuccess: (_, { lock }) => {
      toast.success(lock ? "Domain set & locked" : "Domain updated");
      setOverrideDomain("");
      queryClient.invalidateQueries({ queryKey: ["enrichment-company", companyId] });
    },
    onError: (e) => toast.error(`Failed: ${e.message}`),
  });

  const invalidateIntelMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("company_email_intel")
        .update({ pattern: null, pattern_confidence: 0, examples: [], updated_at: new Date().toISOString() })
        .eq("company_id", companyId!);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Email intel cache invalidated");
      queryClient.invalidateQueries({ queryKey: ["company-email-intel", companyId] });
    },
  });

  const candidates = company?.domain_candidates as any[] || [];
  const reasons = company?.domain_quality_reasons as Record<string, any> || {};

  return (
    <DashboardLayout title="Company Inspector">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              {loadingCompany ? <Skeleton className="h-8 w-48" /> : company?.name || "Company"}
            </h1>
            <p className="text-sm text-muted-foreground">Company Enrichment Inspector</p>
          </div>
        </div>

        {loadingCompany ? (
          <div className="space-y-4">
            <Skeleton className="h-48" />
            <Skeleton className="h-36" />
          </div>
        ) : company ? (
          <>
            {/* Domain-dependent enrichment warning */}
            {company.domain_status === "unresolved" && (
              <div className="flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3">
                <AlertTriangle className="w-5 h-5 text-destructive mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-destructive">Domain unresolved — downstream enrichment blocked</p>
                  <p className="text-xs text-destructive/80 mt-0.5">
                    Hunter, Deep Discovery, and domain-anchored tiers are skipped. Only LinkedIn-based Apollo and BetterContact (with company name) will run.
                    Resolve or lock a domain below to unblock full enrichment.
                  </p>
                </div>
              </div>
            )}
            {company.domain_status === "low_confidence" && (
              <div className="flex items-start gap-3 rounded-xl border border-border bg-muted/50 px-4 py-3">
                <Shield className="w-5 h-5 text-muted-foreground mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-foreground">Domain has low confidence — results may be inaccurate</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Review the domain candidates below and lock the correct one to ensure accurate enrichment.
                  </p>
                </div>
              </div>
            )}

            {/* A) Domain Card */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="w-5 h-5" />
                    Domain
                  </CardTitle>
                  <DomainStatusBadge status={company.domain_status} score={company.domain_quality_score} />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Current domain */}
                <div className="flex items-center gap-3">
                  <span className="text-lg font-mono font-medium">
                    {company.domain || <span className="text-muted-foreground italic">No domain</span>}
                  </span>
                  {company.domain && (
                    <a href={`https://${company.domain}`} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary">
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>

                {/* Quality score */}
                {company.domain_quality_score !== null && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Quality Score</span>
                      <span className="font-medium">{(company.domain_quality_score * 100).toFixed(0)}%</span>
                    </div>
                    <Progress value={company.domain_quality_score * 100} className="h-2" />
                  </div>
                )}

                {/* Reasons */}
                {Object.keys(reasons).length > 0 && (
                  <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded font-mono">
                    {JSON.stringify(reasons, null, 2)}
                  </div>
                )}

                {/* Candidates */}
                {candidates.length > 0 && (
                  <div>
                    <p className="text-sm font-medium mb-2">Candidates ({candidates.length})</p>
                    <div className="space-y-1.5">
                      {candidates.map((c: any, i: number) => (
                        <div key={i} className="flex items-center gap-3 text-sm bg-muted/30 rounded px-3 py-2">
                          <span className="font-mono flex-1">{c.domain}</span>
                          <span className="text-muted-foreground">{((c.score || 0) * 100).toFixed(0)}%</span>
                          <Badge variant="outline" className="text-[10px]">{c.source}</Badge>
                          {c.title && <span className="text-xs text-muted-foreground truncate max-w-[200px]">{c.title}</span>}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-xs"
                            onClick={() => setDomainMutation.mutate({ domain: c.domain, lock: false })}
                          >
                            Set
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-xs"
                            onClick={() => setDomainMutation.mutate({ domain: c.domain, lock: true })}
                          >
                            <Lock className="w-3 h-3 mr-1" /> Lock
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Manual override */}
                <div className="flex gap-2 pt-2 border-t border-border">
                  <Input
                    placeholder="Enter domain manually..."
                    value={overrideDomain}
                    onChange={(e) => setOverrideDomain(e.target.value)}
                    className="max-w-xs font-mono"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={!overrideDomain}
                    onClick={() => setDomainMutation.mutate({ domain: overrideDomain, lock: false })}
                  >
                    Set
                  </Button>
                  <Button
                    size="sm"
                    disabled={!overrideDomain}
                    onClick={() => setDomainMutation.mutate({ domain: overrideDomain, lock: true })}
                  >
                    <Lock className="w-3.5 h-3.5 mr-1" /> Set & Lock
                  </Button>
                </div>

                {/* Re-run actions */}
                <div className="flex gap-2 pt-2">
                  <Button variant="outline" size="sm" onClick={() => rerunDomainMutation.mutate(true)} disabled={rerunDomainMutation.isPending}>
                    <RefreshCw className="w-3.5 h-3.5 mr-1" /> Quick Lookup
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => rerunDomainMutation.mutate(false)} disabled={rerunDomainMutation.isPending}>
                    <RefreshCw className="w-3.5 h-3.5 mr-1" /> Deep Lookup
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* B) Email Intel Card */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    Email Pattern Cache
                  </CardTitle>
                  {emailIntel ? (
                    <Badge variant="default">Cached</Badge>
                  ) : (
                    <Badge variant="secondary">No cache</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {emailIntel ? (
                  <>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-muted-foreground">Pattern</p>
                        <p className="font-mono font-medium">{emailIntel.pattern || "—"}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Confidence</p>
                        <p className="font-medium">{emailIntel.pattern_confidence !== null ? `${(emailIntel.pattern_confidence * 100).toFixed(0)}%` : "—"}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">MX Valid</p>
                        <p className="flex items-center gap-1">
                          {emailIntel.mx_valid ? <CheckCircle2 className="w-4 h-4 text-success" /> : <XCircle className="w-4 h-4 text-destructive" />}
                          {emailIntel.mx_valid ? "Yes" : "No"}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Domain</p>
                        <p className="font-mono text-sm">{emailIntel.domain || "—"}</p>
                      </div>
                    </div>
                    {(emailIntel.examples as any[])?.length > 0 && (
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Examples</p>
                        <div className="flex flex-wrap gap-1.5">
                          {(emailIntel.examples as any[]).map((ex: any, i: number) => (
                            <Badge key={i} variant="outline" className="font-mono text-xs">
                              {typeof ex === "string" ? ex : ex.email || JSON.stringify(ex)}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="flex gap-2 pt-2">
                      <Button variant="outline" size="sm" onClick={() => invalidateIntelMutation.mutate()} disabled={invalidateIntelMutation.isPending}>
                        <Trash2 className="w-3.5 h-3.5 mr-1" /> Invalidate Cache
                      </Button>
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground">No cached email pattern for this company. It will be built automatically during the next stakeholder enrichment.</p>
                )}
              </CardContent>
            </Card>

            {/* C) Stakeholders */}
            <Card>
              <CardHeader>
                <CardTitle>Stakeholders ({stakeholders?.length || 0})</CardTitle>
                <CardDescription>Email enrichment status per contact</CardDescription>
              </CardHeader>
              <CardContent>
                {!stakeholders?.length ? (
                  <p className="text-sm text-muted-foreground">No stakeholders for this company.</p>
                ) : (
                  <div className="space-y-2">
                    {stakeholders.map((s: any) => (
                      <div key={s.id} className="flex items-center gap-3 text-sm py-2 px-3 bg-muted/30 rounded">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium truncate">{s.name}</span>
                            {s.linkedin_url && (
                              <a href={s.linkedin_url} target="_blank" rel="noopener noreferrer">
                                <Linkedin className="w-3.5 h-3.5 text-muted-foreground" />
                              </a>
                            )}
                          </div>
                          {s.title && <p className="text-xs text-muted-foreground">{s.title}</p>}
                        </div>
                        <div className="text-right">
                          {s.email ? (
                            <>
                              <span className="font-mono text-xs">{s.email}</span>
                              {/* Tightened rule: only show ✅ if email exists AND source is not bettercontact_pending */}
                              {s.enrichment_source !== "bettercontact_pending" ? (
                                <p className="text-[10px] text-primary flex items-center gap-0.5 justify-end">✅ Enriched</p>
                              ) : (
                                <p className="text-[10px] text-muted-foreground">⏳ Pending verification</p>
                              )}
                            </>
                          ) : (
                            <span className="text-xs text-muted-foreground italic">No email</span>
                          )}
                          {s.email_confidence !== null && (
                            <p className={`text-[10px] ${s.email_confidence < 0.5 ? "text-destructive" : "text-primary"}`}>
                              {(s.email_confidence * 100).toFixed(0)}% confidence
                            </p>
                          )}
                        </div>
                        {s.bettercontact_status && (
                          <Badge variant={s.bettercontact_status === "done" ? "default" : s.bettercontact_status === "pending" ? "outline" : "secondary"} className="text-[10px]">
                            BC: {s.bettercontact_status}
                          </Badge>
                        )}
                        {s.latest_attempt && (
                          <Badge variant={s.latest_attempt.status === "succeeded" ? "default" : s.latest_attempt.status === "failed" ? "destructive" : "outline"} className="text-[10px]">
                            {s.latest_attempt.status}
                          </Badge>
                        )}
                        <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => navigate(`/enrichment/stakeholder/${s.id}`)}>
                          Timeline
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        ) : null}
      </div>
    </DashboardLayout>
  );
}
