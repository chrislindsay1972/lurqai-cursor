import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { StatCard } from "@/components/dashboard/StatCard";
import { RecentActivity } from "@/components/dashboard/RecentActivity";
import { MatchingPipeline } from "@/components/dashboard/MatchingPipeline";
import { TopMatches } from "@/components/dashboard/TopMatches";
import { Users, Briefcase, Building2, TrendingUp, AlertTriangle, RefreshCw, Mail } from "lucide-react";
import { useDashboardStats } from "@/hooks/useDashboardStats";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

export default function Dashboard() {
  const { data: stats, isLoading } = useDashboardStats();
  const [retrying, setRetrying] = useState(false);
  const [reEnriching, setReEnriching] = useState(false);
  const queryClient = useQueryClient();

  const handleRetryBcTasks = async () => {
    setRetrying(true);
    try {
      const { data, error } = await supabase.functions.invoke("poll-bettercontact-tasks");
      if (error) throw error;
      toast.success(`BetterContact retry complete: ${data?.resolved ?? 0} emails resolved, ${data?.stillPending ?? 0} still pending`);
      queryClient.invalidateQueries({ queryKey: ["dashboard-stats"] });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      toast.error("Failed to retry BetterContact tasks: " + msg);
    } finally {
      setRetrying(false);
    }
  };

  const handleReEnrichMissing = async () => {
    setReEnriching(true);
    try {
      const { data, error } = await supabase.functions.invoke("re-enrich-missing-emails");
      if (error) throw error;
      toast.success(`Re-enrichment started: ${data?.submitted ?? 0} stakeholders submitted to BetterContact`);
      queryClient.invalidateQueries({ queryKey: ["dashboard-stats"] });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      toast.error("Failed to re-enrich: " + msg);
    } finally {
      setReEnriching(false);
    }
  };

  const showBcAlert = !isLoading && (stats?.staleBcTasks ?? 0) > 0;
  const showOrphanAlert = !isLoading && (stats?.orphanedEmailCount ?? 0) > 0;

  return (
    <DashboardLayout
      title="Dashboard"
      subtitle="Welcome back! Let's get Lurqing."
    >
      <div className="space-y-6">
        {/* Orphaned stakeholders — have LinkedIn but never submitted to BetterContact */}
        {showOrphanAlert && (
          <div className="flex items-start gap-3 rounded-xl border border-blue-500/30 bg-blue-500/10 px-4 py-3">
            <Mail className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-blue-600">
                {stats!.orphanedEmailCount} stakeholder{stats!.orphanedEmailCount !== 1 ? "s" : ""} with LinkedIn but no email — never submitted to BetterContact
              </p>
              <p className="text-xs text-blue-600/80 mt-0.5">
                Apollo found the contact but couldn't resolve an email. BetterContact can fill the gap.
              </p>
            </div>
            <button
              onClick={handleReEnrichMissing}
              disabled={reEnriching}
              className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-blue-500/20 text-blue-700 hover:bg-blue-500/30 transition-colors disabled:opacity-50 shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${reEnriching ? "animate-spin" : ""}`} />
              {reEnriching ? "Submitting…" : "Submit to BetterContact"}
            </button>
          </div>
        )}

        {/* BetterContact failure flag */}
        {showBcAlert && (
          <div className="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3">
            <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-amber-600">
                BetterContact enrichment stalled — {stats!.staleBcTasks} stakeholder{stats!.staleBcTasks !== 1 ? "s" : ""} awaiting email resolution
              </p>
              <p className="text-xs text-amber-600/80 mt-0.5">
                Tasks have been pending for over 30 minutes.{" "}
                {stats!.staleBcStakeholders.slice(0, 3).map((s) => s.name).join(", ")}
                {(stats!.staleBcTasks ?? 0) > 3 ? ` +${stats!.staleBcTasks - 3} more` : ""}
              </p>
            </div>
            <button
              onClick={handleRetryBcTasks}
              disabled={retrying}
              className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-700 hover:bg-amber-500/30 transition-colors disabled:opacity-50 shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${retrying ? "animate-spin" : ""}`} />
              {retrying ? "Retrying…" : "Retry now"}
            </button>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total Candidates"
            value={isLoading ? "..." : stats?.totalCandidates ?? 0}
            icon={<Users className="w-6 h-6" />}
          />
          <StatCard
            title="Active Jobs"
            value={isLoading ? "..." : stats?.activeJobs ?? 0}
            icon={<Briefcase className="w-6 h-6" />}
          />
          <StatCard
            title="Companies"
            value={isLoading ? "..." : stats?.totalCompanies ?? 0}
            icon={<Building2 className="w-6 h-6" />}
          />
          <StatCard
            title="Avg Match Rate"
            value={isLoading ? "..." : `${stats?.avgMatchRate ?? 0}%`}
            icon={<TrendingUp className="w-6 h-6" />}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            <TopMatches />
            <MatchingPipeline />
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <RecentActivity />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
