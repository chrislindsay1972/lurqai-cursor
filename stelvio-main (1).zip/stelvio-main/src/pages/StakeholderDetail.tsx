import { useState, useEffect } from "react";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { useParams, useNavigate, Link } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft,
  User,
  Mail,
  Phone,
  MapPin,
  Building2,
  Linkedin,
  Loader2,
  Pencil,
  Save,
  X,
  Globe,
  CheckCircle,
  XCircle,
  Users,
  Briefcase,
  Plus,
  Sparkles,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { NotesSection } from "@/components/notes/NotesSection";
import { EmailList } from "@/components/emails/EmailList";
import { useBetterContactEnrich } from "@/hooks/useBetterContactEnrich";

interface Stakeholder {
  id: string;
  name: string;
  title: string | null;
  email: string | null;
  phone: string | null;
  linkedin_url: string | null;
  location: string | null;
  company_id: string | null;
  job_board_id: string | null;
  source: string | null;
  contacted: boolean;
  notes: string | null;
  created_at: string;
  updated_at: string;
  // BetterContact enrichment fields
  email_status: string | null;
  email_provider: string | null;
  gender: string | null;
  enriched_at: string | null;
  enrichment_source: string | null;
  bettercontact_data: unknown;
  companies?: { id: string; name: string; industry: string | null; employee_count: number | null } | null;
  job_boards?: { id: string; name: string } | null;
}

interface Company {
  id: string;
  name: string;
}

interface JobBoard {
  id: string;
  name: string;
}

interface OtherStakeholder {
  id: string;
  name: string;
  title: string | null;
  email: string | null;
  contacted: boolean;
}

function isSafeUrl(url: string | null): boolean {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

export default function StakeholderDetail() {
  const { formatDate } = useLocaleFormat();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [stakeholder, setStakeholder] = useState<Stakeholder | null>(null);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [jobBoards, setJobBoards] = useState<JobBoard[]>([]);
  const [otherStakeholders, setOtherStakeholders] = useState<OtherStakeholder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    title: "",
    email: "",
    phone: "",
    linkedin_url: "",
    location: "",
    company_id: "",
    job_board_id: "",
    source: "manual",
    contacted: false,
    notes: "",
  });

  const { enrichContact, isEnriching, progress } = useBetterContactEnrich();

  useEffect(() => {
    if (id) {
      fetchData();
    }
  }, [id]);

  const fetchData = async () => {
    try {
      const [stakeholderRes, companiesRes, jobBoardsRes] = await Promise.all([
        supabase
          .from("stakeholders")
          .select("*, companies(id, name, industry, employee_count), job_boards(id, name)")
          .eq("id", id)
          .maybeSingle(),
        supabase.from("companies").select("id, name").order("name"),
        supabase.from("job_boards").select("id, name").eq("status", "active").order("name"),
      ]);

      if (stakeholderRes.error) throw stakeholderRes.error;
      if (!stakeholderRes.data) {
        toast.error("Stakeholder not found");
        navigate("/stakeholders");
        return;
      }

      setStakeholder(stakeholderRes.data as Stakeholder);
      setCompanies(companiesRes.data || []);
      setJobBoards(jobBoardsRes.data || []);

      setFormData({
        name: stakeholderRes.data.name,
        title: stakeholderRes.data.title || "",
        email: stakeholderRes.data.email || "",
        phone: stakeholderRes.data.phone || "",
        linkedin_url: stakeholderRes.data.linkedin_url || "",
        location: stakeholderRes.data.location || "",
        company_id: stakeholderRes.data.company_id || "",
        job_board_id: stakeholderRes.data.job_board_id || "",
        source: stakeholderRes.data.source || "manual",
        contacted: stakeholderRes.data.contacted,
        notes: stakeholderRes.data.notes || "",
      });

      // Fetch other stakeholders from the same company
      if (stakeholderRes.data.company_id) {
        const { data: otherData } = await supabase
          .from("stakeholders")
          .select("id, name, title, email, contacted")
          .eq("company_id", stakeholderRes.data.company_id)
          .neq("id", id)
          .order("name");
        
        setOtherStakeholders(otherData || []);
      }
    } catch (error) {
      console.error("Error fetching stakeholder:", error);
      toast.error("Failed to load stakeholder details");
      navigate("/stakeholders");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!id || !formData.name) {
      toast.error("Name is required");
      return;
    }
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from("stakeholders")
        .update({
          name: formData.name,
          title: formData.title || null,
          email: formData.email || null,
          phone: formData.phone || null,
          linkedin_url: formData.linkedin_url || null,
          location: formData.location || null,
          company_id: formData.company_id || null,
          job_board_id: formData.job_board_id || null,
          source: formData.source || "manual",
          contacted: formData.contacted,
          notes: formData.notes || null,
        })
        .eq("id", id);

      if (error) throw error;

      // Refetch to get updated related data
      await fetchData();
      setIsEditing(false);
      toast.success("Stakeholder updated successfully");
    } catch (error) {
      console.error("Error updating stakeholder:", error);
      toast.error("Failed to save changes");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    if (stakeholder) {
      setFormData({
        name: stakeholder.name,
        title: stakeholder.title || "",
        email: stakeholder.email || "",
        phone: stakeholder.phone || "",
        linkedin_url: stakeholder.linkedin_url || "",
        location: stakeholder.location || "",
        company_id: stakeholder.company_id || "",
        job_board_id: stakeholder.job_board_id || "",
        source: stakeholder.source || "manual",
        contacted: stakeholder.contacted,
        notes: stakeholder.notes || "",
      });
    }
    setIsEditing(false);
  };

  const handleEnrichContact = async () => {
    if (!stakeholder) return;

    // Split name into first and last
    const nameParts = stakeholder.name.trim().split(/\s+/);
    const firstName = nameParts[0] || "";
    const lastName = nameParts.slice(1).join(" ") || nameParts[0] || "";

    const result = await enrichContact({
      stakeholderId: stakeholder.id,
      firstName,
      lastName,
      companyName: stakeholder.companies?.name,
      linkedinUrl: stakeholder.linkedin_url || undefined,
    });

    if (result) {
      // Refresh stakeholder data to show updated email/phone
      await fetchData();
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout title="Stakeholder Details" subtitle="Loading...">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  if (!stakeholder) {
    return (
      <DashboardLayout title="Stakeholder Not Found" subtitle="">
        <div className="text-center py-12">
          <p className="text-muted-foreground">Stakeholder not found</p>
          <Button variant="outline" className="mt-4" onClick={() => navigate("/stakeholders")}>
            Back to Stakeholders
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title={stakeholder.name} subtitle="Stakeholder Details">
      <div className="space-y-6">
        {/* Header Actions */}
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate("/stakeholders")} className="bg-accent text-accent-foreground hover:bg-accent hover:text-accent-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Stakeholders
          </Button>
          <div className="flex gap-2">
            {/* Enrich Contact Button */}
            {!isEditing && (
              <Button
                variant="outline"
                onClick={handleEnrichContact}
                disabled={isEnriching}
                className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30 hover:from-purple-500/20 hover:to-pink-500/20"
              >
                {isEnriching ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enriching with LurqAI...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Enrich with LurqAI
                  </>
                )}
              </Button>
            )}
            {isEditing ? (
              <>
                <Button variant="outline" onClick={handleCancel} disabled={isSaving}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={isSaving}>
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Save Changes
                </Button>
              </>
            ) : (
              <Button onClick={() => setIsEditing(true)}>
                <Pencil className="w-4 h-4 mr-2" />
                Edit Stakeholder
              </Button>
            )}
          </div>
        </div>

        {/* Status Badge */}
        <div className="flex items-center gap-3">
          {stakeholder.contacted ? (
            <Badge variant="outline" className="bg-success/10 text-success border-success/20">
              <CheckCircle className="w-3 h-3 mr-1" />
              Contacted
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-amber-500/15 text-amber-600 border-amber-500/30">
              <XCircle className="w-3 h-3 mr-1" />
              AI-Research
            </Badge>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Personal Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                {isEditing ? (
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                ) : (
                  <p className="text-card-foreground font-medium">{stakeholder.name}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Title</Label>
                {isEditing ? (
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Head of Engineering"
                  />
                ) : (
                  <p className="text-card-foreground">{stakeholder.title || "Not set"}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Location</Label>
                {isEditing ? (
                  <Input
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="Austin, TX"
                  />
                ) : (
                  <p className="flex items-center gap-2 text-card-foreground">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    {stakeholder.location || "Not set"}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Contact Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Email</Label>
                {isEditing ? (
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="john@company.com"
                  />
                ) : stakeholder.email ? (
                  <a href={`mailto:${stakeholder.email}`} className="text-link hover:text-link/80 hover:underline flex items-center gap-1">
                    <Mail className="w-4 h-4" />
                    {stakeholder.email}
                  </a>
                ) : (
                  <p className="text-muted-foreground">Not set</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Phone</Label>
                {isEditing ? (
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+1 555-0123"
                  />
                ) : (
                  <p className="flex items-center gap-2 text-card-foreground">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    {stakeholder.phone || "Not set"}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label>LinkedIn URL</Label>
                {isEditing ? (
                  <Input
                    value={formData.linkedin_url}
                    onChange={(e) => setFormData({ ...formData, linkedin_url: e.target.value })}
                    placeholder="https://linkedin.com/in/..."
                  />
              ) : stakeholder.linkedin_url && isSafeUrl(stakeholder.linkedin_url) ? (
                  <div className="flex items-center gap-3">
                    <a
                      href={stakeholder.linkedin_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-link hover:text-link/80 hover:underline flex items-center gap-1"
                    >
                      <Linkedin className="w-4 h-4" />
                      View on LinkedIn
                    </a>
                    {stakeholder.companies?.name && (
                      <a
                        href={`https://www.linkedin.com/company/${encodeURIComponent(stakeholder.companies.name.toLowerCase().replace(/\s+/g, '-'))}/people/?keywords=${encodeURIComponent(stakeholder.name)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 border border-border rounded-md px-2 py-1 hover:bg-accent transition-colors"
                      >
                        <Users className="w-3 h-3" />
                        Verify
                      </a>
                    )}
                  </div>
                ) : stakeholder.companies?.name ? (
                  <div className="flex items-center gap-3">
                    <p className="text-muted-foreground">{stakeholder.linkedin_url || "Not set"}</p>
                    <a
                      href={`https://www.linkedin.com/company/${encodeURIComponent(stakeholder.companies.name.toLowerCase().replace(/\s+/g, '-'))}/people/?keywords=${encodeURIComponent(stakeholder.name)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 border border-border rounded-md px-2 py-1 hover:bg-accent transition-colors"
                    >
                      <Users className="w-3 h-3" />
                      Verify
                    </a>
                  </div>
                ) : (
                  <p className="text-muted-foreground">{stakeholder.linkedin_url || "Not set"}</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Enrichment Data Card */}
          {stakeholder.enriched_at && (
            <Card className="bg-gradient-to-br from-purple-500/5 to-pink-500/5 border-purple-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-500" />
                  Enrichment Data
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {(() => {
                  const bcData = stakeholder.bettercontact_data as Record<string, unknown> | null;
                  return (
                    <div className="grid grid-cols-2 gap-4">
                      {/* Email Status */}
                      {stakeholder.email_status && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Email Status</p>
                          <Badge 
                            variant="outline" 
                            className={
                              ['deliverable', 'verified'].includes(stakeholder.email_status) 
                                ? 'bg-success/10 text-success border-success/20'
                                : ['catch_all', 'catch_all_safe'].includes(stakeholder.email_status)
                                ? 'bg-amber-500/10 text-amber-600 border-amber-500/20'
                                : 'bg-destructive/10 text-destructive border-destructive/20'
                            }
                          >
                            {stakeholder.email_status === 'deliverable' && <CheckCircle className="w-3 h-3 mr-1" />}
                            {stakeholder.email_status.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                          </Badge>
                        </div>
                      )}
                      
                      {/* Email Provider */}
                      {stakeholder.email_provider && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Email Provider</p>
                          <Badge variant="secondary" className="bg-purple-500/10 text-purple-600 border-purple-500/20">
                            {stakeholder.email_provider}
                          </Badge>
                        </div>
                      )}
                      
                      {/* Gender */}
                      {stakeholder.gender && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Gender</p>
                          <p className="font-medium text-card-foreground capitalize">{stakeholder.gender}</p>
                        </div>
                      )}
                      

                      {/* Additional fields from BetterContact data */}
                      {bcData?.contact_linkedin_profile_url && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">LinkedIn</p>
                          <a 
                            href={String(bcData.contact_linkedin_profile_url)} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-link hover:text-link/80 hover:underline flex items-center gap-1 text-sm"
                          >
                            <Linkedin className="w-3 h-3" />
                            Profile
                          </a>
                        </div>
                      )}

                      {bcData?.contact_city && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">City</p>
                          <p className="text-card-foreground text-sm">{String(bcData.contact_city)}</p>
                        </div>
                      )}

                      {bcData?.contact_country && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Country</p>
                          <p className="text-card-foreground text-sm">{String(bcData.contact_country)}</p>
                        </div>
                      )}

                      {bcData?.contact_job_title && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Job Title (Enriched)</p>
                          <p className="text-card-foreground text-sm">{String(bcData.contact_job_title)}</p>
                        </div>
                      )}

                      {bcData?.contact_phone_number && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Phone (Enriched)</p>
                          <p className="text-card-foreground text-sm">{String(bcData.contact_phone_number)}</p>
                        </div>
                      )}

                      {bcData?.contact_mobile_phone && bcData.contact_mobile_phone !== bcData.contact_phone_number && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Mobile (Enriched)</p>
                          <p className="text-card-foreground text-sm">{String(bcData.contact_mobile_phone)}</p>
                        </div>
                      )}

                      {bcData?.company_linkedin_url && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Company LinkedIn</p>
                          <a 
                            href={String(bcData.company_linkedin_url)} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-link hover:text-link/80 hover:underline flex items-center gap-1 text-sm"
                          >
                            <Linkedin className="w-3 h-3" />
                            Company
                          </a>
                        </div>
                      )}

                      {bcData?.company_domain && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Company Domain</p>
                          <a 
                            href={`https://${String(bcData.company_domain)}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-link hover:text-link/80 hover:underline flex items-center gap-1 text-sm"
                          >
                            <Globe className="w-3 h-3" />
                            {String(bcData.company_domain)}
                          </a>
                        </div>
                      )}

                      {bcData?.company_name && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Company (Enriched)</p>
                          <p className="text-card-foreground text-sm">{String(bcData.company_name)}</p>
                        </div>
                      )}

                      {bcData?.company_employees && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Company Size</p>
                          <p className="text-card-foreground text-sm flex items-center gap-1">
                            <Users className="w-3 h-3 text-muted-foreground" />
                            {String(bcData.company_employees)}
                          </p>
                        </div>
                      )}

                      {bcData?.company_industry_code && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">Industry</p>
                          <p className="text-card-foreground text-sm">{String(bcData.company_industry_code)}</p>
                        </div>
                      )}

                      {bcData?.contact_connections && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">LinkedIn Connections</p>
                          <p className="text-card-foreground text-sm">{String(bcData.contact_connections)}</p>
                        </div>
                      )}

                      {bcData?.contact_followers && (
                        <div className="space-y-1">
                          <p className="text-muted-foreground text-sm">LinkedIn Followers</p>
                          <p className="text-card-foreground text-sm">{String(bcData.contact_followers)}</p>
                        </div>
                      )}

                      {bcData?.do_not_contact === true && (
                        <div className="space-y-1 col-span-2">
                          <Badge variant="destructive" className="bg-destructive/10 text-destructive border-destructive/20">
                            <XCircle className="w-3 h-3 mr-1" />
                            Do Not Contact
                          </Badge>
                        </div>
                      )}
                    </div>
                  );
                })()}
                
                <div className="pt-2 border-t border-purple-500/10">
                  <p className="text-muted-foreground text-xs">
                    Last enriched: {new Date(stakeholder.enriched_at).toLocaleString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Association Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                Association
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Company</Label>
                {isEditing ? (
                  <Select
                    value={formData.company_id || "none"}
                    onValueChange={(value) => setFormData({ ...formData, company_id: value === "none" ? "" : value })}
                  >
                    <SelectTrigger className="bg-white text-slate-900 border-slate-300">
                      <SelectValue placeholder="Select company" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {companies.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : stakeholder.companies ? (
                  <Link
                    to={`/companies/${stakeholder.companies.id}`}
                    className="text-link hover:text-link/80 hover:underline flex items-center gap-1"
                  >
                    <Building2 className="w-4 h-4" />
                    {stakeholder.companies.name}
                  </Link>
                ) : (
                  <p className="text-muted-foreground">Not set</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Job Board Source</Label>
                {isEditing ? (
                  <Select
                    value={formData.job_board_id || "none"}
                    onValueChange={(value) => setFormData({ ...formData, job_board_id: value === "none" ? "" : value })}
                  >
                    <SelectTrigger className="bg-white text-slate-900 border-slate-300">
                      <SelectValue placeholder="Select job board" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {jobBoards.map((jb) => (
                        <SelectItem key={jb.id} value={jb.id}>
                          {jb.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : stakeholder.job_boards ? (
                  <Badge variant="secondary">{stakeholder.job_boards.name}</Badge>
                ) : (
                  <p className="text-muted-foreground">Not set</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Contacted</Label>
                {isEditing ? (
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="contacted"
                      checked={formData.contacted}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, contacted: checked as boolean })
                      }
                    />
                    <label htmlFor="contacted" className="text-sm">
                      Already contacted
                    </label>
                  </div>
                ) : (
                  <Badge
                    variant="outline"
                    className={
                      stakeholder.contacted
                        ? "bg-success/10 text-success border-success/20"
                        : "bg-muted text-muted-foreground"
                    }
                  >
                    {stakeholder.contacted ? "Yes" : "No"}
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Notes */}
          <Card>
            <CardHeader>
              <CardTitle>Notes</CardTitle>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Any additional notes..."
                  rows={4}
                  className="bg-white text-slate-900 border-slate-300 placeholder:text-slate-500"
                />
              ) : (
                <p className="text-card-foreground whitespace-pre-wrap">
                  {stakeholder.notes || "No notes"}
                </p>
              )}
            </CardContent>
          </Card>

          {/* Company Details (if associated) */}
          {stakeholder.companies && (
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5" />
                  Company Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-muted-foreground text-sm">Company Name</p>
                    <Link
                      to={`/companies/${stakeholder.companies.id}`}
                      className="font-medium text-accent hover:underline"
                    >
                      {stakeholder.companies.name}
                    </Link>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Industry</p>
                    <p className="font-medium">{stakeholder.companies.industry || "Not set"}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Employee Count</p>
                    <p className="font-medium">
                      {stakeholder.companies.employee_count?.toLocaleString() || "Unknown"}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Other Stakeholders</p>
                    <p className="font-medium">{otherStakeholders.length} contacts</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Emails */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Emails
              </CardTitle>
              {stakeholder.email && (
                <EmailList 
                  stakeholderId={stakeholder.id}
                  recipientEmail={stakeholder.email}
                  recipientName={stakeholder.name}
                  showComposeButton
                  composeButtonOnly
                />
              )}
            </CardHeader>
            <CardContent>
              <EmailList 
                stakeholderId={stakeholder.id} 
                maxHeight="300px"
              />
            </CardContent>
          </Card>

          {/* Other Stakeholders at Same Company */}
          {otherStakeholders.length > 0 && (
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Other Contacts at {stakeholder.companies?.name}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {otherStakeholders.map((other) => (
                    <Link
                      key={other.id}
                      to={`/stakeholders/${other.id}`}
                      className="p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <p className="font-medium text-card-foreground hover:text-link">
                        {other.name}
                      </p>
                      <p className="text-sm text-muted-foreground">{other.title || "No title"}</p>
                      {other.email && (
                        <p className="text-xs text-muted-foreground truncate">{other.email}</p>
                      )}
                      <Badge
                        variant="outline"
                        className={`mt-2 text-xs ${other.contacted ? "bg-success/10 text-success border-success/20" : ""}`}
                      >
                        {other.contacted ? "Contacted" : "Not Contacted"}
                      </Badge>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Metadata */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Record Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Created At</p>
                  <p className="font-medium">
                    {formatDate(stakeholder.created_at)}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Updated At</p>
                  <p className="font-medium">
                    {formatDate(stakeholder.updated_at)}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Source</p>
                  <p className="font-medium">{stakeholder.source || "manual"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Record ID</p>
                  <p className="font-mono text-xs">{stakeholder.id.slice(0, 8)}...</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notes */}
          <NotesSection entityType="stakeholder" entityId={stakeholder.id} />
        </div>
      </div>
    </DashboardLayout>
  );
}
