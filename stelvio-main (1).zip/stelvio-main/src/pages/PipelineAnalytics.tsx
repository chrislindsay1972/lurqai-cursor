import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend,
} from "recharts";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Zap, Target, TrendingUp, XCircle, CheckCircle, Clock, AlertTriangle, BarChart2, ArrowUp, ArrowDown, Minus, Filter,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Candidate {
  id: string;
  name: string;
  current_title: string | null;
}

interface PendingJob {
  status: string;
  rejection_reason: string | null;
  score: number | null;
  source_board: string | null;
  source_query: string | null;
}

interface SearchFeedbackRow {
  query_text: string;
  board_name: string | null;
  jobs_discovered: number;
  jobs_scored: number;
  jobs_matched: number;
  avg_score: number | null;
  best_score: number | null;
  created_at: string;
}

interface KeywordRow {
  keyword: string;
  times_used: number;
  jobs_found: number;
  matches_produced: number;
  effectiveness_score: number | null;
}

// ─── Constants ───────────────────────────────────────────────────────────────

// Approximate Firecrawl credit costs (v1 pricing estimates):
// - /scrape (links only): ~1 credit
// - /search (no scrapeOptions): ~1–2 credits per result
// We estimate based on jobs discovered as proxy for search calls made.
const CREDITS_PER_SEARCH_CALL = 2; // conservative estimate per Firecrawl search call
const CREDITS_PER_SCRAPE_CALL = 1; // native URL scrape (links only)

const REJECTION_COLORS: Record<string, string> = {
  "location_mismatch":    "hsl(0 72% 51%)",
  "low_score":            "hsl(38 92% 50%)",
  "large_company":        "hsl(220 10% 46%)",
  "duplicate":            "hsl(220 10% 65%)",
  "too_old":              "hsl(270 60% 55%)",
  "category_page":        "hsl(200 70% 50%)",
  "pre_filter":           "hsl(180 60% 40%)",
  "other":                "hsl(67 95% 57%)",
};

function rejectionColor(reason: string): string {
  const key = reason.toLowerCase().replace(/\s+/g, "_");
  for (const [k, v] of Object.entries(REJECTION_COLORS)) {
    if (key.includes(k)) return v;
  }
  return REJECTION_COLORS.other;
}

function labelRejection(reason: string): string {
  return reason
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  color = "text-primary",
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  color?: string;
}) {
  return (
    <Card className="bg-card border-border shadow-sm">
      <CardContent className="p-5 flex items-start gap-4">
        <div className={`mt-0.5 w-10 h-10 rounded-xl bg-muted flex items-center justify-center flex-shrink-0`}>
          <Icon className={`w-5 h-5 ${color}`} />
        </div>
        <div>
          <p className="text-xs text-muted-foreground font-medium">{label}</p>
          <p className="text-2xl font-bold text-card-foreground leading-tight">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function PipelineAnalytics() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [selectedId, setSelectedId] = useState<string>("all");
  const [pendingJobs, setPendingJobs] = useState<PendingJob[]>([]);
  const [feedback, setFeedback] = useState<SearchFeedbackRow[]>([]);
  const [keywords, setKeywords] = useState<KeywordRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [hideOversized, setHideOversized] = useState(true);

  // Load candidate list
  useEffect(() => {
    supabase
      .from("candidates")
      .select("id, name, current_title")
      .order("name")
      .then(({ data }) => setCandidates((data as Candidate[]) || []));
  }, []);

  // Load analytics data when candidate changes
  useEffect(() => {
    setLoading(true);
    const isAll = selectedId === "all";

    const pendingQ = isAll
      ? supabase.from("pipeline_pending_jobs").select("status, rejection_reason, score, source_board, source_query")
      : supabase.from("pipeline_pending_jobs").select("status, rejection_reason, score, source_board, source_query").eq("candidate_id", selectedId);

    const feedbackQ = isAll
      ? supabase.from("search_feedback").select("query_text, board_name, jobs_discovered, jobs_scored, jobs_matched, avg_score, best_score, created_at").order("created_at", { ascending: false }).limit(500)
      : supabase.from("search_feedback").select("query_text, board_name, jobs_discovered, jobs_scored, jobs_matched, avg_score, best_score, created_at").eq("candidate_id", selectedId).order("created_at", { ascending: false }).limit(500);

    const kwQ = isAll
      ? supabase.from("keyword_performance").select("keyword, times_used, jobs_found, matches_produced, effectiveness_score").order("jobs_found", { ascending: false }).limit(20)
      : supabase.from("keyword_performance").select("keyword, times_used, jobs_found, matches_produced, effectiveness_score").eq("candidate_id", selectedId).order("jobs_found", { ascending: false }).limit(20);

    Promise.all([pendingQ, feedbackQ, kwQ]).then(([pRes, fRes, kRes]) => {
      setPendingJobs((pRes.data as PendingJob[]) || []);
      setFeedback((fRes.data as SearchFeedbackRow[]) || []);
      setKeywords((kRes.data as KeywordRow[]) || []);
      setLoading(false);
    });
  }, [selectedId]);

  // ─── Derived Metrics ───────────────────────────────────────────────────────

  // Filter out large_company rejections when toggle is on
  const filteredJobs = hideOversized
    ? pendingJobs.filter((j) => {
        if (j.status !== "rejected") return true;
        const reason = (j.rejection_reason || "").toLowerCase();
        return !reason.includes("large_company") && !reason.includes("exceeds_size");
      })
    : pendingJobs;

  const totalJobs = filteredJobs.length;
  const saved = filteredJobs.filter((j) => j.status === "saved").length;
  const rejected = filteredJobs.filter((j) => j.status === "rejected").length;
  const pending = filteredJobs.filter((j) => j.status === "pending").length;

  // Estimated Firecrawl calls: search_feedback rows represent individual query+board calls
  // Each row = 1 Firecrawl search call. Native scrape calls are additional.
  const totalSearchCalls = feedback.length;
  const totalJobsDiscovered = feedback.reduce((s, r) => s + r.jobs_discovered, 0);
  const estimatedCredits = totalSearchCalls * CREDITS_PER_SEARCH_CALL;
  const jobsPerCall = totalSearchCalls > 0
    ? (totalJobsDiscovered / totalSearchCalls).toFixed(1)
    : "—";
  const saveRate = totalJobs > 0 ? ((saved / totalJobs) * 100).toFixed(1) : "0";
  const avgMatchScore = (() => {
    const scored = filteredJobs.filter((j) => j.score != null);
    if (!scored.length) return "—";
    return (scored.reduce((s, j) => s + (j.score || 0), 0) / scored.length).toFixed(0);
  })();

  // ─── This Week vs Last Week Credit Comparison ──────────────────────────────
  const now = new Date();
  const startOfThisWeek = new Date(now);
  startOfThisWeek.setDate(now.getDate() - now.getDay()); // Sunday
  startOfThisWeek.setHours(0, 0, 0, 0);

  const startOfLastWeek = new Date(startOfThisWeek);
  startOfLastWeek.setDate(startOfThisWeek.getDate() - 7);

  const thisWeekFeedback = feedback.filter((r) => new Date(r.created_at) >= startOfThisWeek);
  const lastWeekFeedback = feedback.filter((r) => {
    const d = new Date(r.created_at);
    return d >= startOfLastWeek && d < startOfThisWeek;
  });

  const thisWeekCredits = thisWeekFeedback.length * CREDITS_PER_SEARCH_CALL;
  const lastWeekCredits = lastWeekFeedback.length * CREDITS_PER_SEARCH_CALL;
  const thisWeekDiscovered = thisWeekFeedback.reduce((s, r) => s + r.jobs_discovered, 0);
  const lastWeekDiscovered = lastWeekFeedback.reduce((s, r) => s + r.jobs_discovered, 0);
  const thisWeekMatched = thisWeekFeedback.reduce((s, r) => s + r.jobs_matched, 0);
  const lastWeekMatched = lastWeekFeedback.reduce((s, r) => s + r.jobs_matched, 0);

  const creditDelta = lastWeekCredits > 0
    ? Math.round(((thisWeekCredits - lastWeekCredits) / lastWeekCredits) * 100)
    : null;
  const discoveredDelta = lastWeekDiscovered > 0
    ? Math.round(((thisWeekDiscovered - lastWeekDiscovered) / lastWeekDiscovered) * 100)
    : null;
  const matchedDelta = lastWeekMatched > 0
    ? Math.round(((thisWeekMatched - lastWeekMatched) / lastWeekMatched) * 100)
    : null;

  // Rejection breakdown
  const rejectionMap = new Map<string, number>();
  for (const job of filteredJobs) {
    if (job.status !== "rejected") continue;
    const reason = (job.rejection_reason || "other").toLowerCase().trim() || "other";
    rejectionMap.set(reason, (rejectionMap.get(reason) || 0) + 1);
  }
  const rejectionData = Array.from(rejectionMap.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([reason, count]) => ({
      reason: labelRejection(reason),
      rawReason: reason,
      count,
      pct: rejected > 0 ? Math.round((count / rejected) * 100) : 0,
    }));

  // Jobs per board (top 10) — derived from pipeline_pending_jobs.source_board
  const boardMap = new Map<string, { found: number; saved: number }>();
  for (const job of filteredJobs) {
    const name = job.source_board || "Unknown";
    const prev = boardMap.get(name) || { found: 0, saved: 0 };
    boardMap.set(name, {
      found: prev.found + 1,
      saved: prev.saved + (job.status === "saved" ? 1 : 0),
    });
  }
  const boardData = Array.from(boardMap.entries())
    .sort((a, b) => b[1].found - a[1].found)
    .slice(0, 10)
    .map(([name, stats]) => ({
      name: name.length > 18 ? name.slice(0, 16) + "…" : name,
      found: stats.found,
      matched: stats.saved,
    }));

  // Top keywords by effectiveness
  const keywordData = keywords.slice(0, 12).map((k) => ({
    keyword: k.keyword.length > 20 ? k.keyword.slice(0, 18) + "…" : k.keyword,
    effectiveness: Math.round(k.effectiveness_score || 0),
    jobsFound: k.jobs_found,
    matches: k.matches_produced,
  }));

  // ─── Render ────────────────────────────────────────────────────────────────

  return (
    <DashboardLayout
      title="Pipeline Analytics"
      subtitle="Firecrawl credit efficiency, match rates & rejection analysis"
    >
      <div className="space-y-6 max-w-7xl mx-auto">

        {/* Candidate Filter */}
        <div className="flex items-center gap-4">
          <label className="text-sm font-medium text-muted-foreground whitespace-nowrap">Filter by candidate:</label>
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger className="w-72">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Candidates (aggregate)</SelectItem>
              {candidates.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.name}{c.current_title ? ` — ${c.current_title}` : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex items-center gap-2 ml-auto">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <Switch id="hide-oversized" checked={hideOversized} onCheckedChange={setHideOversized} />
            <Label htmlFor="hide-oversized" className="text-sm text-muted-foreground cursor-pointer">
              Hide oversized companies
            </Label>
          </div>
        </div>

        {/* KPI Row */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-2xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard icon={Zap} label="Est. Firecrawl Credits" value={estimatedCredits.toLocaleString()} sub={`${totalSearchCalls} search calls`} color="text-warning" />
            <StatCard icon={Target} label="Jobs per API Call" value={jobsPerCall} sub={`${totalJobsDiscovered.toLocaleString()} total discovered`} color="text-primary" />
            <StatCard icon={TrendingUp} label="Save Rate" value={`${saveRate}%`} sub={`${saved} saved of ${totalJobs} total`} color="text-success" />
            <StatCard icon={BarChart2} label="Avg Match Score" value={avgMatchScore} sub="across all scored jobs" color="text-accent-foreground" />
            <StatCard icon={CheckCircle} label="Jobs Saved" value={saved.toLocaleString()} color="text-success" />
            <StatCard icon={XCircle} label="Jobs Rejected" value={rejected.toLocaleString()} sub={`${totalJobs > 0 ? Math.round((rejected/totalJobs)*100) : 0}% of total`} color="text-destructive" />
            <StatCard icon={Clock} label="Jobs Pending Score" value={pending.toLocaleString()} color="text-warning" />
            <StatCard icon={AlertTriangle} label="Rejection Reasons" value={rejectionData.length} sub="distinct categories" color="text-muted-foreground" />
          </div>
        )}

        {/* Charts Row 1: Rejection Breakdown + Board Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* Rejection Breakdown */}
          <Card className="bg-card border-border shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <XCircle className="w-4 h-4 text-destructive" />
                Rejection Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-48 w-full rounded-xl" />
              ) : rejectionData.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-10">No rejection data yet</p>
              ) : (
                <div className="space-y-3">
                  {rejectionData.map((d) => (
                    <div key={d.rawReason} className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ background: rejectionColor(d.rawReason) }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-0.5">
                          <span className="text-xs font-medium text-card-foreground truncate">{d.reason}</span>
                          <span className="text-xs text-muted-foreground ml-2 flex-shrink-0">{d.count} ({d.pct}%)</span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all"
                            style={{ width: `${d.pct}%`, background: rejectionColor(d.rawReason) }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Jobs per Board */}
          <Card className="bg-card border-border shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-primary" />
                Jobs Found per Board (Top 10)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-48 w-full rounded-xl" />
              ) : boardData.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-10">No board data yet</p>
              ) : (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={boardData} layout="vertical" margin={{ left: 0, right: 16, top: 0, bottom: 0 }}>
                    <XAxis type="number" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                    <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={110} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                      formatter={(val: number, name: string) => [val, name === "found" ? "Discovered" : "Saved"]}
                    />
                    <Bar dataKey="found" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} name="found" />
                    <Bar dataKey="matched" fill="hsl(var(--success))" radius={[0, 4, 4, 0]} name="matched" />
                  </BarChart>
                </ResponsiveContainer>
              )}
              {!loading && boardData.length > 0 && (
                <div className="flex items-center gap-4 mt-2 justify-end">
                  <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-sm bg-primary" /><span className="text-xs text-muted-foreground">Discovered</span></div>
                  <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-sm bg-success" /><span className="text-xs text-muted-foreground">Saved</span></div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2: Keyword Effectiveness + Credit Estimate Breakdown */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* Keyword Effectiveness */}
          <Card className="bg-card border-border shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-success" />
                Keyword Effectiveness (Top 12)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-64 w-full rounded-xl" />
              ) : keywordData.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-10">No keyword data yet</p>
              ) : (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={keywordData} margin={{ left: 0, right: 8, top: 4, bottom: 40 }}>
                    <XAxis dataKey="keyword" tick={{ fontSize: 10 }} angle={-35} textAnchor="end" interval={0} tickLine={false} axisLine={false} />
                    <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                      formatter={(val: number, name: string) => [
                        name === "effectiveness" ? `${val}` : val,
                        name === "effectiveness" ? "Effectiveness Score" : name === "jobsFound" ? "Jobs Found" : "Matches",
                      ]}
                    />
                    <Bar dataKey="effectiveness" radius={[4, 4, 0, 0]}>
                      {keywordData.map((d, i) => (
                        <Cell
                          key={i}
                          fill={d.effectiveness >= 60 ? "hsl(var(--success))" : d.effectiveness >= 30 ? "hsl(var(--warning))" : "hsl(var(--destructive))"}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Credit Estimate Card */}
          <Card className="bg-card border-border shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Zap className="w-4 h-4 text-warning" />
                API Credit Estimate
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {loading ? (
                <Skeleton className="h-48 w-full rounded-xl" />
              ) : (
                <>
                  <p className="text-xs text-muted-foreground">
                    Based on logged search feedback calls. Each Firecrawl search call is estimated at ~{CREDITS_PER_SEARCH_CALL} credits.
                    Native scrape calls (links-only) are ~{CREDITS_PER_SCRAPE_CALL} credit each.
                  </p>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-sm text-muted-foreground">Search API calls</span>
                      <Badge variant="outline">{totalSearchCalls.toLocaleString()}</Badge>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-sm text-muted-foreground">Estimated credits used</span>
                      <Badge variant="outline" className="text-warning border-warning/40">{estimatedCredits.toLocaleString()}</Badge>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-sm text-muted-foreground">Total jobs discovered</span>
                      <Badge variant="outline">{totalJobsDiscovered.toLocaleString()}</Badge>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-sm text-muted-foreground">Jobs per credit (est.)</span>
                      <Badge variant="outline" className="text-primary border-primary/40">
                        {estimatedCredits > 0 ? (totalJobsDiscovered / estimatedCredits).toFixed(2) : "—"}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center py-2">
                      <span className="text-sm text-muted-foreground">Saved matches per credit</span>
                      <Badge variant="outline" className="text-success border-success/40">
                        {estimatedCredits > 0 ? (saved / estimatedCredits).toFixed(3) : "—"}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground/70 pt-1">
                    ⚡ Credit counts are estimates. Check your Firecrawl dashboard for exact usage.
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Weekly Credit Comparison */}
        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Zap className="w-4 h-4 text-warning" />
              Firecrawl Credit Usage — This Week vs Last Week
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-36 w-full rounded-xl" />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                {/* Credits */}
                <div className="flex flex-col gap-1">
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Est. Credits Used</p>
                  <div className="flex items-end gap-2">
                    <span className="text-3xl font-bold text-card-foreground">{thisWeekCredits.toLocaleString()}</span>
                    {creditDelta !== null && (
                      <span className={`flex items-center gap-0.5 text-sm font-semibold pb-0.5 ${creditDelta < 0 ? "text-success" : creditDelta > 0 ? "text-destructive" : "text-muted-foreground"}`}>
                        {creditDelta < 0 ? <ArrowDown className="w-3.5 h-3.5" /> : creditDelta > 0 ? <ArrowUp className="w-3.5 h-3.5" /> : <Minus className="w-3.5 h-3.5" />}
                        {Math.abs(creditDelta)}%
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Last week: <span className="font-medium text-card-foreground">{lastWeekCredits.toLocaleString()}</span>
                  </p>
                  <p className="text-xs text-muted-foreground/60 mt-1">↓ lower is better</p>
                </div>

                {/* Jobs Discovered */}
                <div className="flex flex-col gap-1">
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Jobs Discovered</p>
                  <div className="flex items-end gap-2">
                    <span className="text-3xl font-bold text-card-foreground">{thisWeekDiscovered.toLocaleString()}</span>
                    {discoveredDelta !== null && (
                      <span className={`flex items-center gap-0.5 text-sm font-semibold pb-0.5 ${discoveredDelta > 0 ? "text-success" : discoveredDelta < 0 ? "text-destructive" : "text-muted-foreground"}`}>
                        {discoveredDelta > 0 ? <ArrowUp className="w-3.5 h-3.5" /> : discoveredDelta < 0 ? <ArrowDown className="w-3.5 h-3.5" /> : <Minus className="w-3.5 h-3.5" />}
                        {Math.abs(discoveredDelta)}%
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Last week: <span className="font-medium text-card-foreground">{lastWeekDiscovered.toLocaleString()}</span>
                  </p>
                  <p className="text-xs text-muted-foreground/60 mt-1">↑ higher is better</p>
                </div>

                {/* Jobs Matched */}
                <div className="flex flex-col gap-1">
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Jobs Matched</p>
                  <div className="flex items-end gap-2">
                    <span className="text-3xl font-bold text-card-foreground">{thisWeekMatched.toLocaleString()}</span>
                    {matchedDelta !== null && (
                      <span className={`flex items-center gap-0.5 text-sm font-semibold pb-0.5 ${matchedDelta > 0 ? "text-success" : matchedDelta < 0 ? "text-destructive" : "text-muted-foreground"}`}>
                        {matchedDelta > 0 ? <ArrowUp className="w-3.5 h-3.5" /> : matchedDelta < 0 ? <ArrowDown className="w-3.5 h-3.5" /> : <Minus className="w-3.5 h-3.5" />}
                        {Math.abs(matchedDelta)}%
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Last week: <span className="font-medium text-card-foreground">{lastWeekMatched.toLocaleString()}</span>
                  </p>
                  <p className="text-xs text-muted-foreground/60 mt-1">↑ higher is better</p>
                </div>
              </div>
            )}
            {!loading && (
              <p className="text-xs text-muted-foreground/60 mt-4 pt-3 border-t border-border">
                ⚡ Credits estimated at ~{CREDITS_PER_SEARCH_CALL} per Firecrawl search call. Week starts Sunday.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Keyword Table */}
        {!loading && keywords.length > 0 && (
          <Card className="bg-card border-border shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Keyword Performance Detail</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-2 px-3 text-xs font-medium text-muted-foreground">Keyword</th>
                      <th className="text-right py-2 px-3 text-xs font-medium text-muted-foreground">Times Used</th>
                      <th className="text-right py-2 px-3 text-xs font-medium text-muted-foreground">Jobs Found</th>
                      <th className="text-right py-2 px-3 text-xs font-medium text-muted-foreground">Matches</th>
                      <th className="text-right py-2 px-3 text-xs font-medium text-muted-foreground">Effectiveness</th>
                    </tr>
                  </thead>
                  <tbody>
                    {keywords.map((k) => {
                      const eff = Math.round(k.effectiveness_score || 0);
                      return (
                        <tr key={k.keyword} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                          <td className="py-2 px-3 font-medium text-card-foreground">{k.keyword}</td>
                          <td className="py-2 px-3 text-right text-muted-foreground">{k.times_used}</td>
                          <td className="py-2 px-3 text-right text-muted-foreground">{k.jobs_found}</td>
                          <td className="py-2 px-3 text-right text-muted-foreground">{k.matches_produced}</td>
                          <td className="py-2 px-3 text-right">
                            <span className={`font-semibold ${eff >= 60 ? "text-success" : eff >= 30 ? "text-warning" : "text-destructive"}`}>
                              {eff}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
