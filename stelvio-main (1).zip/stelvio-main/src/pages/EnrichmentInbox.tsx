import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Search,
  RefreshCw,
  AlertTriangle,
  Globe,
  Clock,
  MoreHorizontal,
  Linkedin,
  Inbox,
  Shield,
  Zap,
  CheckSquare,
  Rocket,
} from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { EnrichmentHealth } from "@/components/dashboard/EnrichmentHealth";

type FailureType =
  | "bc_stuck"
  | "bc_orphan"
  | "domain_unresolved"
  | "domain_low_confidence"
  | "all_tiers_failed"
  | "low_confidence_email";

interface InboxItem {
  stakeholder_id: string;
  stakeholder_name: string;
  stakeholder_title: string | null;
  stakeholder_linkedin: string | null;
  stakeholder_email: string | null;
  email_confidence: number | null;
  company_id: string | null;
  company_name: string | null;
  company_domain: string | null;
  domain_status: string | null;
  domain_quality_score: number | null;
  bc_task_id: string | null;
  bc_status: string | null;
  bc_submitted_at: string | null;
  bc_last_polled: string | null;
  attempt_id: string | null;
  attempt_status: string | null;
  attempt_started: string | null;
  attempt_error: string | null;
  failure_type: FailureType;
  age: string;
  reason: string;
}

const FILTER_OPTIONS: { value: FailureType | "all"; label: string; icon: React.ReactNode }[] = [
  { value: "all", label: "All Failures", icon: <Inbox className="w-3.5 h-3.5" /> },
  { value: "bc_stuck", label: "Stuck BC", icon: <Clock className="w-3.5 h-3.5" /> },
  { value: "bc_orphan", label: "Orphan BC", icon: <AlertTriangle className="w-3.5 h-3.5" /> },
  { value: "domain_unresolved", label: "Domain Missing", icon: <Globe className="w-3.5 h-3.5" /> },
  { value: "domain_low_confidence", label: "Domain Weak", icon: <Shield className="w-3.5 h-3.5" /> },
  { value: "all_tiers_failed", label: "All Tiers Failed", icon: <Zap className="w-3.5 h-3.5" /> },
  { value: "low_confidence_email", label: "Low Confidence", icon: <AlertTriangle className="w-3.5 h-3.5" /> },
];

const FAILURE_BADGE_MAP: Record<FailureType, { label: string; variant: "destructive" | "secondary" | "outline" | "default" }> = {
  bc_stuck: { label: "BC Stuck", variant: "destructive" },
  bc_orphan: { label: "BC Orphan", variant: "destructive" },
  domain_unresolved: { label: "Domain Missing", variant: "secondary" },
  domain_low_confidence: { label: "Domain Weak", variant: "outline" },
  all_tiers_failed: { label: "All Failed", variant: "destructive" },
  low_confidence_email: { label: "Low Confidence", variant: "outline" },
};

function deriveReason(item: Omit<InboxItem, "reason">): string {
  switch (item.failure_type) {
    case "bc_stuck": {
      const age = item.bc_submitted_at
        ? formatDistanceToNow(new Date(item.bc_submitted_at))
        : "unknown";
      return `BetterContact task pending for ${age}${item.bc_last_polled ? `, last polled ${formatDistanceToNow(new Date(item.bc_last_polled), { addSuffix: true })}` : ", never polled"}`;
    }
    case "bc_orphan":
      return "Marked pending but no BetterContact task ID — submission may have failed";
    case "domain_unresolved":
      return `No valid domain found${item.domain_quality_score !== null ? ` (best score: ${(item.domain_quality_score * 100).toFixed(0)}%)` : ""}`;
    case "domain_low_confidence":
      return `Domain "${item.company_domain}" scored ${item.domain_quality_score !== null ? (item.domain_quality_score * 100).toFixed(0) + "%" : "low"} — may be incorrect`;
    case "all_tiers_failed":
      return item.attempt_error
        ? `All enrichment tiers exhausted: ${item.attempt_error.slice(0, 80)}`
        : "All enrichment tiers exhausted without finding an email";
    case "low_confidence_email":
      return `Email "${item.stakeholder_email}" has ${item.email_confidence !== null ? (item.email_confidence * 100).toFixed(0) + "%" : "low"} confidence — may bounce`;
    default:
      return "Unknown failure";
  }
}

function classifyFailures(stakeholders: any[], companies: Map<string, any>, attempts: Map<string, any>): InboxItem[] {
  const items: InboxItem[] = [];
  const thirtyMinsAgo = new Date(Date.now() - 30 * 60 * 1000).toISOString();
  const confidenceThreshold = 0.5;

  for (const s of stakeholders) {
    const company = s.company_id ? companies.get(s.company_id) : null;
    const attempt = attempts.get(s.id);

    const base = {
      stakeholder_id: s.id,
      stakeholder_name: s.name,
      stakeholder_title: s.title,
      stakeholder_linkedin: s.linkedin_url,
      stakeholder_email: s.email,
      email_confidence: s.email_confidence,
      company_id: s.company_id,
      company_name: company?.name || null,
      company_domain: company?.domain || null,
      domain_status: company?.domain_status || null,
      domain_quality_score: company?.domain_quality_score || null,
      bc_task_id: s.bettercontact_task_id,
      bc_status: s.bettercontact_status,
      bc_submitted_at: s.bettercontact_submitted_at,
      bc_last_polled: s.bettercontact_last_polled_at,
      attempt_id: attempt?.id || null,
      attempt_status: attempt?.status || null,
      attempt_started: attempt?.started_at || null,
      attempt_error: attempt?.error || null,
    };

    let failureType: FailureType | null = null;

    if (s.bettercontact_status === "pending" && s.bettercontact_task_id && s.bettercontact_submitted_at && s.bettercontact_submitted_at < thirtyMinsAgo) {
      failureType = "bc_stuck";
    } else if (s.bettercontact_status === "pending" && !s.bettercontact_task_id) {
      failureType = "bc_orphan";
    } else if (company && company.domain_status === "unresolved") {
      failureType = "domain_unresolved";
    } else if (company && company.domain_status === "low_confidence") {
      failureType = "domain_low_confidence";
    } else if (attempt && attempt.status === "failed") {
      failureType = "all_tiers_failed";
    } else if (s.email && s.email_confidence !== null && s.email_confidence < confidenceThreshold && s.email_status !== "verified") {
      failureType = "low_confidence_email";
    }

    if (failureType) {
      const age = failureType === "bc_stuck" ? s.bettercontact_submitted_at :
        failureType === "bc_orphan" ? s.created_at :
        failureType.startsWith("domain") ? (company?.updated_at || s.updated_at) :
        failureType === "all_tiers_failed" ? attempt.started_at :
        s.updated_at;

      const partial = { ...base, failure_type: failureType, age, reason: "" };
      partial.reason = deriveReason(partial);
      items.push(partial as InboxItem);
    }
  }

  return items.sort((a, b) => new Date(a.age).getTime() - new Date(b.age).getTime());
}

export default function EnrichmentInbox() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FailureType | "all">("all");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: inboxItems, isLoading } = useQuery({
    queryKey: ["enrichment-inbox"],
    queryFn: async () => {
      const { data: stakeholders } = await supabase
        .from("stakeholders")
        .select("id, name, title, linkedin_url, email, email_confidence, email_status, company_id, bettercontact_task_id, bettercontact_status, bettercontact_submitted_at, bettercontact_last_polled_at, enrichment_source, created_at, updated_at")
        .or("bettercontact_status.eq.pending,email.is.null,email_confidence.lt.0.5")
        .limit(500);

      if (!stakeholders?.length) return [];

      const companyIds = [...new Set(stakeholders.map(s => s.company_id).filter(Boolean))] as string[];
      const companyMap = new Map<string, any>();

      if (companyIds.length > 0) {
        const { data: companies } = await supabase
          .from("companies")
          .select("id, name, domain, domain_status, domain_quality_score, domain_quality_reasons, updated_at")
          .in("id", companyIds);
        companies?.forEach(c => companyMap.set(c.id, c));
      }

      const stakeholderIds = stakeholders.map(s => s.id);
      const attemptMap = new Map<string, any>();
      const { data: attempts } = await supabase
        .from("stakeholder_enrichment_attempts")
        .select("id, stakeholder_id, status, started_at, finished_at, final_email, error, trace")
        .in("stakeholder_id", stakeholderIds)
        .order("started_at", { ascending: false });

      attempts?.forEach(a => {
        if (!attemptMap.has(a.stakeholder_id)) attemptMap.set(a.stakeholder_id, a);
      });

      return classifyFailures(stakeholders, companyMap, attemptMap);
    },
    refetchInterval: 30000,
  });

  const forcePollMutation = useMutation({
    mutationFn: async (stakeholderId: string) => {
      const { data, error } = await supabase.functions.invoke("poll-bettercontact-tasks", {
        body: { stakeholder_id: stakeholderId },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success("Force poll triggered");
      queryClient.invalidateQueries({ queryKey: ["enrichment-inbox"] });
    },
    onError: (e) => toast.error(`Poll failed: ${e.message}`),
  });

  const rerunMutation = useMutation({
    mutationFn: async (stakeholderId: string) => {
      const { data, error } = await supabase.functions.invoke("enrich-contact-bettercontact", {
        body: { stakeholder_id: stakeholderId, mode: "debug" },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success("Re-run triggered");
      queryClient.invalidateQueries({ queryKey: ["enrichment-inbox"] });
    },
    onError: (e) => toast.error(`Re-run failed: ${e.message}`),
  });

  // Bulk actions
  const bulkForcePollMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const batch = ids.slice(0, 30);
      const results = await Promise.allSettled(
        batch.map(id =>
          supabase.functions.invoke("poll-bettercontact-tasks", { body: { stakeholder_id: id } })
        )
      );
      const succeeded = results.filter(r => r.status === "fulfilled").length;
      const failed = results.filter(r => r.status === "rejected").length;
      return { succeeded, failed };
    },
    onSuccess: ({ succeeded, failed }) => {
      toast.success(`Bulk poll: ${succeeded} ok, ${failed} failed`);
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["enrichment-inbox"] });
    },
    onError: (e) => toast.error(`Bulk poll failed: ${e.message}`),
  });

  const bulkRerunMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const batch = ids.slice(0, 10);
      const results = await Promise.allSettled(
        batch.map(id =>
          supabase.functions.invoke("enrich-contact-bettercontact", { body: { stakeholder_id: id, mode: "debug" } })
        )
      );
      const succeeded = results.filter(r => r.status === "fulfilled").length;
      return { succeeded, failed: batch.length - succeeded };
    },
    onSuccess: ({ succeeded, failed }) => {
      toast.success(`Bulk re-run: ${succeeded} ok, ${failed} failed`);
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["enrichment-inbox"] });
    },
    onError: (e) => toast.error(`Bulk re-run failed: ${e.message}`),
  });

  const bulkMarkTimeoutMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const { error } = await supabase
        .from("stakeholders")
        .update({ bettercontact_status: "error", notes: "Manually marked as timeout" })
        .in("id", ids);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Marked as timeout");
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["enrichment-inbox"] });
    },
    onError: (e) => toast.error(`Failed: ${e.message}`),
  });

  // Bulk domain resolution sweep
  const bulkDomainSweepMutation = useMutation({
    mutationFn: async (companyIds: string[]) => {
      const uniqueIds = [...new Set(companyIds)].slice(0, 25);
      const { data: companies } = await supabase
        .from("companies")
        .select("id, name")
        .in("id", uniqueIds);
      if (!companies?.length) throw new Error("No companies found");
      
      const results = await Promise.allSettled(
        companies.map(c =>
          supabase.functions.invoke("lookup-company-domain", {
            body: { companyName: c.name, companyId: c.id, quickMode: false, force: true },
          })
        )
      );
      const succeeded = results.filter(r => r.status === "fulfilled").length;
      return { succeeded, failed: companies.length - succeeded, total: companies.length };
    },
    onSuccess: ({ succeeded, failed, total }) => {
      toast.success(`Domain sweep: ${succeeded}/${total} resolved, ${failed} failed`);
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["enrichment-inbox"] });
      queryClient.invalidateQueries({ queryKey: ["enrichment-health"] });
    },
    onError: (e) => toast.error(`Domain sweep failed: ${e.message}`),
  });

  // Tier 1 enrichment sweep
  const [tier1Running, setTier1Running] = useState(false);
  const [tier1Summary, setTier1Summary] = useState<Record<string, number> | null>(null);
  const tier1Mutation = useMutation({
    mutationFn: async (stakeholderIds?: string[]) => {
      const body: Record<string, unknown> = { batch_size: 25 };
      if (stakeholderIds?.length) body.stakeholder_ids = stakeholderIds;
      const { data, error } = await supabase.functions.invoke("tier1-enrich", { body });
      if (error) throw error;
      return data;
    },
    onMutate: () => setTier1Running(true),
    onSuccess: (data) => {
      setTier1Running(false);
      const { email_found = 0, pattern_generated = 0, bc_pending = 0, not_found = 0, errors = 0, processed = 0 } = data || {};
      setTier1Summary({ email_found, pattern_generated, bc_pending, not_found, errors, processed });
      toast.success(`Tier 1: ${email_found + pattern_generated} emails found, ${bc_pending} pending, ${not_found} not found (${processed} processed)`);
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["enrichment-inbox"] });
      queryClient.invalidateQueries({ queryKey: ["enrichment-health"] });
    },
    onError: (e) => {
      setTier1Running(false);
      toast.error(`Tier 1 failed: ${e.message}`);
    },
  });

  const filtered = (inboxItems || []).filter(item => {
    if (filter !== "all" && item.failure_type !== filter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        item.stakeholder_name.toLowerCase().includes(q) ||
        (item.company_name || "").toLowerCase().includes(q) ||
        (item.company_domain || "").toLowerCase().includes(q)
      );
    }
    return true;
  });

  const counts = (inboxItems || []).reduce((acc, item) => {
    acc[item.failure_type] = (acc[item.failure_type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const toggleSelect = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selected.size === filtered.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filtered.map(i => i.stakeholder_id)));
    }
  };

  const selectedItems = filtered.filter(i => selected.has(i.stakeholder_id));
  const selectedBcStuck = selectedItems.filter(i => i.failure_type === "bc_stuck");
  const selectedAllFailed = selectedItems.filter(i => i.failure_type === "all_tiers_failed");
  const selectedDomainWeak = selectedItems.filter(i => i.failure_type === "domain_low_confidence" || i.failure_type === "domain_unresolved");
  const isBulkPending = bulkForcePollMutation.isPending || bulkRerunMutation.isPending || bulkMarkTimeoutMutation.isPending || bulkDomainSweepMutation.isPending || tier1Running;

  return (
    <DashboardLayout title="Enrichment Inbox">
      <div className="space-y-6">
        {/* KPI Widget */}
        <EnrichmentHealth />

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Failures Inbox</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {filtered.length} actionable failure{filtered.length !== 1 ? "s" : ""}
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => queryClient.invalidateQueries({ queryKey: ["enrichment-inbox"] })}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button
            size="sm"
            disabled={tier1Running}
            onClick={() => tier1Mutation.mutate(undefined)}
            className="gap-1.5"
          >
            <Rocket className="w-4 h-4" />
            {tier1Running ? "Running Tier 1…" : "Run Tier 1 Sweep"}
          </Button>
        </div>

        {/* Search + Filters */}
        <div className="space-y-3">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search company or stakeholder..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {FILTER_OPTIONS.map((opt) => (
              <Button
                key={opt.value}
                variant={filter === opt.value ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter(opt.value)}
                className="gap-1.5"
              >
                {opt.icon}
                {opt.label}
                {opt.value !== "all" && counts[opt.value] ? (
                  <Badge variant="secondary" className="ml-1 text-xs px-1.5 py-0">
                    {counts[opt.value]}
                  </Badge>
                ) : null}
              </Button>
            ))}
          </div>
        </div>

        {/* Tier 1 Summary */}
        {tier1Summary && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="py-3 px-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-sm">
                  <span className="font-medium">Tier 1 Results:</span>
                  <span className="text-primary">{tier1Summary.email_found + tier1Summary.pattern_generated} emails found</span>
                  <span className="text-accent-foreground">{tier1Summary.bc_pending} pending</span>
                  <span className="text-muted-foreground">{tier1Summary.not_found} not found</span>
                  {tier1Summary.errors > 0 && <span className="text-destructive">{tier1Summary.errors} errors</span>}
                  <span className="text-muted-foreground">({tier1Summary.processed} processed)</span>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setTier1Summary(null)}>Dismiss</Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Bulk Actions */}
        {selected.size > 0 && (
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 border border-border">
            <CheckSquare className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">{selected.size} selected</span>
            <div className="flex gap-2 ml-auto">
              {selectedBcStuck.length > 0 && (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={isBulkPending}
                    onClick={() => bulkForcePollMutation.mutate(selectedBcStuck.map(i => i.stakeholder_id))}
                  >
                    Force Poll ({selectedBcStuck.length})
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={isBulkPending}
                    onClick={() => bulkMarkTimeoutMutation.mutate(selectedBcStuck.map(i => i.stakeholder_id))}
                  >
                    Mark Timeout ({selectedBcStuck.length})
                  </Button>
                </>
              )}
              {selectedAllFailed.length > 0 && (
                <Button
                  size="sm"
                  variant="outline"
                  disabled={isBulkPending}
                  onClick={() => bulkRerunMutation.mutate(selectedAllFailed.map(i => i.stakeholder_id))}
                >
                  Re-run Debug ({selectedAllFailed.length})
                </Button>
              )}
              {selectedDomainWeak.length > 0 && (
                <Button
                  size="sm"
                  variant="outline"
                  disabled={isBulkPending}
                  onClick={() => {
                    const companyIds = selectedDomainWeak.map(i => i.company_id).filter(Boolean) as string[];
                    bulkDomainSweepMutation.mutate(companyIds);
                  }}
                >
                  <Globe className="w-3.5 h-3.5 mr-1" />
                  Re-resolve Domains ({[...new Set(selectedDomainWeak.map(i => i.company_id).filter(Boolean))].length})
                </Button>
              )}
              <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>
                Clear
              </Button>
            </div>
          </div>
        )}

        {/* List */}
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-lg" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Inbox className="w-12 h-12 mx-auto text-muted-foreground/40 mb-3" />
              <p className="text-muted-foreground font-medium">Inbox is clear</p>
              <p className="text-sm text-muted-foreground/60 mt-1">No enrichment failures match your filters</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {/* Select all */}
            <div className="flex items-center gap-2 px-4 py-1">
              <Checkbox
                checked={selected.size === filtered.length && filtered.length > 0}
                onCheckedChange={toggleSelectAll}
              />
              <span className="text-xs text-muted-foreground">Select all</span>
            </div>

            {filtered.map((item) => {
              const badge = FAILURE_BADGE_MAP[item.failure_type];
              return (
                <Card key={`${item.stakeholder_id}-${item.failure_type}`} className="hover:border-accent/40 transition-colors">
                  <CardContent className="py-3 px-4">
                    <div className="flex items-start gap-3">
                      {/* Checkbox */}
                      <div className="pt-1">
                        <Checkbox
                          checked={selected.has(item.stakeholder_id)}
                          onCheckedChange={() => toggleSelect(item.stakeholder_id)}
                        />
                      </div>

                      {/* Company */}
                      <div className="min-w-[160px]">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-foreground truncate">
                            {item.company_name || "No company"}
                          </span>
                        </div>
                        {item.company_domain && (
                          <span className="text-xs text-muted-foreground font-mono">{item.company_domain}</span>
                        )}
                        {item.domain_status && (
                          <div className="mt-0.5">
                            <Badge
                              variant={item.domain_status === "resolved" ? "default" : item.domain_status === "low_confidence" ? "outline" : "secondary"}
                              className="text-[10px]"
                            >
                              {item.domain_status}
                            </Badge>
                          </div>
                        )}
                      </div>

                      {/* Stakeholder */}
                      <div className="min-w-[120px]">
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-medium truncate">{item.stakeholder_name}</span>
                          {item.stakeholder_linkedin && (
                            <a href={item.stakeholder_linkedin} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary">
                              <Linkedin className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>
                        {item.stakeholder_title && (
                          <p className="text-xs text-muted-foreground truncate">{item.stakeholder_title}</p>
                        )}
                      </div>

                      {/* Failure badge */}
                      <Badge variant={badge.variant} className="shrink-0 mt-0.5">
                        {badge.label}
                      </Badge>

                      {/* Reason - NEW */}
                      <p className="flex-1 text-xs text-muted-foreground leading-snug min-w-0">
                        {item.reason}
                      </p>

                      {/* Age */}
                      <span className="text-xs text-muted-foreground whitespace-nowrap w-20 text-right shrink-0">
                        {formatDistanceToNow(new Date(item.age), { addSuffix: true })}
                      </span>

                      {/* Primary CTA */}
                      <div className="shrink-0">
                        {(item.failure_type === "bc_stuck") && (
                          <Button size="sm" variant="outline" onClick={() => forcePollMutation.mutate(item.stakeholder_id)} disabled={forcePollMutation.isPending}>
                            Force Poll
                          </Button>
                        )}
                        {(item.failure_type === "bc_orphan") && (
                          <Button size="sm" variant="outline" onClick={() => rerunMutation.mutate(item.stakeholder_id)} disabled={rerunMutation.isPending}>
                            Re-submit
                          </Button>
                        )}
                        {(item.failure_type === "domain_unresolved" || item.failure_type === "domain_low_confidence") && item.company_id && (
                          <Button size="sm" variant="outline" onClick={() => navigate(`/enrichment/company/${item.company_id}`)}>
                            Review
                          </Button>
                        )}
                        {(item.failure_type === "all_tiers_failed") && (
                          <Button size="sm" variant="outline" onClick={() => rerunMutation.mutate(item.stakeholder_id)} disabled={rerunMutation.isPending}>
                            Re-run
                          </Button>
                        )}
                        {(item.failure_type === "low_confidence_email") && (
                          <Button size="sm" variant="outline" onClick={() => rerunMutation.mutate(item.stakeholder_id)} disabled={rerunMutation.isPending}>
                            Re-discover
                          </Button>
                        )}
                      </div>

                      {/* Secondary menu */}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => navigate(`/enrichment/stakeholder/${item.stakeholder_id}`)}>
                            Open Timeline
                          </DropdownMenuItem>
                          {item.company_id && (
                            <DropdownMenuItem onClick={() => navigate(`/enrichment/company/${item.company_id}`)}>
                              Company Inspector
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem onClick={() => navigate(`/stakeholders/${item.stakeholder_id}`)}>
                            View Stakeholder
                          </DropdownMenuItem>
                          {item.company_id && (
                            <DropdownMenuItem onClick={() => navigate(`/companies/${item.company_id}`)}>
                              View Company
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
