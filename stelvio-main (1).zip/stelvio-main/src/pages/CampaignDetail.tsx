import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Play, Pause, Users, Mail, BarChart3 } from "lucide-react";
import { toast } from "sonner";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { CampaignStepsManager } from "@/components/campaigns/CampaignStepsManager";
import { CampaignStakeholders } from "@/components/campaigns/CampaignStakeholders";
import { CampaignMetrics } from "@/components/campaigns/CampaignMetrics";

interface Campaign {
  id: string;
  name: string;
  description: string | null;
  status: string;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
  send_time_hour: number | null;
  send_time_minute: number | null;
  send_time_period: string | null;
}

const formatSendTime = (campaign: Campaign) => {
  if (!campaign.send_time_hour || !campaign.send_time_period) return null;
  const minute = (campaign.send_time_minute ?? 0).toString().padStart(2, "0");
  return `${campaign.send_time_hour}:${minute} ${campaign.send_time_period}`;
};

export default function CampaignDetail() {
  const { formatDate, formatDateTime } = useLocaleFormat();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("steps");

  const { data: campaign, isLoading } = useQuery({
    queryKey: ["campaign", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("campaigns")
        .select("*")
        .eq("id", id)
        .single();

      if (error) throw error;
      return data as Campaign;
    },
    enabled: !!id,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const updates: any = { status };
      if (status === "running") {
        updates.started_at = new Date().toISOString();
      } else if (status === "completed") {
        updates.completed_at = new Date().toISOString();
      }
      const { error } = await supabase.from("campaigns").update(updates).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaign", id] });
      toast.success("Campaign status updated");
    },
    onError: (error: any) => {
      toast.error("Failed to update status: " + error.message);
    },
  });

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      draft: "secondary",
      running: "default",
      paused: "outline",
      completed: "secondary",
    };
    return <Badge variant={variants[status] || "secondary"}>{status}</Badge>;
  };

  if (isLoading) {
    return (
      <DashboardLayout title="Campaign">
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Loading campaign...</p>
        </div>
      </DashboardLayout>
    );
  }

  if (!campaign) {
    return (
      <DashboardLayout title="Campaign Not Found">
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <p className="text-muted-foreground">Campaign not found</p>
          <Button variant="outline" onClick={() => navigate("/campaigns")}>
            Back to Campaigns
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title={campaign.name}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/campaigns")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-3xl font-bold text-foreground">{campaign.name}</h1>
                {getStatusBadge(campaign.status)}
              </div>
              {campaign.description && (
                <p className="text-muted-foreground mt-1">{campaign.description}</p>
              )}
              <p className="text-sm text-muted-foreground mt-2">
                Created {formatDate(campaign.created_at)}
                {campaign.started_at &&
                  ` • Started ${formatDateTime(campaign.started_at)}`}
                {formatSendTime(campaign) && ` • Sends at ${formatSendTime(campaign)}`}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {campaign.status === "draft" && (
              <Button onClick={() => updateStatusMutation.mutate("running")}>
                <Play className="w-4 h-4 mr-2" />
                Start Campaign
              </Button>
            )}
            {campaign.status === "running" && (
              <Button variant="outline" onClick={() => updateStatusMutation.mutate("paused")}>
                <Pause className="w-4 h-4 mr-2" />
                Pause
              </Button>
            )}
            {campaign.status === "paused" && (
              <Button onClick={() => updateStatusMutation.mutate("running")}>
                <Play className="w-4 h-4 mr-2" />
                Resume
              </Button>
            )}
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="steps" className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Steps
            </TabsTrigger>
            <TabsTrigger value="stakeholders" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Stakeholders
            </TabsTrigger>
            <TabsTrigger value="metrics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Metrics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="steps" className="mt-6">
            <CampaignStepsManager campaignId={campaign.id} campaignStatus={campaign.status} />
          </TabsContent>

          <TabsContent value="stakeholders" className="mt-6">
            <CampaignStakeholders campaignId={campaign.id} />
          </TabsContent>

          <TabsContent value="metrics" className="mt-6">
            <CampaignMetrics campaignId={campaign.id} />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
