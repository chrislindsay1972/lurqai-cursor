import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  AlertTriangle, CheckCircle2, XCircle, Clock, Search, Zap,
  ArrowRight, Filter, Brain, Database, Globe, ChevronDown, ChevronUp,
  RefreshCw, Activity,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

interface PipelineEvent {
  id: string;
  candidate_id: string;
  event_type: string;
  message: string;
  created_at: string;
}

interface CandidateOption {
  id: string;
  name: string;
  updated_at: string;
}

// The pipeline flow steps in logical order
const PIPELINE_FLOW = [
  { key: 'auth', label: 'Authentication', icon: Database, description: 'Verify user credentials and permissions' },
  { key: 'settings', label: 'Load Settings', icon: Database, description: 'Fetch thresholds, caps, and AI instructions' },
  { key: 'boards', label: 'Board Selection', icon: Filter, description: 'Filter boards by geo, role tags, performance, blocklist' },
  { key: 'native_scrape', label: 'Native URL Scrape', icon: Search, description: 'Search boards using native URL templates' },
  { key: 'fallback_search', label: 'Fallback Search', icon: Globe, description: 'Google-powered site: search when native returns <5 results' },
  { key: 'google_linkedin', label: 'Google → LinkedIn', icon: Globe, description: 'Supplemental LinkedIn discovery via Google indexing' },
  { key: 'url_staging', label: 'URL Staging', icon: Database, description: 'Store discovered URLs to pipeline_pending_jobs' },
  { key: 'content_scrape', label: 'Content Scrape', icon: Search, description: 'Fetch full job page content via Firecrawl' },
  { key: 'ai_scoring', label: 'AI Scoring', icon: Brain, description: 'Score jobs for skill alignment + career trajectory' },
  { key: 'post_filter', label: 'Post-Score Filtering', icon: Filter, description: 'Location, age, company size, agency rejection' },
  { key: 'match_save', label: 'Match Save', icon: CheckCircle2, description: 'Save qualifying jobs as matches' },
  { key: 'enrichment', label: 'Company Enrichment', icon: Zap, description: 'Auto-enrich company data for saved matches' },
];

function parseDiagnostics(events: PipelineEvent[]) {
  const steps: Record<string, { status: 'success' | 'warning' | 'error' | 'skipped' | 'pending'; details: string[]; alarms: string[] }> = {};
  
  // Initialize all steps
  for (const step of PIPELINE_FLOW) {
    steps[step.key] = { status: 'pending', details: [], alarms: [] };
  }

  let totalDiscovered = 0;
  let totalScored = 0;
  let totalSaved = 0;
  let googleJobsFound = 0;
  let firecrawlCalls = 0;
  let rateLimited = false;
  let quotaExceeded = false;
  let rejectionBreakdown: Record<string, number> = {};
  const boardResults: { name: string; status: string; found: number }[] = [];
  let boardsSearched = 0;
  let totalBoardsAvailable = 0;
  let scoringSummaries: any[] = [];

  for (const evt of events) {
    const msg = evt.message;

    // --- board_result events: JSON with board scrape outcomes ---
    if (evt.event_type === 'board_result') {
      try {
        const d = JSON.parse(msg);
        boardResults.push({ name: d.board_name, status: d.status, found: d.jobs_found || 0 });
        if (d.jobs_found > 0) totalDiscovered += d.jobs_found;
      } catch {}
    }

    // --- diagnostics events: scoring_summary ---
    if (evt.event_type === 'diagnostics') {
      try {
        const d = JSON.parse(msg);
        if (d.type === 'scoring_summary') {
          scoringSummaries.push(d);
          totalScored += d.scored || 0;
          totalSaved += d.matches_saved || 0;
          for (const [reason, count] of Object.entries(d.rejection_reasons || {})) {
            rejectionBreakdown[reason] = (rejectionBreakdown[reason] || 0) + (count as number);
          }
        }
      } catch {}
    }

    // --- credit events: firecrawl usage ---
    if (evt.event_type === 'credit') {
      try {
        const d = JSON.parse(msg);
        firecrawlCalls += d.firecrawl_calls || 0;
        if (d.failed_402s > 0) quotaExceeded = true;
      } catch {}
    }

    // --- info events: scrape progress ---
    if (evt.event_type === 'info') {
      const searchedMatch = msg.match(/Searched (\d+) boards?, discovered (\d+) jobs/);
      if (searchedMatch) {
        boardsSearched = Math.max(boardsSearched, parseInt(searchedMatch[1], 10));
        // totalDiscovered already counted from board_result, use as fallback
        if (boardResults.length === 0) {
          totalDiscovered = Math.max(totalDiscovered, parseInt(searchedMatch[2], 10));
        }
      }
      const boardCountMatch = msg.match(/of (\d+) boards/);
      if (boardCountMatch) totalBoardsAvailable = parseInt(boardCountMatch[1], 10);
    }

    // --- warning events ---
    if (evt.event_type === 'warning') {
      if (msg.includes('Scrape paused')) {
        const m = msg.match(/Searched (\d+) of (\d+)/);
        if (m) {
          boardsSearched = parseInt(m[1], 10);
          totalBoardsAvailable = parseInt(m[2], 10);
        }
        const jobsMatch = msg.match(/(\d+) jobs queued/);
        if (jobsMatch && boardResults.length === 0) {
          totalDiscovered = Math.max(totalDiscovered, parseInt(jobsMatch[1], 10));
        }
      }
      if (msg.includes('rate limit')) rateLimited = true;
    }

    // --- filter events ---
    if (evt.event_type === 'filter') {
      try {
        const d = JSON.parse(msg);
        // These are pre-score rejections visible at the filter level
      } catch {}
    }

    // --- success events ---
    if (evt.event_type === 'success') {
      const savedMatch = msg.match(/Saved (\d+) matches? from (\d+) scored/);
      if (savedMatch) {
        // Already counted via scoring_summary, this is just confirmation
      }
    }

    // Google / LinkedIn tracking
    if (msg.includes('Google Jobs:') && msg.includes('LinkedIn')) {
      const match = msg.match(/Found (\d+)/);
      if (match) googleJobsFound = parseInt(match[1], 10);
    }
    if (msg.includes('402') || msg.includes('Payment Required')) {
      quotaExceeded = true;
    }
  }

  // ---- Calculate totalDiscovered from board_result if available ----
  if (boardResults.length > 0) {
    const boardTotal = boardResults.reduce((sum, b) => sum + b.found, 0);
    totalDiscovered = Math.max(totalDiscovered, boardTotal);
  }

  // ---- Determine step statuses ----

  // Auth
  if (events.length > 0) {
    steps.auth.status = 'success';
    steps.auth.details.push('Authenticated successfully');
  }

  // Settings
  if (events.length > 0) {
    steps.settings.status = 'success';
    steps.settings.details.push('Settings loaded');
  }

  // Board Selection
  if (boardResults.length > 0 || boardsSearched > 0) {
    const searched = boardResults.length || boardsSearched;
    steps.boards.status = searched > 0 ? 'success' : 'error';
    steps.boards.details.push(`${searched} boards searched${totalBoardsAvailable > 0 ? ` of ${totalBoardsAvailable} available` : ''}`);
    if (searched === 0) {
      steps.boards.alarms.push('ALARM: Zero boards were searched! Check board activation and filters.');
    }
  }

  // Native Scrape
  if (boardResults.length > 0) {
    const successBoards = boardResults.filter(b => b.status === 'success');
    const emptyBoards = boardResults.filter(b => b.status === 'empty');
    const failedBoards = boardResults.filter(b => b.status === 'failed');
    
    steps.native_scrape.status = successBoards.length > 0 ? 'success' : emptyBoards.length > 0 ? 'warning' : 'error';
    steps.native_scrape.details.push(`${successBoards.length} returned results, ${emptyBoards.length} empty, ${failedBoards.length} failed`);
    for (const b of successBoards) {
      steps.native_scrape.details.push(`  ✓ ${b.name}: ${b.found} jobs`);
    }
    for (const b of emptyBoards) {
      steps.native_scrape.details.push(`  ○ ${b.name}: 0 jobs`);
    }
    for (const b of failedBoards) {
      steps.native_scrape.details.push(`  ✗ ${b.name}: FAILED`);
      steps.native_scrape.alarms.push(`ALARM: ${b.name} scraping failed`);
    }
    if (emptyBoards.length > successBoards.length) {
      steps.native_scrape.alarms.push(`WARNING: ${emptyBoards.length} boards returned zero results.`);
    }
  }

  // Fallback Search
  const fallbackEvents = events.filter(e => e.message.includes('[Search]') || e.message.includes('falling back') || e.message.includes('Google fallback'));
  if (fallbackEvents.length > 0) {
    steps.fallback_search.status = 'success';
    steps.fallback_search.details.push(`Fallback triggered for boards with <5 native results`);
  } else if (boardResults.length > 0) {
    steps.fallback_search.status = 'skipped';
    steps.fallback_search.details.push('Not triggered');
  }

  // Google LinkedIn
  if (googleJobsFound > 0) {
    steps.google_linkedin.status = 'success';
    steps.google_linkedin.details.push(`Found ${googleJobsFound} LinkedIn listings via Google`);
  } else if (quotaExceeded) {
    steps.google_linkedin.status = 'error';
    steps.google_linkedin.details.push('Skipped — Firecrawl quota exceeded (402)');
    steps.google_linkedin.alarms.push('ALARM: Firecrawl credits exhausted.');
  } else if (events.length > 0 && boardResults.length > 0) {
    const anyGoogleEvt = events.find(e => e.message.includes('Google'));
    if (!anyGoogleEvt) {
      steps.google_linkedin.status = 'warning';
      steps.google_linkedin.details.push('No Google search events found in logs');
      steps.google_linkedin.alarms.push('WARNING: Google LinkedIn pass may not have executed.');
    } else {
      steps.google_linkedin.status = 'warning';
      steps.google_linkedin.details.push('Google search ran but returned 0 results');
    }
  }

  // URL Staging
  if (totalDiscovered > 0) {
    steps.url_staging.status = 'success';
    steps.url_staging.details.push(`${totalDiscovered} URLs staged for scoring`);
  } else if (boardResults.length > 0) {
    steps.url_staging.status = 'error';
    steps.url_staging.alarms.push('ALARM: Zero URLs staged.');
  }

  // Content Scrape + AI Scoring
  if (scoringSummaries.length > 0) {
    steps.content_scrape.status = 'success';
    steps.content_scrape.details.push(`${firecrawlCalls} Firecrawl API calls made`);
    if (quotaExceeded) {
      steps.content_scrape.alarms.push('WARNING: Firecrawl returned 402 during scoring');
    }

    steps.ai_scoring.status = totalScored > 0 ? 'success' : 'warning';
    const totalSent = scoringSummaries.reduce((s: number, d: any) => s + (d.sent_to_ai || 0), 0);
    steps.ai_scoring.details.push(`${totalSent} jobs sent to AI, ${totalScored} scored`);
    if (totalScored === 0 && totalSent > 0) {
      steps.ai_scoring.alarms.push('ALARM: AI received jobs but scored zero.');
    }
  } else if (totalDiscovered > 0) {
    steps.content_scrape.status = 'pending';
    steps.content_scrape.details.push('Jobs discovered but scoring not yet complete');
    steps.ai_scoring.status = 'pending';
  }

  // Post-Score Filtering
  if (Object.keys(rejectionBreakdown).length > 0) {
    steps.post_filter.status = 'success';
    const totalRejected = Object.values(rejectionBreakdown).reduce((a, b) => a + b, 0);
    steps.post_filter.details.push(`${totalRejected} jobs rejected:`);
    const sorted = Object.entries(rejectionBreakdown).sort((a, b) => b[1] - a[1]);
    for (const [reason, count] of sorted) {
      steps.post_filter.details.push(`  • ${reason}: ${count}`);
    }
    if ((rejectionBreakdown.scrape_blocked_domain || 0) > 10) {
      steps.post_filter.alarms.push(`ALARM: ${rejectionBreakdown.scrape_blocked_domain} jobs rejected as 'scrape_blocked_domain'.`);
    }
    if ((rejectionBreakdown.recruitment_agency || 0) > totalScored * 0.3) {
      steps.post_filter.alarms.push(`WARNING: High agency rejection rate.`);
    }
  }

  // Match Save
  if (totalSaved > 0) {
    steps.match_save.status = 'success';
    steps.match_save.details.push(`${totalSaved} matches saved`);
  } else if (totalScored > 0) {
    steps.match_save.status = 'error';
    steps.match_save.details.push(`0 matches saved from ${totalScored} scored jobs`);
    steps.match_save.alarms.push('ALARM: Zero matches saved. All scored jobs below threshold or filtered out.');
  }

  // Enrichment
  if (totalSaved > 0) {
    steps.enrichment.status = 'success';
    steps.enrichment.details.push('Triggered for saved matches');
  } else if (totalScored > 0) {
    steps.enrichment.status = 'skipped';
    steps.enrichment.details.push('No matches to enrich');
  }

  return {
    steps,
    summary: {
      totalDiscovered,
      totalScored,
      totalSaved,
      firecrawlCalls,
      rateLimited,
      quotaExceeded,
      googleJobsFound,
      rejectionBreakdown,
    },
  };
}

function StepStatusIcon({ status }: { status: string }) {
  switch (status) {
    case 'success': return <CheckCircle2 className="w-5 h-5 text-primary" />;
    case 'warning': return <AlertTriangle className="w-5 h-5 text-accent-foreground" />;
    case 'error': return <XCircle className="w-5 h-5 text-destructive" />;
    case 'skipped': return <ArrowRight className="w-5 h-5 text-muted-foreground" />;
    default: return <Clock className="w-5 h-5 text-muted-foreground" />;
  }
}

export default function PipelineDiagnostics() {
  const [candidates, setCandidates] = useState<CandidateOption[]>([]);
  const [selectedCandidate, setSelectedCandidate] = useState<string>('');
  const [events, setEvents] = useState<PipelineEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());

  // Load candidates
  useEffect(() => {
    supabase
      .from('candidates')
      .select('id, name, updated_at')
      .order('updated_at', { ascending: false })
      .limit(50)
      .then(({ data }) => {
        if (data) setCandidates(data);
        if (data && data.length > 0) setSelectedCandidate(data[0].id);
      });
  }, []);

  // Load events for selected candidate
  useEffect(() => {
    if (!selectedCandidate) return;
    setLoading(true);
    supabase
      .from('pipeline_events')
      .select('*')
      .eq('candidate_id', selectedCandidate)
      .order('created_at', { ascending: true })
      .limit(500)
      .then(({ data }) => {
        setEvents(data || []);
        setLoading(false);
      });
  }, [selectedCandidate]);

  const refresh = () => {
    if (!selectedCandidate) return;
    setLoading(true);
    supabase
      .from('pipeline_events')
      .select('*')
      .eq('candidate_id', selectedCandidate)
      .order('created_at', { ascending: true })
      .limit(500)
      .then(({ data }) => {
        setEvents(data || []);
        setLoading(false);
      });
  };

  const { steps, summary } = parseDiagnostics(events);
  const allAlarms = PIPELINE_FLOW.flatMap(step => steps[step.key].alarms);

  const toggleStep = (key: string) => {
    setExpandedSteps(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  return (
    <DashboardLayout title="Pipeline Diagnostics" subtitle="Step-by-step execution log with failure detection">
      <div className="space-y-6 p-6">
        <div className="flex items-center justify-end">
          <div className="flex items-center gap-3">
            <Select value={selectedCandidate} onValueChange={setSelectedCandidate}>
              <SelectTrigger className="w-[280px]">
                <SelectValue placeholder="Select candidate..." />
              </SelectTrigger>
              <SelectContent>
                {candidates.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={refresh} disabled={loading}>
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </Button>
          </div>
        </div>

        {/* Alarms Banner */}
        {allAlarms.length > 0 && (
          <Card className="border-destructive/50 bg-destructive/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-destructive flex items-center gap-2 text-lg">
                <AlertTriangle className="w-5 h-5" />
                {allAlarms.length} Pipeline Alarm{allAlarms.length > 1 ? 's' : ''} Detected
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {allAlarms.map((alarm, i) => (
                <div key={i} className="flex items-start gap-2 text-sm">
                  <XCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                  <span>{alarm}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Summary Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="pt-4 pb-3 text-center">
              <div className="text-2xl font-bold">{summary.totalDiscovered}</div>
              <div className="text-xs text-muted-foreground">URLs Discovered</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3 text-center">
              <div className="text-2xl font-bold">{summary.totalScored}</div>
              <div className="text-xs text-muted-foreground">AI Scored</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3 text-center">
              <div className="text-2xl font-bold text-primary">{summary.totalSaved}</div>
              <div className="text-xs text-muted-foreground">Matches Saved</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3 text-center">
              <div className="text-2xl font-bold">{summary.firecrawlCalls}</div>
              <div className="text-xs text-muted-foreground">API Credits Used</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3 text-center">
              <div className="text-2xl font-bold">{summary.googleJobsFound}</div>
              <div className="text-xs text-muted-foreground">Google→LinkedIn</div>
            </CardContent>
          </Card>
        </div>

        {/* Pipeline Flow */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Pipeline Execution Flow
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {PIPELINE_FLOW.map((step, idx) => {
                const stepData = steps[step.key];
                const Icon = step.icon;
                const isExpanded = expandedSteps.has(step.key);
                const hasAlarms = stepData.alarms.length > 0;

                return (
                  <div key={step.key}>
                    {idx > 0 && (
                      <div className="flex items-center pl-[22px] py-0.5">
                        <div className="w-px h-4 bg-border" />
                      </div>
                    )}
                    <button
                      onClick={() => toggleStep(step.key)}
                      className={cn(
                        "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-colors",
                        "hover:bg-muted/50",
                        hasAlarms && "bg-destructive/5 border border-destructive/20",
                        stepData.status === 'success' && !hasAlarms && "bg-primary/5",
                        stepData.status === 'skipped' && "opacity-60",
                      )}
                    >
                      <StepStatusIcon status={stepData.status} />
                      <Icon className="w-4 h-4 text-muted-foreground" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{step.label}</span>
                          <Badge variant={
                            stepData.status === 'success' ? 'default' :
                            stepData.status === 'warning' ? 'secondary' :
                            stepData.status === 'error' ? 'destructive' :
                            'outline'
                          } className="text-[10px] px-1.5 py-0">
                            {stepData.status}
                          </Badge>
                          {hasAlarms && (
                            <Badge variant="destructive" className="text-[10px] px-1.5 py-0">
                              {stepData.alarms.length} alarm{stepData.alarms.length > 1 ? 's' : ''}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground truncate">{step.description}</p>
                      </div>
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>

                    {isExpanded && (stepData.details.length > 0 || stepData.alarms.length > 0) && (
                      <div className="ml-12 mt-1 mb-2 space-y-1">
                        {stepData.alarms.map((alarm, i) => (
                          <div key={`a-${i}`} className="flex items-start gap-2 text-xs text-destructive bg-destructive/10 rounded px-2 py-1">
                            <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                            <span>{alarm}</span>
                          </div>
                        ))}
                        {stepData.details.map((detail, i) => (
                          <div key={`d-${i}`} className="text-xs text-muted-foreground font-mono whitespace-pre-wrap pl-2 border-l-2 border-border">
                            {detail}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Rejection Funnel */}
        {Object.keys(summary.rejectionBreakdown).length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Rejection Funnel
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.entries(summary.rejectionBreakdown)
                  .sort((a, b) => b[1] - a[1])
                  .map(([reason, count]) => {
                    const total = Object.values(summary.rejectionBreakdown).reduce((a, b) => a + b, 0);
                    const pct = Math.round((count / total) * 100);
                    return (
                      <div key={reason} className="flex items-center gap-3">
                        <div className="w-48 text-sm font-mono truncate">{reason}</div>
                        <div className="flex-1 bg-muted rounded-full h-4 overflow-hidden">
                          <div
                            className="h-full bg-destructive/60 rounded-full transition-all"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <div className="w-16 text-right text-sm font-medium">{count} ({pct}%)</div>
                      </div>
                    );
                  })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Raw Event Log */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Raw Event Log ({events.length} events)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <div className="space-y-1">
                {events.map(evt => (
                  <div key={evt.id} className="flex items-start gap-2 text-xs font-mono py-1 border-b border-border/30">
                    <span className="text-muted-foreground w-20 shrink-0">
                      {format(new Date(evt.created_at), 'HH:mm:ss')}
                    </span>
                    <Badge variant={
                      evt.event_type === 'error' ? 'destructive' :
                      evt.event_type === 'warning' ? 'secondary' :
                      evt.event_type === 'success' ? 'default' :
                      'outline'
                    } className="text-[10px] px-1 py-0 shrink-0">
                      {evt.event_type}
                    </Badge>
                    <span className="text-foreground break-all">
                      {evt.message.length > 300 ? evt.message.slice(0, 300) + '...' : evt.message}
                    </span>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}