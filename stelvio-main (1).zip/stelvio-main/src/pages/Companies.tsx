import { useState, useEffect, useMemo } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useListPagination } from "@/hooks/useListPagination";
import { ListPagination } from "@/components/ui/list-pagination";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Search,
  Filter,
  RefreshCw,
  MoreHorizontal,
  Globe,
  Phone,
  MapPin,
  Users,
  ExternalLink,
  Sparkles,
  Plus,
  Loader2,
  Building2,
  Trash2,
  Edit,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useRecycleBin } from "@/hooks/useRecycleBin";
import { BulkDomainLookupDialog } from "@/components/companies/BulkDomainLookupDialog";
import { CsvImportDialog } from "@/components/companies/CsvImportDialog";

interface Company {
  id: string;
  name: string;
  domain: string | null;
  website_url: string | null;
  description: string | null;
  phone: string | null;
  address: string | null;
  employee_count: number | null;
  industry: string | null;
  linkedin_url: string | null;
  enrichment_status: string;
  enriched_at: string | null;
  created_at: string;
  updated_at: string;
}

function formatEmployeeCount(count: number | null): string {
  if (!count) return "Unknown";
  return count.toLocaleString();
}

// Used only for the size filter dropdown
function getEmployeeBandForFilter(count: number | null): string {
  if (!count) return "Unknown";
  if (count <= 50) return "1-50";
  if (count <= 200) return "51-200";
  return "201-500";
}

// URL validation to prevent XSS via javascript: or data: URLs
function isSafeUrl(url: string | null): boolean {
  if (!url) return false;
  try {
    const parsed = new URL(url.startsWith('http') ? url : `https://${url}`);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

export default function Companies() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [ownershipFilter, setOwnershipFilter] = useState<"my" | "all">("all");
  const [enrichmentFilter, setEnrichmentFilter] = useState<"all" | "enriched" | "pending" | "failed">("all");
  const [industryFilter, setIndustryFilter] = useState<string>("all");
  const [employeeFilter, setEmployeeFilter] = useState<string>("all");
  const [companies, setCompanies] = useState<Company[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [enrichingIds, setEnrichingIds] = useState<Set<string>>(new Set());
  const [lookingUpDomainIds, setLookingUpDomainIds] = useState<Set<string>>(new Set());
  const [newCompany, setNewCompany] = useState({ name: '', domain: '' });
  const [isAdding, setIsAdding] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [editDomainCompany, setEditDomainCompany] = useState<Company | null>(null);
  const [editDomainValue, setEditDomainValue] = useState('');
  const [isSavingDomain, setIsSavingDomain] = useState(false);
  const [isBulkLookupOpen, setIsBulkLookupOpen] = useState(false);
  const { toast } = useToast();
  const { user, session, isLoading: authLoading } = useAuth();
  const { moveToRecycleBin } = useRecycleBin();

  // AI-powered domain lookup using OpenAI
  const lookupCompanyDomain = async (companyId: string, companyName: string, jobDescription?: string) => {
    // Prevent a confusing silent failure when the session has expired.
    if (authLoading) return;
    if (!session?.access_token) {
      toast({
        title: "Session expired",
        description: "Please sign in again to use AI domain lookup.",
        variant: "destructive",
      });
      navigate('/login', { replace: true, state: { from: location } });
      return;
    }

    setLookingUpDomainIds(prev => new Set(prev).add(companyId));

    try {
      const { data, error } = await supabase.functions.invoke('lookup-company-domain', {
        body: { companyName, jobDescription, companyId },
      });

      if (error) {
        // If auth expired mid-flight, guide the user back to login with a return location.
        const status = (error as any)?.status;
        if (status === 401) {
          toast({
            title: "Session expired",
            description: "Please sign in again, then retry AI Find Domain.",
            variant: "destructive",
          });
          navigate('/login', { replace: true, state: { from: location } });
          return;
        }
        throw error;
      }
      if (data.error) throw new Error(data.error);

      if (data.data?.domain) {
        // Update local state with found domain
        setCompanies(prev =>
          prev.map(c =>
            c.id === companyId
              ? { ...c, domain: data.data.domain, website_url: data.data.website_url, enrichment_status: 'pending' }
              : c
          )
        );

        toast({
          title: "Domain Found",
          description: `AI found domain "${data.data.domain}" (${data.data.confidence} confidence). Starting enrichment...`,
        });

        // Auto-trigger enrichment after finding domain
        enrichCompany(companyId, data.data.domain);
      } else {
        toast({
          title: "Domain Not Found",
          description: "AI couldn't find a domain. You can add one manually.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error looking up domain:', error);
      toast({
        title: "Domain Lookup Failed",
        description: (error as Error).message || "Failed to lookup company domain",
        variant: "destructive",
      });
    } finally {
      setLookingUpDomainIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(companyId);
        return newSet;
      });
    }
  };

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setCompanies(data || []);
    } catch (error) {
      console.error('Error fetching companies:', error);
      toast({
        title: "Error",
        description: "Failed to load companies",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const addCompany = async () => {
    if (!newCompany.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Company name is required",
        variant: "destructive",
      });
      return;
    }

    setIsAdding(true);
    try {
      const { data, error } = await supabase
        .from('companies')
        .insert({
          name: newCompany.name.trim(),
          domain: newCompany.domain.trim() || null,
          created_by: user?.id,
        })
        .select()
        .single();

      if (error) throw error;

      setCompanies(prev => [data, ...prev]);
      setNewCompany({ name: '', domain: '' });
      setIsAddOpen(false);

      toast({
        title: "Company Added",
        description: `${data.name} has been added successfully`,
      });

      // Auto-enrich if domain provided, otherwise use AI to find domain
      if (data.domain) {
        enrichCompany(data.id, data.domain);
      } else {
        // Use AI to lookup the domain
        toast({
          title: "Looking up domain...",
          description: "AI is searching for the company website",
        });
        lookupCompanyDomain(data.id, data.name);
      }
    } catch (error) {
      console.error('Error adding company:', error);
      toast({
        title: "Error",
        description: "Failed to add company",
        variant: "destructive",
      });
    } finally {
      setIsAdding(false);
    }
  };

  const enrichCompany = async (companyId: string, domain: string) => {
    if (!domain) {
      toast({
        title: "Missing Domain",
        description: "Please add a domain to enrich this company",
        variant: "destructive",
      });
      return;
    }

    setEnrichingIds(prev => new Set(prev).add(companyId));

    try {
      const { data, error } = await supabase.functions.invoke('enrich-company', {
        body: { domain, companyId },
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      // Update local state
      setCompanies(prev =>
        prev.map(c =>
          c.id === companyId
            ? {
                ...c,
                ...data.data,
                enrichment_status: 'enriched',
              }
            : c
        )
      );

      toast({
        title: "AI-Research Complete",
        description: `Successfully researched data for ${domain}`,
      });
    } catch (error) {
      console.error('Error enriching company:', error);
      toast({
        title: "Enrichment Failed",
        description: (error as Error).message || "Failed to enrich company data",
        variant: "destructive",
      });

      // Update status to failed
      setCompanies(prev =>
        prev.map(c =>
          c.id === companyId ? { ...c, enrichment_status: 'failed' } : c
        )
      );
    } finally {
      setEnrichingIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(companyId);
        return newSet;
      });
    }
  };

  const deleteCompany = async (company: Company) => {
    // Create a copy of company data for recycle bin
    const companyData = {
      id: company.id,
      name: company.name,
      domain: company.domain,
      website_url: company.website_url,
      description: company.description,
      phone: company.phone,
      address: company.address,
      employee_count: company.employee_count,
      industry: company.industry,
      linkedin_url: company.linkedin_url,
      enrichment_status: company.enrichment_status,
      enriched_at: company.enriched_at,
      created_at: company.created_at,
    };

    moveToRecycleBin.mutate(
      { entityType: 'companies', entityId: company.id, entityData: companyData },
      {
        onSuccess: () => {
          setCompanies(prev => prev.filter(c => c.id !== company.id));
        },
      }
    );
  };

  const saveDomain = async () => {
    if (!editDomainCompany || !editDomainValue.trim()) {
      toast({
        title: "Validation Error",
        description: "Domain is required",
        variant: "destructive",
      });
      return;
    }

    setIsSavingDomain(true);
    try {
      const domain = editDomainValue.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      
      const { error } = await supabase
        .from('companies')
        .update({ 
          domain, 
          website_url: `https://${domain}`,
          enrichment_status: 'pending' 
        })
        .eq('id', editDomainCompany.id);

      if (error) throw error;

      // Update local state
      setCompanies(prev =>
        prev.map(c =>
          c.id === editDomainCompany.id
            ? { ...c, domain, website_url: `https://${domain}`, enrichment_status: 'pending' }
            : c
        )
      );

      toast({
        title: "Domain Added",
        description: `Domain "${domain}" has been saved. Click Enrich to fetch company data.`,
      });

      setEditDomainCompany(null);
      setEditDomainValue('');

      // Auto-enrich after adding domain
      enrichCompany(editDomainCompany.id, domain);
    } catch (error) {
      console.error('Error saving domain:', error);
      toast({
        title: "Error",
        description: "Failed to save domain",
        variant: "destructive",
      });
    } finally {
      setIsSavingDomain(false);
    }
  };

  // Get unique industries for filter dropdown
  const uniqueIndustries = [...new Set(companies.filter(c => c.industry).map(c => c.industry!))].sort();

  const filteredCompanies = companies.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.domain && c.domain.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (c.industry && c.industry.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesOwnership = ownershipFilter === "all" || (c as any).created_by === user?.id;
    const matchesEnrichment = enrichmentFilter === "all" || c.enrichment_status === enrichmentFilter;
    const matchesIndustry = industryFilter === "all" || c.industry === industryFilter;
    const matchesEmployee = employeeFilter === "all" || getEmployeeBandForFilter(c.employee_count) === employeeFilter;
    return matchesSearch && matchesOwnership && matchesEnrichment && matchesIndustry && matchesEmployee;
  });

  // Sort filtered companies by updated_at (most recently modified first)
  const sortedFilteredCompanies = useMemo(() => {
    return [...filteredCompanies].sort((a, b) => {
      const aTime = new Date(a.updated_at || a.created_at).getTime();
      const bTime = new Date(b.updated_at || b.created_at).getTime();
      return bTime - aTime;
    });
  }, [filteredCompanies]);

  // Pagination
  const companiesPagination = useListPagination(sortedFilteredCompanies, {
    storageKey: 'companies',
  });

  const enrichedCount = companies.filter(c => c.enrichment_status === 'enriched').length;
  const companiesNeedingDomain = companies.filter(c => !c.domain || c.domain.trim() === "");
  const companiesNeedingEnrich = companies.filter(c => c.domain && c.domain.trim() !== "" && c.enrichment_status === "pending");
  const totalNeedingProcessing = companiesNeedingDomain.length + companiesNeedingEnrich.length;

  return (
    <DashboardLayout
      title="Companies"
      subtitle="Company profiles with BetterContact enrichment"
    >
      <div className="space-y-6">
        {/* Actions Bar */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-accent-foreground" />
            <Input
              placeholder="Search companies, domains, or industries..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-accent text-accent-foreground placeholder:text-black/50 border-accent"
            />
          </div>
          <div className="flex gap-2">
            {/* Ownership Toggle */}
            <div className="flex bg-muted rounded-lg p-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setOwnershipFilter("my")}
                className={cn("px-3", ownershipFilter === "my" && "bg-card shadow-sm")}
              >
                My Companies
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setOwnershipFilter("all")}
                className={cn("px-3", ownershipFilter === "all" && "bg-card shadow-sm")}
              >
                All Companies
              </Button>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Status: {enrichmentFilter === "all" ? "All" : enrichmentFilter.charAt(0).toUpperCase() + enrichmentFilter.slice(1)}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-card">
                <DropdownMenuItem onClick={() => setEnrichmentFilter("all")}>
                  All Statuses
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setEnrichmentFilter("enriched")}>
                  <Sparkles className="w-4 h-4 mr-2 text-emerald-600" />
                  Enriched
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setEnrichmentFilter("pending")}>
                  <RefreshCw className="w-4 h-4 mr-2 text-amber-600" />
                  Pending
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setEnrichmentFilter("failed")}>
                  <Globe className="w-4 h-4 mr-2 text-red-600" />
                  Failed
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {uniqueIndustries.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Building2 className="w-4 h-4 mr-2" />
                    Industry: {industryFilter === "all" ? "All" : industryFilter}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-card max-h-64 overflow-y-auto">
                  <DropdownMenuItem onClick={() => setIndustryFilter("all")}>
                    All Industries
                  </DropdownMenuItem>
                  {uniqueIndustries.map((industry) => (
                    <DropdownMenuItem key={industry} onClick={() => setIndustryFilter(industry)}>
                      {industry}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Users className="w-4 h-4 mr-2" />
                  Size: {employeeFilter === "all" ? "All" : employeeFilter}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-card">
                <DropdownMenuItem onClick={() => setEmployeeFilter("all")}>
                  All Sizes
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setEmployeeFilter("1-50")}>
                  1-50 employees
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setEmployeeFilter("51-200")}>
                  51-200 employees
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setEmployeeFilter("201-500")}>
                  201-500 employees
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setEmployeeFilter("Unknown")}>
                  Unknown
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <CsvImportDialog onImportComplete={fetchCompanies} />
            <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="accent-gradient border-0">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Company
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="font-display">Add New Company</DialogTitle>
                  <DialogDescription>
                    Add a company and optionally provide a domain for automatic enrichment.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Company Name *</Label>
                    <Input
                      id="name"
                      placeholder="e.g., Acme Corp"
                      value={newCompany.name}
                      onChange={(e) => setNewCompany(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="domain">Domain (for enrichment)</Label>
                    <Input
                      id="domain"
                      placeholder="e.g., acme.com"
                      value={newCompany.domain}
                      onChange={(e) => setNewCompany(prev => ({ ...prev, domain: e.target.value }))}
                    />
                    <p className="text-xs text-muted-foreground">
                      If provided, we'll automatically fetch company data
                    </p>
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setIsAddOpen(false)}>
                      Cancel
                    </Button>
                    <Button
                      className="accent-gradient border-0"
                      onClick={addCompany}
                      disabled={isAdding}
                    >
                      {isAdding ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Adding...
                        </>
                      ) : (
                        <>
                          <Plus className="w-4 h-4 mr-2" />
                          Add Company
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            
            {/* Bulk Domain Lookup Button */}
            {totalNeedingProcessing > 0 && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => setIsBulkLookupOpen(true)}
                className="border-primary/30 text-primary hover:bg-primary/5"
              >
                <Zap className="w-4 h-4 mr-2" />
                Bulk AI Lookup ({totalNeedingProcessing})
              </Button>
            )}
          </div>
        </div>

        {/* Bulk Domain Lookup Dialog */}
        <BulkDomainLookupDialog
          open={isBulkLookupOpen}
          onOpenChange={setIsBulkLookupOpen}
          companies={companies}
          onComplete={fetchCompanies}
        />

        {/* Stats Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-card rounded-lg p-4 border border-border/50">
            <p className="text-sm text-muted-foreground">Total Companies</p>
            <p className="text-2xl font-display font-bold">{companies.length}</p>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border/50">
            <p className="text-sm text-muted-foreground">AI-Research</p>
            <p className="text-2xl font-display font-bold text-amber-600">
              {enrichedCount}
            </p>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border/50">
            <p className="text-sm text-muted-foreground">Pending</p>
            <p className="text-2xl font-display font-bold text-warning">
              {companies.filter(c => c.enrichment_status === 'pending').length}
            </p>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border/50">
            <p className="text-sm text-muted-foreground">With Domains</p>
            <p className="text-2xl font-display font-bold">
              {companies.filter(c => c.domain).length}
            </p>
          </div>
        </div>

        {/* Companies Table */}
        <div className="bg-card rounded-xl border border-border/50 shadow-sm overflow-hidden">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredCompanies.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Building2 className="w-12 h-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No companies found</p>
              <p className="text-sm text-muted-foreground/70 mt-1">
                Add companies to get started with enrichment
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="bg-accent">
                  <TableHead className="font-semibold text-accent-foreground">Company</TableHead>
                  <TableHead className="font-semibold text-accent-foreground">Industry</TableHead>
                  <TableHead className="font-semibold text-accent-foreground">Size</TableHead>
                  <TableHead className="font-semibold text-accent-foreground">Location</TableHead>
                  <TableHead className="font-semibold text-accent-foreground">Status</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {companiesPagination.paginatedItems.map((company, index) => {
                  const isEnriching = enrichingIds.has(company.id);
                  return (
                    <TableRow
                      key={company.id}
                      className="hover:bg-muted/30 transition-colors animate-slide-up"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="w-10 h-10 rounded-lg">
                            <AvatarFallback className="rounded-lg bg-primary/10 text-primary font-semibold text-sm">
                              {company.name.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <Link
                              to={`/companies/${company.id}`}
                              className="font-medium text-foreground hover:underline transition-colors"
                            >
                              {company.name}
                            </Link>
                            {company.domain && isSafeUrl(company.domain) ? (
                              <a
                                href={`https://${company.domain}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sm hover:underline flex items-center gap-1 text-link"
                              >
                                <Globe className="w-3 h-3" />
                                {company.domain}
                              </a>
                            ) : company.domain ? (
                              <span className="text-sm text-link flex items-center gap-1">
                                <Globe className="w-3 h-3" />
                                {company.domain}
                              </span>
                            ) : (
                              <span className="text-sm text-muted-foreground/70">No domain</span>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {company.industry ? (
                          <Badge variant="secondary">{company.industry}</Badge>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-muted-foreground" />
                          <span>{formatEmployeeCount(company.employee_count)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {company.address ? (
                          <p className="text-sm flex items-center gap-1 text-muted-foreground">
                            <MapPin className="w-3 h-3" />
                            {company.address}
                          </p>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {isEnriching ? (
                          <Badge variant="outline" className="gap-1">
                            <Loader2 className="w-3 h-3 animate-spin" />
                            Enriching...
                          </Badge>
                        ) : lookingUpDomainIds.has(company.id) ? (
                          <Badge variant="outline" className="gap-1">
                            <Loader2 className="w-3 h-3 animate-spin" />
                            Finding domain...
                          </Badge>
                        ) : company.enrichment_status === 'enriched' ? (
                          <Badge
                            variant="outline"
                            className="bg-amber-500/15 text-amber-600 border-amber-500/30"
                          >
                            <Sparkles className="w-3 h-3 mr-1" />
                            AI-Research
                          </Badge>
                        ) : company.enrichment_status === 'failed' ? (
                          <Badge
                            variant="outline"
                            className="bg-destructive/10 text-destructive border-destructive/20"
                          >
                            Failed
                          </Badge>
                        ) : company.enrichment_status === 'skipped' || !company.domain ? (
                          <Badge
                            variant="outline"
                            className="bg-warning/10 text-warning border-warning/20"
                          >
                            Needs Domain
                          </Badge>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7 text-xs"
                            onClick={() => enrichCompany(company.id, company.domain || '')}
                            disabled={!company.domain}
                          >
                            <RefreshCw className="w-3 h-3 mr-1" />
                            Enrich
                          </Button>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="w-8 h-8">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem 
                                onSelect={(e) => {
                                  e.preventDefault();
                                  setSelectedCompany(company);
                                }}
                              >
                                <ExternalLink className="w-4 h-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              {company.linkedin_url && isSafeUrl(company.linkedin_url) && (
                                <DropdownMenuItem asChild>
                                  <a
                                    href={company.linkedin_url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                  >
                                    <ExternalLink className="w-4 h-4 mr-2" />
                                    LinkedIn
                                  </a>
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem>
                                <Users className="w-4 h-4 mr-2" />
                                Find Stakeholders
                              </DropdownMenuItem>
                              {!company.domain && (
                                <DropdownMenuItem
                                  onSelect={(e) => {
                                    e.preventDefault();
                                    lookupCompanyDomain(company.id, company.name);
                                  }}
                                  disabled={lookingUpDomainIds.has(company.id)}
                                >
                                  <Sparkles className="w-4 h-4 mr-2" />
                                  AI Find Domain
                                </DropdownMenuItem>
                              )}
                              {!company.domain && (
                                <DropdownMenuItem
                                  onSelect={(e) => {
                                    e.preventDefault();
                                    setEditDomainCompany(company);
                                    setEditDomainValue('');
                                  }}
                                >
                                  <Edit className="w-4 h-4 mr-2" />
                                  Add Domain Manually
                                </DropdownMenuItem>
                              )}
                              {company.domain && (
                                <DropdownMenuItem
                                  onSelect={(e) => {
                                    e.preventDefault();
                                    setEditDomainCompany(company);
                                    setEditDomainValue(company.domain || '');
                                  }}
                                >
                                  <Edit className="w-4 h-4 mr-2" />
                                  Edit Domain
                                </DropdownMenuItem>
                              )}
                              {company.domain && (
                                <DropdownMenuItem
                                  onClick={() => enrichCompany(company.id, company.domain!)}
                                  disabled={isEnriching}
                                >
                                  <RefreshCw className="w-4 h-4 mr-2" />
                                  Re-enrich
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                            onClick={() => deleteCompany(company)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </div>
        
        {/* Pagination */}
        <ListPagination
          currentPage={companiesPagination.currentPage}
          totalPages={companiesPagination.totalPages}
          pageSize={companiesPagination.pageSize}
          totalItems={companiesPagination.totalItems}
          startIndex={companiesPagination.startIndex}
          endIndex={companiesPagination.endIndex}
          hasNextPage={companiesPagination.hasNextPage}
          hasPreviousPage={companiesPagination.hasPreviousPage}
          onPageChange={companiesPagination.goToPage}
          onPageSizeChange={companiesPagination.setPageSize}
        />

        {/* View Company Details Dialog */}
        <Dialog open={!!selectedCompany} onOpenChange={(open) => !open && setSelectedCompany(null)}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="font-display flex items-center gap-3">
                <Avatar className="w-10 h-10 rounded-lg">
                  <AvatarFallback className="rounded-lg bg-primary/10 text-primary font-semibold">
                    {selectedCompany?.name.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                {selectedCompany?.name}
              </DialogTitle>
              <DialogDescription>
                {selectedCompany?.industry || "Company Details"}
              </DialogDescription>
            </DialogHeader>
            
            {selectedCompany && (
              <div className="space-y-4 mt-4">
                {selectedCompany.description && (
                  <div>
                    <p className="text-sm text-muted-foreground">Description</p>
                    <p className="text-sm">{selectedCompany.description}</p>
                  </div>
                )}
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Domain</p>
                    <p className="font-medium">{selectedCompany.domain || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Industry</p>
                    <p className="font-medium">{selectedCompany.industry || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Company Size</p>
                    <p className="font-medium">{formatEmployeeCount(selectedCompany.employee_count)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <Badge
                      variant="outline"
                      className={cn(
                        selectedCompany.enrichment_status === 'enriched'
                          ? "bg-amber-500/15 text-amber-600 border-amber-500/30"
                          : "bg-muted"
                      )}
                    >
                      {selectedCompany.enrichment_status === 'enriched' ? 'AI-Research' : 'Pending'}
                    </Badge>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Phone</p>
                    <p className="font-medium">{selectedCompany.phone || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Website</p>
                    {selectedCompany.website_url && isSafeUrl(selectedCompany.website_url) ? (
                      <a
                        href={selectedCompany.website_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium text-accent hover:underline"
                      >
                        {selectedCompany.website_url}
                      </a>
                    ) : (
                      <p className="font-medium">-</p>
                    )}
                  </div>
                </div>
                
                {selectedCompany.address && (
                  <div>
                    <p className="text-sm text-muted-foreground">Address</p>
                    <p className="font-medium">{selectedCompany.address}</p>
                  </div>
                )}
                
                <div className="flex gap-2 pt-2">
                  {selectedCompany.linkedin_url && isSafeUrl(selectedCompany.linkedin_url) && (
                    <Button variant="outline" size="sm" asChild>
                      <a
                        href={selectedCompany.linkedin_url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        LinkedIn
                      </a>
                    </Button>
                  )}
                  {selectedCompany.domain && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        enrichCompany(selectedCompany.id, selectedCompany.domain!);
                        setSelectedCompany(null);
                      }}
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Re-enrich
                    </Button>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Edit Domain Dialog */}
        <Dialog open={!!editDomainCompany} onOpenChange={(open) => !open && setEditDomainCompany(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="font-display">
                {editDomainCompany?.domain ? 'Edit Domain' : 'Add Domain'}
              </DialogTitle>
              <DialogDescription>
                {editDomainCompany?.domain 
                  ? `Update the domain for ${editDomainCompany.name}`
                  : `Add a domain for ${editDomainCompany?.name} to enable enrichment`
                }
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="edit-domain">Domain</Label>
                <Input
                  id="edit-domain"
                  placeholder="e.g., slrobotics.com"
                  value={editDomainValue}
                  onChange={(e) => setEditDomainValue(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && saveDomain()}
                />
                <p className="text-xs text-muted-foreground">
                  Enter the company's website domain (e.g., example.com)
                </p>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setEditDomainCompany(null)}>
                  Cancel
                </Button>
                <Button
                  className="accent-gradient border-0"
                  onClick={saveDomain}
                  disabled={isSavingDomain || !editDomainValue.trim()}
                >
                  {isSavingDomain ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Save & Enrich
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
