import { useState, useEffect, useRef } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { LurqLogoFull, LurqLogo } from "@/components/LurqLogo";
import { supabase } from "@/integrations/supabase/client";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const signupSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  fullName: z.string().min(2, "Name must be at least 2 characters"),
});

export default function Login() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const { signIn, signUp, user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || "/";

  // Prevent repeated async redirects (e.g. token refresh / role load) from causing route bouncing.
  const hasRedirectedRef = useRef(false);

  // If a job search is running, always return the user to the candidate detail page
  // where the job matrix + realtime subscriptions are rendered.
  const ACTIVE_SEARCH_KEY = 'lurq_active_search';
  const ACTIVE_SEARCH_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours
  const PIPELINE_RESUME_KEY = 'lurq_pipeline_resume_v1';

  function getActiveSearchCandidateId(): string | null {
    try {
      const stored = sessionStorage.getItem(ACTIVE_SEARCH_KEY);
      if (!stored) return null;
      const parsed = JSON.parse(stored) as { candidateId?: string; startedAt?: number };
      if (!parsed?.candidateId || typeof parsed.startedAt !== 'number') return null;
      // Expire after TTL
      if (Date.now() - parsed.startedAt > ACTIVE_SEARCH_TTL_MS) {
        sessionStorage.removeItem(ACTIVE_SEARCH_KEY);
        return null;
      }
      return parsed.candidateId;
    } catch {
      return null;
    }
  }

  function getResumeCandidateId(): string | null {
    try {
      const raw = window.localStorage.getItem(PIPELINE_RESUME_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as { candidateId?: string };
      return parsed?.candidateId || null;
    } catch {
      return null;
    }
  }

  // Query pipeline_events to find a candidate with an incomplete search for THIS user only.
  // IMPORTANT: Do not query pipeline_pending_jobs here because it cannot be scoped by user and
  // can incorrectly redirect users into other people's candidates (leading to redirect loops).
  async function findIncompleteSearchCandidate(userId: string): Promise<string | null> {
    try {
      // Check for timeout events with boards remaining
      const windowStart = new Date(Date.now() - 30 * 60 * 1000).toISOString(); // 30 min window
      
      const { data: events } = await supabase
        .from('pipeline_events')
        .select('candidate_id, message, created_at')
        .eq('created_by', userId)
        .eq('event_type', 'warning')
        .gte('created_at', windowStart)
        .order('created_at', { ascending: false })
        .limit(20);

      // Find a timeout event with boards remaining
      const timeoutEvent = events?.find(e => {
        if (!e.message?.includes('time limit reached') && !e.message?.includes('Search paused')) {
          return false;
        }
        const boardMatch = e.message.match(/Searched (\d+) of (\d+) boards/);
        if (!boardMatch) return false;
        const searched = parseInt(boardMatch[1], 10);
        const total = parseInt(boardMatch[2], 10);
        return searched < total; // Has boards remaining
      });

      return timeoutEvent?.candidate_id || null;
    } catch {
      return null;
    }
  }

  // Redirect away from login if already authenticated
  useEffect(() => {
    if (authLoading) return;

    // Reset guard when fully signed out
    if (!user) {
      hasRedirectedRef.current = false;
      return;
    }

    if (hasRedirectedRef.current) return;
    hasRedirectedRef.current = true;

    if (user) {
      const redirectToDestination = async () => {
        // 1. Check localStorage resume intent first (explicit redirect saved by ProtectedRoute)
        const resumeCandidateId = getResumeCandidateId();
        if (resumeCandidateId) {
          console.log('Login: Redirecting to resume candidate:', resumeCandidateId);
          navigate(`/candidates/${resumeCandidateId}`, { replace: true });
          return;
        }

        // 2. Check sessionStorage for active search
        const activeCandidateId = getActiveSearchCandidateId();
        if (activeCandidateId) {
          console.log('Login: Redirecting to active search candidate:', activeCandidateId);
          navigate(`/candidates/${activeCandidateId}`, { replace: true });
          return;
        }

        // 3. Query database for any incomplete search for THIS user (handles session loss scenarios)
        const incompleteCandidate = await findIncompleteSearchCandidate(user.id);
        if (incompleteCandidate) {
          console.log('Login: Found incomplete search for candidate:', incompleteCandidate);
          navigate(`/candidates/${incompleteCandidate}`, { replace: true });
          return;
        }

        // 4. Default: go to original destination
        navigate(from, { replace: true });
      };

      redirectToDestination();
    }
  }, [user, authLoading, navigate, from]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setIsLoading(true);

    try {
      if (isSignUp) {
        const result = signupSchema.safeParse({ email, password, fullName });
        if (!result.success) {
          const fieldErrors: Record<string, string> = {};
          result.error.errors.forEach((err) => {
            if (err.path[0]) {
              fieldErrors[err.path[0].toString()] = err.message;
            }
          });
          setErrors(fieldErrors);
          setIsLoading(false);
          return;
        }

        const { error } = await signUp(email, password, fullName);
        if (error) {
          if (error.message.includes("already registered")) {
            toast({
              title: "Account exists",
              description: "This email is already registered. Please sign in instead.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Sign up failed",
              description: error.message,
              variant: "destructive",
            });
          }
          setIsLoading(false);
          return;
        }

        toast({
          title: "Account created",
          description: "Welcome to LurqAI Recruitment Portal!",
        });
        // IMPORTANT: Don't navigate here.
        // We rely on the `useEffect` below (auth state) to redirect to:
        // - explicit resume intent (localStorage)
        // - active search (sessionStorage)
        // - incomplete search detection (DB)
        // Navigating here can unmount the page before that logic runs.
        setIsLoading(false);
      } else {
        const result = loginSchema.safeParse({ email, password });
        if (!result.success) {
          const fieldErrors: Record<string, string> = {};
          result.error.errors.forEach((err) => {
            if (err.path[0]) {
              fieldErrors[err.path[0].toString()] = err.message;
            }
          });
          setErrors(fieldErrors);
          setIsLoading(false);
          return;
        }

        const { error } = await signIn(email, password);
        if (error) {
          if (error.message.includes("Invalid login credentials")) {
            toast({
              title: "Invalid credentials",
              description: "Please check your email and password and try again.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Sign in failed",
              description: error.message,
              variant: "destructive",
            });
          }
          setIsLoading(false);
          return;
        }

        toast({
          title: "Welcome back",
          description: "You've been signed in successfully.",
        });
        // IMPORTANT: Don't navigate here; let the auth-driven `useEffect` decide.
        setIsLoading(false);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Panel - Branding with neon lime accent */}
      <div className="hidden lg:flex lg:w-1/2 bg-accent p-12 flex-col justify-between relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />

        {/* Logo */}
        <div className="relative z-10">
          <LurqLogoFull size="lg" className="text-black" />
        </div>

        {/* Feature Highlights */}
        <div className="relative z-10 space-y-8">
          <div>
            <h2 className="font-display text-4xl font-bold text-black mb-4 italic">
              TRANSFORM YOUR<br />
              RECRUITMENT PROCESS
            </h2>
            <p className="text-black/80 text-lg max-w-md">
              Experience seamless hiring with our end-to-end AI recruiter and business 
              development engine, revolutionizing how you connect candidates with opportunities.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "Candidates Processed", value: "50,000+" },
              { label: "Companies Enriched", value: "12,000+" },
              { label: "Successful Matches", value: "8,500+" },
              { label: "Time Saved", value: "75%" },
            ].map((stat) => (
              <div
                key={stat.label}
                className="bg-black/10 backdrop-blur-sm rounded-2xl p-4 border border-black/20"
              >
                <p className="text-2xl font-display font-bold text-black">
                  {stat.value}
                </p>
                <p className="text-sm text-black/70">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="relative z-10">
          <p className="text-sm text-black/60">
            © 2024 LurqAI. All rights reserved.
          </p>
        </div>
      </div>

      {/* Right Panel - Login Form with deep navy background */}
      <div className="flex-1 flex items-center justify-center p-8 sidebar-gradient">
        <div className="w-full max-w-md space-y-8 animate-slide-up">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center mb-8">
            <LurqLogo size="md" textClassName="text-accent" />
          </div>

          <div className="text-center">
            <h2 className="font-display text-2xl font-bold text-sidebar-accent-foreground">
              {isSignUp ? "Create an account" : "Welcome back"}
            </h2>
            <p className="text-sidebar-foreground/80 mt-2">
              {isSignUp
                ? "Sign up to access the recruitment portal"
                : "Sign in to access your recruitment dashboard"}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {isSignUp && (
              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-sidebar-accent-foreground">Full Name</Label>
                <Input
                  id="fullName"
                  type="text"
                  placeholder="John Doe"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className={`bg-accent text-primary border-accent placeholder:text-primary/50 rounded-full px-6 font-medium ${errors.fullName ? "border-destructive" : ""}`}
                />
                {errors.fullName && (
                  <p className="text-sm text-destructive">{errors.fullName}</p>
                )}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email" className="text-sidebar-accent-foreground">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`bg-accent text-primary border-accent placeholder:text-primary/50 rounded-full px-6 font-medium ${errors.email ? "border-destructive" : ""}`}
              />
              {errors.email && (
                <p className="text-sm text-destructive">{errors.email}</p>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-sidebar-accent-foreground">Password</Label>
                {!isSignUp && (
                  <Link
                    to="/forgot-password"
                    className="text-sm text-accent hover:underline"
                  >
                    Forgot password?
                  </Link>
                )}
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`bg-accent text-primary border-accent placeholder:text-primary/50 rounded-full px-6 font-medium ${errors.password ? "border-destructive" : ""}`}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4 text-primary/70" />
                  ) : (
                    <Eye className="w-4 h-4 text-primary/70" />
                  )}
                </Button>
              </div>
              {errors.password && (
                <p className="text-sm text-destructive">{errors.password}</p>
              )}
            </div>

            {!isSignUp && (
              <div className="flex items-center gap-2">
                <Checkbox id="remember" className="border-sidebar-border data-[state=checked]:bg-accent data-[state=checked]:border-accent" />
                <Label htmlFor="remember" className="text-sm font-normal text-sidebar-foreground/80">
                  Remember me for 30 days
                </Label>
              </div>
            )}

            <Button
              type="submit"
              className="w-full cta-gradient border-0 h-12 rounded-full text-base"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {isSignUp ? "Creating account..." : "Signing in..."}
                </>
              ) : isSignUp ? (
                "Create account"
              ) : (
                "Sign in"
              )}
            </Button>
          </form>

          <p className="text-center text-sm text-sidebar-foreground/80">
            {isSignUp ? (
              <>
                Already have an account?{" "}
                <button
                  type="button"
                  onClick={() => setIsSignUp(false)}
                  className="text-accent font-medium hover:underline"
                >
                  Sign in
                </button>
              </>
            ) : (
              <>
                Don't have an account?{" "}
                <button
                  type="button"
                  onClick={() => setIsSignUp(true)}
                  className="text-accent font-medium hover:underline"
                >
                  Sign up
                </button>
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}