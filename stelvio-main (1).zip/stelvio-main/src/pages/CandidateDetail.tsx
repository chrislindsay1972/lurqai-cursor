import { useState, useEffect, useCallback, useRef } from "react";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { useParams, useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ArrowLeft,
  User,
  Mail,
  Phone,
  MapPin,
  Briefcase,
  Calendar,
  FileText,
  Loader2,
  Pencil,
  Save,
  X,
  Download,
  CheckCircle2,
  Clock,
  AlertCircle,
  Target,
  ClipboardList,
  Sparkles,
  Plus,
  Brain,
  Award,
  Building2,
  Globe,
  Languages,
  Heart,
  TrendingUp,
  Compass,
  Home,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { NotesSection } from "@/components/notes/NotesSection";
import { MatchedJobsGrid } from "@/components/candidates/MatchedJobsGrid";
import { InlineEditField } from "@/components/candidates/InlineEditField";
import { SearchKeywordsEditor } from "@/components/candidates/SearchKeywordsEditor";
import { UXDebugLogger, addUXLog } from "@/components/candidates/UXDebugLogger";
import { EngagementWizard } from "@/components/campaigns/engagement/EngagementWizard";
import { ShortlistPivot } from "@/components/pipeline/ShortlistPivot";
import { PipelineStepper } from "@/components/pipeline/PipelineStepper";
import { usePipelineData } from "@/hooks/usePipelineData";
import { Rocket } from "lucide-react";
import type { Json } from "@/integrations/supabase/types";

interface Candidate {
  id: string;
  name: string;
  email: string | null;
  mobile: string | null;
  address: string | null;
  skills: string[] | null;
  experience_years: number | null;
  current_title: string | null;
  status: string;
  cv_file_url: string | null;
  cv_raw_text: string | null;
  created_at: string;
  updated_at: string;
  desired_location: string | null;
  desired_salary: string | null;
  reason_for_looking: string | null;
  sponsorship_requirements: string | null;
  education: string | null;
  certifications: string | null;
  pre_search_completed: boolean | null;
  search_notes: string | null;
  search_keywords: string[] | null;
  // Pre-search location fields
  search_city: string | null;
  search_country: string | null;
  search_distance_km: number | null;
  is_remote_worker: boolean | null;
  // New AI-extracted fields
  ai_summary: string | null;
  career_highlights: string[] | null;
  ideal_role: string | null;
  ideal_company_size: string | null;
  work_style_preference: string | null;
  industries_of_interest: string[] | null;
  salary_expectation: string | null;
  notice_period: string | null;
  relocation_willingness: string | null;
  languages: string[] | null;
  soft_skills: string[] | null;
  technical_proficiency: Json | null;
  career_goals: string | null;
  parsed_at: string | null;
}

interface Match {
  id: string;
  job_id: string;
  match_score: number;
  match_reason: string | null;
  skills_matched: string[] | null;
  skills_missing: string[] | null;
  status: string;
  created_at?: string;
  // Salary benchmark data
  salary_benchmark: {
    min?: number;
    max?: number;
    median?: number;
    job_salary?: number;
    currency?: string;
  } | null;
  salary_percentile: number | null;
  jobs: {
    id: string;
    title: string;
    source_url: string | null;
    location: string | null;
    job_type: string | null;
    salary_range: string | null;
    posted_at: string | null;
    companies: { 
      id: string; 
      name: string;
      created_by: string | null;
    } | null;
  };
}

const statusConfig: Record<string, { label: string; icon: typeof CheckCircle2; className: string }> = {
  parsed: {
    label: "Parsed",
    icon: CheckCircle2,
    className: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
  },
  pending_review: {
    label: "Review",
    icon: Clock,
    className: "bg-amber-500/15 text-amber-600 border-amber-500/30",
  },
  approved: {
    label: "Approved",
    icon: CheckCircle2,
    className: "bg-purple-500/15 text-purple-600 border-purple-500/30",
  },
  error: {
    label: "Error",
    icon: AlertCircle,
    className: "bg-red-500/15 text-red-600 border-red-500/30",
  },
};


export default function CandidateDetail() {
  const { formatDate } = useLocaleFormat();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [candidate, setCandidate] = useState<Candidate | null>(null);
  const [matches, setMatches] = useState<Match[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState<Partial<Candidate>>({});
  const [skillsInput, setSkillsInput] = useState("");
  const [isEngagementWizardOpen, setIsEngagementWizardOpen] = useState(false);
  const [selectedStakeholders, setSelectedStakeholders] = useState<Set<string>>(new Set());

  // Pipeline data - show all matched companies
  const { companies: pipelineCompanies, currentStep: pipelineStep, pipelineDurationSeconds } = usePipelineData(id);
  const enrichedCompanies = pipelineCompanies;

  // Auto-trigger enrichment only for companies in 'pending' status
  const enrichmentTriggeredRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (!pipelineCompanies.length) return;

    // Only trigger for genuinely pending companies — enriched companies with no stakeholders
    // were already processed (stakeholders deleted due to domain mismatch) and should not be re-enriched.
    const companiesToEnrich = pipelineCompanies.filter(
      c => !enrichmentTriggeredRef.current.has(c.id) && c.enrichmentStatus === "pending"
    );

    if (companiesToEnrich.length === 0) return;

    console.log(`[Enrichment] Triggering enrichment for ${companiesToEnrich.length} companies in batches of 12`);

    // Mark all as triggered immediately to prevent duplicate fire
    for (const company of companiesToEnrich) {
      enrichmentTriggeredRef.current.add(company.id);
    }

    const ENRICHMENT_TIMEOUT_MS = 4 * 60 * 1000; // 4 minutes
    const BATCH_SIZE = 12;

    const enrichOneCompany = async (company: typeof companiesToEnrich[0]) => {
      const timeoutPromise = new Promise<void>((_, reject) =>
        setTimeout(() => reject(new Error("ENRICHMENT_TIMEOUT")), ENRICHMENT_TIMEOUT_MS)
      );

      try {
        await Promise.race([
          (async () => {
            // First look up the domain if needed
            const { data: companyRow } = await supabase
              .from("companies")
              .select("domain, name")
              .eq("id", company.id)
              .single();

            let domain = companyRow?.domain;

            if (!domain) {
              const { data: lookupData } = await supabase.functions.invoke("lookup-company-domain", {
                body: { companyName: company.name, companyId: company.id, quickMode: false },
              });
              domain = lookupData?.domain;
            }

            if (!domain) {
              console.log(`[Enrichment] No domain found for ${company.name}, marking failed`);
              await supabase
                .from("companies")
                .update({ enrichment_status: "failed", enriched_at: new Date().toISOString() })
                .eq("id", company.id);
              return;
            }

            if (company.enrichmentStatus === "pending") {
              const { error: enrichErr } = await supabase.functions.invoke("enrich-company", {
                body: { domain, companyId: company.id },
              });

              if (enrichErr) {
                console.error(`[Enrichment] Failed for ${company.name}:`, enrichErr);
                await supabase
                  .from("companies")
                  .update({ enrichment_status: "failed", enriched_at: new Date().toISOString() })
                  .eq("id", company.id);
                return;
              }
            }

            await supabase.functions.invoke("enrich-stakeholders", {
              body: { companyId: company.id, companyName: company.name, domain },
            });

            console.log(`[Enrichment] Completed chain for ${company.name}`);
          })(),
          timeoutPromise,
        ]);
      } catch (err) {
        const isTimeout = (err as Error)?.message === "ENRICHMENT_TIMEOUT";
        console.error(`[Enrichment] ${isTimeout ? "Timeout" : "Error"} for ${company.name}:`, err);
        try {
          await supabase
            .from("companies")
            .update({ enrichment_status: "failed", enriched_at: new Date().toISOString() })
            .eq("id", company.id)
            .eq("enrichment_status", "pending");
        } catch {
          // ignore secondary failure
        }
      }
    };

    // Process in batches of BATCH_SIZE to avoid flooding edge function concurrency limits
    (async () => {
      for (let i = 0; i < companiesToEnrich.length; i += BATCH_SIZE) {
        const batch = companiesToEnrich.slice(i, i + BATCH_SIZE);
        console.log(`[Enrichment] Processing batch ${Math.floor(i / BATCH_SIZE) + 1}: ${batch.map(c => c.name).join(", ")}`);
        await Promise.all(batch.map(enrichOneCompany));
      }
      console.log(`[Enrichment] All batches complete`);
    })();
  }, [pipelineCompanies]);

  const toggleStakeholder = (sid: string) => {
    setSelectedStakeholders(prev => {
      const next = new Set(prev);
      if (next.has(sid)) next.delete(sid);
      else next.add(sid);
      return next;
    });
  };

  const selectAllForCompany = (stakeholderIds: string[]) => {
    setSelectedStakeholders(prev => {
      const next = new Set(prev);
      const allSelected = stakeholderIds.every(sid => next.has(sid));
      if (allSelected) stakeholderIds.forEach(sid => next.delete(sid));
      else stakeholderIds.forEach(sid => next.add(sid));
      return next;
    });
  };
  const [preSearchData, setPreSearchData] = useState({
    desired_location: "",
    desired_salary: "",
    reason_for_looking: "",
    sponsorship_requirements: "",
    education: "",
    certifications: "",
  });

  // Avoid re-creating fetchData (used by subscriptions/polling)
  const fetchDataRef = useRef<(() => Promise<void>) | null>(null);

  const logAuthSnapshot = useCallback(async (context: string) => {
    try {
      const { data, error } = await supabase.auth.getSession();
      if (error) {
        addUXLog('error', 'Auth', `getSession failed (${context})`, { error: error.message });
        return;
      }
      addUXLog('info', 'Auth', `Session snapshot (${context})`, {
        hasSession: !!data.session,
        userIdPrefix: data.session?.user?.id ? String(data.session.user.id).slice(0, 8) : null,
        expiresAt: data.session?.expires_at ?? null,
      });
    } catch (e: any) {
      addUXLog('error', 'Auth', `getSession threw (${context})`, { error: e?.message });
    }
  }, []);

  useEffect(() => {
    if (id) {
      fetchData();
    }
  }, [id]);

  // Subscribe to realtime match changes for this candidate
  useEffect(() => {
    if (!id) return;

     addUXLog('info', 'Realtime', `Setting up matches subscription for candidate ${id.slice(0, 8)}...`);
     void logAuthSnapshot('before_matches_subscribe');

    const channel = supabase
      .channel(`candidate-matches-${id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'matches',
          filter: `candidate_id=eq.${id}`,
        },
        (payload) => {
          addUXLog('success', 'Realtime', 'Match change detected; refreshing', {
            eventType: payload.eventType,
          });
          // Use ref so we always call the latest fetchData
          void fetchDataRef.current?.();
        }
      )
      .subscribe((status, err) => {
        addUXLog(err ? 'error' : 'info', 'Realtime', `Matches subscription status: ${status}`, err ? { error: err.message } : undefined);
      });

    return () => {
      addUXLog('info', 'Realtime', 'Cleaning up matches subscription');
      supabase.removeChannel(channel);
    };
  }, [id, logAuthSnapshot]);

  // Fallback polling for environments where realtime misses events.
  // Poll only counts; fetch full data only when the count changes.
  const lastMatchCountRef = useRef<number | null>(null);
  useEffect(() => {
    if (!id) return;

    let cancelled = false;
    let interval: number | null = null;

    const tick = async () => {
      try {
        const { count, error } = await supabase
          .from('matches')
          .select('id', { count: 'exact', head: true })
          .eq('candidate_id', id);

        if (error) {
          addUXLog('error', 'Polling', 'Match count poll failed', { error: error.message });
          return;
        }

        const next = count ?? 0;
        if (lastMatchCountRef.current === null) {
          lastMatchCountRef.current = next;
          addUXLog('info', 'Polling', `Initial match count: ${next}`);
          return;
        }

        if (next !== lastMatchCountRef.current) {
          addUXLog('success', 'Polling', `Match count changed: ${lastMatchCountRef.current} → ${next}; refreshing`);
          lastMatchCountRef.current = next;
          await fetchDataRef.current?.();
        }
      } catch (e: any) {
        addUXLog('error', 'Polling', 'Match count poll threw', { error: e?.message });
      }
    };

    // Run immediately and then poll.
    void tick();
    interval = window.setInterval(() => {
      if (!cancelled) void tick();
    }, 8000);

    return () => {
      cancelled = true;
      if (interval) window.clearInterval(interval);
    };
  }, [id]);

  const fetchData = async () => {
    try {
      addUXLog('info', 'Fetch', 'Fetching candidate + matches', { candidateId: id?.slice(0, 8) });
      const [candidateRes, matchesRes] = await Promise.all([
        supabase.from("candidates").select("*").eq("id", id).maybeSingle(),
        supabase
          .from("matches")
          .select(`
            id,
            job_id,
            match_score,
            match_reason,
            skills_matched,
            skills_missing,
            status,
            created_at,
            salary_benchmark,
            salary_percentile,
            jobs(id, title, source_url, location, job_type, salary_range, posted_at, companies(id, name, created_by))
          `)
          .eq("candidate_id", id)
          .order("match_score", { ascending: false }),
      ]);

      if (candidateRes.error) throw candidateRes.error;
      if (matchesRes.error) throw matchesRes.error;
      if (!candidateRes.data) {
        toast({
          title: "Not Found",
          description: "Candidate not found",
          variant: "destructive",
        });
        navigate("/candidates");
        return;
      }

      setCandidate(candidateRes.data);
      setFormData(candidateRes.data);
      setSkillsInput(candidateRes.data.skills?.join(", ") || "");
      setPreSearchData({
        desired_location: candidateRes.data.desired_location || "",
        desired_salary: candidateRes.data.desired_salary || "",
        reason_for_looking: candidateRes.data.reason_for_looking || "",
        sponsorship_requirements: candidateRes.data.sponsorship_requirements || "",
        education: candidateRes.data.education || "",
        certifications: candidateRes.data.certifications || "",
      });
      setMatches((matchesRes.data as unknown as Match[]) || []);
    } catch (error) {
      console.error("Error fetching candidate:", error);
      addUXLog('error', 'Fetch', 'Failed to load candidate detail', {
        candidateId: id?.slice(0, 8),
        error: (error as any)?.message ?? String(error),
      });
      toast({
        title: "Error",
        description: "Failed to load candidate details",
        variant: "destructive",
      });
      navigate("/candidates");
    } finally {
      setIsLoading(false);
    }
  };

  // Keep the ref updated for subscriptions/polling
  useEffect(() => {
    fetchDataRef.current = fetchData;
  }, [fetchData]);

  const handleSave = async () => {
    if (!id) return;
    setIsSaving(true);
    try {
      const skills = skillsInput
        .split(",")
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      const { error } = await supabase
        .from("candidates")
        .update({
          name: formData.name,
          email: formData.email || null,
          mobile: formData.mobile || null,
          address: formData.address || null,
          skills: skills.length > 0 ? skills : null,
          experience_years: formData.experience_years || null,
          current_title: formData.current_title || null,
          status: formData.status,
          desired_location: preSearchData.desired_location || null,
          desired_salary: preSearchData.desired_salary || null,
          reason_for_looking: preSearchData.reason_for_looking || null,
          sponsorship_requirements: preSearchData.sponsorship_requirements || null,
          education: preSearchData.education || null,
          certifications: preSearchData.certifications || null,
        })
        .eq("id", id);

      if (error) throw error;

      setCandidate({
        ...candidate,
        ...formData,
        skills,
        ...preSearchData,
      } as Candidate);
      setIsEditing(false);
      toast({
        title: "Candidate Updated",
        description: "Changes saved successfully",
      });
    } catch (error) {
      console.error("Error updating candidate:", error);
      toast({
        title: "Error",
        description: "Failed to save changes",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setFormData(candidate || {});
    setSkillsInput(candidate?.skills?.join(", ") || "");
    setPreSearchData({
      desired_location: candidate?.desired_location || "",
      desired_salary: candidate?.desired_salary || "",
      reason_for_looking: candidate?.reason_for_looking || "",
      sponsorship_requirements: candidate?.sponsorship_requirements || "",
      education: candidate?.education || "",
      certifications: candidate?.certifications || "",
    });
    setIsEditing(false);
  };

  const downloadCV = async () => {
    if (!candidate?.cv_file_url) return;
    try {
      const { data, error } = await supabase.storage
        .from("cv-files")
        .download(candidate.cv_file_url);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${candidate.name.replace(/\s+/g, "_")}_Resume.${candidate.cv_file_url.split(".").pop()}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading resume:", error);
      toast({
        title: "Download failed",
        description: "Could not download the resume file",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout title="Candidate Details" subtitle="Loading...">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  if (!candidate) {
    return (
      <DashboardLayout title="Candidate Not Found" subtitle="">
        <div className="text-center py-12">
          <p className="text-muted-foreground">Candidate not found</p>
          <Button variant="outline" className="mt-4" onClick={() => navigate("/candidates")}>
            Back to Candidates
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const status = statusConfig[candidate.status] || statusConfig.pending_review;
  const StatusIcon = status.icon;

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    const scrollContainer = el.closest("main") as HTMLElement | null;
    if (scrollContainer) {
      const containerTop = scrollContainer.getBoundingClientRect().top;
      const elTop = el.getBoundingClientRect().top;
      const offset = scrollContainer.scrollTop + (elTop - containerTop) - 90;
      scrollContainer.scrollTo({ top: offset, behavior: "smooth" });
    } else {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const pipelineStages = [
    { id: "section-cv", label: "Resume Summary", sublabel: "Skills & goals", icon: "📄", done: !!candidate.ai_summary },
    { id: "section-jobs", label: "Jobs Matched", sublabel: "AI-scored opportunities", icon: "🎯", done: matches.length > 0 },
    
    { id: "section-shortlist", label: "Shortlist", sublabel: "Select stakeholders", icon: "🚀", done: selectedStakeholders.size > 0 },
  ];

  return (
    <DashboardLayout title={candidate.name} subtitle="Candidate Details">
      <div className="space-y-4">

        {/* Pipeline Progress Bar */}
        <div className="sticky top-0 z-20 -mx-4 px-4 py-3 bg-background/95 backdrop-blur border-b border-border">
          <div className="flex items-center gap-0 overflow-x-auto">
            {pipelineStages.map((stage, i) => (
              <button
                key={stage.id}
                onClick={() => scrollToSection(stage.id)}
                className="flex items-center gap-0 group flex-shrink-0"
              >
                <div className={`flex items-center gap-2.5 px-4 py-2 rounded-lg text-sm font-medium transition-all hover:bg-accent/50 ${stage.done ? "text-primary" : "text-muted-foreground"}`}>
                  <span className="text-base">{stage.icon}</span>
                  <div className="text-left">
                    <div className={`font-semibold leading-none text-sm ${stage.done ? "text-primary" : "text-foreground"}`}>{stage.label}</div>
                    <div className="text-xs text-muted-foreground leading-none mt-0.5">{stage.sublabel}</div>
                  </div>
                  {stage.done && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
                </div>
                {i < pipelineStages.length - 1 && (
                  <span className="text-muted-foreground/40 text-base px-1 flex-shrink-0">›</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Compact Header Bar */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/candidates")} className="bg-accent text-accent-foreground hover:bg-accent hover:text-accent-foreground h-8 px-3">
              <ArrowLeft className="w-3.5 h-3.5 mr-1.5" />
              Candidates
            </Button>
            <Badge variant="outline" className={status.className}>
              <StatusIcon className="w-3 h-3 mr-1" />
              {status.label}
            </Badge>
            {candidate.current_title && (
              <span className="text-sm text-muted-foreground hidden sm:block">{candidate.current_title}</span>
            )}
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button onClick={() => setIsEngagementWizardOpen(true)} variant="default" size="sm" className="h-8">
              <Sparkles className="w-3.5 h-3.5 mr-1.5" />
              Create Campaign
            </Button>
            {candidate.cv_file_url && (
              <Button variant="outline" size="sm" onClick={downloadCV} className="h-8">
                <Download className="w-3.5 h-3.5 mr-1.5" />
                Resume
              </Button>
            )}
            {isEditing ? (
              <>
                <Button variant="outline" size="sm" onClick={handleCancel} disabled={isSaving} className="h-8">
                  <X className="w-3.5 h-3.5 mr-1.5" />
                  Cancel
                </Button>
                <Button size="sm" onClick={handleSave} disabled={isSaving} className="h-8">
                  {isSaving ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Save className="w-3.5 h-3.5 mr-1.5" />}
                  Save
                </Button>
              </>
            ) : (
              <Button variant="outline" size="sm" onClick={() => setIsEditing(true)} className="h-8">
                <Pencil className="w-3.5 h-3.5 mr-1.5" />
                Edit
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Personal Information */}
          <Card>
            <CardHeader className="py-3 px-4">
              <CardTitle className="flex items-center gap-2 text-base">
                <User className="w-4 h-4" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-3">
              {isEditing ? (
                <>
                  <div className="space-y-1">
                    <Label className="text-xs">Full Name</Label>
                    <Input value={formData.name || ""} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Email</Label>
                    <Input type="email" value={formData.email || ""} onChange={(e) => setFormData({ ...formData, email: e.target.value })} placeholder="email@example.com" className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Mobile</Label>
                    <Input value={formData.mobile || ""} onChange={(e) => setFormData({ ...formData, mobile: e.target.value })} placeholder="+1 555-0123" className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Address</Label>
                    <Input value={formData.address || ""} onChange={(e) => setFormData({ ...formData, address: e.target.value })} placeholder="City, State" className="h-8 text-sm" />
                  </div>
                </>
              ) : (
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                    <span className="text-card-foreground">{candidate.email || <span className="text-muted-foreground italic">No email</span>}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                    <span className="text-card-foreground">{candidate.mobile || <span className="text-muted-foreground italic">No mobile</span>}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                    <span className="text-card-foreground">{candidate.address || <span className="text-muted-foreground italic">No address</span>}</span>
                  </div>
                  {candidate.experience_years && (
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                      <span className="text-card-foreground">{candidate.experience_years} years experience</span>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Professional Information */}
          <Card>
            <CardHeader className="py-3 px-4">
              <CardTitle className="flex items-center gap-2 text-base">
                <Briefcase className="w-4 h-4" />
                Professional Information
              </CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-3">
              {isEditing ? (
                <>
                  <div className="space-y-1">
                    <Label className="text-xs">Current Title</Label>
                    <Input value={formData.current_title || ""} onChange={(e) => setFormData({ ...formData, current_title: e.target.value })} placeholder="Software Engineer" className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Years of Experience</Label>
                    <Input type="number" value={formData.experience_years || ""} onChange={(e) => setFormData({ ...formData, experience_years: parseInt(e.target.value) || null })} placeholder="5" className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Status</Label>
                    <select className="w-full px-3 py-1.5 border rounded-md bg-background text-sm" value={formData.status || "pending_review"} onChange={(e) => setFormData({ ...formData, status: e.target.value })}>
                      <option value="pending_review">Pending Review</option>
                      <option value="parsed">Parsed</option>
                      <option value="approved">Approved</option>
                      <option value="error">Error</option>
                    </select>
                  </div>
                </>
              ) : (
                <div className="space-y-2 text-sm">
                  {candidate.current_title && <p className="font-medium text-card-foreground">{candidate.current_title}</p>}
                  <div className="flex flex-wrap gap-3 text-muted-foreground text-xs">
                    {candidate.experience_years && <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{candidate.experience_years}y exp</span>}
                    {candidate.education && <span className="flex items-center gap-1"><Award className="w-3 h-3" />{candidate.education}</span>}
                    {candidate.notice_period && <span className="flex items-center gap-1"><Clock className="w-3 h-3" />Notice: {candidate.notice_period}</span>}
                  </div>
                  {candidate.salary_expectation && (
                    <p className="text-xs text-muted-foreground">Salary: {candidate.salary_expectation}</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Skills */}
          <Card id="section-cv" className="lg:col-span-2">
            <CardHeader className="py-3 px-4">
              <CardTitle className="text-base">Skills</CardTitle>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <div className="space-y-2">
                  <Input
                    value={skillsInput}
                    onChange={(e) => setSkillsInput(e.target.value)}
                    placeholder="JavaScript, React, Node.js (comma-separated)"
                  />
                  <p className="text-xs text-muted-foreground">
                    Separate skills with commas
                  </p>
                </div>
              ) : candidate.skills && candidate.skills.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {candidate.skills.map((skill, index) => (
                    <Badge key={index} variant="skill">
                      {skill}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No skills listed</p>
              )}
            </CardContent>
          </Card>

          {/* AI Profile Summary - Only show if we have AI data */}
          {candidate.ai_summary && (
            <Card className="lg:col-span-2 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
              <CardHeader className="py-3 px-4">
                <CardTitle className="flex items-center gap-2 text-primary text-base">
                  <Brain className="w-4 h-4" />
                  AI Candidate Profile
                  {candidate.parsed_at && (
                    <span className="ml-auto text-xs font-normal text-muted-foreground">
                      {formatDate(candidate.parsed_at)}
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <p className="text-sm text-card-foreground leading-relaxed line-clamp-4">{candidate.ai_summary}</p>
              </CardContent>
            </Card>
          )}

          {/* Career Insights + Skills Analysis + Work Preferences — compact 2-col side-by-side */}
          {(candidate.career_highlights?.length || candidate.ideal_role || candidate.career_goals || candidate.industries_of_interest?.length) && (
            <Card>
              <CardHeader className="py-3 px-4">
                <CardTitle className="flex items-center gap-2 text-base">
                  <TrendingUp className="w-4 h-4" />
                  Career Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-2">
                {candidate.ideal_role && (
                  <div>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Ideal Role</p>
                    <p className="text-sm font-medium text-card-foreground">{candidate.ideal_role}</p>
                  </div>
                )}
                {candidate.career_goals && (
                  <div>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Goals</p>
                    <p className="text-sm text-card-foreground line-clamp-2">{candidate.career_goals}</p>
                  </div>
                )}
                {candidate.career_highlights && candidate.career_highlights.length > 0 && (
                  <div>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Highlights</p>
                    <ul className="space-y-1">
                      {candidate.career_highlights.slice(0, 3).map((h, i) => (
                        <li key={i} className="flex items-start gap-1.5 text-xs text-card-foreground">
                          <CheckCircle2 className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                          <span className="line-clamp-1">{h}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {candidate.industries_of_interest && candidate.industries_of_interest.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {candidate.industries_of_interest.slice(0, 4).map((ind, i) => (
                      <Badge key={i} variant="outline" className="text-[10px] px-1.5 py-0 h-5">{ind}</Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {(candidate.technical_proficiency || candidate.soft_skills?.length || candidate.languages?.length || candidate.work_style_preference || candidate.ideal_company_size || candidate.notice_period || candidate.relocation_willingness) && (
            <Card>
              <CardHeader className="py-3 px-4">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Sparkles className="w-4 h-4" />
                  Skills & Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-3">
                {candidate.technical_proficiency && typeof candidate.technical_proficiency === 'object' && (
                  <div>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Technical</p>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(candidate.technical_proficiency as Record<string, string>).slice(0, 6).map(([skill, level]) => (
                        <Badge key={skill} variant="outline" className={`text-[10px] px-1.5 py-0 h-5 ${level === 'expert' ? 'border-primary bg-primary/10' : level === 'advanced' ? 'border-accent bg-accent/10' : ''}`}>
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                {candidate.soft_skills && candidate.soft_skills.length > 0 && (
                  <div>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1 flex items-center gap-1"><Heart className="w-3 h-3" />Soft Skills</p>
                    <div className="flex flex-wrap gap-1">
                      {candidate.soft_skills.slice(0, 5).map((s, i) => <Badge key={i} variant="secondary" className="text-[10px] px-1.5 py-0 h-5">{s}</Badge>)}
                    </div>
                  </div>
                )}
                {candidate.languages && candidate.languages.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {candidate.languages.map((l, i) => <Badge key={i} variant="outline" className="text-[10px] px-1.5 py-0 h-5"><Languages className="w-2.5 h-2.5 mr-0.5" />{l}</Badge>)}
                  </div>
                )}
                {/* Work preferences inline */}
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs pt-1 border-t border-border">
                  {candidate.work_style_preference && <div><span className="text-muted-foreground">Style: </span><span className="capitalize">{candidate.work_style_preference}</span></div>}
                  {candidate.ideal_company_size && <div><span className="text-muted-foreground">Size: </span><span className="capitalize">{candidate.ideal_company_size}</span></div>}
                  {candidate.notice_period && <div><span className="text-muted-foreground">Notice: </span><span>{candidate.notice_period}</span></div>}
                  {candidate.relocation_willingness && <div><span className="text-muted-foreground">Relocation: </span><span className="capitalize">{candidate.relocation_willingness}</span></div>}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Pre Search Questions */}
          <Card className="lg:col-span-2">
            <CardHeader className="py-3 px-4">
              <CardTitle className="flex items-center gap-2 text-base">
                <ClipboardList className="w-4 h-4" />
                Search Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <InlineEditField
                  label="Desired Location"
                  value={candidate.desired_location}
                  placeholder="e.g., London, Remote, UK"
                  onSave={async (value) => {
                    const { error } = await supabase.from("candidates").update({ desired_location: value || null }).eq("id", id);
                    if (error) throw error;
                    setCandidate({ ...candidate, desired_location: value || null });
                  }}
                />

                {/* Remote Worker Toggle */}
                <div className="space-y-1">
                  <Label className="text-xs font-medium text-muted-foreground">Remote Worker</Label>
                  <button
                    onClick={async () => {
                      const newValue = !candidate.is_remote_worker;
                      const { error } = await supabase.from("candidates").update({ is_remote_worker: newValue }).eq("id", id);
                      if (error) { toast({ title: "Error", description: "Failed to update", variant: "destructive" }); return; }
                      setCandidate({ ...candidate, is_remote_worker: newValue });
                    }}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm transition-all duration-200 ${candidate.is_remote_worker ? 'bg-primary/20 ring-2 ring-primary text-primary' : 'bg-muted text-muted-foreground hover:bg-muted/80'}`}
                  >
                    <Home className="w-3.5 h-3.5" />
                    <span className="font-medium">{candidate.is_remote_worker ? 'Yes — Remote' : 'No — On-site/Hybrid'}</span>
                  </button>
                </div>

                <InlineEditField label="Desired Salary" value={candidate.desired_salary} placeholder="e.g., £50,000 - £70,000"
                  onSave={async (value) => { const { error } = await supabase.from("candidates").update({ desired_salary: value || null }).eq("id", id); if (error) throw error; setCandidate({ ...candidate, desired_salary: value || null }); }}
                />
                <InlineEditField label="Reason for Looking" value={candidate.reason_for_looking} placeholder="e.g., Career growth"
                  onSave={async (value) => { const { error } = await supabase.from("candidates").update({ reason_for_looking: value || null }).eq("id", id); if (error) throw error; setCandidate({ ...candidate, reason_for_looking: value || null }); }}
                />
                <InlineEditField label="Sponsorship Requirements" value={candidate.sponsorship_requirements} placeholder="e.g., UK work visa required"
                  onSave={async (value) => { const { error } = await supabase.from("candidates").update({ sponsorship_requirements: value || null }).eq("id", id); if (error) throw error; setCandidate({ ...candidate, sponsorship_requirements: value || null }); }}
                />
                <InlineEditField label="Education" value={candidate.education} placeholder="e.g., BSc Computer Science"
                  onSave={async (value) => { const { error } = await supabase.from("candidates").update({ education: value || null }).eq("id", id); if (error) throw error; setCandidate({ ...candidate, education: value || null }); }}
                />
                <InlineEditField label="Certifications" value={candidate.certifications} placeholder="e.g., AWS Certified, PMP"
                  onSave={async (value) => { const { error } = await supabase.from("candidates").update({ certifications: value || null }).eq("id", id); if (error) throw error; setCandidate({ ...candidate, certifications: value || null }); }}
                />
              </div>

              {/* Search Keywords */}
              <div className="pt-3 mt-3 border-t border-border">
                <SearchKeywordsEditor
                  candidateId={candidate.id}
                  keywords={candidate.search_keywords}
                  searchNotes={candidate.search_notes}
                  onUpdate={(keywords) => setCandidate({ ...candidate, search_keywords: keywords })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Matched Jobs Grid */}
          <div id="section-jobs" className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <Target className="w-4 h-4 text-muted-foreground" />
              <h2 className="text-base font-semibold">Matched Job Vacancies</h2>
              <Badge variant="outline" className="text-xs">{matches.length}</Badge>
            </div>
            <MatchedJobsGrid 
              matches={matches} 
              onMatchUpdated={fetchData} 
              candidateId={candidate.id}
              candidateName={candidate.name}
            />
          </div>

          {/* Pipeline Shortlist */}
          {(() => {
            const pendingCount = pipelineCompanies.filter(c => c.enrichmentStatus === "pending").length;
            const showSection = enrichedCompanies.length > 0 || (matches.length > 0 && pendingCount > 0);
            if (!showSection) return null;
            return (
              <div id="section-enriched" className="lg:col-span-2 space-y-3">
                <div id="section-shortlist">
                  {enrichedCompanies.length > 0 && (
                    <ShortlistPivot
                      companies={enrichedCompanies}
                      selectedStakeholders={selectedStakeholders}
                      onToggleStakeholder={toggleStakeholder}
                      onSelectAllForCompany={selectAllForCompany}
                      totalMatchedCompanies={pipelineCompanies.length}
                      pendingEnrichmentCount={pendingCount}
                      totalMatchedJobs={matches.length}
                      pipelineDurationSeconds={pipelineDurationSeconds ?? undefined}
                    />
                  )}
                </div>

                {pendingCount > 0 && (
                  <div className="flex items-center gap-3 p-3 rounded-xl border border-border bg-card">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    <div>
                      <p className="text-sm font-medium text-card-foreground">Enriching companies & discovering stakeholders…</p>
                      <p className="text-xs text-muted-foreground">{pendingCount} {pendingCount === 1 ? "company" : "companies"} still processing.</p>
                    </div>
                  </div>
                )}

                {/* Sticky Launch Bar */}
                {selectedStakeholders.size > 0 && (
                  <div className="sticky bottom-4 z-30">
                    <div className="bg-card border border-border rounded-2xl p-4 shadow-lg flex items-center justify-between animate-slide-up">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center">
                          <Rocket className="w-4 h-4 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-card-foreground">{selectedStakeholders.size} stakeholder{selectedStakeholders.size !== 1 ? "s" : ""} selected</p>
                          <p className="text-xs text-muted-foreground">Ready to launch campaign</p>
                        </div>
                      </div>
                      <Button size="sm" className="rounded-xl px-4 gap-2" onClick={() => setIsEngagementWizardOpen(true)}>
                        <Rocket className="w-3.5 h-3.5" />
                        Launch Campaign
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            );
          })()}

          {/* Notes */}
          <NotesSection entityType="candidate" entityId={candidate.id} />

          {/* Footer metadata strip */}
          <div className="lg:col-span-2 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-muted-foreground px-1 pb-2">
            <span className="flex items-center gap-1.5">
              <FileText className="w-3 h-3" />
              {candidate.cv_file_url ? (
                <button onClick={downloadCV} className="hover:text-foreground transition-colors underline underline-offset-2">Resume on file</button>
              ) : "No resume"}
            </span>
            <span>Created {formatDate(candidate.created_at)}</span>
            <span>Updated {formatDate(candidate.updated_at)}</span>
            <span className="font-mono">ID: {candidate.id.slice(0, 8)}</span>
          </div>
        </div>
      </div>

      {/* Engagement Campaign Wizard */}
      <EngagementWizard
        open={isEngagementWizardOpen}
        onOpenChange={(open) => {
          setIsEngagementWizardOpen(open);
          if (!open) setSelectedStakeholders(new Set());
        }}
        candidate={{
          id: candidate.id,
          name: candidate.name,
          email: candidate.email,
          current_title: candidate.current_title,
          status: candidate.status,
          updated_at: candidate.updated_at,
        }}
        selectedStakeholderIds={Array.from(selectedStakeholders)}
      />
    </DashboardLayout>
  );
}
