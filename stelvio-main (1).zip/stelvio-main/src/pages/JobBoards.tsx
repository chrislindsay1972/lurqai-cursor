import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useListPagination } from "@/hooks/useListPagination";
import { ListPagination } from "@/components/ui/list-pagination";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Plus,
  Search,
  Globe,
  ExternalLink,
  Pencil,
  Trash2,
  Wand2,
  Loader2,
} from "lucide-react";

interface JobBoard {
  id: string;
  name: string;
  url: string;
  description: string | null;
  status: string;
  is_active: boolean | null;
  max_employee_count: number | null;
  search_url_template: string | null;
  created_at: string;
  updated_at: string;
  created_by: string | null;
}

export default function JobBoards() {
  const { user, role } = useAuth();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingBoard, setEditingBoard] = useState<JobBoard | null>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    url: "",
    description: "",
    status: "active",
    max_employee_count: "500",
    search_url_template: "",
  });

  const handleAutoDetect = async () => {
    if (!formData.url) {
      toast.error("Please enter a URL first");
      return;
    }
    setIsDetecting(true);
    try {
      const { data, error } = await supabase.functions.invoke('detect-search-template', {
        body: { url: formData.url, name: formData.name },
      });
      if (error) throw error;
      if (data?.success && data?.template) {
        setFormData(prev => ({ ...prev, search_url_template: data.template }));
        toast.success("Search template detected!");
      } else {
        toast.error(data?.error || "Could not detect search template");
      }
    } catch (err: any) {
      toast.error("Detection failed: " + (err.message || "Unknown error"));
    } finally {
      setIsDetecting(false);
    }
  };

  const { data: jobBoards = [], isLoading } = useQuery({
    queryKey: ["job-boards"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("job_boards")
        .select("*")
        .order("updated_at", { ascending: false });

      if (error) throw error;
      return data as JobBoard[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const { error } = await supabase.from("job_boards").insert({
        name: data.name,
        url: data.url,
        description: data.description || null,
        status: data.status,
        max_employee_count: parseInt(data.max_employee_count) || 500,
        search_url_template: data.search_url_template || null,
        created_by: user?.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-boards"] });
      toast.success("Job board added successfully");
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error) => {
      toast.error("Failed to add job board: " + error.message);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const { error } = await supabase
        .from("job_boards")
        .update({
          name: data.name,
          url: data.url,
          description: data.description || null,
          status: data.status,
          max_employee_count: parseInt(data.max_employee_count) || 500,
          search_url_template: data.search_url_template || null,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-boards"] });
      toast.success("Job board updated successfully");
      resetForm();
      setEditingBoard(null);
    },
    onError: (error) => {
      toast.error("Failed to update job board: " + error.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("job_boards").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-boards"] });
      toast.success("Job board deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete job board: " + error.message);
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase
        .from("job_boards")
        .update({ is_active })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-boards"] });
    },
    onError: (error) => {
      toast.error("Failed to update: " + error.message);
    },
  });

  const resetForm = () => {
    setFormData({ name: "", url: "", description: "", status: "active", max_employee_count: "500", search_url_template: "" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.url) {
      toast.error("Name and URL are required");
      return;
    }
    if (editingBoard) {
      updateMutation.mutate({ id: editingBoard.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (board: JobBoard) => {
    setEditingBoard(board);
    setFormData({
      name: board.name,
      url: board.url,
      description: board.description || "",
      status: board.status,
      max_employee_count: String(board.max_employee_count ?? 500),
      search_url_template: board.search_url_template || "",
    });
  };

  const filteredBoards = jobBoards.filter(
    (board) =>
      board.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      board.url.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort filtered boards by updated_at (most recently modified first)
  const sortedFilteredBoards = useMemo(() => {
    return [...filteredBoards].sort((a, b) => {
      const aTime = new Date(a.updated_at || a.created_at).getTime();
      const bTime = new Date(b.updated_at || b.created_at).getTime();
      return bTime - aTime;
    });
  }, [filteredBoards]);

  // Pagination
  const boardsPagination = useListPagination(sortedFilteredBoards, {
    storageKey: 'job_boards',
  });

  const canDelete = role === "admin";

  return (
    <DashboardLayout title="Job Boards" subtitle="Manage job board URLs for CV matching">
      <div className="space-y-6 animate-fade-in">
        {/* Search and Add */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black" />
            <Input
              placeholder="Search job boards..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-accent text-accent-foreground placeholder:text-black/50 border-accent"
            />
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="accent-gradient" onClick={resetForm}>
                <Plus className="w-4 h-4 mr-2" />
                Add Job Board
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Job Board</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="e.g., LinkedIn Jobs"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="url">URL *</Label>
                  <Input
                    id="url"
                    type="url"
                    value={formData.url}
                    onChange={(e) =>
                      setFormData({ ...formData, url: e.target.value })
                    }
                    placeholder="https://..."
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    placeholder="Optional description..."
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) =>
                      setFormData({ ...formData, status: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_employee_count">Max Employee Count</Label>
                  <Input
                    id="max_employee_count"
                    type="number"
                    value={formData.max_employee_count}
                    onChange={(e) =>
                      setFormData({ ...formData, max_employee_count: e.target.value })
                    }
                    placeholder="500"
                  />
                  <p className="text-xs text-muted-foreground">
                    Only match jobs from companies with fewer than this many employees
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="search_url_template">Search URL Template</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleAutoDetect}
                      disabled={isDetecting || !formData.url}
                    >
                      {isDetecting ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Wand2 className="w-3 h-3 mr-1" />}
                      {isDetecting ? "Detecting..." : "Auto-detect"}
                    </Button>
                  </div>
                  <Textarea
                    id="search_url_template"
                    value={formData.search_url_template}
                    onChange={(e) =>
                      setFormData({ ...formData, search_url_template: e.target.value })
                    }
                    placeholder="https://example.com/jobs?search={query}&location={location}"
                    rows={2}
                  />
                  <p className="text-xs text-muted-foreground">
                    Use placeholders: {"{query}"}, {"{title}"}, {"{location}"}, {"{employee_segments}"}
                  </p>
                </div>
                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Adding..." : "Add Job Board"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Table */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5" />
              Job Boards ({filteredBoards.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading...
              </div>
            ) : filteredBoards.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No job boards found. Add your first one!
              </div>
            ) : (
              <>
                <Table>
                <TableHeader>
                  <TableRow className="bg-accent text-black">
                    <TableHead className="w-16 text-center">Active</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>URL</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {boardsPagination.paginatedItems.map((board) => (
                    <TableRow key={board.id}>
                      <TableCell className="text-center">
                        <Checkbox
                          checked={board.is_active === true}
                          onCheckedChange={(checked) =>
                            toggleActiveMutation.mutate({ id: board.id, is_active: checked === true })
                          }
                        />
                      </TableCell>
                      <TableCell className="font-medium text-black">{board.name}</TableCell>
                      <TableCell>
                        <a
                          href={board.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 hover:underline text-primary"
                        >
                          {new URL(board.url).hostname}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </TableCell>
                      <TableCell className="text-black max-w-xs truncate">
                        {board.description || "-"}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Dialog
                            open={editingBoard?.id === board.id}
                            onOpenChange={(open) => {
                              if (!open) {
                                setEditingBoard(null);
                                resetForm();
                              }
                            }}
                          >
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEdit(board)}
                              >
                                <Pencil className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit Job Board</DialogTitle>
                              </DialogHeader>
                              <form onSubmit={handleSubmit} className="space-y-4">
                                <div className="space-y-2">
                                  <Label htmlFor="edit-name">Name *</Label>
                                  <Input
                                    id="edit-name"
                                    value={formData.name}
                                    onChange={(e) =>
                                      setFormData({
                                        ...formData,
                                        name: e.target.value,
                                      })
                                    }
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-url">URL *</Label>
                                  <Input
                                    id="edit-url"
                                    type="url"
                                    value={formData.url}
                                    onChange={(e) =>
                                      setFormData({
                                        ...formData,
                                        url: e.target.value,
                                      })
                                    }
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-description">
                                    Description
                                  </Label>
                                  <Textarea
                                    id="edit-description"
                                    value={formData.description}
                                    onChange={(e) =>
                                      setFormData({
                                        ...formData,
                                        description: e.target.value,
                                      })
                                    }
                                    rows={3}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-status">Status</Label>
                                  <Select
                                    value={formData.status}
                                    onValueChange={(value) =>
                                      setFormData({ ...formData, status: value })
                                    }
                                  >
                                    <SelectTrigger>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="active">Active</SelectItem>
                                      <SelectItem value="inactive">
                                        Inactive
                                      </SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-max_employee_count">Max Employee Count</Label>
                                  <Input
                                    id="edit-max_employee_count"
                                    type="number"
                                    value={formData.max_employee_count}
                                    onChange={(e) =>
                                      setFormData({ ...formData, max_employee_count: e.target.value })
                                    }
                                  />
                                  <p className="text-xs text-muted-foreground">
                                    Only match jobs from companies with fewer than this many employees
                                  </p>
                                </div>
                                <div className="space-y-2">
                                  <div className="flex items-center justify-between">
                                    <Label htmlFor="edit-search_url_template">Search URL Template</Label>
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      onClick={handleAutoDetect}
                                      disabled={isDetecting || !formData.url}
                                    >
                                      {isDetecting ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Wand2 className="w-3 h-3 mr-1" />}
                                      {isDetecting ? "Detecting..." : "Auto-detect"}
                                    </Button>
                                  </div>
                                  <Textarea
                                    id="edit-search_url_template"
                                    value={formData.search_url_template}
                                    onChange={(e) =>
                                      setFormData({ ...formData, search_url_template: e.target.value })
                                    }
                                    rows={2}
                                  />
                                  <p className="text-xs text-muted-foreground">
                                    Use placeholders: {"{query}"}, {"{title}"}, {"{location}"}, {"{employee_segments}"}
                                  </p>
                                </div>
                                <div className="flex justify-end gap-2">
                                  <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingBoard(null);
                                      resetForm();
                                    }}
                                  >
                                    Cancel
                                  </Button>
                                  <Button
                                    type="submit"
                                    disabled={updateMutation.isPending}
                                  >
                                    {updateMutation.isPending
                                      ? "Saving..."
                                      : "Save Changes"}
                                  </Button>
                                </div>
                              </form>
                            </DialogContent>
                          </Dialog>
                          {canDelete && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-destructive hover:text-destructive"
                              onClick={() => deleteMutation.mutate(board.id)}
                              disabled={deleteMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {/* Pagination */}
              <ListPagination
                currentPage={boardsPagination.currentPage}
                totalPages={boardsPagination.totalPages}
                pageSize={boardsPagination.pageSize}
                totalItems={boardsPagination.totalItems}
                startIndex={boardsPagination.startIndex}
                endIndex={boardsPagination.endIndex}
                hasNextPage={boardsPagination.hasNextPage}
                hasPreviousPage={boardsPagination.hasPreviousPage}
                onPageChange={boardsPagination.goToPage}
                onPageSizeChange={boardsPagination.setPageSize}
              />
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
