import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useListPagination } from "@/hooks/useListPagination";
import { ListPagination } from "@/components/ui/list-pagination";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Upload,
  Search,
  Filter,
  MoreHorizontal,
  FileText,
  Mail,
  Eye,
  Trash2,
  CheckCircle2,
  Clock,
  AlertCircle,
  Loader2,
  X,
  Download,
  Briefcase,
  ExternalLink,
  XCircle,
  Building2,
  MapPin,
  Info,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { Progress } from "@/components/ui/progress";
import { PreSearchQuestionsDialog } from "@/components/candidates/PreSearchQuestionsDialog";
import { useCompletionWatcher, DiagnosticsData } from "@/hooks/useCompletionWatcher";
import { RejectionSummaryPanel } from "@/components/candidates/RejectionSummaryPanel";
import { SearchDiagnosticsPanel } from "@/components/candidates/SearchDiagnosticsPanel";

// Expandable reasoning cell component
function ExpandableReasoning({ reason }: { reason: string | null }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const text = reason || "-";
  const isLongText = text.length > 80;

  if (!isLongText || text === "-") {
    return <span className="text-sm text-black">{text}</span>;
  }

  return (
    <div className="space-y-1">
      <p className={`text-sm text-black ${isExpanded ? "" : "line-clamp-2"}`}>
        {text}
      </p>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center gap-1 text-xs font-medium text-black/70 hover:text-black transition-colors"
      >
        {isExpanded ? (
          <>
            <ChevronUp className="w-3 h-3" />
            Show less
          </>
        ) : (
          <>
            <ChevronDown className="w-3 h-3" />
            Show more
          </>
        )}
      </button>
    </div>
  );
}

// SessionStorage keys for persisting dialog state across tab switches
const PRE_SEARCH_CANDIDATE_KEY = 'lurq_pre_search_candidate';
const CV_UPLOAD_OPEN_KEY = 'lurq_cv_upload_open';
const CV_UPLOAD_FILES_KEY = 'lurq_cv_upload_files';
const CV_PROCESSING_KEY = 'lurq_cv_processing';
const CV_PROCESSING_STARTED_AT_KEY = 'lurq_cv_processing_started_at';

interface Candidate {
  id: string;
  name: string;
  email: string | null;
  mobile: string | null;
  address: string | null;
  skills: string[];
  experience_years: number | null;
  current_title: string | null;
  status: string;
  cv_file_url: string | null;
  created_at: string;
  updated_at: string;
}

interface CandidateMatch {
  id: string;
  job_id: string;
  match_score: number;
  match_reason: string | null;
  skills_matched: string[];
  skills_missing: string[];
  status: string;
  jobs: {
    id: string;
    title: string;
    source_url: string | null;
    companies: { name: string } | null;
  };
}

interface FileWithStatus {
  file: File;
  status: 'pending' | 'scanning' | 'uploading' | 'parsing' | 'parsed' | 'error';
  error?: string;
  parsedData?: Partial<Candidate>;
}

interface RealTimeJob {
  id: string;
  matchId: string;
  title: string;
  company_name: string | null;
  location: string | null;
  source_url: string | null;
  match_score: number;
  match_reason: string | null;
}

interface PipelineResult {
  internalMatches: Array<{
    jobId: string;
    jobTitle: string;
    score: number;
    reason: string;
    skillsMatched: string[];
    skillsMissing: string[];
    available: boolean | null;
    availabilityReason: string | null;
  }>;
  allInternalMatches?: Array<{
    jobId: string;
    jobTitle: string;
    score: number;
    reason: string;
  }>;
  externalJobs: Array<{
    title: string;
    url: string;
    matchScore: number;
    matchReason: string;
    skillsMatched: string[];
    skillsMissing: string[];
    source: string;
    companyName?: string;
    stakeholders?: Array<{ name: string; title: string | null }>;
  }>;
  allExternalJobs?: Array<{
    title: string;
    url: string;
    matchScore: number;
    source: string;
  }>;
  jobsChecked: number;
  jobsMarkedFilled: number;
  searchQuery?: string;
  externalSearchResults?: number;
  apolloCreditsExhausted?: boolean;
}

async function invokeBackendFunction<TResponse>(
  functionName: string,
  body: unknown,
  accessToken: string
): Promise<TResponse> {
  const baseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
  const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

  if (!baseUrl) {
    throw new Error('Backend is not configured (missing VITE_SUPABASE_URL).');
  }
  if (!publishableKey) {
    throw new Error('Backend is not configured (missing VITE_SUPABASE_PUBLISHABLE_KEY).');
  }
  if (!accessToken) {
    throw new Error('You must be logged in to perform this action.');
  }

  const endpoint = `${baseUrl.replace(/\/$/, '')}/functions/v1/${functionName}`;
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      apikey: publishableKey,
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify(body),
  });

  const raw = await res.text();
  let json: any = {};
  if (raw) {
    try {
      json = JSON.parse(raw);
    } catch {
      throw new Error(`Backend returned an invalid response (HTTP ${res.status}).`);
    }
  }

  if (!res.ok) {
    throw new Error(json?.error || json?.message || `Backend request failed (HTTP ${res.status}).`);
  }

  return json as TResponse;
}

const statusConfig: Record<
  string,
  { label: string; icon: typeof CheckCircle2; className: string }
> = {
  parsed: {
    label: "Parsed",
    icon: CheckCircle2,
    className: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
  },
  pending_review: {
    label: "Review",
    icon: Clock,
    className: "bg-amber-500/15 text-amber-600 border-amber-500/30",
  },
  approved: {
    label: "Approved",
    icon: CheckCircle2,
    className: "bg-purple-500/15 text-purple-600 border-purple-500/30",
  },
  error: {
    label: "Error",
    icon: AlertCircle,
    className: "bg-red-500/15 text-red-600 border-red-500/30",
  },
};

export default function Candidates() {
  const { formatDate } = useLocaleFormat();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "parsed" | "pending_review" | "approved" | "error">("all");
  // CV Upload dialog state - persisted to sessionStorage so it survives tab switches
  const [isUploadOpen, setIsUploadOpenInternal] = useState(() => {
    try {
      return sessionStorage.getItem(CV_UPLOAD_OPEN_KEY) === 'true';
    } catch {
      return false;
    }
  });
  
  // Wrapper to persist isUploadOpen to sessionStorage
  const setIsUploadOpen = useCallback((value: boolean | ((prev: boolean) => boolean)) => {
    setIsUploadOpenInternal(prev => {
      const newValue = typeof value === 'function' ? value(prev) : value;
      try {
        if (newValue) {
          sessionStorage.setItem(CV_UPLOAD_OPEN_KEY, 'true');
        } else {
          sessionStorage.removeItem(CV_UPLOAD_OPEN_KEY);
        }
      } catch {
        // ignore storage errors
      }
      return newValue;
    });
  }, []);
  const [isDragging, setIsDragging] = useState(false);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // CV upload files state - persisted to sessionStorage for tab switch survival
  const [uploadFiles, setUploadFilesInternal] = useState<FileWithStatus[]>(() => {
    try {
      const stored = sessionStorage.getItem(CV_UPLOAD_FILES_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // File objects cannot be serialized, so we only restore status info
        // Return empty array - files need to be re-added after tab switch
        return [];
      }
    } catch {
      // ignore parse errors
    }
    return [];
  });
  
  // Processing state - persisted to sessionStorage
  const [isProcessing, setIsProcessingInternal] = useState(() => {
    try {
      return sessionStorage.getItem(CV_PROCESSING_KEY) === 'true';
    } catch {
      return false;
    }
  });
  
  // Wrapper to persist uploadFiles metadata to sessionStorage
  const setUploadFiles = useCallback((value: FileWithStatus[] | ((prev: FileWithStatus[]) => FileWithStatus[])) => {
    setUploadFilesInternal(prev => {
      const newValue = typeof value === 'function' ? value(prev) : value;
      try {
        if (newValue.length > 0) {
          // Store status metadata (without actual File objects which can't be serialized)
          const metadata = newValue.map(f => ({
            name: f.file.name,
            status: f.status,
            error: f.error,
          }));
          sessionStorage.setItem(CV_UPLOAD_FILES_KEY, JSON.stringify(metadata));
        } else {
          sessionStorage.removeItem(CV_UPLOAD_FILES_KEY);
        }
      } catch {
        // ignore storage errors
      }
      return newValue;
    });
  }, []);
  
  // Wrapper to persist isProcessing to sessionStorage
  const setIsProcessing = useCallback((value: boolean | ((prev: boolean) => boolean)) => {
    setIsProcessingInternal(prev => {
      const newValue = typeof value === 'function' ? value(prev) : value;
      try {
        if (newValue) {
          sessionStorage.setItem(CV_PROCESSING_KEY, 'true');
          // Set a start timestamp once so we can distinguish active runs from stale flags.
          if (!sessionStorage.getItem(CV_PROCESSING_STARTED_AT_KEY)) {
            sessionStorage.setItem(CV_PROCESSING_STARTED_AT_KEY, String(Date.now()));
          }
        } else {
          sessionStorage.removeItem(CV_PROCESSING_KEY);
          sessionStorage.removeItem(CV_PROCESSING_STARTED_AT_KEY);
        }
      } catch {
        // ignore storage errors
      }
      return newValue;
    });
  }, []);

  // Track whether this is the initial page load vs. subsequent renders
  const isInitialMountRef = useRef(true);
  const hasRestoredFromVisibilityRef = useRef(false);
  
  // Restore processing state when browser tab regains focus.
  // Chrome may drop React state when tabs are backgrounded; this ensures recovery.
  useEffect(() => {
    const restoreProcessingState = () => {
      try {
        const wasProcessing = sessionStorage.getItem(CV_PROCESSING_KEY) === 'true';
        if (wasProcessing) {
          const startedAtRaw = sessionStorage.getItem(CV_PROCESSING_STARTED_AT_KEY);
          const startedAt = startedAtRaw ? Number(startedAtRaw) : NaN;
          const MAX_AGE_MS = 2 * 60 * 60 * 1000; // 2 hours
          const isStale = !Number.isFinite(startedAt) || Date.now() - startedAt > MAX_AGE_MS;

          if (!isStale) {
            // Active processing: ensure the dialog stays open
            console.log('[Candidates] Restoring processing state on visibility change');
            hasRestoredFromVisibilityRef.current = true;
            setIsProcessingInternal(true);
            setIsUploadOpenInternal(true);
          }
        }
      } catch {
        // Ignore errors
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        restoreProcessingState();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  // Detect actual page reloads vs. in-app navigation by checking sessionStorage
  // We use a session-scoped flag to differentiate full page loads from React re-mounts
  const PAGE_LOAD_MARKER_KEY = 'lurq_page_load_marker';
  
  useEffect(() => {
    // Only run cleanup logic on true initial mount (component first loaded)
    if (!isInitialMountRef.current) return;
    isInitialMountRef.current = false;
    
    try {
      // Check if this is a full page reload by looking for our marker
      // If the marker exists and matches, this is an in-app navigation (don't clear)
      // If the marker is missing or stale (>2s old), this is likely a page reload
      const markerRaw = sessionStorage.getItem(PAGE_LOAD_MARKER_KEY);
      const markerTime = markerRaw ? Number(markerRaw) : 0;
      const now = Date.now();
      const isLikelyReload = !markerRaw || (now - markerTime > 2000);
      
      // Always update the marker for future navigation checks
      sessionStorage.setItem(PAGE_LOAD_MARKER_KEY, String(now));
      
      const wasProcessing = sessionStorage.getItem(CV_PROCESSING_KEY) === 'true';
      
      // If actively processing and this looks like navigation (not reload), keep state
      if (wasProcessing && !isLikelyReload) {
        console.log('[Candidates] Preserving CV processing state (in-app navigation detected)');
        setIsProcessingInternal(true);
        setIsUploadOpenInternal(true);
        return;
      }
      
      // On actual page reload, clear stale processing state since files can't survive
      if (wasProcessing && isLikelyReload) {
        const startedAtRaw = sessionStorage.getItem(CV_PROCESSING_STARTED_AT_KEY);
        const startedAt = startedAtRaw ? Number(startedAtRaw) : NaN;
        const MAX_STALE_MS = 5 * 60 * 1000; // 5 minutes - consider stale
        const isStale = !Number.isFinite(startedAt) || Date.now() - startedAt > MAX_STALE_MS;
        
        if (isStale) {
          console.log('[Candidates] Clearing stale CV upload state on page reload');
          sessionStorage.removeItem(CV_PROCESSING_KEY);
          sessionStorage.removeItem(CV_PROCESSING_STARTED_AT_KEY);
          sessionStorage.removeItem(CV_UPLOAD_OPEN_KEY);
          sessionStorage.removeItem(CV_UPLOAD_FILES_KEY);
          setIsProcessingInternal(false);
          setIsUploadOpenInternal(false);
          setUploadFilesInternal([]);
        } else {
          // Recent processing - keep the UI showing even though files are lost
          // This allows user to see processing is happening
          console.log('[Candidates] Keeping recent CV processing state visible on reload');
          setIsProcessingInternal(true);
          setIsUploadOpenInternal(true);
        }
      }
    } catch {
      // Ignore errors
    }
  }, []);

  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [candidateMatches, setCandidateMatches] = useState<CandidateMatch[]>([]);
  const [isLoadingMatches, setIsLoadingMatches] = useState(false);
  const [pipelineCandidate, setPipelineCandidate] = useState<Candidate | null>(null);
  const [isPipelineRunning, setIsPipelineRunning] = useState(false);
  const [pipelineResults, setPipelineResults] = useState<PipelineResult | null>(null);
  // Pre-search candidate state - persisted to sessionStorage so it survives tab switches
  
  // Initialize from sessionStorage to restore dialog after tab switch
  const [preSearchCandidate, setPreSearchCandidateInternal] = useState<{ id: string; name: string } | null>(() => {
    try {
      const stored = sessionStorage.getItem(PRE_SEARCH_CANDIDATE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed?.id && parsed?.name) {
          return parsed;
        }
      }
    } catch {
      // ignore parse errors
    }
    return null;
  });

  // Wrapper to persist preSearchCandidate to sessionStorage
  const setPreSearchCandidate = useCallback((value: { id: string; name: string } | null) => {
    setPreSearchCandidateInternal(value);
    try {
      if (value) {
        sessionStorage.setItem(PRE_SEARCH_CANDIDATE_KEY, JSON.stringify(value));
      } else {
        sessionStorage.removeItem(PRE_SEARCH_CANDIDATE_KEY);
      }
    } catch {
      // ignore storage errors
    }
  }, []);
  
  // Job filter state (from URL)
  const [filterJobId, setFilterJobId] = useState<string | null>(null);
  const [filterJobTitle, setFilterJobTitle] = useState<string | null>(null);
  const [matchedCandidateIds, setMatchedCandidateIds] = useState<Set<string> | null>(null);
  
  // Real-time search progress state
  const [searchStatus, setSearchStatus] = useState<string>("");
  const [realTimeJobs, setRealTimeJobs] = useState<RealTimeJob[]>([]);
  const [searchComplete, setSearchComplete] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [apolloCreditsExhausted, setApolloCreditsExhausted] = useState(false);
  const [pausedSearch, setPausedSearch] = useState<null | {
    boardsSearched: number;
    totalBoards: number;
  }>(null);
  const [shortlistedMatchIds, setShortlistedMatchIds] = useState<Set<string>>(new Set());
  const [addingMatchId, setAddingMatchId] = useState<string | null>(null);
  const [showReasonDialog, setShowReasonDialog] = useState(false);
  const [selectedReason, setSelectedReason] = useState<string | null>(null);
  const [targetMatches, setTargetMatches] = useState(20); // Default target matches
  const [diagnostics, setDiagnostics] = useState<DiagnosticsData>({
    lastDbPollTime: null,
    lastRealtimeEventTime: null,
    matchCountInDb: 0,
    lastAuthError: false,
    lastAuthErrorMessage: undefined,
  });

  // Keep latest realtime jobs available to interval/timeout callbacks without stale closures.
  const realTimeJobsRef = useRef<RealTimeJob[]>([]);
  useEffect(() => {
    realTimeJobsRef.current = realTimeJobs;
  }, [realTimeJobs]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const searchResultsRef = useRef<HTMLDivElement>(null);
  const autoContinueCountRef = useRef(0);
  const MAX_AUTO_CONTINUATIONS = 10;
  const { toast } = useToast();
  const { user, session: authSession, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Keep the session alive during long-running searches to avoid redirecting to /login mid-pipeline.
  // This is intentionally lightweight (periodic refresh) and only runs while the pipeline is active.
  useEffect(() => {
    if (!isPipelineRunning) return;

    let cancelled = false;
    const interval = window.setInterval(async () => {
      if (cancelled) return;
      try {
        const { data } = await supabase.auth.getSession();
        // If there's no session (or it's close to expiring), attempt a refresh.
        if (!data.session) {
          await supabase.auth.refreshSession();
        }
      } catch {
        // Ignore refresh errors; the UI will handle auth redirects and resume via PIPELINE_RESUME_KEY.
      }
    }, 4 * 60 * 1000); // every 4 minutes

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, [isPipelineRunning]);

  const PIPELINE_RESUME_KEY = 'lurq_pipeline_resume_v1';
  const ACTIVE_SEARCH_KEY = 'lurq_active_search';
  const ACTIVE_SEARCH_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours
  
  // Check for active search on mount and redirect to candidate detail page if found
  // This effect runs when location changes to ensure redirects work when navigating back
  useEffect(() => {
    // Only check on the exact /candidates path, not on /candidates/:id
    if (location.pathname !== '/candidates') return;
    
    try {
      const stored = sessionStorage.getItem(ACTIVE_SEARCH_KEY);
      if (!stored) {
        console.log('[ActiveSearchRedirect] No active search found in sessionStorage');
        return;
      }
      
      const parsed = JSON.parse(stored) as { candidateId: string; startedAt: number };
      console.log('[ActiveSearchRedirect] Found stored search:', parsed);
      
      // Only redirect if search is still within TTL
      if (typeof parsed.startedAt !== 'number' || Date.now() - parsed.startedAt > ACTIVE_SEARCH_TTL_MS) {
        console.log('[ActiveSearchRedirect] Search expired, clearing');
        sessionStorage.removeItem(ACTIVE_SEARCH_KEY);
        return;
      }

      // If search is already complete, clear the key and show the list normally
      if (searchComplete) {
        console.log('[ActiveSearchRedirect] Search complete, clearing key');
        sessionStorage.removeItem(ACTIVE_SEARCH_KEY);
        return;
      }

      // Only redirect if the pipeline is ACTIVELY running in this browser session.
      // If isPipelineRunning is false, the search is stale (page was refreshed or
      // navigated away), so clear the key instead of redirecting.
      if (!isPipelineRunning) {
        console.log('[ActiveSearchRedirect] Pipeline not running in this session, clearing stale key');
        sessionStorage.removeItem(ACTIVE_SEARCH_KEY);
        return;
      }
      
      // Redirect to candidate detail page to show the active search
      console.log('[ActiveSearchRedirect] Redirecting to candidate detail page:', parsed.candidateId);
      navigate(`/candidates/${parsed.candidateId}`, { replace: true });
    } catch (err) {
      console.error('[ActiveSearchRedirect] Parse error:', err);
    }
  }, [navigate, location.pathname, searchComplete, isPipelineRunning]);

  // Auto-continue handler for pipeline
  const handleAutoContinue = useCallback(async (fromBoardIndex: number): Promise<boolean> => {
    if (!pipelineCandidate?.id) {
      console.warn('Cannot auto-continue: no pipeline candidate');
      return false;
    }

    // ALWAYS fetch a FRESH session from Supabase rather than relying on React state,
    // which can be stale after dialogs close or mid-pipeline.
    const { data: freshSessionData } = await supabase.auth.getSession();
    const session = freshSessionData?.session;
    if (!session?.access_token) {
      console.warn('Cannot auto-continue: no session (fresh check)');
      // Persist resume intent so after login we can continue automatically.
      // Include candidateName so we can restore pipelineCandidate even if candidates list isn't loaded.
      try {
        window.localStorage.setItem(
          PIPELINE_RESUME_KEY,
          JSON.stringify({ 
            action: 'continue',
            candidateId: pipelineCandidate.id, 
            continueFromBoard: fromBoardIndex,
            candidateName: pipelineCandidate.name
          })
        );
      } catch {
        // ignore
      }
      return false;
    }

    console.log(`Candidates.tsx: Auto-continuing pipeline for ${pipelineCandidate.name} from board ${fromBoardIndex}`);
    setSearchStatus(`Auto-continuing search from board ${fromBoardIndex}...`);

    try {
      // Fire-and-forget the continuation call
      invokeBackendFunction<any>(
        'run-candidate-pipeline',
        { candidateId: pipelineCandidate.id, continueFromBoard: fromBoardIndex },
        session.access_token
      ).then((data) => {
        if (data?.error) {
          console.error('Auto-continue pipeline error:', data.error);
        } else {
          console.log('Auto-continue pipeline response received');
        }
      }).catch((err) => {
        // Network timeout is expected for long searches - the backend continues
        console.log('Auto-continue pipeline network error (expected):', err.message);
      });
      return true;
    } catch (err) {
      console.error('Failed to trigger auto-continue:', err);
      return false;
    }
  }, [pipelineCandidate?.id, pipelineCandidate?.name]);

  // Handler to trigger scoring for pending jobs
  const handleTriggerScoring = useCallback(async (pendingCount: number): Promise<boolean> => {
    if (!pipelineCandidate?.id) {
      console.warn('Cannot trigger scoring: no pipeline candidate');
      return false;
    }

    // ALWAYS fetch a FRESH session from Supabase rather than relying on React state,
    // which can be stale after dialogs close or mid-pipeline.
    const { data: freshSessionData } = await supabase.auth.getSession();
    const session = freshSessionData?.session;
    if (!session?.access_token) {
      console.warn('Cannot trigger scoring: no session (fresh check)');

      // Persist resume intent so after login we can continue scoring automatically.
      try {
        window.localStorage.setItem(
          PIPELINE_RESUME_KEY,
          JSON.stringify({
            action: 'score',
            candidateId: pipelineCandidate.id,
            pendingCount,
            candidateName: pipelineCandidate.name,
          })
        );
      } catch {
        // ignore
      }
      return false;
    }

    console.log(`Candidates.tsx: Triggering scoring for ${pendingCount} pending jobs (candidate: ${pipelineCandidate.name})`);
    setSearchStatus(`Scoring ${pendingCount} discovered jobs...`);

    try {
      // Fire-and-forget the scoring call with mode: 'score'
      invokeBackendFunction<any>(
        'run-candidate-pipeline',
        { candidateId: pipelineCandidate.id, mode: 'score' },
        session.access_token
      ).then((data) => {
        if (data?.error) {
          console.error('Scoring pipeline error:', data.error);
        } else {
          console.log('Scoring pipeline response received');
        }
      }).catch((err) => {
        // Network timeout is expected for long scoring - the backend continues
        console.log('Scoring pipeline network error (expected):', err.message);
      });
      return true;
    } catch (err) {
      console.error('Failed to trigger scoring:', err);
      return false;
    }
  }, [pipelineCandidate?.id, pipelineCandidate?.name]);

  // Completion watcher hook - always polls DB to ensure matches are displayed
  const { startWatching: startCompletionWatcher, stopWatching, loadMatchesFromDb, recordRealtimeEvent } = useCompletionWatcher({
    onJobsUpdated: (jobs) => setRealTimeJobs(jobs),
    onComplete: (jobCount) => {
      setIsPipelineRunning(false);
      setSearchComplete(true);
      sessionStorage.removeItem('lurq_active_search'); // Clear so /candidates nav works normally
      setSearchStatus(jobCount > 0 ? `Found ${jobCount} matching jobs` : 'No matching jobs found');
      // Refetch candidates list after search completes
      supabase
        .from('candidates')
        .select('*')
        .order('created_at', { ascending: false })
        .then(({ data }) => {
          if (data) setCandidates(data);
        });
    },
    onStatusUpdate: (status) => {
      // Never display raw JSON blobs as user-facing status text
      const trimmed = (status || '').trim();
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) return;
      setSearchStatus(status);
    },
    onAutoContinue: handleAutoContinue,
    onTriggerScoring: handleTriggerScoring,
    onDiagnosticsUpdate: (newDiagnostics) => setDiagnostics(newDiagnostics),
    targetMatches, // Pass dynamic target from settings
  });

  // If we were redirected to login mid-run, resume automatically after successful auth.
  // This effect ALSO handles restoring pipelineCandidate from localStorage if it was lost due to page refresh.
  useEffect(() => {
    if (!authSession?.access_token) return;

    try {
      const raw = window.localStorage.getItem(PIPELINE_RESUME_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as {
        action?: 'continue' | 'score';
        candidateId?: string;
        continueFromBoard?: number;
        pendingCount?: number;
        candidateName?: string;
      };

      if (!parsed?.candidateId) return;

      // If pipelineCandidate is not set or doesn't match, we need to restore it first
      if (!pipelineCandidate || pipelineCandidate.id !== parsed.candidateId) {
        // Try to find the candidate in our list, or create a minimal object
        const existingCandidate = candidates.find(c => c.id === parsed.candidateId);
        if (existingCandidate) {
          console.log(`Restoring pipelineCandidate from localStorage: ${existingCandidate.name}`);
          setPipelineCandidate(existingCandidate);
          setIsPipelineRunning(true);
          // Start the completion watcher to poll DB for live updates
          startCompletionWatcher(parsed.candidateId);
          // Don't continue yet - let the effect re-run with updated pipelineCandidate
          return;
        } else if (parsed.candidateName) {
          // Fallback: create minimal candidate object for resumption
          console.log(`Restoring pipelineCandidate (minimal) from localStorage: ${parsed.candidateName}`);
          setPipelineCandidate({ id: parsed.candidateId, name: parsed.candidateName } as Candidate);
          setIsPipelineRunning(true);
          // Start the completion watcher to poll DB for live updates
          startCompletionWatcher(parsed.candidateId);
          return;
        } else {
          // Cannot restore candidate - clear the resume intent
          console.warn('Cannot restore pipelineCandidate: candidate not found and no name stored');
          window.localStorage.removeItem(PIPELINE_RESUME_KEY);
          return;
        }
      }

      // pipelineCandidate matches - proceed with resumption
      console.log(
        `Resuming pipeline from localStorage: action=${parsed.action}, candidate=${parsed.candidateId}` +
          (typeof parsed.continueFromBoard === 'number' ? `, board=${parsed.continueFromBoard}` : '') +
          (typeof parsed.pendingCount === 'number' ? `, pending=${parsed.pendingCount}` : '')
      );
      window.localStorage.removeItem(PIPELINE_RESUME_KEY);
      setPausedSearch(null);
      // Ensure completion watcher is running for live updates
      startCompletionWatcher(parsed.candidateId);

      if (parsed.action === 'score') {
        // Fallback to 1 if the old payload didn't include pendingCount.
        const count = typeof parsed.pendingCount === 'number' && parsed.pendingCount > 0 ? parsed.pendingCount : 1;
        handleTriggerScoring(count);
        return;
      }

      if (typeof parsed.continueFromBoard === 'number') {
        handleAutoContinue(parsed.continueFromBoard);
      }
    } catch {
      // ignore
    }
  }, [authSession?.access_token, pipelineCandidate?.id, candidates, handleAutoContinue, handleTriggerScoring, startCompletionWatcher]);

  // Real-time subscription for new matches during search
  useEffect(() => {
    if (!isPipelineRunning || !pipelineCandidate?.id) return;

    console.log('Setting up realtime subscription for candidate:', pipelineCandidate.id);

    const channel = supabase
      .channel(`matches-list-${pipelineCandidate.id}-${Date.now()}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'matches',
          filter: `candidate_id=eq.${pipelineCandidate.id}`,
        },
        async (payload) => {
          console.log('Realtime matches INSERT received:', payload);
          recordRealtimeEvent(); // Track for diagnostics
          const matchData = payload.new as { id: string; job_id: string; match_score: number; match_reason: string | null };
          
          // Fetch job details
          const { data: jobData } = await supabase
            .from('jobs')
            .select(`id, title, location, source_url, companies(name)`)
            .eq('id', matchData.job_id)
            .single();

          if (jobData) {
            const newJob: RealTimeJob = {
              id: jobData.id,
              matchId: matchData.id,
              title: jobData.title,
              company_name: (jobData.companies as { name: string } | null)?.name || null,
              location: jobData.location,
              source_url: jobData.source_url,
              match_score: matchData.match_score,
              match_reason: matchData.match_reason,
            };

            setRealTimeJobs((prev) => {
              if (prev.some((j) => j.id === newJob.id)) return prev;
              return [...prev, newJob];
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'pipeline_events',
          filter: `candidate_id=eq.${pipelineCandidate.id}`,
        },
        (payload) => {
          console.log('Realtime pipeline_events INSERT received:', payload);
          recordRealtimeEvent(); // Track for diagnostics
          const event = payload.new as { event_type: string; message: string };

          // Capture pause/timeout so the UI can show a "Continue" action.
          if (event?.event_type === 'warning' && event?.message?.includes('time limit reached')) {
            const boardMatch = event.message.match(/Searched (\d+) of (\d+) boards/i);
            if (boardMatch) {
              setPausedSearch({
                boardsSearched: parseInt(boardMatch[1], 10),
                totalBoards: parseInt(boardMatch[2], 10),
              });
            }
          }
          
          // Parse job_match events directly from pipeline_events as backup
          if (event.event_type === 'job_match') {
            try {
              const jobData = JSON.parse(event.message);
              const newJob: RealTimeJob = {
                id: jobData.id,
                matchId: jobData.matchId,
                title: jobData.title,
                company_name: jobData.company_name || null,
                location: null, // Not included in event, will be fetched if needed
                source_url: jobData.url,
                match_score: jobData.match_score,
                match_reason: jobData.match_reason,
              };

              setRealTimeJobs((prev) => {
                if (prev.some((j) => j.id === newJob.id)) return prev;
                return [...prev, newJob];
              });
            } catch (e) {
              console.error('Failed to parse job_match event:', e);
            }
          }
        }
      )
      .subscribe((status, err) => {
        console.log('Realtime subscription status:', status, err);
      });

    return () => {
      console.log('Cleaning up realtime subscription');
      supabase.removeChannel(channel);
    };
  }, [isPipelineRunning, pipelineCandidate?.id]);

  // Fetch target matches setting from app_settings
  useEffect(() => {
    async function fetchTargetMatches() {
      const { data: targetSetting } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'target_matches')
        .maybeSingle();
      
      if (targetSetting?.setting_value) {
        const parsed = parseInt(targetSetting.setting_value, 10);
        if (!isNaN(parsed) && parsed >= 1 && parsed <= 100) {
          setTargetMatches(parsed);
        }
      }
    }
    fetchTargetMatches();
  }, []);

  // AUTO-CONTINUATION EFFECT: When pausedSearch is detected and we have a valid session,
  // automatically trigger continuation if we haven't reached the target matches.
  // This is a backup to the useCompletionWatcher's auto-continue logic.
  useEffect(() => {
    // Only trigger if we have a paused search and a valid candidate
    if (!pausedSearch || !pipelineCandidate?.id) return;
    
    // Don't trigger if already searching
    if (isPipelineRunning && !searchComplete) return;
    
    // Check if we have a valid session
    if (!authSession?.access_token) {
      console.log('Auto-continue deferred: no session');
      return;
    }

    const checkAndContinue = async () => {
      try {
        // Fetch current match count
        const { count: matchCount } = await supabase
          .from('matches')
          .select('id', { count: 'exact', head: true })
          .eq('candidate_id', pipelineCandidate.id);
        
        const currentMatches = matchCount || 0;
        const hasMoreBoards = pausedSearch.boardsSearched < pausedSearch.totalBoards;
        const needsMoreMatches = currentMatches < targetMatches;
        
        console.log(`Auto-continue effect check: matches=${currentMatches}/${targetMatches}, boards=${pausedSearch.boardsSearched}/${pausedSearch.totalBoards}, hasMoreBoards=${hasMoreBoards}, needsMoreMatches=${needsMoreMatches}, continuations=${autoContinueCountRef.current}/${MAX_AUTO_CONTINUATIONS}`);
        
        if (hasMoreBoards && needsMoreMatches && autoContinueCountRef.current < MAX_AUTO_CONTINUATIONS) {
          autoContinueCountRef.current++;
          console.log(`Auto-continue effect: triggering continuation #${autoContinueCountRef.current} from board ${pausedSearch.boardsSearched}`);
          setPausedSearch(null); // Clear to prevent re-triggering
          setIsPipelineRunning(true);
          setSearchComplete(false);
          handleAutoContinue(pausedSearch.boardsSearched);
        } else if (autoContinueCountRef.current >= MAX_AUTO_CONTINUATIONS) {
          console.log(`Auto-continue effect: MAX continuations (${MAX_AUTO_CONTINUATIONS}) reached. Stopping.`);
          setPausedSearch(null);
          setIsPipelineRunning(false);
          setSearchComplete(true);
          sessionStorage.removeItem('lurq_active_search'); // Clear so /candidates nav works normally
          setSearchStatus(`Search complete - searched all available boards. ${currentMatches} matches found.`);
          autoContinueCountRef.current = 0;
        }
      } catch (err) {
        console.error('Auto-continue effect error:', err);
      }
    };

    // Small delay to let other state settle
    const timer = setTimeout(checkAndContinue, 1500);
    return () => clearTimeout(timer);
  }, [pausedSearch, pipelineCandidate?.id, authSession?.access_token, isPipelineRunning, searchComplete, targetMatches, handleAutoContinue]);

  const fetchCandidateMatches = async (candidateId: string) => {
    setIsLoadingMatches(true);
    try {
      const { data, error } = await supabase
        .from('matches')
        .select(`
          id,
          job_id,
          match_score,
          match_reason,
          skills_matched,
          skills_missing,
          status,
          jobs(id, title, source_url, companies(name))
        `)
        .eq('candidate_id', candidateId)
        .order('match_score', { ascending: false });

      if (error) throw error;
      setCandidateMatches(data as unknown as CandidateMatch[] || []);
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setIsLoadingMatches(false);
    }
  };

  const openCandidateProfile = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    fetchCandidateMatches(candidate.id);
  };

  // Handle jobId URL param for filtering
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const jobId = params.get('jobId');
    
    if (jobId) {
      setFilterJobId(jobId);
      // Fetch job title and matched candidate IDs
      const fetchJobMatches = async () => {
        const [jobRes, matchesRes] = await Promise.all([
          supabase.from('jobs').select('title').eq('id', jobId).maybeSingle(),
          supabase.from('matches').select('candidate_id').eq('job_id', jobId),
        ]);
        
        if (jobRes.data) {
          setFilterJobTitle(jobRes.data.title);
        }
        if (matchesRes.data) {
          setMatchedCandidateIds(new Set(matchesRes.data.map(m => m.candidate_id)));
        }
      };
      fetchJobMatches();
    } else {
      setFilterJobId(null);
      setFilterJobTitle(null);
      setMatchedCandidateIds(null);
    }
  }, [location.search]);

  useEffect(() => {
    fetchCandidates();
  }, []);

  // Real-time subscription for candidates table updates (e.g., after CV upload)
  useEffect(() => {
    const candidatesChannel = supabase
      .channel('candidates-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'candidates',
        },
        (payload) => {
          console.log('New candidate received via realtime:', payload);
          fetchCandidates();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'candidates',
        },
        () => {
          fetchCandidates();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'candidates',
        },
        () => {
          fetchCandidates();
        }
      )
      .subscribe((status, err) => {
        console.log('Candidates realtime subscription status:', status, err);
      });

    return () => {
      supabase.removeChannel(candidatesChannel);
    };
  }, []);

  const fetchCandidates = async () => {
    try {
      const { data, error } = await supabase
        .from('candidates')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCandidates(data || []);
    } catch (error) {
      console.error('Error fetching candidates:', error);
      toast({
        title: "Error",
        description: "Failed to load candidates",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const extractTextFromFile = async (file: File): Promise<string> => {
    const fileName = file.name.toLowerCase();

    // For plain text files, read directly
    if (fileName.endsWith('.txt')) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const text = e.target?.result as string;
          resolve(text);
        };
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsText(file);
      });
    }

    // For PDF and DOCX, use the backend extraction function
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData?.session?.access_token;

    if (!token) {
      throw new Error('You must be logged in to process resumes. Please log in and try again.');
    }

    const baseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
    const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

    if (!baseUrl) {
      throw new Error('Backend is not configured (missing VITE_SUPABASE_URL).');
    }
    if (!publishableKey) {
      throw new Error('Backend is not configured (missing VITE_SUPABASE_PUBLISHABLE_KEY).');
    }

    const formData = new FormData();
    formData.append('file', file);

    const endpoint = `${baseUrl.replace(/\/$/, '')}/functions/v1/extract-document-text`;

    let response: Response;
    try {
      response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          // Required by the backend functions gateway
          apikey: publishableKey,
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
    } catch (err) {
      // Network / CORS / DNS errors never reach the backend logs
      const message = err instanceof Error ? err.message : String(err);
      throw new Error(`Could not reach the document extraction service. ${message}`);
    }

    let errorPayload: any = null;
    if (!response.ok) {
      try {
        errorPayload = await response.json();
      } catch {
        // ignore
      }
      const fallback = `Failed to extract text from document (HTTP ${response.status})`;
      throw new Error(errorPayload?.error || fallback);
    }

    const result = await response.json();
    if (!result?.success) {
      throw new Error(result?.error || 'Failed to extract text');
    }

    return result.text as string;
  };

  const uploadFileToStorage = async (file: File, userId: string): Promise<string> => {
    const fileExt = file.name.split('.').pop()?.toLowerCase() || 'txt';
    const fileName = `${userId}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    
    const { data, error } = await supabase.storage
      .from('cv-files')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (error) throw error;
    return data.path;
  };

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    
    const validFiles: FileWithStatus[] = [];
    const allowedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
    ];
    const allowedExtensions = ['.pdf', '.docx', '.txt'];

    Array.from(files).forEach((file) => {
      const ext = '.' + file.name.split('.').pop()?.toLowerCase();
      if (allowedTypes.includes(file.type) || allowedExtensions.includes(ext)) {
        if (file.size <= 10 * 1024 * 1024) {
          validFiles.push({ file, status: 'pending' });
        } else {
          toast({
            title: "File too large",
            description: `${file.name} exceeds 10MB limit`,
            variant: "destructive",
          });
        }
      } else {
        toast({
          title: "Invalid file type",
          description: `${file.name} is not a supported format`,
          variant: "destructive",
        });
      }
    });

    if (validFiles.length > 0) {
      setUploadFiles((prev) => [...prev, ...validFiles]);
    }
  };

  // Auto-start processing when new pending files are added
  useEffect(() => {
    const hasPendingFiles = uploadFiles.some(f => f.status === 'pending');
    if (hasPendingFiles && !isProcessing && user) {
      processFiles();
    }
  }, [uploadFiles, isProcessing, user]);

  const removeFile = (index: number) => {
    setUploadFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const scanFileForViruses = async (file: File): Promise<{ safe: boolean; message: string }> => {
    const baseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
    const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

    if (!baseUrl || !publishableKey) {
      // If not configured, skip scan but warn
      console.warn('Virus scan not configured, skipping...');
      return { safe: true, message: 'Scan skipped - not configured' };
    }

    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData?.session?.access_token;

    const formData = new FormData();
    formData.append('file', file);

    const endpoint = `${baseUrl.replace(/\/$/, '')}/functions/v1/scan-file-virus`;

    let response: Response;
    try {
      response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          apikey: publishableKey,
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: formData,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      throw new Error(`Could not reach the virus scanning service. ${message}`);
    }

    let result: any = null;
    try {
      result = await response.json();
    } catch {
      // ignore
    }

    if (!response.ok) {
      throw new Error(result?.error || `Virus scan failed (HTTP ${response.status})`);
    }

    return { safe: !!result?.safe, message: String(result?.message || '') };
  };

  // Auto-process function that takes files as parameter (for auto-start)
  const processFilesAuto = async (files: FileWithStatus[]) => {
    if (files.length === 0 || !user) return;
    
    setIsProcessing(true);
    
    for (let i = 0; i < files.length; i++) {
      const fileItem = files[i];
      if (fileItem.status !== 'pending') continue;

      // Update status to scanning
      setUploadFiles((prev) =>
        prev.map((f, idx) => (idx === i ? { ...f, status: 'scanning' } : f))
      );

      try {
        // Step 1: Scan file for viruses BEFORE storage upload
        const scanResult = await scanFileForViruses(fileItem.file);
        
        if (!scanResult.safe) {
          throw new Error(`Security scan failed: ${scanResult.message}`);
        }

        // Update status to uploading
        setUploadFiles((prev) =>
          prev.map((f, idx) => (idx === i ? { ...f, status: 'uploading' } : f))
        );

        // Upload file to storage
        const filePath = await uploadFileToStorage(fileItem.file, user.id);
        
        // Update status to parsing (Lurqing!)
        setUploadFiles((prev) =>
          prev.map((f, idx) => (idx === i ? { ...f, status: 'parsing' } : f))
        );

        // Extract text from file (supports TXT, PDF, DOCX)
        const cvText = await extractTextFromFile(fileItem.file);

        // Call the AI parsing function
        console.log('[CV Upload] Calling parse-cv function...');
        const { data, error } = await supabase.functions.invoke('parse-cv', {
          body: { cvText, fileName: fileItem.file.name },
        });

        if (error) {
          console.error('[CV Upload] parse-cv function error:', error);
          throw error;
        }
        if (data.error) {
          console.error('[CV Upload] parse-cv returned error:', data.error);
          throw new Error(data.error);
        }

        const parsedData = data.data;
        console.log('[CV Upload] Parsed data received:', {
          name: parsedData?.name,
          email: parsedData?.email,
          skillsCount: parsedData?.skills?.length,
          hasAiSummary: !!parsedData?.ai_summary,
        });

        // Generate search_keywords from parsed profile data
        const generateSearchKeywords = (): string[] => {
          const keywords: string[] = [];
          const seen = new Set<string>();
          const addKeyword = (kw: string) => {
            const normalized = kw.trim();
            if (normalized && normalized.length >= 3 && !seen.has(normalized.toLowerCase())) {
              seen.add(normalized.toLowerCase());
              keywords.push(normalized);
            }
          };

          // 1. Current title and ideal role are the most important search terms
          if (parsedData.current_title) addKeyword(parsedData.current_title);
          if (parsedData.ideal_role) {
            // Split compound roles like "Senior/Lead Software Engineer or Cloud Architect"
            const roleParts = parsedData.ideal_role
              .split(/\s*(?:or|\/|,)\s*/i)
              .map((p: string) => p.replace(/^\(|\)$/g, '').trim())
              .filter((p: string) => p.length >= 3);
            roleParts.forEach((part: string) => addKeyword(part));
          }

          // 2. Top technical skills (first 5 most relevant)
          const topSkills = (parsedData.skills || []).slice(0, 5);
          topSkills.forEach((skill: string) => addKeyword(skill));

          // 3. Industries of interest
          (parsedData.industries_of_interest || []).slice(0, 3).forEach((ind: string) => addKeyword(ind));

          // Cap at 10 keywords to keep searches focused
          return keywords.slice(0, 10);
        };

        const searchKeywords = generateSearchKeywords();
        console.log('[CV Upload] Generated search keywords:', searchKeywords);

        // Prepare insert payload
        const insertPayload = {
          // Basic info
          name: parsedData.name,
          email: parsedData.email,
          mobile: parsedData.mobile,
          address: parsedData.address,
          current_title: parsedData.current_title,
          experience_years: parsedData.experience_years,
          
          // Skills analysis
          skills: parsedData.skills,
          soft_skills: parsedData.soft_skills,
          technical_proficiency: parsedData.technical_proficiency,
          languages: parsedData.languages,
          
          // Career insights
          career_highlights: parsedData.career_highlights,
          ideal_role: parsedData.ideal_role,
          career_goals: parsedData.career_goals,
          industries_of_interest: parsedData.industries_of_interest,
          
          // Work preferences
          work_style_preference: parsedData.work_style_preference,
          ideal_company_size: parsedData.ideal_company_size,
          salary_expectation: parsedData.salary_expectation,
          notice_period: parsedData.notice_period,
          relocation_willingness: parsedData.relocation_willingness,
          
          // AI narrative
          ai_summary: parsedData.ai_summary,
          parsed_at: parsedData.parsed_at,
          
          // Search keywords (auto-generated from profile)
          search_keywords: searchKeywords.length > 0 ? searchKeywords : null,
          
          // File data
          cv_file_url: filePath,
          cv_raw_text: cvText.slice(0, 50000), // Limit stored text
          status: 'pending_review',
          created_by: user.id,
        };

        console.log('[CV Upload] Inserting candidate with payload:', {
          name: insertPayload.name,
          email: insertPayload.email,
          created_by: insertPayload.created_by,
          cv_file_url: insertPayload.cv_file_url,
          status: insertPayload.status,
        });

        // Check current session before insert
        const { data: sessionCheck } = await supabase.auth.getSession();
        console.log('[CV Upload] Current session:', {
          hasSession: !!sessionCheck?.session,
          userId: sessionCheck?.session?.user?.id,
          expiresAt: sessionCheck?.session?.expires_at,
        });

        // Insert into database with file URL and all AI-extracted fields
        const { data: insertedCandidate, error: insertError } = await supabase
          .from('candidates')
          .insert(insertPayload)
          .select()
          .single();

        if (insertError) {
          console.error('[CV Upload] Database insert error:', {
            code: insertError.code,
            message: insertError.message,
            details: insertError.details,
            hint: insertError.hint,
          });
          throw new Error(`Database error: ${insertError.message} (${insertError.code})`);
        }

        console.log('[CV Upload] Candidate inserted successfully:', {
          id: insertedCandidate?.id,
          name: insertedCandidate?.name,
        });

        setUploadFiles((prev) =>
          prev.map((f, idx) =>
            idx === i ? { ...f, status: 'parsed', parsedData } : f
          )
        );

        toast({
          title: "Resume Lurqed! ✨",
          description: `Successfully parsed ${parsedData.name}'s resume. Please answer pre-search questions.`,
        });

        // Show pre-search questions dialog instead of auto-triggering pipeline
        if (insertedCandidate) {
          setPreSearchCandidate({ id: insertedCandidate.id, name: parsedData.name });
          
          // Explicitly clear all CV upload session storage to prevent ghost modals
          try {
            sessionStorage.removeItem(CV_UPLOAD_OPEN_KEY);
            sessionStorage.removeItem(CV_UPLOAD_FILES_KEY);
            sessionStorage.removeItem(CV_PROCESSING_KEY);
            sessionStorage.removeItem(CV_PROCESSING_STARTED_AT_KEY);
          } catch {
            // ignore storage errors
          }
          
          // Clear React state after storage to ensure consistency
          setIsProcessing(false);
          setIsUploadOpen(false);
          setUploadFiles([]);
        }
      } catch (error) {
        console.error('[CV Upload] Processing failed:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        setUploadFiles((prev) =>
          prev.map((f, idx) =>
            idx === i
              ? { ...f, status: 'error', error: errorMessage }
              : f
          )
        );
      }
    }

    setIsProcessing(false);
    fetchCandidates();
  };
  
  const processFiles = async () => {
    if (uploadFiles.length === 0 || !user) return;
    processFilesAuto(uploadFiles);
  };

  const downloadCV = async (filePath: string, candidateName: string) => {
    try {
      const { data, error } = await supabase.storage
        .from('cv-files')
        .download(filePath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${candidateName.replace(/\s+/g, '_')}_Resume.${filePath.split('.').pop()}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading resume:', error);
      toast({
        title: "Download failed",
        description: "Could not download the resume file",
        variant: "destructive",
      });
    }
  };

  const closeUploadDialog = () => {
    setIsUploadOpen(false);
    setUploadFiles([]);
    setIsProcessing(false);
  };

  const runMatchingPipeline = async (candidate: Candidate) => {
    try {
      // Ensure we have an active session BEFORE starting UI state / subscriptions.
      // This prevents "logged in but still on /login" edge-cases and avoids failed invoke requests.
      if (authLoading) {
        toast({
          title: "Checking session",
          description: "Please try again in a moment.",
        });
        return;
      }

      const { data: { session: latestSession } } = await supabase.auth.getSession();
      const session = latestSession ?? authSession;

      if (!session?.access_token) {
        toast({
          title: "Please log in",
          description: "You need to be logged in to run job search.",
          variant: "destructive",
        });
        // Preserve the current route so login can return users here.
        navigate('/login', { replace: true, state: { from: location } });
        return;
      }

      // Reset state and start search
      setPipelineCandidate(candidate);
      setIsPipelineRunning(true);
      autoContinueCountRef.current = 0;
      setPipelineResults(null);
      setRealTimeJobs([]);
      setSearchComplete(false);
      setSearchError(null);
      setSearchStatus(`Searching for jobs matching ${candidate.name}...`);

      // Persist "active search" so if the user returns to /candidates we can route them
      // back to the detail screen that renders the live matching grid.
      try {
        sessionStorage.setItem(
          ACTIVE_SEARCH_KEY,
          JSON.stringify({ candidateId: candidate.id, startedAt: Date.now() })
        );
      } catch {
        // ignore
      }

      // Start the completion watcher to poll DB and update realTimeJobs in real-time
      startCompletionWatcher(candidate.id);

      // Move the user to the candidate detail screen immediately.
      // The detail view is the canonical place for live job scoring + resume.
      navigate(`/candidates/${candidate.id}`);

      const data = await invokeBackendFunction<any>(
        'run-candidate-pipeline',
        { candidateId: candidate.id },
        session.access_token
      );

      if (data?.error) throw new Error(data.error);

      setPipelineResults({
        internalMatches: data.internalMatches || [],
        externalJobs: data.externalJobs || [],
        jobsChecked: data.jobsChecked || 0,
        jobsMarkedFilled: data.jobsMarkedFilled || 0,
        apolloCreditsExhausted: data.apolloCreditsExhausted || false,
      });

      // Track Apollo credit exhaustion for UI warning
      if (data.apolloCreditsExhausted) {
        setApolloCreditsExhausted(true);
      }

      // IMPORTANT: the backend run is fire-and-forget; results may arrive after this call returns.
      // Keep the UI “running” so realtime subscription stays active, and use DB polling fallback.
      setSearchStatus('Search started — gathering results...');
      startCompletionWatcher(candidate.id);
    } catch (error) {
      console.error('Pipeline error:', error);
      const message = error instanceof Error ? error.message : 'Failed to run matching pipeline';

      // IMPORTANT: A long-running pipeline can outlive the browser request.
      // In those cases, fetch often fails with a generic network error like:
      // - "Failed to fetch" (Chrome)
      // - "NetworkError" (Firefox)
      // - "Load failed" (Safari)
      // The backend continues running and realtime/DB polling will still deliver results.
      const looksLikeNetworkTimeout = /(failed to fetch|networkerror|load failed|fetch failed|typeerror)/i.test(message);

      if (looksLikeNetworkTimeout) {
        setSearchError(null);
        setSearchStatus('Search running in background — results will appear automatically...');

        // Keep the UI in “running” state so realtime stays active and DB polling continues.
        setIsPipelineRunning(true);
        startCompletionWatcher(candidate.id);

        toast({
          title: 'Search Running',
          description: 'The search is still running in the background. Results will appear as they are found.',
        });
        return;
      }

      setSearchError(message);
      setSearchStatus('Search failed');

      // Ensure we stop “running” state on genuine errors.
      sessionStorage.removeItem('lurq_active_search'); // Clear so /candidates nav works normally
      setIsPipelineRunning(false);

      // If this is an auth/session issue, send them to login.
      if (/session has expired|log in again|unauthorized/i.test(message)) {
        // Using hard redirect avoids any routing edge-cases when auth state is broken.
        window.location.href = '/login';
      }
      toast({
        title: "Pipeline Failed",
        description: message,
        variant: "destructive",
      });
    }
  };

  const dismissSearchProgress = () => {
    setPipelineCandidate(null);
    setPipelineResults(null);
    setRealTimeJobs([]);
    setSearchComplete(false);
    setSearchError(null);
    setSearchStatus("");
    setApolloCreditsExhausted(false);
  };

  // Handler for when pre-search questions saves and initiates search
  const handlePreSearchComplete = (candidateId: string, candidateName: string) => {
    // Set up the live grid UI immediately
    const candidate = candidates.find(c => c.id === candidateId);
    if (candidate) {
      setPipelineCandidate(candidate);
    } else {
      // Fallback if candidate not in current list yet
      setPipelineCandidate({ id: candidateId, name: candidateName } as Candidate);
    }
    setIsPipelineRunning(true);
    setPipelineResults(null);
    setRealTimeJobs([]);
    setSearchComplete(false);
    setSearchError(null);
    setSearchStatus(`Searching for jobs matching ${candidateName}...`);

    // Scroll to search results section
    setTimeout(() => {
      searchResultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);

    // Start the completion watcher to poll DB and update realTimeJobs in real-time
    // This ensures the grid updates as matches are scored, not just on completion
    startCompletionWatcher(candidateId);

    // Persist “active search” so if the user returns to /candidates we can route them
    // back to the detail screen that renders the live matching grid.
    try {
      sessionStorage.setItem(
        ACTIVE_SEARCH_KEY,
        JSON.stringify({ candidateId, startedAt: Date.now() })
      );
    } catch {
      // ignore
    }

    // Move the user to the candidate detail screen immediately.
    // The detail view is the canonical place for live job scoring + resume.
    navigate(`/candidates/${candidateId}`);
  };

  const truncateUrl = (url: string | null) => {
    if (!url) return "-";
    try {
      const urlObj = new URL(url);
      return urlObj.hostname.replace('www.', '');
    } catch {
      return url.substring(0, 20) + "...";
    }
  };

  const handleAddToShortlist = async (matchId: string) => {
    setAddingMatchId(matchId);
    try {
      const { error } = await supabase
        .from("matches")
        .update({ status: "shortlisted" })
        .eq("id", matchId);

      if (error) throw error;

      setShortlistedMatchIds((prev) => new Set([...prev, matchId]));
      toast({
        title: "Added to Shortlist",
        description: "Match has been added to the next stage",
      });
    } catch (error) {
      console.error("Error updating match:", error);
      toast({
        title: "Error",
        description: "Failed to update match status",
        variant: "destructive",
      });
    } finally {
      setAddingMatchId(null);
    }
  };

  const handleExplainClick = (reason: string | null) => {
    setSelectedReason(reason);
    setShowReasonDialog(true);
  };

  const filteredCandidates = candidates.filter((c) => {
    // First, apply job filter if active
    if (matchedCandidateIds !== null && !matchedCandidateIds.has(c.id)) {
      return false;
    }
    // Apply status filter
    if (statusFilter !== "all" && c.status !== statusFilter) {
      return false;
    }
    // Then apply search filter
    return (
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.email && c.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (c.skills && c.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())))
    );
  });

  // Sort filtered candidates by updated_at (most recently modified first)
  const sortedFilteredCandidates = useMemo(() => {
    return [...filteredCandidates].sort((a, b) => {
      const aTime = new Date((a as any).updated_at || a.created_at).getTime();
      const bTime = new Date((b as any).updated_at || b.created_at).getTime();
      return bTime - aTime;
    });
  }, [filteredCandidates]);

  // Pagination
  const candidatesPagination = useListPagination(sortedFilteredCandidates, {
    storageKey: 'candidates',
  });

  const clearJobFilter = useCallback(() => {
    navigate('/candidates');
  }, [navigate]);

  const parsedCount = uploadFiles.filter((f) => f.status === 'parsed').length;
  const progressPercent = uploadFiles.length > 0 ? (parsedCount / uploadFiles.length) * 100 : 0;

  return (
    <DashboardLayout
      title={filterJobTitle ? `Candidates matched to "${filterJobTitle}"` : "Candidates"}
      subtitle={filterJobTitle ? `Showing ${filteredCandidates.length} matched candidate${filteredCandidates.length !== 1 ? 's' : ''}` : "Manage and track all candidate profiles"}
    >
      <div className="space-y-6">
        {/* Job Filter Banner */}
        {filterJobId && filterJobTitle && (
          <div className="flex items-center justify-between p-3 rounded-lg bg-primary/10 border border-primary/20">
            <div className="flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">
                Filtering by job: <span className="text-primary">{filterJobTitle}</span>
              </span>
              <Badge variant="secondary" className="text-xs">
                {filteredCandidates.length} candidate{filteredCandidates.length !== 1 ? 's' : ''}
              </Badge>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearJobFilter}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4 mr-1" />
              Clear filter
            </Button>
          </div>
        )}

        {/* Actions Bar */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black" />
            <Input
              placeholder="Search by name, email, or skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-accent text-accent-foreground placeholder:text-black/50 border-accent"
            />
          </div>
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Status: {statusFilter === "all" ? "All" : statusConfig[statusFilter]?.label || statusFilter}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-card">
                <DropdownMenuItem onClick={() => setStatusFilter("all")}>
                  All Statuses
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setStatusFilter("parsed")}>
                  <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-600" />
                  Parsed
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setStatusFilter("pending_review")}>
                  <Clock className="w-4 h-4 mr-2 text-amber-600" />
                  Review
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setStatusFilter("approved")}>
                  <CheckCircle2 className="w-4 h-4 mr-2 text-purple-600" />
                  Approved
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setStatusFilter("error")}>
                  <AlertCircle className="w-4 h-4 mr-2 text-red-600" />
                  Error
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Dialog open={isUploadOpen} onOpenChange={(open) => {
              // Prevent closing during processing - user must wait for completion
              if (!open && isProcessing) {
                console.log('[CV Upload Dialog] Blocked close attempt during processing');
                return;
              }
              setIsUploadOpen(open);
            }}>
              <DialogTrigger asChild>
                <Button size="sm" className="cta-gradient border-0">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Resumes
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-accent border-2 border-black">
                <DialogHeader>
                  <DialogTitle className="font-display text-black">
                    Upload Candidate Resumes
                  </DialogTitle>
                  <DialogDescription className="text-black/70">
                    Drag and drop resume files or click to browse. Files are stored securely in cloud storage.
                  </DialogDescription>
                </DialogHeader>
                
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  multiple
                  accept=".txt,.pdf,.docx"
                  onChange={(e) => handleFiles(e.target.files)}
                />
                
                <div
                  className={cn(
                    "mt-4 border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 cursor-pointer",
                    isDragging
                      ? "border-black bg-black/5"
                      : "border-black/50 hover:border-black"
                  )}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDragging(false);
                    handleFiles(e.dataTransfer.files);
                  }}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-black/10 flex items-center justify-center">
                    <FileText className="w-6 h-6 text-black" />
                  </div>
                  <p className="text-black font-medium mb-1">
                    Drop files here or click to upload
                  </p>
                  <p className="text-sm text-black/70">
                    PDF, DOCX, or TXT files up to 10MB each
                  </p>
                </div>

                {/* File List */}
                {uploadFiles.length > 0 && (
                  <div className="mt-4 space-y-2 max-h-48 overflow-y-auto">
                    {uploadFiles.map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-black/10 rounded-lg"
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <FileText className="w-4 h-4 text-black/70 flex-shrink-0" />
                          <span className="text-sm text-black truncate">{item.file.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {item.status === 'pending' && (
                            <Badge variant="secondary" className="text-xs bg-black/20 text-black">Pending</Badge>
                          )}
                          {item.status === 'scanning' && (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin text-black" />
                              <span className="text-xs text-black/70">Scanning...</span>
                            </>
                          )}
                          {item.status === 'uploading' && (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin text-black" />
                              <span className="text-xs text-black/70">Uploading</span>
                            </>
                          )}
                          {item.status === 'parsing' && (
                            <div className="flex items-center gap-2">
                              <Loader2 className="w-4 h-4 animate-spin text-primary" />
                              <span className="text-xs text-black/80 font-medium italic">
                                ✨ LurqAI is decoding brilliance...
                              </span>
                            </div>
                          )}
                          {item.status === 'parsed' && (
                            <CheckCircle2 className="w-4 h-4 text-success" />
                          )}
                          {item.status === 'error' && (
                            <div className="flex items-center gap-2 max-w-[200px]">
                              <AlertCircle className="w-4 h-4 text-destructive shrink-0" />
                              <span className="text-xs text-destructive truncate" title={item.error}>
                                {item.error || 'Processing failed'}
                              </span>
                            </div>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-6 h-6 text-black hover:bg-black/10"
                            onClick={() => removeFile(index)}
                            disabled={item.status === 'scanning' || item.status === 'uploading' || item.status === 'parsing'}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Progress */}
                {isProcessing && uploadFiles.length > 0 && (
                  <div className="mt-4">
                    <Progress value={progressPercent} className="h-2" />
                    <p className="text-sm text-black/70 mt-2 text-center">
                      Processing {parsedCount} of {uploadFiles.length} files...
                    </p>
                  </div>
                )}
                
                {/* Processing indicator when files were lost due to tab switch */}
                {isProcessing && uploadFiles.length === 0 && (
                  <div className="mt-4 flex flex-col items-center gap-3 p-4">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    <p className="text-sm text-black/70 text-center font-medium">
                      LurqAI is decoding brilliance...
                    </p>
                    <p className="text-xs text-black/50 text-center">
                      Processing continues in the background
                    </p>
                  </div>
                )}
                
                <div className="flex justify-end gap-2 mt-4">
                  <Button 
                    variant="outline" 
                    onClick={closeUploadDialog}
                    className="border-black text-black hover:bg-black/10"
                  >
                    {uploadFiles.some((f) => f.status === 'parsed') ? 'Done' : 'Cancel'}
                  </Button>
                  <Button
                    className="bg-primary hover:bg-primary/90 text-primary-foreground border-0"
                    onClick={processFiles}
                    disabled={uploadFiles.filter((f) => f.status === 'pending').length === 0 || isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      'Process CVs'
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Inline Job Search Progress Section */}
        {(isPipelineRunning || searchComplete || searchError || pipelineCandidate) && (
          <div 
            ref={searchResultsRef}
            className={`rounded-xl border-2 p-6 ${
              searchError 
                ? 'bg-destructive/10 border-destructive'
                : 'bg-accent border-accent'
            }`}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                {isPipelineRunning ? (
                  <Loader2 className="w-6 h-6 animate-spin text-black" />
                ) : searchComplete ? (
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                ) : searchError ? (
                  <AlertCircle className="w-6 h-6 text-destructive" />
                ) : (
                  <Briefcase className="w-6 h-6 text-black" />
                )}
                <div>
                  <h3 className="font-semibold text-black text-lg">
                    {isPipelineRunning 
                      ? `Lurqing Jobs for ${pipelineCandidate?.name}...`
                      : searchComplete
                      ? `Lurq Complete for ${pipelineCandidate?.name}`
                      : searchError
                      ? "Lurq Failed"
                      : `Job Matches for ${pipelineCandidate?.name}`
                    }
                  </h3>
                  <p className="text-sm text-black/70">{searchStatus}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {pausedSearch && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleAutoContinue(pausedSearch.boardsSearched)}
                    className="border-black text-black hover:bg-black/10"
                  >
                    Continue Search ({pausedSearch.boardsSearched}/{pausedSearch.totalBoards})
                  </Button>
                )}
                {isPipelineRunning && (
                  <Badge variant="outline" className="bg-white text-black border-black animate-pulse">
                    {realTimeJobs.length} jobs found
                  </Badge>
                )}
                {(searchComplete || searchError) && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={dismissSearchProgress}
                    className="text-black hover:bg-black/10"
                  >
                    <X className="w-4 h-4 mr-1" />
                    Dismiss
                  </Button>
                )}
              </div>
            </div>

            {/* Real-time jobs table - always show when searching or has results */}
            {(isPipelineRunning || searchComplete || realTimeJobs.length > 0) && (
              <div className="overflow-x-auto rounded-lg border-2 border-accent">
                <table className="w-full accent-grid-table">
                  <thead>
                    <tr className="bg-accent">
                      <th className="px-4 py-3 text-left text-sm font-semibold text-black border-r border-accent-foreground/20 w-36">Company</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-black border-r border-accent-foreground/20 w-48">Job Title</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-black border-r border-accent-foreground/20 w-44">Location</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-black border-r border-accent-foreground/20 w-36">Job URL</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-black border-r border-accent-foreground/20 w-24">Suitability %</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-black border-r border-accent-foreground/20">Reasoning</th>
                      <th className="px-4 py-3 w-24"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {realTimeJobs.length === 0 && isPipelineRunning ? (
                      // Empty state with skeleton rows while searching
                      <>
                        {[1, 2, 3].map((i) => (
                          <tr key={`skeleton-${i}`} className="bg-accent border-t border-accent-foreground/20">
                            <td className="px-4 py-3 border-r border-accent-foreground/20">
                              <div className="h-4 bg-black/10 rounded animate-pulse w-24"></div>
                            </td>
                            <td className="px-4 py-3 border-r border-accent-foreground/20">
                              <div className="h-4 bg-black/10 rounded animate-pulse w-32"></div>
                            </td>
                            <td className="px-4 py-3 border-r border-accent-foreground/20">
                              <div className="h-4 bg-black/10 rounded animate-pulse w-20"></div>
                            </td>
                            <td className="px-4 py-3 border-r border-accent-foreground/20">
                              <div className="h-4 bg-black/10 rounded animate-pulse w-16"></div>
                            </td>
                            <td className="px-4 py-3 border-r border-accent-foreground/20">
                              <div className="h-6 bg-black/10 rounded animate-pulse w-12"></div>
                            </td>
                            <td className="px-4 py-3 border-r border-accent-foreground/20">
                              <div className="h-6 bg-black/10 rounded animate-pulse w-16"></div>
                            </td>
                            <td className="px-2 py-3">
                              <div className="h-8 bg-black/10 rounded-full animate-pulse w-16"></div>
                            </td>
                          </tr>
                        ))}
                        <tr className="bg-accent">
                          <td colSpan={7} className="px-4 py-4 text-center text-black/60 text-sm">
                            <div className="flex items-center justify-center gap-2">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              Lurqing job boards for matching positions...
                              
                            </div>
                          </td>
                        </tr>
                      </>
                    ) : realTimeJobs.length === 0 && searchComplete && pausedSearch ? (
                      // Search paused with boards remaining - show continue prompt
                      <tr className="bg-accent">
                        <td colSpan={7} className="px-4 py-8 text-center text-black/70">
                          <div className="flex flex-col items-center gap-3">
                            <Loader2 className="w-8 h-8 text-black/40" />
                            <p className="font-medium">Search paused ({pausedSearch.boardsSearched}/{pausedSearch.totalBoards} boards searched)</p>
                            <p className="text-sm text-black/50">No matches found yet. Click "Continue Search" to check more job boards.</p>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleAutoContinue(pausedSearch.boardsSearched)}
                              className="border-black text-black hover:bg-black/10 mt-2"
                            >
                              Continue Search ({pausedSearch.boardsSearched}/{pausedSearch.totalBoards})
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ) : realTimeJobs.length === 0 && searchComplete ? (
                      // No results found state - only show when search is truly complete (no pausedSearch)
                      <tr className="bg-accent">
                        <td colSpan={7} className="px-4 py-8 text-center text-black/70">
                          <div className="flex flex-col items-center gap-2">
                            <XCircle className="w-8 h-8 text-black/40" />
                            <p className="font-medium">No matching jobs found</p>
                            <p className="text-sm text-black/50">Try adjusting the candidate's skills or desired location</p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      // Jobs found - render them sorted by match score (best first)
                      realTimeJobs
                        .filter((job) => !shortlistedMatchIds.has(job.matchId))
                        .sort((a, b) => b.match_score - a.match_score)
                        .map((job, index) => (
                          <tr 
                            key={job.id} 
                            className="bg-accent border-t border-accent-foreground/20 animate-fade-in hover:bg-accent/80 transition-colors"
                            style={{ animationDelay: `${index * 50}ms` }}
                          >
                            <td className="px-4 py-3 text-sm text-black border-r border-accent-foreground/20">
                              <div className="flex items-center gap-1">
                                <Building2 className="w-3 h-3" />
                                {job.company_name || "-"}
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm text-black font-medium border-r border-accent-foreground/20">
                              <Link 
                                to={`/jobs/${job.id}`}
                                className="hover:underline"
                              >
                                {job.title}
                              </Link>
                            </td>
                            <td className="px-4 py-3 text-sm text-black border-r border-accent-foreground/20">
                              <div className="flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                {job.location || "-"}
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm text-black border-r border-accent-foreground/20">
                              {job.source_url ? (
                                <a
                                  href={job.source_url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-1 hover:underline"
                                >
                                  {truncateUrl(job.source_url)}
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              ) : (
                                "-"
                              )}
                            </td>
                            <td className="px-4 py-3 text-sm border-r border-accent-foreground/20">
                              <Badge className="bg-white text-black border border-black">
                                {job.match_score}%
                              </Badge>
                            </td>
                            <td className="px-4 py-3 text-sm text-black border-r border-accent-foreground/20 min-w-[400px]">
                              <ExpandableReasoning reason={job.match_reason} />
                            </td>
                            <td className="px-2 py-3">
                              <Button
                                onClick={() => handleAddToShortlist(job.matchId)}
                                disabled={addingMatchId === job.matchId}
                                className="rounded-full bg-accent text-black font-semibold hover:bg-accent hover:text-black border-2 border-black px-6"
                              >
                                {addingMatchId === job.matchId ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  "ADD"
                                )}
                              </Button>
                            </td>
                          </tr>
                        ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Search complete banner */}
            {searchComplete && realTimeJobs.length > 0 && (
              <div className="mt-4 p-4 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-lg border border-green-500/30 animate-fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-black">Search Complete!</p>
                      <p className="text-sm text-black/70">
                        Found {realTimeJobs.length} matching job{realTimeJobs.length !== 1 ? 's' : ''} for {pipelineCandidate?.name}
                      </p>
                    </div>
                  </div>
                  <Button
                    onClick={() => navigate(`/candidates/${pipelineCandidate?.id}`)}
                    className="rounded-full bg-black text-white font-semibold hover:bg-black/80"
                  >
                    View Full Details
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}

            {/* "Error report" / filtered-out reasons */}
            <RejectionSummaryPanel
              candidateId={pipelineCandidate?.id ?? null}
              searchComplete={searchComplete}
              isSearching={isPipelineRunning}
            />

            {/* Diagnostics panel for debugging */}
            <SearchDiagnosticsPanel
              diagnostics={diagnostics}
              isVisible={isPipelineRunning || searchComplete}
            />

            {/* Apollo Credits Exhausted Warning */}
            {apolloCreditsExhausted && (
              <div className="mt-4 p-4 bg-gradient-to-r from-amber-500/20 to-orange-500/20 rounded-lg border border-amber-500/30 animate-fade-in">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                    <AlertCircle className="w-6 h-6 text-amber-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-black">Contact Enrichment Unavailable</p>
                    <p className="text-sm text-black/70 mt-1">
                      Apollo API credits have been exhausted. Job matching is still working, but stakeholder contact information won't be enriched until credits are replenished.
                    </p>
                    <p className="text-xs text-black/50 mt-2">
                      Visit your Apollo dashboard to upgrade your plan or add more credits.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Error message */}
            {searchError && (
              <div className="mt-4 p-3 bg-white/50 rounded-lg">
                <p className="text-destructive text-sm">{searchError}</p>
              </div>
            )}
          </div>
        )}

        {/* Candidates Table - hidden during active job search to reduce clutter */}
        {!(isPipelineRunning || pipelineCandidate) && (
        <div className="bg-card rounded-xl border border-border/50 shadow-sm overflow-hidden">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredCandidates.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FileText className="w-12 h-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No candidates found</p>
              <p className="text-sm text-muted-foreground/70 mt-1">
                Upload CVs to get started
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="bg-accent text-black">
                  <TableHead className="font-semibold">Candidate</TableHead>
                  <TableHead className="font-semibold">Contact</TableHead>
                  <TableHead className="font-semibold">Skills</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold">Experience</TableHead>
                  <TableHead className="font-semibold">Added</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {candidatesPagination.paginatedItems.map((candidate, index) => {
                  const status = statusConfig[candidate.status] || statusConfig.pending_review;
                  const StatusIcon = status.icon;
                  return (
                    <TableRow
                      key={candidate.id}
                      className="hover:bg-muted/30 transition-colors animate-slide-up"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarFallback className="bg-primary/10 text-primary font-medium text-sm">
                              {candidate.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .slice(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <Link
                              to={`/candidates/${candidate.id}`}
                              className="font-medium hover:underline transition-colors text-primary"
                            >
                              {candidate.name}
                            </Link>
                            <p className="text-sm text-muted-foreground">
                              {candidate.current_title || candidate.address || 'No title'}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <p className="text-sm text-primary">{candidate.email || '-'}</p>
                        <p className="text-sm text-muted-foreground">
                          {candidate.mobile || '-'}
                        </p>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {(candidate.skills || []).slice(0, 3).map((skill) => (
                            <Badge
                              key={skill}
                              className="text-xs bg-primary text-primary-foreground"
                            >
                              {skill}
                            </Badge>
                          ))}
                          {(candidate.skills || []).length > 3 && (
                            <Badge
                              variant="secondary"
                              className="text-xs bg-muted"
                            >
                              +{candidate.skills.length - 3}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={cn("gap-1", status.className)}
                        >
                          <StatusIcon className="w-3 h-3" />
                          {status.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-muted-foreground">
                          {candidate.experience_years
                            ? `${candidate.experience_years} yrs`
                            : '-'}
                        </span>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDate(candidate.created_at)}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="w-8 h-8">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openCandidateProfile(candidate)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View Profile
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => runMatchingPipeline(candidate)}>
                              <Briefcase className="w-4 h-4 mr-2" />
                              Find Jobs
                            </DropdownMenuItem>
                            {candidate.cv_file_url && (
                              <DropdownMenuItem
                                onClick={() => downloadCV(candidate.cv_file_url!, candidate.name)}
                              >
                                <Download className="w-4 h-4 mr-2" />
                                Download CV
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem>
                              <Mail className="w-4 h-4 mr-2" />
                              Send Email
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={async () => {
                                try {
                                  const { error } = await supabase
                                    .from('candidates')
                                    .delete()
                                    .eq('id', candidate.id);
                                  
                                  if (error) throw error;
                                  
                                  setCandidates((prev) => prev.filter((c) => c.id !== candidate.id));
                                  toast({
                                    title: "Candidate deleted",
                                    description: `${candidate.name} has been removed`,
                                  });
                                } catch (error) {
                                  console.error('Error deleting candidate:', error);
                                  toast({
                                    title: "Delete failed",
                                    description: error instanceof Error ? error.message : "Could not delete the candidate. Only admins can delete candidates.",
                                    variant: "destructive",
                                  });
                                }
                              }}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
          
          {/* Pagination */}
          <ListPagination
            currentPage={candidatesPagination.currentPage}
            totalPages={candidatesPagination.totalPages}
            pageSize={candidatesPagination.pageSize}
            totalItems={candidatesPagination.totalItems}
            startIndex={candidatesPagination.startIndex}
            endIndex={candidatesPagination.endIndex}
            hasNextPage={candidatesPagination.hasNextPage}
            hasPreviousPage={candidatesPagination.hasPreviousPage}
            onPageChange={candidatesPagination.goToPage}
            onPageSizeChange={candidatesPagination.setPageSize}
          />
        </div>
        )}

        {/* View Profile Dialog */}
        <Dialog open={!!selectedCandidate} onOpenChange={(open) => { if (!open) { setSelectedCandidate(null); setCandidateMatches([]); } }}>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-display flex items-center gap-3">
                <Avatar className="w-10 h-10">
                  <AvatarFallback className="bg-primary/10 text-primary font-medium">
                    {selectedCandidate?.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
                {selectedCandidate?.name}
              </DialogTitle>
              <DialogDescription>
                {selectedCandidate?.current_title || "Candidate Profile"}
              </DialogDescription>
            </DialogHeader>
            
            {selectedCandidate && (
              <div className="space-y-6 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="font-medium">{selectedCandidate.email || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Mobile</p>
                    <p className="font-medium">{selectedCandidate.mobile || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Experience</p>
                    <p className="font-medium">
                      {selectedCandidate.experience_years ? `${selectedCandidate.experience_years} years` : "-"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <Badge
                      variant="outline"
                      className={cn("gap-1", (statusConfig[selectedCandidate.status] || statusConfig.pending_review).className)}
                    >
                      {(statusConfig[selectedCandidate.status] || statusConfig.pending_review).label}
                    </Badge>
                  </div>
                </div>
                
                {selectedCandidate.address && (
                  <div>
                    <p className="text-sm text-muted-foreground">Address</p>
                    <p className="font-medium">{selectedCandidate.address}</p>
                  </div>
                )}
                
                {selectedCandidate.skills && selectedCandidate.skills.length > 0 && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Skills</p>
                    <div className="flex flex-wrap gap-1">
                      {selectedCandidate.skills.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Linked Job Matches Section */}
                <div className="border-t pt-4">
                  <p className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-accent" />
                    Linked Job Matches ({candidateMatches.length})
                  </p>
                  {isLoadingMatches ? (
                    <div className="flex items-center justify-center py-4">
                      <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                    </div>
                  ) : candidateMatches.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No job matches found. Use "Find Jobs" to match this candidate.</p>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {candidateMatches.map((match) => (
                        <div
                          key={match.id}
                          className="flex items-center justify-between p-3 bg-muted/50 rounded-lg cursor-pointer hover:bg-muted transition-colors"
                          onClick={() => {
                            setSelectedCandidate(null);
                            setCandidateMatches([]);
                            navigate(`/jobs?search=${encodeURIComponent(match.jobs.title)}`);
                          }}
                        >
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-medium truncate text-accent hover:underline">{match.jobs.title}</span>
                              {match.jobs.source_url && (
                                <a
                                  href={match.jobs.source_url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-muted-foreground hover:text-link transition-colors"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </a>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground truncate">
                              {match.jobs.companies?.name || 'Unknown Company'}
                            </p>
                          </div>
                          <Badge className={cn(
                            "shrink-0 ml-2",
                            match.match_score >= 90 ? "bg-success" :
                            match.match_score >= 80 ? "bg-accent" : "bg-primary"
                          )}>
                            {match.match_score}%
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {selectedCandidate.cv_file_url && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => downloadCV(selectedCandidate.cv_file_url!, selectedCandidate.name)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download CV
                  </Button>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Pre-Search Questions Dialog */}
        {preSearchCandidate && (
          <PreSearchQuestionsDialog
            open={!!preSearchCandidate}
            onOpenChange={(open) => {
              // Only clear preSearchCandidate when closing; do NOT clear pipelineCandidate here
              if (!open) setPreSearchCandidate(null);
            }}
            candidateId={preSearchCandidate.id}
            candidateName={preSearchCandidate.name}
            onComplete={() => {
              // Refetch candidates list but do NOT clear pipelineCandidate — the search is running
              fetchCandidates();
            }}
            onSearchStarted={handlePreSearchComplete}
          />
        )}

        {/* Suitability Reason Dialog */}
        <Dialog open={showReasonDialog} onOpenChange={setShowReasonDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Suitability Reasoning</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              {selectedReason ? (
                <p className="text-foreground">{selectedReason}</p>
              ) : (
                <p className="text-muted-foreground">No reasoning available for this match.</p>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
