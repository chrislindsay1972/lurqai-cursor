import React, { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useRecycleBin, getEntityLabel, getEntityName, DeletedRecord } from '@/hooks/useRecycleBin';
import { formatDistanceToNow } from 'date-fns';
import { useLocaleFormat } from "@/hooks/useLocaleFormat";
import { Trash2, RotateCcw, AlertTriangle, Search, Filter, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const ENTITY_TYPES = [
  { value: 'all', label: 'All Types' },
  { value: 'candidates', label: 'Candidates' },
  { value: 'jobs', label: 'Jobs' },
  { value: 'companies', label: 'Companies' },
  { value: 'stakeholders', label: 'Stakeholders' },
  { value: 'job_boards', label: 'Job Boards' },
  { value: 'matches', label: 'Matches' },
];

const getEntityColor = (entityType: string): string => {
  const colors: Record<string, string> = {
    candidates: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    jobs: 'bg-green-500/10 text-green-500 border-green-500/20',
    companies: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
    stakeholders: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
    job_boards: 'bg-cyan-500/10 text-cyan-500 border-cyan-500/20',
    matches: 'bg-pink-500/10 text-pink-500 border-pink-500/20',
  };
  return colors[entityType] || 'bg-muted text-muted-foreground';
};

export default function RecycleBin() {
  const { formatDate } = useLocaleFormat();
  const { deletedRecords, isLoading, restoreFromRecycleBin, permanentlyDelete, emptyRecycleBin } = useRecycleBin();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [selectedRecord, setSelectedRecord] = useState<DeletedRecord | null>(null);

  const filteredRecords = deletedRecords.filter((record) => {
    const matchesSearch = getEntityName(record).toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || record.entity_type === filterType;
    return matchesSearch && matchesType;
  });

  const handleRestore = (record: DeletedRecord) => {
    restoreFromRecycleBin.mutate(record);
  };

  const handlePermanentDelete = (recordId: string) => {
    permanentlyDelete.mutate(recordId);
    setSelectedRecord(null);
  };

  const handleEmptyRecycleBin = () => {
    emptyRecycleBin.mutate();
  };

  if (isLoading) {
    return (
      <DashboardLayout title="Recycle Bin">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout 
      title="Recycle Bin" 
      subtitle="Deleted items are automatically removed after 30 days"
    >
      <div className="space-y-6">
      <div className="flex items-center justify-end">
        {deletedRecords.length > 0 && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="w-4 h-4 mr-2" />
                Empty Recycle Bin
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Empty Recycle Bin?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete all {deletedRecords.length} items in the recycle bin.
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleEmptyRecycleBin}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Empty Recycle Bin
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>

      <Card>
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search deleted items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                {ENTITY_TYPES.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {filteredRecords.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Trash2 className="w-12 h-12 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium">Recycle bin is empty</h3>
              <p className="text-muted-foreground mt-1">
                {searchQuery || filterType !== 'all'
                  ? 'No items match your search criteria'
                  : 'Deleted items will appear here'}
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Deleted</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">
                        {getEntityName(record)}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={getEntityColor(record.entity_type)}>
                          {getEntityLabel(record.entity_type)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDistanceToNow(new Date(record.deleted_at), { addSuffix: true })}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(record.expires_at)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRestore(record)}
                            disabled={restoreFromRecycleBin.isPending}
                          >
                            <RotateCcw className="w-4 h-4 mr-1" />
                            Restore
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-destructive hover:text-destructive"
                                onClick={() => setSelectedRecord(record)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle className="flex items-center gap-2">
                                  <AlertTriangle className="w-5 h-5 text-destructive" />
                                  Permanently Delete?
                                </AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete "{getEntityName(record)}".
                                  This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handlePermanentDelete(record.id)}
                                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                >
                                  Delete Permanently
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {filteredRecords.length > 0 && (
        <p className="text-sm text-muted-foreground text-center">
          Showing {filteredRecords.length} of {deletedRecords.length} deleted items
        </p>
      )}
      </div>
    </DashboardLayout>
  );
}
