import { useState, useRef, useCallback, useMemo } from "react";
import { useBetterContactEnrich } from "@/hooks/useBetterContactEnrich";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useListPagination } from "@/hooks/useListPagination";
import { ListPagination } from "@/components/ui/list-pagination";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { StakeholderForm, StakeholderFormData } from "@/components/stakeholders/StakeholderForm";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  Search,
  Filter,
  Plus,
  MoreHorizontal,
  Mail,
  Phone,
  Linkedin,
  Building2,
  Trash2,
  Pencil,
  Globe,
} from "lucide-react";

interface Stakeholder {
  id: string;
  name: string;
  title: string | null;
  email: string | null;
  phone: string | null;
  linkedin_url: string | null;
  location: string | null;
  company_id: string | null;
  job_board_id: string | null;
  source: string | null;
  contacted: boolean;
  notes: string | null;
  created_by: string | null;
  updated_at: string;
  created_at: string;
  companies?: { id: string; name: string } | null;
  job_boards?: { id: string; name: string } | null;
}

interface Company {
  id: string;
  name: string;
}

interface JobBoard {
  id: string;
  name: string;
}

export default function Stakeholders() {
  const { user, role, hasRole } = useAuth();
  const { enrichContact } = useBetterContactEnrich();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [ownershipFilter, setOwnershipFilter] = useState<"my" | "all">("my");
  const [contactedFilter, setContactedFilter] = useState<"all" | "contacted" | "not_contacted">("all");
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingStakeholder, setEditingStakeholder] = useState<Stakeholder | null>(null);
  const [formData, setFormData] = useState<StakeholderFormData>({
    name: "",
    title: "",
    email: "",
    phone: "",
    linkedin_url: "",
    location: "",
    company_id: "",
    job_board_id: "",
    source: "manual",
    contacted: false,
    notes: "",
  });

  const { data: stakeholders = [], isLoading } = useQuery({
    queryKey: ["stakeholders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stakeholders")
        .select("*, companies(id, name), job_boards(id, name)")
        .order("updated_at", { ascending: false });

      if (error) throw error;
      return data as Stakeholder[];
    },
  });

  const { data: companies = [] } = useQuery({
    queryKey: ["companies-list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("companies")
        .select("id, name")
        .order("name");
      if (error) throw error;
      return data as Company[];
    },
  });

  const { data: jobBoards = [] } = useQuery({
    queryKey: ["job-boards-list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("job_boards")
        .select("id, name")
        .eq("status", "active")
        .order("name");
      if (error) throw error;
      return data as JobBoard[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const { data: inserted, error } = await supabase.from("stakeholders").insert({
        name: data.name,
        title: data.title || null,
        email: data.email || null,
        phone: data.phone || null,
        linkedin_url: data.linkedin_url || null,
        location: data.location || null,
        company_id: data.company_id || null,
        job_board_id: data.job_board_id || null,
        source: data.source || "manual",
        contacted: data.contacted,
        notes: data.notes || null,
        created_by: user?.id,
      }).select("id, name, company_id").single();
      if (error) throw error;
      return { ...data, id: inserted.id, companyName: undefined as string | undefined, companyDomain: undefined as string | undefined };
    },
    onSuccess: async (result) => {
      queryClient.invalidateQueries({ queryKey: ["stakeholders"] });
      toast.success("Stakeholder added successfully");
      resetForm();
      setIsAddDialogOpen(false);

      // Auto-enrich with LurqAI
      const nameParts = result.name.trim().split(/\s+/);
      const firstName = nameParts[0] || "";
      const lastName = nameParts.slice(1).join(" ") || nameParts[0] || "";

      // Get company name if available
      let companyName: string | undefined;
      if (result.company_id) {
        const company = companies.find(c => c.id === result.company_id);
        companyName = company?.name;
      }

      toast.info("LurqAI enrichment starting automatically...");
      await enrichContact({
        stakeholderId: result.id,
        firstName,
        lastName,
        companyName,
        linkedinUrl: result.linkedin_url || undefined,
      });
      queryClient.invalidateQueries({ queryKey: ["stakeholders"] });
    },
    onError: (error) => {
      toast.error("Failed to add stakeholder: " + error.message);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const { error } = await supabase
        .from("stakeholders")
        .update({
          name: data.name,
          title: data.title || null,
          email: data.email || null,
          phone: data.phone || null,
          linkedin_url: data.linkedin_url || null,
          location: data.location || null,
          company_id: data.company_id || null,
          job_board_id: data.job_board_id || null,
          source: data.source || "manual",
          contacted: data.contacted,
          notes: data.notes || null,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["stakeholders"] });
      toast.success("Stakeholder updated successfully");
      resetForm();
      setEditingStakeholder(null);
    },
    onError: (error) => {
      toast.error("Failed to update stakeholder: " + error.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("stakeholders").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["stakeholders"] });
      toast.success("Stakeholder deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete stakeholder: " + error.message);
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      title: "",
      email: "",
      phone: "",
      linkedin_url: "",
      location: "",
      company_id: "",
      job_board_id: "",
      source: "manual",
      contacted: false,
      notes: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) {
      toast.error("Name is required");
      return;
    }
    if (editingStakeholder) {
      updateMutation.mutate({ id: editingStakeholder.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (stakeholder: Stakeholder) => {
    setEditingStakeholder(stakeholder);
    setFormData({
      name: stakeholder.name,
      title: stakeholder.title || "",
      email: stakeholder.email || "",
      phone: stakeholder.phone || "",
      linkedin_url: stakeholder.linkedin_url || "",
      location: stakeholder.location || "",
      company_id: stakeholder.company_id || "",
      job_board_id: stakeholder.job_board_id || "",
      source: stakeholder.source || "manual",
      contacted: stakeholder.contacted,
      notes: stakeholder.notes || "",
    });
  };

  // Get unique sources for filter dropdown
  const uniqueSources = [...new Set(stakeholders.filter(s => s.source).map(s => s.source!))].sort();

  const filteredStakeholders = stakeholders.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.companies?.name || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.title || "").toLowerCase().includes(searchQuery.toLowerCase());
    const matchesOwnership = ownershipFilter === "all" || s.created_by === user?.id;
    const matchesContacted = contactedFilter === "all" || 
      (contactedFilter === "contacted" && s.contacted) || 
      (contactedFilter === "not_contacted" && !s.contacted);
    const matchesSource = sourceFilter === "all" || s.source === sourceFilter;
    return matchesSearch && matchesOwnership && matchesContacted && matchesSource;
  });

  // Sort filtered stakeholders by updated_at (most recently modified first)
  const sortedFilteredStakeholders = useMemo(() => {
    return [...filteredStakeholders].sort((a, b) => {
      const aTime = new Date(a.updated_at || a.created_at).getTime();
      const bTime = new Date(b.updated_at || b.created_at).getTime();
      return bTime - aTime;
    });
  }, [filteredStakeholders]);

  // Pagination
  const stakeholdersPagination = useListPagination(sortedFilteredStakeholders, {
    storageKey: 'stakeholders',
  });

  const canDelete = hasRole("admin");

  const dialogContentRef = useRef<HTMLDivElement>(null);
  const editDialogContentRef = useRef<HTMLDivElement>(null);

  const handleAddCancel = useCallback(() => {
    setIsAddDialogOpen(false);
    resetForm();
  }, []);

  const handleEditCancel = useCallback(() => {
    setEditingStakeholder(null);
    resetForm();
  }, []);

  return (
    <DashboardLayout
      title="Stakeholders"
      subtitle="Key contacts at target companies"
    >
      <div className="space-y-6">
        {/* Actions Bar */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-accent-foreground" />
            <Input
              placeholder="Search stakeholders, companies, or titles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-accent text-accent-foreground placeholder:text-black/50 border-accent"
            />
          </div>
          <div className="flex gap-2">
            {/* Ownership Toggle */}
            <div className="flex bg-muted rounded-lg p-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setOwnershipFilter("my")}
                className={cn("px-3", ownershipFilter === "my" && "bg-card shadow-sm")}
              >
                My Stakeholders
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setOwnershipFilter("all")}
                className={cn("px-3", ownershipFilter === "all" && "bg-card shadow-sm")}
              >
                All Stakeholders
              </Button>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Status: {contactedFilter === "all" ? "All" : contactedFilter === "contacted" ? "Contacted" : "Not Contacted"}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-card">
                <DropdownMenuItem onClick={() => setContactedFilter("all")}>
                  All Statuses
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setContactedFilter("contacted")}>
                  <Mail className="w-4 h-4 mr-2 text-emerald-600" />
                  Contacted
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setContactedFilter("not_contacted")}>
                  <Mail className="w-4 h-4 mr-2 text-muted-foreground" />
                  Not Contacted
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {uniqueSources.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Globe className="w-4 h-4 mr-2" />
                    Source: {sourceFilter === "all" ? "All" : sourceFilter}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-card max-h-64 overflow-y-auto">
                  <DropdownMenuItem onClick={() => setSourceFilter("all")}>
                    All Sources
                  </DropdownMenuItem>
                  {uniqueSources.map((source) => (
                    <DropdownMenuItem key={source} onClick={() => setSourceFilter(source)}>
                      {source}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="accent-gradient border-0" onClick={resetForm}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Stakeholder
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg" ref={dialogContentRef} onInteractOutside={(e) => e.preventDefault()}>
                <DialogHeader>
                  <DialogTitle>Add New Stakeholder</DialogTitle>
                </DialogHeader>
                <StakeholderForm
                  formData={formData}
                  setFormData={setFormData}
                  onSubmit={handleSubmit}
                  onCancel={handleAddCancel}
                  isPending={createMutation.isPending}
                  companies={companies}
                  jobBoards={jobBoards}
                  containerRef={dialogContentRef}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stakeholders Table */}
        <div className="bg-card rounded-xl border border-border/50 shadow-sm overflow-hidden">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading...</div>
          ) : filteredStakeholders.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No stakeholders found. Add your first one!
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="bg-accent">
                  <TableHead className="font-semibold text-accent-foreground">Stakeholder</TableHead>
                  <TableHead className="font-semibold text-accent-foreground">Company</TableHead>
                  <TableHead className="font-semibold text-accent-foreground">Contact</TableHead>
                  <TableHead className="font-semibold text-accent-foreground">Status</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stakeholdersPagination.paginatedItems.map((stakeholder, index) => (
                  <TableRow
                    key={stakeholder.id}
                    className="hover:bg-muted/30 transition-colors animate-slide-up"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-accent/10 text-accent font-medium text-sm">
                            {stakeholder.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <Link
                            to={`/stakeholders/${stakeholder.id}`}
                            className="font-medium text-foreground hover:text-link hover:underline transition-colors"
                          >
                            {stakeholder.name}
                          </Link>
                          <p className="text-sm text-muted-foreground">
                            {stakeholder.title || "-"}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {stakeholder.companies ? (
                        <Link
                          to={`/companies/${stakeholder.companies.id}`}
                          className="flex items-center gap-2 text-foreground hover:text-link hover:underline transition-colors"
                        >
                          <Building2 className="w-4 h-4 text-muted-foreground" />
                          <span>{stakeholder.companies.name}</span>
                        </Link>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {stakeholder.email ? (
                          <a
                            href={`mailto:${stakeholder.email}`}
                            className="text-sm flex items-center gap-1 hover:text-link transition-colors"
                          >
                            <Mail className="w-3 h-3 text-muted-foreground" />
                            <span className="truncate max-w-[180px]">{stakeholder.email}</span>
                          </a>
                        ) : (
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            No email
                          </span>
                        )}
                        {stakeholder.linkedin_url && (
                          <a
                            href={stakeholder.linkedin_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm flex items-center gap-1 text-primary hover:text-primary/80"
                          >
                            <Linkedin className="w-3 h-3" />
                            LinkedIn
                          </a>
                        )}
                        {stakeholder.phone && (
                          <p className="text-sm flex items-center gap-1 text-muted-foreground">
                            <Phone className="w-3 h-3" />
                            {stakeholder.phone}
                          </p>
                        )}
                        {stakeholder.location && (
                          <p className="text-xs text-muted-foreground truncate max-w-[180px]">
                            📍 {stakeholder.location}
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {stakeholder.contacted ? (
                        <Badge
                          variant="outline"
                          className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30"
                        >
                          Contacted
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="bg-amber-500/15 text-amber-600 border-amber-500/30"
                        >
                          AI-Research
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="w-8 h-8">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onSelect={(e) => {
                                e.preventDefault();
                                handleEdit(stakeholder);
                              }}
                            >
                              <Pencil className="w-4 h-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            {stakeholder.email && (
                              <DropdownMenuItem
                                onSelect={(e) => {
                                  e.preventDefault();
                                  window.location.href = `mailto:${stakeholder.email}`;
                                }}
                              >
                                <Mail className="w-4 h-4 mr-2" />
                                Send Email
                              </DropdownMenuItem>
                            )}
                            {stakeholder.linkedin_url && (
                              <DropdownMenuItem
                                onSelect={(e) => {
                                  e.preventDefault();
                                  window.open(stakeholder.linkedin_url!, "_blank");
                                }}
                              >
                                <Linkedin className="w-4 h-4 mr-2" />
                                View LinkedIn
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                        {canDelete && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                            onClick={() => deleteMutation.mutate(stakeholder.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
          
          {/* Pagination */}
          <ListPagination
            currentPage={stakeholdersPagination.currentPage}
            totalPages={stakeholdersPagination.totalPages}
            pageSize={stakeholdersPagination.pageSize}
            totalItems={stakeholdersPagination.totalItems}
            startIndex={stakeholdersPagination.startIndex}
            endIndex={stakeholdersPagination.endIndex}
            hasNextPage={stakeholdersPagination.hasNextPage}
            hasPreviousPage={stakeholdersPagination.hasPreviousPage}
            onPageChange={stakeholdersPagination.goToPage}
            onPageSizeChange={stakeholdersPagination.setPageSize}
          />
        </div>

        {/* Edit Dialog */}
        <Dialog
          open={editingStakeholder !== null}
          onOpenChange={(open) => {
            if (!open) {
              setEditingStakeholder(null);
              resetForm();
            }
          }}
        >
          <DialogContent className="max-w-lg" ref={editDialogContentRef} onInteractOutside={(e) => e.preventDefault()}>
            <DialogHeader>
              <DialogTitle>Edit Stakeholder</DialogTitle>
            </DialogHeader>
            <StakeholderForm
              formData={formData}
              setFormData={setFormData}
              onSubmit={handleSubmit}
              onCancel={handleEditCancel}
              isEdit
              isPending={updateMutation.isPending}
              companies={companies}
              jobBoards={jobBoards}
              containerRef={editDialogContentRef}
            />
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
