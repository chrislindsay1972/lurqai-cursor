import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import type { Json } from '@/integrations/supabase/types';

export interface DeletedRecord {
  id: string;
  entity_type: string;
  entity_id: string;
  entity_data: Record<string, unknown>;
  deleted_by: string;
  deleted_at: string;
  expires_at: string;
}

type EntityType = 'candidates' | 'jobs' | 'companies' | 'stakeholders' | 'job_boards' | 'matches';

const ENTITY_LABELS: Record<EntityType, string> = {
  candidates: 'Candidate',
  jobs: 'Job',
  companies: 'Company',
  stakeholders: 'Stakeholder',
  job_boards: 'Job Board',
  matches: 'Match',
};

export const getEntityLabel = (entityType: string): string => {
  return ENTITY_LABELS[entityType as EntityType] || entityType;
};

export const getEntityName = (record: DeletedRecord): string => {
  const data = record.entity_data;
  
  switch (record.entity_type) {
    case 'candidates':
      return (data.name as string) || 'Unknown Candidate';
    case 'jobs':
      return (data.title as string) || 'Unknown Job';
    case 'companies':
      return (data.name as string) || 'Unknown Company';
    case 'stakeholders':
      return (data.name as string) || 'Unknown Stakeholder';
    case 'job_boards':
      return (data.name as string) || 'Unknown Job Board';
    case 'matches':
      return `Match #${record.entity_id.slice(0, 8)}`;
    default:
      return 'Unknown Record';
  }
};

export function useRecycleBin() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: deletedRecords = [], isLoading, refetch } = useQuery({
    queryKey: ['deleted-records'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('deleted_records')
        .select('*')
        .order('deleted_at', { ascending: false });

      if (error) throw error;
      return data as DeletedRecord[];
    },
    enabled: !!user,
  });

  const moveToRecycleBin = useMutation({
    mutationFn: async ({ entityType, entityId, entityData }: { 
      entityType: EntityType; 
      entityId: string; 
      entityData: Record<string, unknown>;
    }) => {
      if (!user) throw new Error('Not authenticated');

      // Insert into recycle bin
      const { error: insertError } = await supabase
        .from('deleted_records')
        .insert({
          entity_type: entityType,
          entity_id: entityId,
          entity_data: entityData as Json,
          deleted_by: user.id,
        });

      if (insertError) throw insertError;

      // Delete from original table
      const { error: deleteError } = await supabase
        .from(entityType)
        .delete()
        .eq('id', entityId);

      if (deleteError) {
        // Rollback: remove from recycle bin if delete fails
        await supabase
          .from('deleted_records')
          .delete()
          .eq('entity_id', entityId)
          .eq('entity_type', entityType);
        throw deleteError;
      }

      return { entityType, entityId };
    },
    onSuccess: (_, variables) => {
      toast.success(`${getEntityLabel(variables.entityType)} moved to recycle bin`);
      queryClient.invalidateQueries({ queryKey: ['deleted-records'] });
      queryClient.invalidateQueries({ queryKey: [variables.entityType] });
    },
    onError: (error) => {
      toast.error(`Failed to delete: ${error.message}`);
    },
  });

  const restoreFromRecycleBin = useMutation({
    mutationFn: async (record: DeletedRecord) => {
      if (!user) throw new Error('Not authenticated');

      const entityType = record.entity_type as EntityType;
      const entityData = { ...record.entity_data };
      
      // Restore the original ID
      entityData.id = record.entity_id;
      
      // Re-insert into original table
      const { error: insertError } = await supabase
        .from(entityType)
        .insert(entityData as never);

      if (insertError) throw insertError;

      // Remove from recycle bin
      const { error: deleteError } = await supabase
        .from('deleted_records')
        .delete()
        .eq('id', record.id);

      if (deleteError) {
        // Rollback: remove restored record
        await supabase.from(entityType).delete().eq('id', record.entity_id);
        throw deleteError;
      }

      return record;
    },
    onSuccess: (record) => {
      toast.success(`${getEntityLabel(record.entity_type)} restored successfully`);
      queryClient.invalidateQueries({ queryKey: ['deleted-records'] });
      queryClient.invalidateQueries({ queryKey: [record.entity_type] });
    },
    onError: (error) => {
      toast.error(`Failed to restore: ${error.message}`);
    },
  });

  const permanentlyDelete = useMutation({
    mutationFn: async (recordId: string) => {
      const { error } = await supabase
        .from('deleted_records')
        .delete()
        .eq('id', recordId);

      if (error) throw error;
      return recordId;
    },
    onSuccess: () => {
      toast.success('Record permanently deleted');
      queryClient.invalidateQueries({ queryKey: ['deleted-records'] });
    },
    onError: (error) => {
      toast.error(`Failed to permanently delete: ${error.message}`);
    },
  });

  const emptyRecycleBin = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('deleted_records')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Recycle bin emptied');
      queryClient.invalidateQueries({ queryKey: ['deleted-records'] });
    },
    onError: (error) => {
      toast.error(`Failed to empty recycle bin: ${error.message}`);
    },
  });

  return {
    deletedRecords,
    isLoading,
    refetch,
    moveToRecycleBin,
    restoreFromRecycleBin,
    permanentlyDelete,
    emptyRecycleBin,
  };
}
