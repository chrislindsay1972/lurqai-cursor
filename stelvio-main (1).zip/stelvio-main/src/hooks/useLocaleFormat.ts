import { useEffect, useState } from "react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";

interface LocaleSettings {
  dateFormat: string;
  timeFormat: string;
  timezone: string;
}

const DEFAULTS: LocaleSettings = {
  dateFormat: "dd/MM/yyyy",
  timeFormat: "HH:mm",
  timezone: "Europe/London",
};

let cachedSettings: LocaleSettings | null = null;
let cachePromise: Promise<LocaleSettings> | null = null;

async function fetchLocaleSettings(): Promise<LocaleSettings> {
  try {
    const { data } = await supabase
      .from("app_settings")
      .select("setting_key, setting_value")
      .in("setting_key", ["locale_date_format", "locale_time_format", "locale_timezone"]);

    const settings = { ...DEFAULTS };
    for (const s of data || []) {
      if (s.setting_key === "locale_date_format") settings.dateFormat = s.setting_value;
      if (s.setting_key === "locale_time_format") settings.timeFormat = s.setting_value;
      if (s.setting_key === "locale_timezone") settings.timezone = s.setting_value;
    }
    return settings;
  } catch {
    return DEFAULTS;
  }
}

function getSettings(): Promise<LocaleSettings> {
  if (cachedSettings) return Promise.resolve(cachedSettings);
  if (!cachePromise) {
    cachePromise = fetchLocaleSettings().then((s) => {
      cachedSettings = s;
      return s;
    });
  }
  return cachePromise;
}

/** Invalidate the cache so next hook mount re-fetches */
export function invalidateLocaleCache() {
  cachedSettings = null;
  cachePromise = null;
}

export function useLocaleFormat() {
  const [settings, setSettings] = useState<LocaleSettings>(cachedSettings || DEFAULTS);

  useEffect(() => {
    getSettings().then(setSettings);
  }, []);

  /** Format a date string or Date using the user's chosen date format */
  function formatDate(dateInput: string | Date | null | undefined): string {
    if (!dateInput) return "-";
    try {
      const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
      if (isNaN(d.getTime())) return "-";
      return format(d, settings.dateFormat);
    } catch {
      return String(dateInput);
    }
  }

  /** Format a date+time using the user's chosen date and time formats */
  function formatDateTime(dateInput: string | Date | null | undefined): string {
    if (!dateInput) return "-";
    try {
      const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
      if (isNaN(d.getTime())) return "-";
      return format(d, `${settings.dateFormat} ${settings.timeFormat}`);
    } catch {
      return String(dateInput);
    }
  }

  /** Format time only */
  function formatTime(dateInput: string | Date | null | undefined): string {
    if (!dateInput) return "-";
    try {
      const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
      if (isNaN(d.getTime())) return "-";
      return format(d, settings.timeFormat);
    } catch {
      return String(dateInput);
    }
  }

  /** Short date (e.g. "Feb 15" or "15 Feb" depending on format) */
  function formatShortDate(dateInput: string | Date | null | undefined): string {
    if (!dateInput) return "-";
    try {
      const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
      if (isNaN(d.getTime())) return "-";
      // Use MMM d for US formats, d MMM for others
      const isUSFormat = settings.dateFormat.startsWith("MM") || settings.dateFormat.startsWith("MMM");
      return format(d, isUSFormat ? "MMM d" : "d MMM");
    } catch {
      return String(dateInput);
    }
  }

  return { formatDate, formatDateTime, formatTime, formatShortDate, settings };
}
