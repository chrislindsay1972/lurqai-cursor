import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface TopMatch {
  id: string;
  candidateName: string;
  initials: string;
  jobTitle: string;
  companyName: string;
  matchScore: number;
  skills: string[];
}

export function useTopMatches(limit = 4) {
  return useQuery({
    queryKey: ["top-matches", limit],
    queryFn: async () => {
      const { data: matches, error } = await supabase
        .from("matches")
        .select(`
          id,
          match_score,
          skills_matched,
          candidate_id,
          job_id,
          candidates (
            name,
            skills
          ),
          jobs (
            title,
            company_id,
            companies (
              name
            )
          )
        `)
        .order("match_score", { ascending: false })
        .limit(limit);

      if (error) throw error;

      return (matches ?? []).map((match): TopMatch => {
        const candidate = match.candidates as { name: string; skills: string[] | null } | null;
        const job = match.jobs as { title: string; company_id: string | null; companies: { name: string } | null } | null;
        
        const candidateName = candidate?.name ?? "Unknown Candidate";
        const initials = candidateName
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase()
          .slice(0, 2);

        return {
          id: match.id,
          candidateName,
          initials,
          jobTitle: job?.title ?? "Unknown Position",
          companyName: job?.companies?.name ?? "Unknown Company",
          matchScore: match.match_score,
          skills: match.skills_matched ?? candidate?.skills?.slice(0, 3) ?? [],
        };
      });
    },
  });
}
