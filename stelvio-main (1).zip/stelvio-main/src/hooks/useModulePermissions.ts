import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export type AppRole = 'admin' | 'recruiter' | 'viewer';
export type Module = 'dashboard' | 'candidates' | 'jobs' | 'companies' | 'stakeholders' | 'job_boards' | 'communications' | 'settings';

export interface RoleModulePermission {
  id: string;
  role: string;
  module: string;
  has_access: boolean;
  created_at: string;
  updated_at: string;
}

export const MODULES: { key: Module; label: string; description: string }[] = [
  { key: 'dashboard', label: 'Dashboard', description: 'Overview and analytics' },
  { key: 'candidates', label: 'Candidates', description: 'Manage candidate profiles' },
  { key: 'jobs', label: 'Jobs', description: 'Job listings and matching' },
  { key: 'companies', label: 'Companies', description: 'Company information' },
  { key: 'stakeholders', label: 'Stakeholders', description: 'Key contacts at companies' },
  { key: 'job_boards', label: 'Job Boards', description: 'External job board integration' },
  { key: 'communications', label: 'Communications', description: 'Email campaigns and messaging' },
  { key: 'settings', label: 'Settings', description: 'System configuration' },
];

export const ROLES: { key: AppRole; label: string }[] = [
  { key: 'admin', label: 'Admin' },
  { key: 'recruiter', label: 'Recruiter' },
  { key: 'viewer', label: 'Viewer' },
];

export function useModulePermissions() {
  const queryClient = useQueryClient();

  const { data: permissions = [], isLoading, error } = useQuery({
    queryKey: ['role-module-permissions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('role_module_permissions')
        .select('*')
        .order('role')
        .order('module');
      
      if (error) throw error;
      return data as RoleModulePermission[];
    },
  });

  const updatePermission = useMutation({
    mutationFn: async ({ role, module, hasAccess }: { role: string; module: string; hasAccess: boolean }) => {
      const { error } = await supabase
        .from('role_module_permissions')
        .upsert(
          { role, module, has_access: hasAccess, updated_at: new Date().toISOString() },
          { onConflict: 'role,module' }
        );
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['role-module-permissions'] });
      toast.success('Permission updated');
    },
    onError: (error) => {
      console.error('Failed to update permission:', error);
      toast.error('Failed to update permission');
    },
  });

  const getPermission = (role: string, module: string): boolean => {
    const perm = permissions.find(p => p.role === role && p.module === module);
    return perm?.has_access ?? true;
  };

  return {
    permissions,
    isLoading,
    error,
    updatePermission,
    getPermission,
  };
}
