import { useRef, useCallback, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface RealTimeJob {
  id: string;
  matchId: string;
  title: string;
  company_name: string | null;
  location: string | null;
  source_url: string | null;
  match_score: number;
  match_reason: string | null;
}

export interface DiagnosticsData {
  lastDbPollTime: Date | null;
  lastRealtimeEventTime: Date | null;
  matchCountInDb: number;
  lastAuthError: boolean;
  lastAuthErrorMessage?: string;
}

interface UseCompletionWatcherOptions {
  onJobsUpdated: (jobs: RealTimeJob[]) => void;
  onComplete: (jobCount: number) => void;
  onStatusUpdate?: (status: string) => void;
  // Return true if the continuation was successfully triggered.
  // Return false if it could not be triggered (e.g. user not authenticated), so we don't incorrectly mark the search complete.
  onAutoContinue?: (fromBoardIndex: number) => boolean | Promise<boolean>;
  // Called when pending jobs need scoring - return true if scoring was triggered
  onTriggerScoring?: (pendingCount: number) => boolean | Promise<boolean>;
  onDiagnosticsUpdate?: (diagnostics: DiagnosticsData) => void;
  targetMatches?: number;
}

const DEFAULT_MATCHES_TARGET = 20;

export function useCompletionWatcher(options: UseCompletionWatcherOptions) {
  const { onJobsUpdated, onComplete, onStatusUpdate, onAutoContinue, onTriggerScoring, onDiagnosticsUpdate, targetMatches = DEFAULT_MATCHES_TARGET } = options;
  const intervalRef = useRef<number | null>(null);
  const timeoutRef = useRef<number | null>(null);
  const targetRef = useRef(targetMatches);
  const diagnosticsRef = useRef<DiagnosticsData>({
    lastDbPollTime: null,
    lastRealtimeEventTime: null,
    matchCountInDb: 0,
    lastAuthError: false,
    lastAuthErrorMessage: undefined,
  });

  // Keep ref updated when prop changes
  useEffect(() => {
    targetRef.current = targetMatches;
  }, [targetMatches]);

  const updateDiagnostics = useCallback((updates: Partial<DiagnosticsData>) => {
    diagnosticsRef.current = { ...diagnosticsRef.current, ...updates };
    onDiagnosticsUpdate?.(diagnosticsRef.current);
  }, [onDiagnosticsUpdate]);

  // Returns:
  // - RealTimeJob[] when query succeeds
  // - null when we detect an auth/session problem (callers should NOT treat as "0 jobs")
  const loadMatchesFromDb = useCallback(async (candidateId: string): Promise<RealTimeJob[] | null> => {
    const runQuery = async () => {
      return supabase
        .from('matches')
        .select(`
          id,
          job_id,
          match_score,
          match_reason,
          jobs(id, title, location, source_url, companies(name))
        `)
        .eq('candidate_id', candidateId)
        .order('match_score', { ascending: false });
    };

    const looksLikeAuthIssue = (e: any) => {
      const msg = String(e?.message ?? '').toLowerCase();
      return (
        e?.status === 401 ||
        msg.includes('jwt') ||
        msg.includes('unauthorized') ||
        msg.includes('not authenticated') ||
        msg.includes('invalid claim') ||
        msg.includes('session')
      );
    };

    try {
      let { data: matches, error } = await runQuery();

      // Update diagnostics: poll time
      updateDiagnostics({ lastDbPollTime: new Date() });

      // If we hit a transient auth hiccup, try a refresh and retry once.
      if (error && looksLikeAuthIssue(error)) {
        const { data: sessionData } = await supabase.auth.getSession();
        if (!sessionData.session) {
          await supabase.auth.refreshSession();
        }
        const retry = await runQuery();
        matches = retry.data;
        error = retry.error;
      }

      if (error) {
        if (looksLikeAuthIssue(error)) {
          console.warn('Auth/session issue while loading matches; deferring completion.', error);
          updateDiagnostics({ 
            lastAuthError: true, 
            lastAuthErrorMessage: error.message || 'Authentication issue detected'
          });
          onStatusUpdate?.('Session issue detected — please refresh or re-sign in, then we will continue updating results.');
          return null;
        }
        throw error;
      }

      // Successful query - update diagnostics
      const matchCount = matches?.length ?? 0;
      updateDiagnostics({ 
        matchCountInDb: matchCount,
        lastAuthError: false,
        lastAuthErrorMessage: undefined
      });

      if (matches && matches.length > 0) {
        const dbJobs: RealTimeJob[] = matches.map((m: any) => ({
          id: m.jobs?.id || m.job_id,
          matchId: m.id,
          title: m.jobs?.title || 'Unknown Job',
          company_name: m.jobs?.companies?.name || null,
          location: m.jobs?.location || null,
          source_url: m.jobs?.source_url || null,
          match_score: m.match_score,
          match_reason: m.match_reason,
        }));

        onJobsUpdated(dbJobs);
        return dbJobs;
      }

      // Successful query, legitimately 0 rows.
      return [];
    } catch (err) {
      console.error('Failed to load matches from database:', err);
      updateDiagnostics({ 
        lastAuthError: true, 
        lastAuthErrorMessage: err instanceof Error ? err.message : 'Unknown error'
      });
      return [];
    }
  }, [onJobsUpdated, onStatusUpdate, updateDiagnostics]);

  const checkForTimeoutEvent = useCallback(async (candidateId: string): Promise<{ hasTimeout: boolean; boardsSearched: number; totalBoards: number; eventTimestamp: string | null }> => {
    try {
      // Check for recent timeout/pause events.
      // 4 minutes was too short when users get redirected to /login (or step away) and come back.
      // Using a longer window keeps auto-continuation reliable.
      const windowStart = new Date(Date.now() - 30 * 60 * 1000).toISOString(); // 30 minutes
      
      const { data: events } = await supabase
        .from('pipeline_events')
        .select('event_type, message, created_at')
        .eq('candidate_id', candidateId)
        .gte('created_at', windowStart)
        .order('created_at', { ascending: false })
        .limit(50);

      // Look for timeout warning (handles both "time limit reached" and "Search paused - time limit reached")
      const timeoutEvent = events?.find(e => 
        e.event_type === 'warning' && 
        (e.message?.includes('time limit reached') || e.message?.includes('Search paused') || e.message?.includes('Scoring paused'))
      );

      if (timeoutEvent) {
        // Parse board progress from message (e.g., "Searched 40 of 100 boards")
        const boardMatch = timeoutEvent.message?.match(/Searched (\d+) of (\d+) boards/);
        if (boardMatch) {
          return {
            hasTimeout: true,
            boardsSearched: parseInt(boardMatch[1]),
            totalBoards: parseInt(boardMatch[2]),
            eventTimestamp: timeoutEvent.created_at,
          };
        }
        return { hasTimeout: true, boardsSearched: 0, totalBoards: 0, eventTimestamp: timeoutEvent.created_at };
      }

      return { hasTimeout: false, boardsSearched: 0, totalBoards: 0, eventTimestamp: null };
    } catch (err) {
      console.error('Error checking for timeout events:', err);
      return { hasTimeout: false, boardsSearched: 0, totalBoards: 0, eventTimestamp: null };
    }
  }, []);

  // Check for pending jobs in pipeline_pending_jobs that need scoring
  // Returns:
  // - number when query succeeds
  // - null when we detect auth/session issues (callers should NOT treat as 0)
  const checkForPendingJobs = useCallback(async (candidateId: string): Promise<number | null> => {
    try {
      const { count, error } = await supabase
        .from('pipeline_pending_jobs')
        .select('id', { count: 'exact', head: true })
        .eq('candidate_id', candidateId)
        .eq('status', 'pending');

      const looksLikeAuthIssue = (e: any) => {
        const msg = String(e?.message ?? '').toLowerCase();
        return (
          e?.status === 401 ||
          msg.includes('jwt') ||
          msg.includes('unauthorized') ||
          msg.includes('not authenticated') ||
          msg.includes('invalid claim') ||
          msg.includes('session')
        );
      };

      if (error) {
        if (looksLikeAuthIssue(error)) {
          console.warn('Auth/session issue while checking pending jobs; deferring completion.', error);
          updateDiagnostics({
            lastAuthError: true,
            lastAuthErrorMessage: error.message || 'Authentication issue detected',
          });
          onStatusUpdate?.('Session issue detected — please refresh or re-sign in, then we will continue scoring pending jobs.');
          return null;
        }
        throw error;
      }
      
      return count || 0;
    } catch (err) {
      console.error('Error checking for pending jobs:', err);
      // If we can't reliably read pending jobs, do not allow callers to assume "0".
      updateDiagnostics({
        lastAuthError: true,
        lastAuthErrorMessage: err instanceof Error ? err.message : 'Unknown error',
      });
      return null;
    }
  }, [onStatusUpdate, updateDiagnostics]);

  // Method to record realtime event timestamp (called from parent component)
  const recordRealtimeEvent = useCallback(() => {
    updateDiagnostics({ lastRealtimeEventTime: new Date() });
  }, [updateDiagnostics]);

  const startWatching = useCallback((candidateId: string) => {
    let lastJobCount = 0;
    let stableCount = 0;
    let completed = false;
    let lastProcessedTimeoutAt: string | null = null;
    let failsafeStartTime = Date.now();
    // CRITICAL: Define BEFORE use to avoid hoisting issues causing the 30s throttle to silently fail.
    let lastAutoContinueAttemptMs = 0;
    let lastScoringTriggerAttemptMs = 0;

    // Clear any existing intervals/timeouts
    if (intervalRef.current) window.clearInterval(intervalRef.current);
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);

    // Reset diagnostics at start
    updateDiagnostics({
      lastDbPollTime: null,
      lastRealtimeEventTime: null,
      matchCountInDb: 0,
      lastAuthError: false,
      lastAuthErrorMessage: undefined,
    });

    intervalRef.current = window.setInterval(async () => {
      // Always poll the database to catch any matches that realtime missed.
      const dbJobs = await loadMatchesFromDb(candidateId);
      if (dbJobs === null) {
        // Auth/session issue; keep watching rather than concluding "0 jobs".
        stableCount = 0;
        return;
      }
      const currentCount = dbJobs.length;

      if (currentCount === lastJobCount) {
        stableCount++;
      } else {
        lastJobCount = currentCount;
        stableCount = 0;
      }

      onStatusUpdate?.(`Gathering results... (${currentCount} jobs found)`);

      // After ~10 seconds of no new jobs, check if we should auto-continue or complete
      // Also force-check after 60 seconds regardless (handles edge cases where stableCount resets)
      const elapsedSecs = (Date.now() - failsafeStartTime) / 1000;
      const forceCheck = elapsedSecs > 60 && stableCount >= 2;
      if (!completed && (stableCount >= 5 || forceCheck)) {
        // Before declaring complete, check for timeout events that indicate more boards remain
        const timeoutInfo = await checkForTimeoutEvent(candidateId);
        
        if (timeoutInfo.hasTimeout && timeoutInfo.boardsSearched < timeoutInfo.totalBoards) {
          // Check if this is a NEW timeout event we haven't processed yet
          const isNewTimeout = !lastProcessedTimeoutAt || 
            (timeoutInfo.eventTimestamp && timeoutInfo.eventTimestamp > lastProcessedTimeoutAt);
          
          if (!isNewTimeout) {
            // Same timeout event, wait for backend to process continuation
            onStatusUpdate?.(`Waiting for continuation from board ${timeoutInfo.boardsSearched}...`);
            stableCount = 0; // Keep watching
            return;
          }

          // There are more boards remaining — always continue regardless of match count
          // Target is informational only; we exhaust all relevant boards
          const needsMoreMatches = true;
          
          console.log(`CompletionWatcher: NEW Timeout detected. Matches=${currentCount}, Target=${targetRef.current}, BoardsSearched=${timeoutInfo.boardsSearched}, TotalBoards=${timeoutInfo.totalBoards}`);
          
          // Throttle auto-continue attempts so we don't spam while the user is on /login.
          // (We only need to resume once a valid session exists.)
          const nowMs = Date.now();
          if (needsMoreMatches && onAutoContinue && nowMs - lastAutoContinueAttemptMs > 30_000) {
            console.log(`CompletionWatcher: Auto-continuing from board ${timeoutInfo.boardsSearched}`);
            onStatusUpdate?.(`Found ${currentCount}/${targetRef.current} matches - auto-continuing search...`);

            // Record attempt time before invoking to prevent rapid retries.
            lastAutoContinueAttemptMs = nowMs;

            const didTrigger = await Promise.resolve(onAutoContinue(timeoutInfo.boardsSearched));

            // If we couldn't trigger continuation (usually because the session is missing),
            // do NOT mark completion and do NOT treat this timeout as processed.
            if (!didTrigger) {
              onStatusUpdate?.(
                `Search paused (time limit reached). Sign in to continue searching remaining boards (${timeoutInfo.boardsSearched}/${timeoutInfo.totalBoards}).`
              );
              stableCount = 0;
              return;
            }

            // Mark this timeout as processed ONLY when continuation actually started.
            lastProcessedTimeoutAt = timeoutInfo.eventTimestamp || new Date().toISOString();

            // Reset stable count and extend failsafe to keep watching
            stableCount = 0;
            failsafeStartTime = Date.now(); // Reset failsafe timer

            // Clear and reset the failsafe timeout for this continuation wave.
            if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
            timeoutRef.current = window.setTimeout(async () => {
              if (completed) return;
              // If we're still paused with boards remaining, keep watching rather than forcing completion.
              const timeoutInfo2 = await checkForTimeoutEvent(candidateId);
              const dbJobs2 = await loadMatchesFromDb(candidateId);
              if (dbJobs2 === null) return;

              const count2 = dbJobs2.length;
              const stillNeedsMore = count2 < targetRef.current;
              const stillHasBoards = timeoutInfo2.hasTimeout && timeoutInfo2.boardsSearched < timeoutInfo2.totalBoards;
              if (stillNeedsMore && stillHasBoards) {
                onStatusUpdate?.(
                  `Search paused (time limit reached). Waiting to continue (${timeoutInfo2.boardsSearched}/${timeoutInfo2.totalBoards}).`
                );
                // Keep watching; do not force-complete while paused.
                // eslint-disable-next-line @typescript-eslint/no-use-before-define
                rearmFailsafe();
                return;
              }

              // Otherwise finalize.
              completed = true;
              if (intervalRef.current) window.clearInterval(intervalRef.current);
              if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
              onComplete(count2);
            }, 180000); // 3 minutes for each continuation wave

            return;
          }

          // If we need more matches but cannot auto-continue (e.g. session expired),
          // do NOT declare completion — keep polling and surface a clear status.
          if (needsMoreMatches && !onAutoContinue) {
            onStatusUpdate?.(
              `Search paused (time limit reached). Found ${currentCount}/${targetRef.current} matches — sign in and continue to search remaining boards.`
            );
            stableCount = 0;
            return;
          }
        }
        
        // Before declaring complete, check if there are pending jobs that need scoring
        const pendingJobsCount = await checkForPendingJobs(candidateId);
        if (pendingJobsCount === null) {
          // Can't read pending count due to auth/session; don't complete.
          stableCount = 0;
          return;
        }
        if (pendingJobsCount > 0 && currentCount < targetRef.current) {
          // There are pending jobs that need scoring - try to trigger scoring
          console.log(`CompletionWatcher: ${pendingJobsCount} pending jobs need scoring`);
          
          // Throttle scoring trigger attempts (30 seconds between attempts)
          const nowMs = Date.now();
          if (onTriggerScoring && nowMs - lastScoringTriggerAttemptMs > 30_000) {
            console.log(`CompletionWatcher: Triggering scoring for ${pendingJobsCount} pending jobs`);
            onStatusUpdate?.(`Triggering scoring for ${pendingJobsCount} discovered jobs...`);
            lastScoringTriggerAttemptMs = nowMs;
            
            const didTrigger = await Promise.resolve(onTriggerScoring(pendingJobsCount));
            
            if (!didTrigger) {
              // Scoring couldn't be triggered (likely auth issue)
              onStatusUpdate?.(`${pendingJobsCount} jobs discovered — sign in to continue scoring.`);
              stableCount = 0;
              return;
            }
            
            // Scoring triggered successfully - reset failsafe timer
            failsafeStartTime = Date.now();
          } else {
            // Scoring already triggered or no handler - just update status
            onStatusUpdate?.(`Scoring ${pendingJobsCount} discovered jobs...`);
          }
          
          stableCount = 0; // Keep watching
          return;
        }
        
        // No timeout, no pending jobs needing scoring, or enough matches - mark as complete
        completed = true;
        if (intervalRef.current) window.clearInterval(intervalRef.current);
        if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
        onComplete(currentCount);
      }
    }, 2000);

    // lastAutoContinueAttemptMs is now defined at the top of startWatching

    const rearmFailsafe = () => {
      if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
      timeoutRef.current = window.setTimeout(async () => {
        if (completed) return;

        const dbJobs = await loadMatchesFromDb(candidateId);
        if (dbJobs === null) {
          // Don't force-complete on auth issues.
          onStatusUpdate?.('Session issue detected — please refresh or re-sign in to finalize results.');
          // Keep watching.
          rearmFailsafe();
          return;
        }

        const count = dbJobs.length;
        const timeoutInfo = await checkForTimeoutEvent(candidateId);
        const pendingJobsCount = await checkForPendingJobs(candidateId);
        if (pendingJobsCount === null) {
          // Can't reliably check pending jobs (likely auth); keep watching.
          onStatusUpdate?.('Session issue detected — please refresh or re-sign in to continue scoring pending jobs.');
          rearmFailsafe();
          return;
        }
        const stillHasBoards = timeoutInfo.hasTimeout && timeoutInfo.boardsSearched < timeoutInfo.totalBoards;
        const hasPendingJobs = pendingJobsCount > 0;

        // If boards remain, always keep searching — target is informational, not a hard stop.
        if (stillHasBoards) {
          onStatusUpdate?.(
            `Search paused (time limit reached). Waiting to continue (${timeoutInfo.boardsSearched}/${timeoutInfo.totalBoards}).`
          );
          rearmFailsafe();
          return;
        }

        // If there are pending jobs that need scoring, try to trigger scoring
        if (hasPendingJobs) {
          console.log(`CompletionWatcher failsafe: ${pendingJobsCount} pending jobs need scoring`);
          
          const nowMs = Date.now();
          if (onTriggerScoring && nowMs - lastScoringTriggerAttemptMs > 30_000) {
            console.log(`CompletionWatcher failsafe: Triggering scoring for ${pendingJobsCount} pending jobs`);
            onStatusUpdate?.(`Triggering scoring for ${pendingJobsCount} discovered jobs...`);
            lastScoringTriggerAttemptMs = nowMs;
            await Promise.resolve(onTriggerScoring(pendingJobsCount));
          } else {
            onStatusUpdate?.(`Scoring ${pendingJobsCount} discovered jobs...`);
          }
          
          rearmFailsafe();
          return;
        }

        completed = true;
        if (intervalRef.current) window.clearInterval(intervalRef.current);
        if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
        onComplete(count);
      }, 180000);
    };

    // Failsafe: check-in every 3 minutes, but never force "0 jobs" completion while paused with boards remaining.
    rearmFailsafe();
  }, [loadMatchesFromDb, onComplete, onStatusUpdate, onAutoContinue, onTriggerScoring, checkForTimeoutEvent, checkForPendingJobs, updateDiagnostics]);

  const stopWatching = useCallback(() => {
    if (intervalRef.current) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  }, []);

  return { startWatching, stopWatching, loadMatchesFromDb, recordRealtimeEvent, checkForPendingJobs };
}
