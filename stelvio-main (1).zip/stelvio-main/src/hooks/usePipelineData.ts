import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface PipelineStakeholder {
  id: string;
  name: string;
  title: string | null;
  email: string | null;
  emailStatus: string;
  linkedinUrl: string | null;
  confidence: number;
}

export interface PipelineCompany {
  id: string;
  name: string;
  logo: string | null;
  industry: string;
  employeeCount: number;
  location: string;
  fundingStage: string;
  totalFunding: string;
  glassdoorRating: number;
  matchedJobTitle: string;
  matchScore: number;
  enrichmentStatus: "enriched" | "pending" | "failed";
  enrichedAt: string | null;
  stakeholders: PipelineStakeholder[];
}

export interface PipelineCandidate {
  id: string;
  name: string;
  currentTitle: string;
  skills: string[];
  idealRole: string;
  location: string;
  experienceYears: number;
}

function formatFunding(amount: number | null): string {
  if (!amount) return "—";
  if (amount >= 1_000_000_000) return `$${(amount / 1_000_000_000).toFixed(1)}B`;
  if (amount >= 1_000_000) return `$${(amount / 1_000_000).toFixed(0)}M`;
  if (amount >= 1_000) return `$${(amount / 1_000).toFixed(0)}K`;
  return `$${amount}`;
}

export function usePipelineData(candidateId: string | undefined) {
  // Fetch candidate
  const candidateQuery = useQuery({
    queryKey: ["pipeline-candidate", candidateId],
    enabled: !!candidateId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("candidates")
        .select("id, name, current_title, skills, ideal_role, experience_years, search_city, search_country, cv_raw_text, cv_file_url, parsed_at")
        .eq("id", candidateId!)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;

      const location = [data.search_city, data.search_country].filter(Boolean).join(", ") || "Not specified";

      return {
        id: data.id,
        name: data.name,
        currentTitle: data.current_title || "Not specified",
        skills: data.skills || [],
        idealRole: data.ideal_role || "Not specified",
        location,
        experienceYears: data.experience_years || 0,
        hasCv: !!data.cv_file_url,
        isParsed: !!data.cv_raw_text,
        parsedAt: data.parsed_at,
      } satisfies PipelineCandidate & { hasCv: boolean; isParsed: boolean; parsedAt: string | null };
    },
  });

  // Fetch matches → companies → stakeholders
  const companiesQuery = useQuery({
    queryKey: ["pipeline-companies", candidateId],
    enabled: !!candidateId,
    queryFn: async () => {
      // 1. Get matches with jobs and companies
      const { data: matches, error: matchErr } = await supabase
        .from("matches")
        .select(`
          id, match_score,
          jobs (
            id, title,
            companies (
              id, name, logo_url, industry, employee_count,
              city, country, enrichment_status, enriched_at,
              latest_funding_stage, total_funding,
              glassdoor_rating
            )
          )
        `)
        .eq("candidate_id", candidateId!)
        .order("match_score", { ascending: false });

      if (matchErr) throw matchErr;

      // Filter out companies that exceed the size cap — they should never appear in the shortlist
      const filteredMatches = (matches || []).filter((match) => {
        const company = (match.jobs as any)?.companies;
        return company && company.enrichment_status !== 'exceeds_size';
      });

      // 2. Group by company — take highest match score per company
      const companyMap = new Map<string, {
        company: any;
        matchedJobTitle: string;
        matchScore: number;
      }>();

      for (const match of filteredMatches) {
        const job = match.jobs as any;
        const company = job?.companies;
        if (!company?.id) continue;

        if (!companyMap.has(company.id) || match.match_score > companyMap.get(company.id)!.matchScore) {
          companyMap.set(company.id, {
            company,
            matchedJobTitle: job.title || "Untitled Role",
            matchScore: match.match_score,
          });
        }
      }

      if (companyMap.size === 0) return [];

      // 3. Fetch stakeholders for all matched companies
      const companyIds = Array.from(companyMap.keys());
      const { data: stakeholders, error: sErr } = await supabase
        .from("stakeholders")
        .select("id, name, title, email, email_status, linkedin_url, company_id")
        .in("company_id", companyIds);

      if (sErr) throw sErr;

      // Group stakeholders by company
      const stakeholdersByCompany = new Map<string, any[]>();
      for (const s of stakeholders || []) {
        if (!s.company_id) continue;
        if (!stakeholdersByCompany.has(s.company_id)) {
          stakeholdersByCompany.set(s.company_id, []);
        }
        stakeholdersByCompany.get(s.company_id)!.push(s);
      }

      // 4. Build final structure
      const result: PipelineCompany[] = [];
      for (const [companyId, entry] of companyMap) {
        const c = entry.company;
        const companyStakeholders = stakeholdersByCompany.get(companyId) || [];

        result.push({
          id: c.id,
          name: c.name,
          logo: c.logo_url || null,
          industry: c.industry || "Unknown",
          employeeCount: c.employee_count || 0,
          location: [c.city, c.country].filter(Boolean).join(", ") || "—",
          fundingStage: c.latest_funding_stage || "—",
          totalFunding: formatFunding(c.total_funding),
          glassdoorRating: c.glassdoor_rating || 0,
          matchedJobTitle: entry.matchedJobTitle,
          matchScore: entry.matchScore,
          enrichmentStatus: (c.enrichment_status === "enriched" ? "enriched" : c.enrichment_status === "failed" || c.enrichment_status === "exceeds_size" ? "failed" : "pending") as any,
          enrichedAt: c.enriched_at || null,
          stakeholders: companyStakeholders.map((s: any) => ({
            id: s.id,
            name: s.name,
            title: s.title,
            email: s.email,
            emailStatus: s.email_status || "unknown",
            linkedinUrl: s.linkedin_url,
            confidence: s.email ? (s.email_status === "verified" ? 95 : s.email_status === "catchall" ? 70 : 50) : 30,
          })),
        });
      }

      // Sort by match score descending
      result.sort((a, b) => b.matchScore - a.matchScore);
      return result;
    },
  });

  // Calculate pipeline step based on data state
  const currentStep = (() => {
    const candidate = candidateQuery.data;
    if (!candidate) return 0;
    if (!candidate.isParsed) return 0; // CV not parsed yet
    const companies = companiesQuery.data || [];
    if (companies.length === 0) return 1; // Parsed but no matches
    const hasEnriched = companies.some((c) => c.enrichmentStatus === "enriched");
    if (!hasEnriched) return 2; // Has matches but not enriched
    const hasStakeholders = companies.some((c) => c.stakeholders.length > 0);
    if (!hasStakeholders) return 2; // Enriched but no stakeholders
    return 3; // Full pipeline complete
  })();

  // Candidate list for selector
  const candidateListQuery = useQuery({
    queryKey: ["pipeline-candidate-list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("candidates")
        .select("id, name, current_title, cv_raw_text")
        .not("cv_raw_text", "is", null)
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data || [];
    },
  });

  // Auto-refresh pipeline data when companies or stakeholders change
  const queryClient = useQueryClient();
  useEffect(() => {
    if (!candidateId) return;

    const channel = supabase
      .channel(`pipeline-realtime-${candidateId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "companies" },
        () => {
          queryClient.invalidateQueries({ queryKey: ["pipeline-companies", candidateId] });
        }
      )
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "stakeholders" },
        () => {
          queryClient.invalidateQueries({ queryKey: ["pipeline-companies", candidateId] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [candidateId, queryClient]);

  // Compute end-to-end pipeline duration
  const pipelineDurationSeconds = (() => {
    const candidate = candidateQuery.data;
    const companies = companiesQuery.data;
    if (!candidate?.parsedAt || !companies?.length) return null;

    // Find the latest enrichedAt across all enriched companies
    const lastEnrichedAt = companies
      .map(c => c.enrichedAt)
      .filter(Boolean)
      .map(d => new Date(d!).getTime())
      .sort((a, b) => b - a)[0];

    if (!lastEnrichedAt) return null;
    const startMs = new Date(candidate.parsedAt).getTime();
    return Math.round((lastEnrichedAt - startMs) / 1000);
  })();

  return {
    candidate: candidateQuery.data ?? null,
    companies: companiesQuery.data ?? [],
    currentStep,
    candidateList: candidateListQuery.data ?? [],
    isLoading: candidateQuery.isLoading || companiesQuery.isLoading,
    isLoadingList: candidateListQuery.isLoading,
    pipelineDurationSeconds,
  };
}
