import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface EnrichParams {
  stakeholderId: string;
  firstName: string;
  lastName: string;
  companyName?: string;
  companyDomain?: string;
  linkedinUrl?: string;
  title?: string;
}

interface EnrichResult {
  email: string | null;
}

export function useBetterContactEnrich() {
  const [isEnriching, setIsEnriching] = useState(false);
  const [progress, setProgress] = useState<string>("");

  const enrichContact = useCallback(async (params: EnrichParams): Promise<EnrichResult | null> => {
    setIsEnriching(true);
    setProgress("Enriching with Apollo...");

    try {
      const { data, error } = await supabase.functions.invoke(
        "enrich-contact-bettercontact",
        {
          body: {
            stakeholder_id: params.stakeholderId,
            first_name: params.firstName,
            last_name: params.lastName,
            company_name: params.companyName,
            company_domain: params.companyDomain,
            linkedin_url: params.linkedinUrl,
            title: params.title,
          },
        }
      );

      if (error || !data?.success) {
        const errorMsg = data?.error || error?.message || "Failed to enrich contact";
        toast.error(errorMsg);
        return null;
      }

      if (data.email) {
        toast.success("LurqAI found new contact details!");
      } else {
        toast.info("LurqAI couldn't find additional contact info.");
      }

      return {
        email: data.email,
      };

    } catch (error) {
      console.error("Enrichment error:", error);
      toast.error("LurqAI enrichment failed. Please try again.");
      return null;
    } finally {
      setIsEnriching(false);
      setProgress("");
    }
  }, []);

  return {
    enrichContact,
    isEnriching,
    progress,
  };
}
