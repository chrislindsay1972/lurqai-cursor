import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useDashboardStats() {
  return useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => {
      const thirtyMinsAgo = new Date(Date.now() - 30 * 60 * 1000).toISOString();

      const [candidatesResult, jobsResult, companiesResult, matchesResult, bcPendingResult, orphanedResult] = await Promise.all([
        supabase.from("candidates").select("id", { count: "exact", head: true }),
        supabase.from("jobs").select("id", { count: "exact", head: true }).eq("status", "active"),
        supabase.from("companies").select("id", { count: "exact", head: true }),
        supabase.from("matches").select("match_score"),
        supabase.from("stakeholders")
          .select("id, name, enriched_at", { count: "exact" })
          .eq("enrichment_source", "bettercontact_pending")
          .ilike("notes", "%[bc_task:%")
          .is("email", null)
          .lt("enriched_at", thirtyMinsAgo),
        supabase.from("stakeholders")
          .select("id", { count: "exact", head: true })
          .is("email", null)
          .not("linkedin_url", "is", null)
          .neq("enrichment_source", "bettercontact_pending"),
      ]);

      const totalCandidates = candidatesResult.count ?? 0;
      const activeJobs = jobsResult.count ?? 0;
      const totalCompanies = companiesResult.count ?? 0;

      // Calculate average match rate
      const matches = matchesResult.data ?? [];
      const avgMatchRate = matches.length > 0
        ? Math.round(matches.reduce((sum, m) => sum + m.match_score, 0) / matches.length)
        : 0;

      const staleBcTasks = bcPendingResult.count ?? 0;
      const staleBcStakeholders = bcPendingResult.data ?? [];
      const orphanedEmailCount = orphanedResult.count ?? 0;

      return {
        totalCandidates,
        activeJobs,
        totalCompanies,
        avgMatchRate,
        staleBcTasks,
        staleBcStakeholders,
        orphanedEmailCount,
      };
    },
    refetchInterval: 60_000,
  });
}

