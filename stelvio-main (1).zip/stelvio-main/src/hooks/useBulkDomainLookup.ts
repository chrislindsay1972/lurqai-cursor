import { useState, useCallback, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Company {
  id: string;
  name: string;
  domain: string | null;
  enrichment_status?: string;
}

type StepStatus = "pending" | "running" | "success" | "failed" | "skipped";

interface CompanyResult {
  companyId: string;
  companyName: string;
  domainStatus: StepStatus;
  enrichStatus: StepStatus;
  stakeholderStatus: StepStatus;
  domain?: string;
  stakeholdersFound?: number;
  error?: string;
}

interface BulkLookupProgress {
  total: number;
  completed: number;
  succeeded: number;
  failed: number;
  current: string | null;
  currentStep: "domain" | "enrich" | "stakeholders" | null;
  isRunning: boolean;
  results: CompanyResult[];
}

export function useBulkDomainLookup() {
  const [progress, setProgress] = useState<BulkLookupProgress>({
    total: 0,
    completed: 0,
    succeeded: 0,
    failed: 0,
    current: null,
    currentStep: null,
    isRunning: false,
    results: [],
  });

  const runIdRef = useRef<string | null>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  // Derive current company + step from results
  const deriveCurrentFromResults = useCallback((results: CompanyResult[]): { current: string | null; currentStep: "domain" | "enrich" | "stakeholders" | null } => {
    for (const r of results) {
      if (r.domainStatus === "running") return { current: r.companyName, currentStep: "domain" };
      if (r.enrichStatus === "running") return { current: r.companyName, currentStep: "enrich" };
      if (r.stakeholderStatus === "running") return { current: r.companyName, currentStep: "stakeholders" };
    }
    return { current: null, currentStep: null };
  }, []);

  // Fetch latest state from DB
  const fetchState = useCallback(async (runId: string) => {
    const [{ data: run }, { data: items }] = await Promise.all([
      supabase.from("bulk_enrichment_runs").select("*").eq("id", runId).maybeSingle(),
      supabase.from("bulk_enrichment_items").select("*").eq("run_id", runId).order("processing_order"),
    ]);

    if (!run || !items) return;

    const results: CompanyResult[] = items.map((item: Record<string, unknown>) => ({
      companyId: item.company_id as string,
      companyName: item.company_name as string,
      domainStatus: item.domain_status as StepStatus,
      enrichStatus: item.enrich_status as StepStatus,
      stakeholderStatus: item.stakeholder_status as StepStatus,
      domain: item.domain as string | undefined,
      stakeholdersFound: item.stakeholders_found as number | undefined,
      error: item.error as string | undefined,
    }));

    const { current, currentStep } = deriveCurrentFromResults(results);

    setProgress({
      total: run.total as number,
      completed: run.completed as number,
      succeeded: run.succeeded as number,
      failed: run.failed as number,
      current,
      currentStep,
      isRunning: run.status === "running",
      results,
    });
  }, [deriveCurrentFromResults]);

  // Subscribe to realtime updates on items
  const subscribeToRun = useCallback((runId: string) => {
    // Clean up any existing subscription
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
    }

    const channel = supabase
      .channel(`bulk-enrich-${runId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "bulk_enrichment_items", filter: `run_id=eq.${runId}` },
        () => fetchState(runId),
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "bulk_enrichment_runs", filter: `id=eq.${runId}` },
        () => fetchState(runId),
      )
      .subscribe();

    channelRef.current = channel;
  }, [fetchState]);

  // Cleanup subscription on unmount
  useEffect(() => {
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, []);

  const startBulkLookup = useCallback(async (companies: Company[]) => {
    const needsLookup = companies.filter(c => !c.domain || c.domain.trim() === "");
    const needsEnrichOnly = companies.filter(
      c => c.domain && c.domain.trim() !== "" && c.enrichment_status === "pending"
    );
    const allToProcess = [...needsLookup, ...needsEnrichOnly];

    if (allToProcess.length === 0) {
      return { success: true, message: "No companies need processing" };
    }

    // 1. Create run record
    const { data: run, error: runError } = await supabase
      .from("bulk_enrichment_runs")
      .insert({ total: allToProcess.length, status: "running" })
      .select("id")
      .single();

    if (runError || !run) {
      console.error("Failed to create bulk enrichment run:", runError);
      return { success: false, message: "Failed to start bulk enrichment" };
    }

    const runId = run.id;
    runIdRef.current = runId;

    // 2. Create item records
    const itemRecords = allToProcess.map((c, idx) => ({
      run_id: runId,
      company_id: c.id,
      company_name: c.name,
      domain: c.domain || null,
      domain_status: c.domain && c.domain.trim() !== "" ? "success" : "pending",
      processing_order: idx,
    }));

    await supabase.from("bulk_enrichment_items").insert(itemRecords);

    // 3. Set initial progress state
    setProgress({
      total: allToProcess.length,
      completed: 0,
      succeeded: 0,
      failed: 0,
      current: allToProcess[0]?.name || null,
      currentStep: allToProcess[0]?.domain ? "enrich" : "domain",
      isRunning: true,
      results: itemRecords.map(r => ({
        companyId: r.company_id,
        companyName: r.company_name,
        domainStatus: r.domain_status as StepStatus,
        enrichStatus: "pending" as StepStatus,
        stakeholderStatus: "pending" as StepStatus,
        domain: r.domain || undefined,
      })),
    });

    // 4. Subscribe to realtime updates
    subscribeToRun(runId);

    // 5. Fire-and-forget: invoke the server-side edge function
    supabase.functions.invoke("bulk-enrich-companies", { body: { runId } }).catch(err => {
      console.error("Bulk enrich invocation error:", err);
    });

    return { success: true, runId };
  }, [subscribeToRun]);

  // Check for any active run on mount (persistence across navigation)
  const checkActiveRun = useCallback(async () => {
    const { data: activeRun } = await supabase
      .from("bulk_enrichment_runs")
      .select("id")
      .eq("status", "running")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (activeRun) {
      runIdRef.current = activeRun.id;
      subscribeToRun(activeRun.id);
      await fetchState(activeRun.id);
      return true;
    }
    return false;
  }, [subscribeToRun, fetchState]);

  const stopBulkLookup = useCallback(async () => {
    // We can't abort the server-side function, but we can mark the run as completed
    // and the UI will stop showing it as running
    if (runIdRef.current) {
      await supabase
        .from("bulk_enrichment_runs")
        .update({ status: "completed" })
        .eq("id", runIdRef.current);
    }
    setProgress(prev => ({ ...prev, isRunning: false }));
  }, []);

  const resetProgress = useCallback(() => {
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }
    runIdRef.current = null;
    setProgress({
      total: 0,
      completed: 0,
      succeeded: 0,
      failed: 0,
      current: null,
      currentStep: null,
      isRunning: false,
      results: [],
    });
  }, []);

  return {
    progress,
    startBulkLookup,
    stopBulkLookup,
    resetProgress,
    checkActiveRun,
  };
}
