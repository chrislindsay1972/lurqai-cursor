 import { useState, useMemo, useCallback, useEffect } from 'react';
 
 const STORAGE_KEY_PREFIX = 'lurq_page_size_';
 
 export type PageSize = 25 | 50 | 100;
 
 export interface UseListPaginationOptions {
   /** Unique key for persisting page size preference */
   storageKey: string;
   /** Default page size (defaults to 25) */
   defaultPageSize?: PageSize;
 }
 
 export interface UseListPaginationResult<T> {
   /** Current page (1-indexed) */
   currentPage: number;
   /** Items per page */
   pageSize: PageSize;
   /** Total number of pages */
   totalPages: number;
   /** Items to display on current page */
   paginatedItems: T[];
   /** Total number of items */
   totalItems: number;
   /** Go to specific page */
   goToPage: (page: number) => void;
   /** Go to next page */
   nextPage: () => void;
   /** Go to previous page */
   previousPage: () => void;
   /** Change page size */
   setPageSize: (size: PageSize) => void;
   /** Reset to first page */
   resetPage: () => void;
   /** Whether there's a next page */
   hasNextPage: boolean;
   /** Whether there's a previous page */
   hasPreviousPage: boolean;
   /** Start index of current page (1-indexed for display) */
   startIndex: number;
   /** End index of current page (1-indexed for display) */
   endIndex: number;
 }
 
 export function useListPagination<T>(
   items: T[],
   options: UseListPaginationOptions
 ): UseListPaginationResult<T> {
   const { storageKey, defaultPageSize = 25 } = options;
   const fullStorageKey = STORAGE_KEY_PREFIX + storageKey;
 
   // Initialize page size from localStorage
   const [pageSize, setPageSizeInternal] = useState<PageSize>(() => {
     try {
       const stored = localStorage.getItem(fullStorageKey);
       if (stored) {
         const parsed = parseInt(stored, 10);
         if (parsed === 25 || parsed === 50 || parsed === 100) {
           return parsed as PageSize;
         }
       }
     } catch {
       // Ignore storage errors
     }
     return defaultPageSize;
   });
 
   const [currentPage, setCurrentPage] = useState(1);
 
   // Calculate total pages
   const totalPages = useMemo(() => {
     return Math.max(1, Math.ceil(items.length / pageSize));
   }, [items.length, pageSize]);
 
   // Reset to page 1 when items change significantly (e.g., filter applied)
   useEffect(() => {
     if (currentPage > totalPages) {
       setCurrentPage(totalPages);
     }
   }, [totalPages, currentPage]);
 
   // Get paginated items
   const paginatedItems = useMemo(() => {
     const startIndex = (currentPage - 1) * pageSize;
     return items.slice(startIndex, startIndex + pageSize);
   }, [items, currentPage, pageSize]);
 
   // Calculate display indices
   const startIndex = useMemo(() => {
     if (items.length === 0) return 0;
     return (currentPage - 1) * pageSize + 1;
   }, [currentPage, pageSize, items.length]);
 
   const endIndex = useMemo(() => {
     return Math.min(currentPage * pageSize, items.length);
   }, [currentPage, pageSize, items.length]);
 
   // Page navigation
   const goToPage = useCallback((page: number) => {
     setCurrentPage(Math.max(1, Math.min(page, totalPages)));
   }, [totalPages]);
 
   const nextPage = useCallback(() => {
     setCurrentPage(prev => Math.min(prev + 1, totalPages));
   }, [totalPages]);
 
   const previousPage = useCallback(() => {
     setCurrentPage(prev => Math.max(prev - 1, 1));
   }, []);
 
   const resetPage = useCallback(() => {
     setCurrentPage(1);
   }, []);
 
   // Persist page size preference
   const setPageSize = useCallback((size: PageSize) => {
     setPageSizeInternal(size);
     setCurrentPage(1); // Reset to first page when changing page size
     try {
       localStorage.setItem(fullStorageKey, String(size));
     } catch {
       // Ignore storage errors
     }
   }, [fullStorageKey]);
 
   return {
     currentPage,
     pageSize,
     totalPages,
     paginatedItems,
     totalItems: items.length,
     goToPage,
     nextPage,
     previousPage,
     setPageSize,
     resetPage,
     hasNextPage: currentPage < totalPages,
     hasPreviousPage: currentPage > 1,
     startIndex,
     endIndex,
   };
 }