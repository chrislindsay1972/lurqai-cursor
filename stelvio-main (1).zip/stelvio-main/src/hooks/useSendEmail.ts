import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface SendEmailParams {
  connectionId?: string;
  to: string | string[];
  cc?: string[];
  bcc?: string[];
  subject: string;
  body: string;
  isHtml?: boolean;
}

interface SendEmailResult {
  email: string;
  success: boolean;
  error?: string;
}

interface SendEmailResponse {
  success: boolean;
  message: string;
  results: SendEmailResult[];
  totalSent: number;
  totalFailed: number;
}

export function useSendEmail() {
  const [isSending, setIsSending] = useState(false);

  const sendEmail = async (params: SendEmailParams): Promise<boolean> => {
    setIsSending(true);
    try {
      const { data, error } = await supabase.functions.invoke<SendEmailResponse>("send-email-365", {
        body: params,
      });

      if (error) {
        console.error("Error sending email:", error);
        toast.error("Failed to send email: " + error.message);
        return false;
      }

      if (data) {
        if (data.success && data.totalFailed === 0) {
          toast.success(`Successfully sent email`);
          return true;
        } else if (data.totalSent > 0) {
          toast.warning(`Sent ${data.totalSent} emails, ${data.totalFailed} failed`);
          return true;
        } else {
          toast.error(data.message || "Failed to send email");
          return false;
        }
      }

      return false;
    } catch (err: any) {
      console.error("Error sending email:", err);
      toast.error("Failed to send email: " + err.message);
      return false;
    } finally {
      setIsSending(false);
    }
  };

  return { sendEmail, isSending };
}
