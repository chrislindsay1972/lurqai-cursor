import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export type ModuleType = 'candidates' | 'jobs' | 'companies' | 'stakeholders' | 'job_boards';
export type FieldType = 'text' | 'textarea' | 'number' | 'date' | 'select' | 'checkbox' | 'multi_select';

export interface CustomFieldDefinition {
  id: string;
  module: ModuleType;
  field_name: string;
  field_label: string;
  field_type: FieldType;
  field_options: string[] | null;
  is_required: boolean;
  display_order: number;
  show_in_list: boolean;
  show_in_detail: boolean;
  created_at: string;
  updated_at: string;
  created_by: string | null;
}

export interface FieldOrdering {
  id: string;
  module: ModuleType;
  field_name: string;
  is_system_field: boolean;
  display_order: number;
  show_in_list: boolean;
  show_in_detail: boolean;
}

export interface CustomFieldValue {
  id: string;
  field_definition_id: string;
  entity_id: string;
  value: unknown;
}

// System fields for each module
export const SYSTEM_FIELDS: Record<ModuleType, { name: string; label: string; type: FieldType }[]> = {
  candidates: [
    { name: 'name', label: 'Name', type: 'text' },
    { name: 'email', label: 'Email', type: 'text' },
    { name: 'mobile', label: 'Mobile', type: 'text' },
    { name: 'current_title', label: 'Current Title', type: 'text' },
    { name: 'experience_years', label: 'Experience (Years)', type: 'number' },
    { name: 'skills', label: 'Skills', type: 'multi_select' },
    { name: 'address', label: 'Address', type: 'text' },
    { name: 'status', label: 'Status', type: 'select' },
  ],
  jobs: [
    { name: 'title', label: 'Title', type: 'text' },
    { name: 'description', label: 'Description', type: 'textarea' },
    { name: 'location', label: 'Location', type: 'text' },
    { name: 'job_type', label: 'Job Type', type: 'select' },
    { name: 'experience_level', label: 'Experience Level', type: 'select' },
    { name: 'salary_range', label: 'Salary Range', type: 'text' },
    { name: 'skills_required', label: 'Skills Required', type: 'multi_select' },
    { name: 'requirements', label: 'Requirements', type: 'textarea' },
    { name: 'status', label: 'Status', type: 'select' },
  ],
  companies: [
    { name: 'name', label: 'Name', type: 'text' },
    { name: 'domain', label: 'Domain', type: 'text' },
    { name: 'industry', label: 'Industry', type: 'text' },
    { name: 'employee_count', label: 'Employee Count', type: 'number' },
    { name: 'address', label: 'Address', type: 'text' },
    { name: 'phone', label: 'Phone', type: 'text' },
    { name: 'website_url', label: 'Website', type: 'text' },
    { name: 'linkedin_url', label: 'LinkedIn', type: 'text' },
    { name: 'description', label: 'Description', type: 'textarea' },
  ],
  stakeholders: [
    { name: 'name', label: 'Name', type: 'text' },
    { name: 'title', label: 'Title', type: 'text' },
    { name: 'email', label: 'Email', type: 'text' },
    { name: 'phone', label: 'Phone', type: 'text' },
    { name: 'linkedin_url', label: 'LinkedIn', type: 'text' },
    { name: 'location', label: 'Location', type: 'text' },
    { name: 'source', label: 'Source', type: 'select' },
    { name: 'contacted', label: 'Contacted', type: 'checkbox' },
    { name: 'notes', label: 'Notes', type: 'textarea' },
  ],
  job_boards: [
    { name: 'name', label: 'Name', type: 'text' },
    { name: 'url', label: 'URL', type: 'text' },
    { name: 'description', label: 'Description', type: 'textarea' },
    { name: 'status', label: 'Status', type: 'select' },
    { name: 'max_employee_count', label: 'Max Employee Count', type: 'number' },
  ],
};

export function useCustomFieldDefinitions(module?: ModuleType) {
  return useQuery({
    queryKey: ['custom-field-definitions', module],
    queryFn: async () => {
      let query = supabase
        .from('custom_field_definitions')
        .select('*')
        .order('display_order', { ascending: true });
      
      if (module) {
        query = query.eq('module', module);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as CustomFieldDefinition[];
    },
  });
}

export function useFieldOrdering(module?: ModuleType) {
  return useQuery({
    queryKey: ['field-ordering', module],
    queryFn: async () => {
      let query = supabase
        .from('field_ordering')
        .select('*')
        .order('display_order', { ascending: true });
      
      if (module) {
        query = query.eq('module', module);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as FieldOrdering[];
    },
  });
}

export function useCustomFieldValues(entityId: string, module: ModuleType) {
  return useQuery({
    queryKey: ['custom-field-values', entityId, module],
    queryFn: async () => {
      const { data: definitions } = await supabase
        .from('custom_field_definitions')
        .select('id')
        .eq('module', module);
      
      if (!definitions?.length) return [];
      
      const { data, error } = await supabase
        .from('custom_field_values')
        .select('*, custom_field_definitions(*)')
        .eq('entity_id', entityId)
        .in('field_definition_id', definitions.map(d => d.id));
      
      if (error) throw error;
      return data;
    },
    enabled: !!entityId,
  });
}

export function useCreateCustomField() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (field: Omit<CustomFieldDefinition, 'id' | 'created_at' | 'updated_at' | 'created_by'>) => {
      // Using type assertion because the database types may not be synced yet
      const { data, error } = await (supabase
        .from('custom_field_definitions') as any)
        .insert({
          module: field.module,
          field_name: field.field_name,
          field_label: field.field_label,
          field_type: field.field_type,
          field_options: field.field_options,
          is_required: field.is_required,
          display_order: field.display_order,
          show_in_list: field.show_in_list,
          show_in_detail: field.show_in_detail,
        })
        .select()
        .single();
      
      if (error) throw error;
      return data as CustomFieldDefinition;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-field-definitions'] });
      toast.success('Custom field created');
    },
    onError: (error: Error) => {
      toast.error(`Failed to create field: ${error.message}`);
    },
  });
}

export function useUpdateCustomField() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<CustomFieldDefinition> & { id: string }) => {
      const updatePayload: Record<string, unknown> = {};
      if (updates.field_label !== undefined) updatePayload.field_label = updates.field_label;
      if (updates.field_options !== undefined) updatePayload.field_options = updates.field_options;
      if (updates.is_required !== undefined) updatePayload.is_required = updates.is_required;
      if (updates.display_order !== undefined) updatePayload.display_order = updates.display_order;
      if (updates.show_in_list !== undefined) updatePayload.show_in_list = updates.show_in_list;
      if (updates.show_in_detail !== undefined) updatePayload.show_in_detail = updates.show_in_detail;
      
      // Using type assertion because the database types may not be synced yet
      const { data, error } = await (supabase
        .from('custom_field_definitions') as any)
        .update(updatePayload)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data as CustomFieldDefinition;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-field-definitions'] });
      toast.success('Field updated');
    },
    onError: (error: Error) => {
      toast.error(`Failed to update field: ${error.message}`);
    },
  });
}

export function useDeleteCustomField() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      // Using type assertion because the database types may not be synced yet
      const { error } = await (supabase
        .from('custom_field_definitions') as any)
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-field-definitions'] });
      toast.success('Field deleted');
    },
    onError: (error: Error) => {
      toast.error(`Failed to delete field: ${error.message}`);
    },
  });
}

export function useUpdateFieldOrdering() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (fields: Partial<FieldOrdering>[]) => {
      // Using type assertion because the database types may not be synced yet
      const { error } = await (supabase
        .from('field_ordering') as any)
        .upsert(fields, { onConflict: 'module,field_name' });
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['field-ordering'] });
      toast.success('Field order updated');
    },
    onError: (error: Error) => {
      toast.error(`Failed to update field order: ${error.message}`);
    },
  });
}

export function useSaveCustomFieldValue() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ fieldDefinitionId, entityId, value }: { 
      fieldDefinitionId: string; 
      entityId: string; 
      value: unknown;
    }) => {
      // Using type assertion because the database types may not be synced yet
      const { data: existing } = await (supabase
        .from('custom_field_values') as any)
        .select('id')
        .eq('field_definition_id', fieldDefinitionId)
        .eq('entity_id', entityId)
        .maybeSingle();
      
      if (existing) {
        const { error } = await (supabase
          .from('custom_field_values') as any)
          .update({ value })
          .eq('id', existing.id);
        if (error) throw error;
      } else {
        const { error } = await (supabase
          .from('custom_field_values') as any)
          .insert({
            field_definition_id: fieldDefinitionId,
            entity_id: entityId,
            value,
          });
        if (error) throw error;
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['custom-field-values', variables.entityId] });
    },
    onError: (error: Error) => {
      toast.error(`Failed to save field value: ${error.message}`);
    },
  });
}
