-- Add resolution_comment column to issues table
ALTER TABLE public.issues 
ADD COLUMN resolution_comment TEXT;