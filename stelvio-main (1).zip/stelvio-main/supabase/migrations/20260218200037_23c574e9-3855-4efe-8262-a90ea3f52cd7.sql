
-- Fix: use correct net.http_post(url, body jsonb, params, headers) signature
CREATE OR REPLACE FUNCTION public.trigger_match_enrichment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_company_id uuid;
  v_enrichment_status text;
  v_service_key text;
BEGIN
  -- Get the company_id from the matched job
  SELECT j.company_id INTO v_company_id
  FROM public.jobs j
  WHERE j.id = NEW.job_id;

  IF v_company_id IS NULL THEN
    RETURN NEW;
  END IF;

  -- Only trigger enrichment if company is still pending
  SELECT enrichment_status INTO v_enrichment_status
  FROM public.companies
  WHERE id = v_company_id;

  IF v_enrichment_status IS DISTINCT FROM 'pending' THEN
    RETURN NEW;
  END IF;

  v_service_key := 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhhZmdyaWJ1bW52bmZ1aXVpa3RtIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2NzcyNjc1MiwiZXhwIjoyMDgzMzAyNzUyfQ.tD46pOHGQ6BJNY-A3XCmhpNG_cHmQlfomMjpTrqvMhc';

  -- Correct signature: net.http_post(url, body jsonb, params jsonb, headers jsonb, timeout_ms int)
  PERFORM net.http_post(
    url                  := 'https://xafgribumnvnfuiuiktm.supabase.co/functions/v1/auto-enrich-company',
    body                 := jsonb_build_object(
                              'company_id', v_company_id::text,
                              'candidate_id', NEW.candidate_id::text
                            ),
    params               := '{}'::jsonb,
    headers              := jsonb_build_object(
                              'Content-Type', 'application/json',
                              'apikey', v_service_key,
                              'Authorization', 'Bearer ' || v_service_key
                            ),
    timeout_milliseconds := 5000
  );

  RETURN NEW;
END;
$$;
