-- Create storage bucket for assets (including signature logos)
INSERT INTO storage.buckets (id, name, public)
VALUES ('assets', 'assets', true)
ON CONFLICT (id) DO NOTHING;

-- Create policy to allow authenticated users to upload to assets bucket
CREATE POLICY "Authenticated users can upload assets"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'assets');

-- Create policy to allow public read access to assets
CREATE POLICY "Public read access to assets"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'assets');

-- Create policy to allow authenticated users to update their uploads
CREATE POLICY "Authenticated users can update assets"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'assets');

-- Create policy to allow authenticated users to delete their uploads
CREATE POLICY "Authenticated users can delete assets"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'assets');