-- Ensure realtime is enabled for pipeline_events so the UI can subscribe to live progress
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'pipeline_events'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.pipeline_events;
  END IF;
END$$;