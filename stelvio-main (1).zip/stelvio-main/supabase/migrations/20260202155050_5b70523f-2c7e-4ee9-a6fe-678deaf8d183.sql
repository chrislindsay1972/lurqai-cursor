-- Create table to store email connection configurations
CREATE TABLE public.email_connections (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_name TEXT NOT NULL,
    email_address TEXT NOT NULL,
    imap_host TEXT NOT NULL DEFAULT 'outlook.office365.com',
    imap_port INTEGER NOT NULL DEFAULT 993,
    use_oauth BOOLEAN NOT NULL DEFAULT false,
    oauth_refresh_token TEXT,
    app_password TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    last_sync_at TIMESTAMP WITH TIME ZONE,
    last_sync_status TEXT,
    sync_interval_minutes INTEGER NOT NULL DEFAULT 15,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    created_by UUID REFERENCES auth.users(id)
);

-- Create table to store synced emails
CREATE TABLE public.emails (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_id UUID NOT NULL REFERENCES public.email_connections(id) ON DELETE CASCADE,
    message_id TEXT NOT NULL,
    folder TEXT NOT NULL,
    subject TEXT,
    from_address TEXT NOT NULL,
    from_name TEXT,
    to_addresses TEXT[] NOT NULL DEFAULT '{}',
    cc_addresses TEXT[] DEFAULT '{}',
    bcc_addresses TEXT[] DEFAULT '{}',
    body_text TEXT,
    body_html TEXT,
    sent_at TIMESTAMP WITH TIME ZONE NOT NULL,
    received_at TIMESTAMP WITH TIME ZONE,
    has_attachments BOOLEAN NOT NULL DEFAULT false,
    is_read BOOLEAN NOT NULL DEFAULT false,
    company_id UUID REFERENCES public.companies(id) ON DELETE SET NULL,
    stakeholder_id UUID REFERENCES public.stakeholders(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(connection_id, message_id)
);

-- Create table to store email attachments metadata
CREATE TABLE public.email_attachments (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    email_id UUID NOT NULL REFERENCES public.emails(id) ON DELETE CASCADE,
    filename TEXT NOT NULL,
    content_type TEXT,
    size_bytes INTEGER,
    storage_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_emails_connection_id ON public.emails(connection_id);
CREATE INDEX idx_emails_company_id ON public.emails(company_id);
CREATE INDEX idx_emails_stakeholder_id ON public.emails(stakeholder_id);
CREATE INDEX idx_emails_from_address ON public.emails(from_address);
CREATE INDEX idx_emails_sent_at ON public.emails(sent_at DESC);
CREATE INDEX idx_emails_folder ON public.emails(folder);
CREATE INDEX idx_email_attachments_email_id ON public.email_attachments(email_id);

-- Enable RLS
ALTER TABLE public.email_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.emails ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_attachments ENABLE ROW LEVEL SECURITY;

-- RLS policies for email_connections (admin/recruiter only)
CREATE POLICY "Admins and recruiters can view email connections"
ON public.email_connections FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.user_roles
        WHERE user_id = auth.uid()
        AND role IN ('admin', 'recruiter')
    )
);

CREATE POLICY "Admins can manage email connections"
ON public.email_connections FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.user_roles
        WHERE user_id = auth.uid()
        AND role = 'admin'
    )
);

-- RLS policies for emails (all authenticated users can view)
CREATE POLICY "Authenticated users can view emails"
ON public.emails FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins and recruiters can manage emails"
ON public.emails FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.user_roles
        WHERE user_id = auth.uid()
        AND role IN ('admin', 'recruiter')
    )
);

-- RLS policies for email_attachments
CREATE POLICY "Authenticated users can view email attachments"
ON public.email_attachments FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins and recruiters can manage email attachments"
ON public.email_attachments FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.user_roles
        WHERE user_id = auth.uid()
        AND role IN ('admin', 'recruiter')
    )
);

-- Add triggers for updated_at
CREATE TRIGGER update_email_connections_updated_at
    BEFORE UPDATE ON public.email_connections
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_emails_updated_at
    BEFORE UPDATE ON public.emails
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for email attachments
INSERT INTO storage.buckets (id, name, public)
VALUES ('email-attachments', 'email-attachments', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for email attachments
CREATE POLICY "Authenticated users can view email attachments"
ON storage.objects FOR SELECT
USING (bucket_id = 'email-attachments' AND auth.uid() IS NOT NULL);

CREATE POLICY "Admins and recruiters can upload email attachments"
ON storage.objects FOR INSERT
WITH CHECK (
    bucket_id = 'email-attachments' AND
    EXISTS (
        SELECT 1 FROM public.user_roles
        WHERE user_id = auth.uid()
        AND role IN ('admin', 'recruiter')
    )
);