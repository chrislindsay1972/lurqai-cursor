
-- Add is_active boolean column to job_boards, default null so user can populate
ALTER TABLE public.job_boards ADD COLUMN is_active boolean DEFAULT NULL;

-- Set all existing boards to null so user can populate manually
UPDATE public.job_boards SET is_active = NULL;
