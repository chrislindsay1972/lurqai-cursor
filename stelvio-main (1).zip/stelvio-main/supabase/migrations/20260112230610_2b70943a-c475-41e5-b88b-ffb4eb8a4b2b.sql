-- Create table for storing AI instruction prompts
CREATE TABLE public.ai_instructions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    instruction_key TEXT NOT NULL UNIQUE,
    instruction_name TEXT NOT NULL,
    instruction_prompt TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    created_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.ai_instructions ENABLE ROW LEVEL SECURITY;

-- Only admins can view/edit AI instructions
CREATE POLICY "Admins can view AI instructions"
ON public.ai_instructions
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert AI instructions"
ON public.ai_instructions
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update AI instructions"
ON public.ai_instructions
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete AI instructions"
ON public.ai_instructions
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Insert default matching instruction
INSERT INTO public.ai_instructions (instruction_key, instruction_name, instruction_prompt, description) VALUES
('job_match_scoring', 'Job Match Scoring', 
'Analyze job posting for candidate with skills: {{candidate_skills}}
{{#candidate_title}}Role: {{candidate_title}}{{/candidate_title}}

SCORING CRITERIA:
- 90-100%: Perfect match - all required skills present, matching seniority level, same job family
- 70-89%: Strong match - most skills present (80%+), related job title, minor gaps
- 50-69%: Moderate match - core skills present (60%+), transferable experience
- 30-49%: Weak match - some relevant skills, significant gaps
- 0-29%: Poor match - minimal skill overlap, different specialization

Consider:
1. Direct skill matches (exact technology/tool)
2. Related skills (e.g., React experience counts for JavaScript roles)
3. Seniority alignment (Senior vs Junior roles)
4. Domain relevance (e.g., Healthcare IT experience for Healthcare jobs)

Return JSON:
- job_title: string
- match_score: number 0-100
- match_reason: string (explain the score with specific skill analysis)
- skills_matched: string[]
- skills_missing: string[]
- is_job_posting: boolean

Only valid JSON.',
'Prompt used to score how well a candidate matches a job posting. Uses {{candidate_skills}} and {{candidate_title}} placeholders.');

-- Trigger for updated_at
CREATE TRIGGER update_ai_instructions_updated_at
BEFORE UPDATE ON public.ai_instructions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();