-- Insert the max company employees setting if it doesn't exist
INSERT INTO public.app_settings (setting_key, setting_value, setting_type, description)
VALUES (
  'max_company_employees',
  '500',
  'number',
  'Companies with more employees than this threshold will be excluded from job searches. Large companies are harder to sell to.'
)
ON CONFLICT (setting_key) DO NOTHING;