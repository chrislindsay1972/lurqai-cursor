-- =====================================================
-- EMAIL CAMPAIGN MODULE - PHASE 1 DATABASE SCHEMA
-- =====================================================

-- Create campaigns table
CREATE TABLE public.campaigns (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'draft', -- draft, scheduled, active, paused, completed
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID,
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Create email templates table
CREATE TABLE public.email_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  subject TEXT NOT NULL,
  body_html TEXT NOT NULL,
  placeholders JSONB, -- e.g. {"first_name": "text", "company_name": "text"}
  include_unsubscribe_link BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID
);

-- Create campaign steps table (step-list configuration)
CREATE TABLE public.campaign_steps (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  step_order INTEGER NOT NULL,
  step_type TEXT NOT NULL, -- send_email, wait_delay, condition
  template_id UUID REFERENCES public.email_templates(id),
  delay_minutes INTEGER NOT NULL DEFAULT 2, -- delay before executing this step
  condition_type TEXT, -- for future: if_opened, if_clicked, if_not_opened
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(campaign_id, step_order)
);

-- Create stakeholder campaign states table (tracks progress through campaign)
CREATE TABLE public.stakeholder_campaign_states (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  stakeholder_id UUID NOT NULL REFERENCES public.stakeholders(id) ON DELETE CASCADE,
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  current_step_order INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, in_progress, completed, paused, failed
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  last_action_at TIMESTAMP WITH TIME ZONE,
  next_step_scheduled_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(stakeholder_id, campaign_id)
);

-- Create campaign metrics table (tracks email events)
CREATE TABLE public.campaign_metrics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  stakeholder_id UUID NOT NULL REFERENCES public.stakeholders(id) ON DELETE CASCADE,
  step_id UUID REFERENCES public.campaign_steps(id) ON DELETE SET NULL,
  email_address TEXT NOT NULL,
  event_type TEXT NOT NULL, -- sent, delivered, bounced, opened, clicked, failed
  event_data JSONB, -- additional event details
  event_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create opt-out records table (GDPR/CAN-SPAM compliance)
CREATE TABLE public.opt_out_records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  stakeholder_id UUID REFERENCES public.stakeholders(id) ON DELETE CASCADE,
  email_address TEXT NOT NULL,
  campaign_id UUID REFERENCES public.campaigns(id) ON DELETE SET NULL,
  opt_out_reason TEXT,
  opted_out_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaign_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stakeholder_campaign_states ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaign_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.opt_out_records ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- RLS POLICIES
-- =====================================================

-- Campaigns: Users can view/edit campaigns they created or are admins
CREATE POLICY "Users can view campaigns they created"
  ON public.campaigns FOR SELECT
  TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can create campaigns"
  ON public.campaigns FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their campaigns"
  ON public.campaigns FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can delete their campaigns"
  ON public.campaigns FOR DELETE
  TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- Email Templates: Users can view/manage templates they created
CREATE POLICY "Users can view templates they created"
  ON public.email_templates FOR SELECT
  TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can create templates"
  ON public.email_templates FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their templates"
  ON public.email_templates FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- Campaign Steps: Access controlled via campaign
CREATE POLICY "Users can view steps for campaigns they created"
  ON public.campaign_steps FOR SELECT
  TO authenticated
  USING (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );

CREATE POLICY "Users can manage steps for their campaigns"
  ON public.campaign_steps FOR INSERT
  TO authenticated
  WITH CHECK (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid()
    )
  );

CREATE POLICY "Users can update steps in their campaigns"
  ON public.campaign_steps FOR UPDATE
  TO authenticated
  USING (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );

-- Stakeholder Campaign States: Access controlled via campaign
CREATE POLICY "Users can view states for campaigns they created"
  ON public.stakeholder_campaign_states FOR SELECT
  TO authenticated
  USING (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );

CREATE POLICY "System can insert/update campaign states"
  ON public.stakeholder_campaign_states FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update campaign states"
  ON public.stakeholder_campaign_states FOR UPDATE
  TO authenticated
  USING (true);

-- Campaign Metrics: Access controlled via campaign
CREATE POLICY "Users can view metrics for campaigns they created"
  ON public.campaign_metrics FOR SELECT
  TO authenticated
  USING (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );

CREATE POLICY "System can insert metrics"
  ON public.campaign_metrics FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Opt-out Records: System managed
CREATE POLICY "Users can view opt-out records for campaigns they created"
  ON public.opt_out_records FOR SELECT
  TO authenticated
  USING (
    campaign_id IS NULL OR campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );

CREATE POLICY "System can insert opt-out records"
  ON public.opt_out_records FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- =====================================================
-- TRIGGERS FOR AUTOMATIC TIMESTAMP UPDATES
-- =====================================================

CREATE TRIGGER update_campaigns_updated_at
  BEFORE UPDATE ON public.campaigns
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_email_templates_updated_at
  BEFORE UPDATE ON public.email_templates
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_campaign_steps_updated_at
  BEFORE UPDATE ON public.campaign_steps
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_stakeholder_campaign_states_updated_at
  BEFORE UPDATE ON public.stakeholder_campaign_states
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();