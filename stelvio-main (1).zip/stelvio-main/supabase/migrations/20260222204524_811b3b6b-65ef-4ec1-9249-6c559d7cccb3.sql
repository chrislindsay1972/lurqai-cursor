
CREATE OR REPLACE FUNCTION public.check_enrichment_drift()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_total_sh int;
  v_with_email int;
  v_coverage numeric;
  v_bc_stale_30m int;
  v_bc_stale_24h int;
  v_total_co int;
  v_unresolved_co int;
  v_unresolved_rate numeric;
BEGIN
  SELECT count(*) INTO v_total_sh FROM stakeholders;
  SELECT count(*) INTO v_with_email FROM stakeholders WHERE email IS NOT NULL;
  v_coverage := CASE WHEN v_total_sh > 0 THEN (v_with_email::numeric / v_total_sh) * 100 ELSE 0 END;

  SELECT count(*) INTO v_bc_stale_30m
  FROM stakeholders
  WHERE bettercontact_status = 'pending'
    AND bettercontact_submitted_at < now() - interval '30 minutes';

  SELECT count(*) INTO v_bc_stale_24h
  FROM stakeholders
  WHERE bettercontact_status = 'pending'
    AND bettercontact_submitted_at < now() - interval '24 hours';

  SELECT count(*) INTO v_total_co FROM companies;
  SELECT count(*) INTO v_unresolved_co FROM companies WHERE domain_status = 'unresolved';
  v_unresolved_rate := CASE WHEN v_total_co > 0 THEN (v_unresolved_co::numeric / v_total_co) * 100 ELSE 0 END;

  UPDATE system_alerts SET resolved = true, resolved_at = now()
  WHERE resolved = false AND created_at < now() - interval '1 day';

  IF v_bc_stale_30m > 5 THEN
    INSERT INTO system_alerts (alert_type, severity, message, metric_name, metric_value, threshold)
    VALUES ('bc_stale_30m', 'warning',
      format('%s BetterContact tasks pending > 30 minutes', v_bc_stale_30m),
      'bc_stale_30m_count', v_bc_stale_30m, 5);
  END IF;

  IF v_bc_stale_24h > 0 THEN
    INSERT INTO system_alerts (alert_type, severity, message, metric_name, metric_value, threshold)
    VALUES ('bc_stale_24h', 'critical',
      format('%s BetterContact tasks pending > 24 hours', v_bc_stale_24h),
      'bc_stale_24h_count', v_bc_stale_24h, 0);
  END IF;

  IF v_unresolved_rate > 20 THEN
    INSERT INTO system_alerts (alert_type, severity, message, metric_name, metric_value, threshold)
    VALUES ('domain_unresolved_rate', 'warning',
      format('Domain unresolved rate is %s%% (%s/%s companies)', round(v_unresolved_rate, 1), v_unresolved_co, v_total_co),
      'domain_unresolved_rate', v_unresolved_rate, 20);
  END IF;

  IF v_coverage < 50 AND v_total_sh > 10 THEN
    INSERT INTO system_alerts (alert_type, severity, message, metric_name, metric_value, threshold)
    VALUES ('low_email_coverage', 'warning',
      format('Email coverage is %s%% (%s/%s stakeholders)', round(v_coverage, 1), v_with_email, v_total_sh),
      'email_coverage_pct', v_coverage, 50);
  END IF;
END;
$function$;
