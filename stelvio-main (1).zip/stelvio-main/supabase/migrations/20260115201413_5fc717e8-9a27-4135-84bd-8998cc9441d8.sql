-- Create table for configurable pre-search question options
CREATE TABLE public.pre_search_options (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question_key TEXT NOT NULL,
  option_value TEXT NOT NULL,
  is_default BOOLEAN NOT NULL DEFAULT false,
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE(question_key, option_value)
);

-- Enable RLS
ALTER TABLE public.pre_search_options ENABLE ROW LEVEL SECURITY;

-- Everyone can read options (needed for the dialog)
CREATE POLICY "Anyone can view pre-search options"
  ON public.pre_search_options
  FOR SELECT
  USING (true);

-- Only admins can modify options
CREATE POLICY "Admins can insert pre-search options"
  ON public.pre_search_options
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can update pre-search options"
  ON public.pre_search_options
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can delete pre-search options"
  ON public.pre_search_options
  FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Insert default options for each question
INSERT INTO public.pre_search_options (question_key, option_value, is_default, display_order) VALUES
-- Desired Location
('desired_location', 'Remote - UK', false, 1),
('desired_location', 'Remote - USA', false, 2),
('desired_location', 'Remote - Europe', false, 3),
('desired_location', 'London', false, 4),
('desired_location', 'Manchester', false, 5),
('desired_location', 'Birmingham', false, 6),
('desired_location', 'New York', false, 7),
('desired_location', 'San Francisco', false, 8),
('desired_location', 'Hybrid', false, 9),
-- Desired Salary
('desired_salary', '£30,000 - £40,000', false, 1),
('desired_salary', '£40,000 - £50,000', false, 2),
('desired_salary', '£50,000 - £60,000', false, 3),
('desired_salary', '£60,000 - £80,000', false, 4),
('desired_salary', '£80,000 - £100,000', false, 5),
('desired_salary', '£100,000+', false, 6),
('desired_salary', '$50,000 - $75,000', false, 7),
('desired_salary', '$75,000 - $100,000', false, 8),
('desired_salary', '$100,000 - $150,000', false, 9),
('desired_salary', '$150,000+', false, 10),
-- Reason for Looking
('reason_for_looking', 'Career Growth', true, 1),
('reason_for_looking', 'Better Compensation', false, 2),
('reason_for_looking', 'Work-Life Balance', false, 3),
('reason_for_looking', 'New Challenges', false, 4),
('reason_for_looking', 'Relocation', false, 5),
('reason_for_looking', 'Company Culture', false, 6),
('reason_for_looking', 'Remote Work', false, 7),
('reason_for_looking', 'Redundancy', false, 8),
-- Sponsorship Requirements
('sponsorship_requirements', 'No Sponsorship Needed', true, 1),
('sponsorship_requirements', 'UK Work Visa Required', false, 2),
('sponsorship_requirements', 'US Work Visa Required', false, 3),
('sponsorship_requirements', 'EU Work Permit Required', false, 4),
('sponsorship_requirements', 'Open to Sponsorship', false, 5),
-- Education
('education', 'High School / A-Levels', false, 1),
('education', 'Bachelor''s Degree', true, 2),
('education', 'Master''s Degree', false, 3),
('education', 'PhD / Doctorate', false, 4),
('education', 'Professional Certification', false, 5),
('education', 'Self-Taught', false, 6),
-- Certifications
('certifications', 'AWS Certified', false, 1),
('certifications', 'Azure Certified', false, 2),
('certifications', 'Google Cloud Certified', false, 3),
('certifications', 'PMP', false, 4),
('certifications', 'CISSP', false, 5),
('certifications', 'Scrum Master', false, 6),
('certifications', 'CPA / ACCA', false, 7),
('certifications', 'Six Sigma', false, 8),
('certifications', 'None', false, 9);

-- Create updated_at trigger
CREATE TRIGGER update_pre_search_options_updated_at
  BEFORE UPDATE ON public.pre_search_options
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();