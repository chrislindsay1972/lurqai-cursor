-- Create candidates table
CREATE TABLE public.candidates (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT,
    mobile TEXT,
    address TEXT,
    skills TEXT[],
    experience_years INTEGER,
    current_title TEXT,
    cv_file_url TEXT,
    cv_raw_text TEXT,
    status TEXT NOT NULL DEFAULT 'pending_review',
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create unique constraint on email (when not null)
CREATE UNIQUE INDEX idx_candidates_email ON public.candidates(email) WHERE email IS NOT NULL;

-- Enable RLS
ALTER TABLE public.candidates ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view candidates"
ON public.candidates
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Recruiters and admins can insert candidates"
ON public.candidates
FOR INSERT
TO authenticated
WITH CHECK (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Recruiters and admins can update candidates"
ON public.candidates
FOR UPDATE
TO authenticated
USING (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Admins can delete candidates"
ON public.candidates
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'));

-- Trigger for updated_at
CREATE TRIGGER update_candidates_updated_at
BEFORE UPDATE ON public.candidates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();