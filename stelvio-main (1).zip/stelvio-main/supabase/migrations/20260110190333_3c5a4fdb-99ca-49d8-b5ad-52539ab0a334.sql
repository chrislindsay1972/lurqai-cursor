-- Add search_url_template field to job_boards table
-- This allows users to define custom search URL patterns for each job board
-- Placeholders: {query}, {title}, {location}, {employee_segments}
ALTER TABLE public.job_boards
ADD COLUMN search_url_template text;

-- Set default templates for known job boards
COMMENT ON COLUMN public.job_boards.search_url_template IS 'URL template for direct scraping. Placeholders: {query}, {title}, {location}, {employee_segments}';

-- Update existing BuiltIn board with proper template
UPDATE public.job_boards
SET search_url_template = 'https://builtin.com/jobs/{employee_segments}?search={query}&country=USA&allLocations=true'
WHERE LOWER(name) LIKE '%builtin%' OR url LIKE '%builtin.com%';

-- Update existing Indeed board with proper template  
UPDATE public.job_boards
SET search_url_template = 'https://www.indeed.com/jobs?q={query}&l={location}'
WHERE LOWER(name) LIKE '%indeed%' OR url LIKE '%indeed.com%';

-- Update existing Glassdoor board with proper template
UPDATE public.job_boards
SET search_url_template = 'https://www.glassdoor.com/Job/jobs.htm?sc.keyword={query}'
WHERE LOWER(name) LIKE '%glassdoor%' OR LOWER(name) LIKE '%glass door%' OR url LIKE '%glassdoor%';