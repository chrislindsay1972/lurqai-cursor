-- Create table for custom field definitions
CREATE TABLE public.custom_field_definitions (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    module TEXT NOT NULL CHECK (module IN ('candidates', 'jobs', 'companies', 'stakeholders', 'job_boards')),
    field_name TEXT NOT NULL,
    field_label TEXT NOT NULL,
    field_type TEXT NOT NULL CHECK (field_type IN ('text', 'textarea', 'number', 'date', 'select', 'checkbox', 'multi_select')),
    field_options JSONB DEFAULT NULL, -- For select/multi_select: array of options
    is_required BOOLEAN NOT NULL DEFAULT false,
    display_order INTEGER NOT NULL DEFAULT 0,
    show_in_list BOOLEAN NOT NULL DEFAULT false,
    show_in_detail BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    created_by UUID,
    UNIQUE(module, field_name)
);

-- Create table for custom field values
CREATE TABLE public.custom_field_values (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    field_definition_id UUID NOT NULL REFERENCES public.custom_field_definitions(id) ON DELETE CASCADE,
    entity_id UUID NOT NULL,
    value JSONB NOT NULL DEFAULT '""',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    created_by UUID,
    UNIQUE(field_definition_id, entity_id)
);

-- Create table for storing default field ordering per module
CREATE TABLE public.field_ordering (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    module TEXT NOT NULL CHECK (module IN ('candidates', 'jobs', 'companies', 'stakeholders', 'job_boards')),
    field_name TEXT NOT NULL,
    is_system_field BOOLEAN NOT NULL DEFAULT true,
    display_order INTEGER NOT NULL DEFAULT 0,
    show_in_list BOOLEAN NOT NULL DEFAULT true,
    show_in_detail BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(module, field_name)
);

-- Enable RLS
ALTER TABLE public.custom_field_definitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.custom_field_values ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.field_ordering ENABLE ROW LEVEL SECURITY;

-- RLS Policies for custom_field_definitions
CREATE POLICY "Admins can manage field definitions"
ON public.custom_field_definitions
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view field definitions"
ON public.custom_field_definitions
FOR SELECT
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Viewers can view field definitions"
ON public.custom_field_definitions
FOR SELECT
USING (has_role(auth.uid(), 'viewer'::app_role));

-- RLS Policies for custom_field_values
CREATE POLICY "Admins can manage all field values"
ON public.custom_field_values
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can manage field values"
ON public.custom_field_values
FOR ALL
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Viewers can view field values"
ON public.custom_field_values
FOR SELECT
USING (has_role(auth.uid(), 'viewer'::app_role));

-- RLS Policies for field_ordering
CREATE POLICY "Admins can manage field ordering"
ON public.field_ordering
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view field ordering"
ON public.field_ordering
FOR SELECT
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Viewers can view field ordering"
ON public.field_ordering
FOR SELECT
USING (has_role(auth.uid(), 'viewer'::app_role));

-- Add updated_at triggers
CREATE TRIGGER update_custom_field_definitions_updated_at
BEFORE UPDATE ON public.custom_field_definitions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_custom_field_values_updated_at
BEFORE UPDATE ON public.custom_field_values
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_field_ordering_updated_at
BEFORE UPDATE ON public.field_ordering
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();