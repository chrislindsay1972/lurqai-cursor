
-- Track which search query produced each pending job (add column to existing table)
ALTER TABLE public.pipeline_pending_jobs 
  ADD COLUMN IF NOT EXISTS source_query TEXT;

-- Search feedback: aggregate query→score correlation per candidate
CREATE TABLE public.search_feedback (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  query_text TEXT NOT NULL,
  board_name TEXT,
  board_id UUID REFERENCES public.job_boards(id) ON DELETE SET NULL,
  jobs_discovered INTEGER NOT NULL DEFAULT 0,
  jobs_scored INTEGER NOT NULL DEFAULT 0,
  jobs_matched INTEGER NOT NULL DEFAULT 0,
  avg_score NUMERIC(5,2),
  best_score NUMERIC(5,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.search_feedback ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read search feedback"
  ON public.search_feedback FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can manage search feedback"
  ON public.search_feedback FOR ALL
  USING (auth.uid() IS NOT NULL);

CREATE INDEX idx_search_feedback_candidate ON public.search_feedback(candidate_id);
CREATE INDEX idx_search_feedback_board ON public.search_feedback(board_id);

-- Keyword learning: track which keywords lead to accepted/rejected matches
CREATE TABLE public.keyword_performance (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  keyword TEXT NOT NULL,
  times_used INTEGER NOT NULL DEFAULT 0,
  jobs_found INTEGER NOT NULL DEFAULT 0,
  matches_produced INTEGER NOT NULL DEFAULT 0,
  matches_accepted INTEGER NOT NULL DEFAULT 0,
  matches_rejected INTEGER NOT NULL DEFAULT 0,
  avg_match_score NUMERIC(5,2),
  effectiveness_score NUMERIC(5,2) DEFAULT 50.00,
  last_used_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(candidate_id, keyword)
);

ALTER TABLE public.keyword_performance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read keyword performance"
  ON public.keyword_performance FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can manage keyword performance"
  ON public.keyword_performance FOR ALL
  USING (auth.uid() IS NOT NULL);

CREATE INDEX idx_keyword_perf_candidate ON public.keyword_performance(candidate_id);

-- Board-candidate affinity: per-candidate board performance (beyond global board stats)
ALTER TABLE public.job_board_performance 
  ADD COLUMN IF NOT EXISTS candidate_id UUID REFERENCES public.candidates(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS high_score_count INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS accepted_count INTEGER DEFAULT 0;
