-- Add BetterContact enrichment fields to stakeholders table
ALTER TABLE public.stakeholders
ADD COLUMN IF NOT EXISTS email_status text,
ADD COLUMN IF NOT EXISTS email_provider text,
ADD COLUMN IF NOT EXISTS gender text,
ADD COLUMN IF NOT EXISTS enriched_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS enrichment_source text,
ADD COLUMN IF NOT EXISTS bettercontact_data jsonb DEFAULT '{}'::jsonb;

-- Add comment for documentation
COMMENT ON COLUMN public.stakeholders.email_status IS 'Email deliverability status from BetterContact (deliverable, catch_all, undeliverable, not_found)';
COMMENT ON COLUMN public.stakeholders.email_provider IS 'Email provider identified by BetterContact';
COMMENT ON COLUMN public.stakeholders.gender IS 'Gender inferred by BetterContact';
COMMENT ON COLUMN public.stakeholders.enriched_at IS 'Timestamp of last enrichment';
COMMENT ON COLUMN public.stakeholders.enrichment_source IS 'Source of enrichment (bettercontact, manual, etc.)';
COMMENT ON COLUMN public.stakeholders.bettercontact_data IS 'Raw BetterContact API response for future-proofing';