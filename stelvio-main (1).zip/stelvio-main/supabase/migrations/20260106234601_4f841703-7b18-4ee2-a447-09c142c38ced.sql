-- =====================================================
-- FIX: Cross-Company Data Access Not Restricted
-- Implementing owner-based isolation for data tables
-- Recruiters can only access their own records
-- Admins can access all records
-- =====================================================

-- Drop existing policies for candidates table
DROP POLICY IF EXISTS "Admins can delete candidates" ON public.candidates;
DROP POLICY IF EXISTS "Recruiters and admins can insert candidates" ON public.candidates;
DROP POLICY IF EXISTS "Recruiters and admins can update candidates" ON public.candidates;
DROP POLICY IF EXISTS "Recruiters and admins can view candidates" ON public.candidates;

-- Create new owner-based policies for candidates
CREATE POLICY "Admins can view all candidates"
ON public.candidates
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own candidates"
ON public.candidates
FOR SELECT
TO authenticated
USING (created_by = auth.uid() AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert candidates"
ON public.candidates
FOR INSERT
TO authenticated
WITH CHECK (
  (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role))
  AND (created_by IS NULL OR created_by = auth.uid())
);

CREATE POLICY "Admins can update all candidates"
ON public.candidates
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can update own candidates"
ON public.candidates
FOR UPDATE
TO authenticated
USING (created_by = auth.uid() AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Admins can delete candidates"
ON public.candidates
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Drop existing policies for companies table
DROP POLICY IF EXISTS "Admins can delete companies" ON public.companies;
DROP POLICY IF EXISTS "Recruiters and admins can insert companies" ON public.companies;
DROP POLICY IF EXISTS "Recruiters and admins can update companies" ON public.companies;
DROP POLICY IF EXISTS "Recruiters and admins can view companies" ON public.companies;

-- Create new owner-based policies for companies
CREATE POLICY "Admins can view all companies"
ON public.companies
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own companies"
ON public.companies
FOR SELECT
TO authenticated
USING (created_by = auth.uid() AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert companies"
ON public.companies
FOR INSERT
TO authenticated
WITH CHECK (
  (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role))
  AND (created_by IS NULL OR created_by = auth.uid())
);

CREATE POLICY "Admins can update all companies"
ON public.companies
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can update own companies"
ON public.companies
FOR UPDATE
TO authenticated
USING (created_by = auth.uid() AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Admins can delete companies"
ON public.companies
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Drop existing policies for jobs table
DROP POLICY IF EXISTS "Admins can delete jobs" ON public.jobs;
DROP POLICY IF EXISTS "Recruiters and admins can insert jobs" ON public.jobs;
DROP POLICY IF EXISTS "Recruiters and admins can update jobs" ON public.jobs;
DROP POLICY IF EXISTS "Recruiters and admins can view jobs" ON public.jobs;

-- Create new owner-based policies for jobs
CREATE POLICY "Admins can view all jobs"
ON public.jobs
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own jobs"
ON public.jobs
FOR SELECT
TO authenticated
USING (created_by = auth.uid() AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert jobs"
ON public.jobs
FOR INSERT
TO authenticated
WITH CHECK (
  (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role))
  AND (created_by IS NULL OR created_by = auth.uid())
);

CREATE POLICY "Admins can update all jobs"
ON public.jobs
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can update own jobs"
ON public.jobs
FOR UPDATE
TO authenticated
USING (created_by = auth.uid() AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Admins can delete jobs"
ON public.jobs
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Drop existing policies for matches table
DROP POLICY IF EXISTS "Admins can delete matches" ON public.matches;
DROP POLICY IF EXISTS "Recruiters and admins can insert matches" ON public.matches;
DROP POLICY IF EXISTS "Recruiters and admins can update matches" ON public.matches;
DROP POLICY IF EXISTS "Recruiters and admins can view matches" ON public.matches;

-- Create new owner-based policies for matches
CREATE POLICY "Admins can view all matches"
ON public.matches
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own matches"
ON public.matches
FOR SELECT
TO authenticated
USING (created_by = auth.uid() AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert matches"
ON public.matches
FOR INSERT
TO authenticated
WITH CHECK (
  (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role))
  AND (created_by IS NULL OR created_by = auth.uid())
);

CREATE POLICY "Admins can update all matches"
ON public.matches
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can update own matches"
ON public.matches
FOR UPDATE
TO authenticated
USING (created_by = auth.uid() AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Admins can delete matches"
ON public.matches
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));