-- Add column to email_templates for CV attachment toggle
ALTER TABLE public.email_templates 
ADD COLUMN include_cv_attachment boolean NOT NULL DEFAULT false;