
-- Create table for BuiltIn job category catalog
CREATE TABLE public.builtin_job_categories (
  slug TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  parent_slug TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  last_seen_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  examples JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- RLS
ALTER TABLE public.builtin_job_categories ENABLE ROW LEVEL SECURITY;

-- Everyone authenticated can read
CREATE POLICY "Authenticated users can view categories"
  ON public.builtin_job_categories
  FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- Admins can manage
CREATE POLICY "Admins can manage categories"
  ON public.builtin_job_categories
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Seed initial category catalog (from BuiltIn's known categories)
INSERT INTO public.builtin_job_categories (slug, label, parent_slug) VALUES
  ('dev-engineering', 'Software Engineering', NULL),
  ('ai-machine-learning', 'AI & Machine Learning', NULL),
  ('data-analytics', 'Data & Analytics', NULL),
  ('cybersecurity', 'Cybersecurity', NULL),
  ('product-management', 'Product Management', NULL),
  ('design', 'Design', NULL),
  ('project-management', 'Project & Program Management', NULL),
  ('sales', 'Sales', NULL),
  ('consulting', 'Consulting', NULL),
  ('marketing', 'Marketing', NULL),
  ('operations', 'Operations & Support', NULL),
  ('hr', 'HR & Recruiting', NULL),
  ('finance', 'Finance & Accounting', NULL),
  ('legal', 'Legal', NULL),
  ('customer-success', 'Customer Success', NULL),
  ('content', 'Content', NULL),
  ('qa', 'Quality Assurance', NULL),
  ('devops-sysadmin', 'DevOps & SysAdmin', NULL),
  ('hardware-engineering', 'Hardware Engineering', NULL),
  ('research-science', 'Research & Science', NULL),
  ('cloud-computing', 'Cloud Computing', NULL),
  ('blockchain', 'Blockchain', NULL),
  ('iot', 'Internet of Things', NULL),
  ('ar-vr', 'AR/VR', NULL),
  ('gaming', 'Gaming', NULL),
  ('edtech', 'Education Technology', NULL),
  ('healthtech', 'Healthcare Technology', NULL),
  ('fintech', 'Fintech', NULL),
  ('e-commerce', 'E-Commerce', NULL),
  ('social-media', 'Social Media', NULL)
ON CONFLICT (slug) DO NOTHING;
