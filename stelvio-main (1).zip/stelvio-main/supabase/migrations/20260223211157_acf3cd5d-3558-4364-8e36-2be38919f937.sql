-- Create a trigger function that auto-purges oversized companies
-- whenever employee_count is updated to exceed the max setting
CREATE OR REPLACE FUNCTION public.enforce_max_company_size()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_max_employees int := 500;
  v_setting text;
BEGIN
  -- Fetch the configurable max from app_settings
  SELECT setting_value INTO v_setting
  FROM public.app_settings
  WHERE setting_key = 'max_company_employees'
  LIMIT 1;
  
  IF v_setting IS NOT NULL THEN
    v_max_employees := v_setting::int;
  END IF;

  -- Only act when employee_count is set/changed and exceeds max
  IF NEW.employee_count IS NOT NULL AND NEW.employee_count > v_max_employees THEN
    -- Mark the company as exceeds_size
    NEW.enrichment_status := 'exceeds_size';
    NEW.enriched_at := now();

    -- Cascade delete: campaign metrics → campaign states → enrichment attempts → stakeholders
    DELETE FROM public.campaign_metrics
    WHERE stakeholder_id IN (SELECT id FROM public.stakeholders WHERE company_id = NEW.id);

    DELETE FROM public.stakeholder_campaign_states
    WHERE stakeholder_id IN (SELECT id FROM public.stakeholders WHERE company_id = NEW.id);

    DELETE FROM public.stakeholder_enrichment_attempts
    WHERE stakeholder_id IN (SELECT id FROM public.stakeholders WHERE company_id = NEW.id);

    DELETE FROM public.stakeholders WHERE company_id = NEW.id;

    -- Delete matches via jobs
    DELETE FROM public.matches
    WHERE job_id IN (SELECT id FROM public.jobs WHERE company_id = NEW.id);

    -- Delete jobs
    DELETE FROM public.jobs WHERE company_id = NEW.id;

    -- Delete email intel
    DELETE FROM public.company_email_intel WHERE company_id = NEW.id;

    -- Delete the company record itself (after trigger completes)
    -- We can't delete NEW in a BEFORE trigger, so we schedule it
    -- Instead, we'll just let the row persist with exceeds_size status
    -- and delete it in a deferred way
    
    RAISE LOG '[enforce_max_company_size] Purged all data for oversized company: % (% employees, max %)', NEW.name, NEW.employee_count, v_max_employees;
  END IF;

  RETURN NEW;
END;
$function$;

-- Attach trigger to companies table (BEFORE UPDATE so we can modify NEW)
CREATE TRIGGER trg_enforce_max_company_size
BEFORE UPDATE OF employee_count ON public.companies
FOR EACH ROW
EXECUTE FUNCTION public.enforce_max_company_size();

-- Also fire on INSERT (catches companies created with employee_count already set)
CREATE TRIGGER trg_enforce_max_company_size_insert
BEFORE INSERT ON public.companies
FOR EACH ROW
EXECUTE FUNCTION public.enforce_max_company_size();