-- Create jobs table
CREATE TABLE public.jobs (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    company_id UUID REFERENCES public.companies(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    description TEXT,
    requirements TEXT,
    location TEXT,
    salary_range TEXT,
    job_type TEXT, -- full-time, part-time, contract, etc.
    experience_level TEXT, -- junior, mid, senior, etc.
    skills_required TEXT[],
    source_url TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create matches table for candidate-job relationships
CREATE TABLE public.matches (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
    job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
    match_score INTEGER NOT NULL CHECK (match_score >= 0 AND match_score <= 100),
    match_reason TEXT,
    skills_matched TEXT[],
    skills_missing TEXT[],
    status TEXT NOT NULL DEFAULT 'pending', -- pending, reviewed, contacted, rejected
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(candidate_id, job_id)
);

-- Enable RLS on jobs
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;

-- Jobs RLS Policies
CREATE POLICY "Recruiters and admins can view jobs"
ON public.jobs
FOR SELECT
TO authenticated
USING (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Recruiters and admins can insert jobs"
ON public.jobs
FOR INSERT
TO authenticated
WITH CHECK (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Recruiters and admins can update jobs"
ON public.jobs
FOR UPDATE
TO authenticated
USING (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Admins can delete jobs"
ON public.jobs
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'));

-- Enable RLS on matches
ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;

-- Matches RLS Policies
CREATE POLICY "Recruiters and admins can view matches"
ON public.matches
FOR SELECT
TO authenticated
USING (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Recruiters and admins can insert matches"
ON public.matches
FOR INSERT
TO authenticated
WITH CHECK (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Recruiters and admins can update matches"
ON public.matches
FOR UPDATE
TO authenticated
USING (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Admins can delete matches"
ON public.matches
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'));

-- Triggers for updated_at
CREATE TRIGGER update_jobs_updated_at
BEFORE UPDATE ON public.jobs
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_matches_updated_at
BEFORE UPDATE ON public.matches
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Index for faster matching queries
CREATE INDEX idx_matches_candidate_id ON public.matches(candidate_id);
CREATE INDEX idx_matches_job_id ON public.matches(job_id);
CREATE INDEX idx_jobs_company_id ON public.jobs(company_id);
CREATE INDEX idx_jobs_status ON public.jobs(status);