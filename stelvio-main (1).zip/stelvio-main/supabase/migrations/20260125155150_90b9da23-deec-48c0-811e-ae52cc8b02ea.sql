-- Insert the max_job_age_days setting with default of 14 days
INSERT INTO app_settings (setting_key, setting_value, setting_type, description)
VALUES ('max_job_age_days', '14', 'number', 'Maximum age of job postings in days - jobs older than this will be filtered out')
ON CONFLICT (setting_key) DO NOTHING;