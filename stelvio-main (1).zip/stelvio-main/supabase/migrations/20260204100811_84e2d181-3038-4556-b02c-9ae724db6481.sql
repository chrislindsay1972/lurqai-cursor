-- Remove overly-permissive policy; service-role already bypasses RLS and doesn't need a policy.
DROP POLICY IF EXISTS "Service role full access to pending jobs" ON public.pipeline_pending_jobs;