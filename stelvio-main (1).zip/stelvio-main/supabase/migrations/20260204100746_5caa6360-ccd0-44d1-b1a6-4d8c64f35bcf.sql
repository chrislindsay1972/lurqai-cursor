-- Allow the frontend to read pipeline_pending_jobs counts/status for its own candidates
-- (required for auto-resume scoring and progress UI)

ALTER TABLE public.pipeline_pending_jobs ENABLE ROW LEVEL SECURITY;

-- Read access for admins
DROP POLICY IF EXISTS "Admins can read pending jobs" ON public.pipeline_pending_jobs;
CREATE POLICY "Admins can read pending jobs"
ON public.pipeline_pending_jobs
FOR SELECT
USING (
  public.has_role('admin', auth.uid())
);

-- Read access for recruiters, scoped to candidates they created
DROP POLICY IF EXISTS "Recruiters can read pending jobs for their candidates" ON public.pipeline_pending_jobs;
CREATE POLICY "Recruiters can read pending jobs for their candidates"
ON public.pipeline_pending_jobs
FOR SELECT
USING (
  public.has_role('recruiter', auth.uid())
  AND EXISTS (
    SELECT 1
    FROM public.candidates c
    WHERE c.id = public.pipeline_pending_jobs.candidate_id
      AND c.created_by = auth.uid()
  )
);

-- Optional: viewers get no access (default-deny when no policy matches)
