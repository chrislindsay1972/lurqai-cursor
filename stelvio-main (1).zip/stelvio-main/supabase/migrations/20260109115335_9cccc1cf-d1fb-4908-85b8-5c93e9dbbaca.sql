-- Junction table: job_board_jobs (many-to-many: job boards <-> jobs)
CREATE TABLE public.job_board_jobs (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    job_board_id UUID NOT NULL REFERENCES public.job_boards(id) ON DELETE CASCADE,
    job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (job_board_id, job_id)
);

-- Junction table: job_board_candidates (many-to-many: job boards <-> candidates)
CREATE TABLE public.job_board_candidates (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    job_board_id UUID NOT NULL REFERENCES public.job_boards(id) ON DELETE CASCADE,
    candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (job_board_id, candidate_id)
);

-- Stakeholders table
CREATE TABLE public.stakeholders (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    title TEXT,
    email TEXT,
    phone TEXT,
    linkedin_url TEXT,
    company_id UUID REFERENCES public.companies(id) ON DELETE SET NULL,
    job_board_id UUID REFERENCES public.job_boards(id) ON DELETE SET NULL,
    source TEXT DEFAULT 'manual',
    contacted BOOLEAN NOT NULL DEFAULT false,
    notes TEXT,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all new tables
ALTER TABLE public.job_board_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_board_candidates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stakeholders ENABLE ROW LEVEL SECURITY;

-- RLS for job_board_jobs
CREATE POLICY "Admins can view all job_board_jobs"
ON public.job_board_jobs FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own job_board_jobs"
ON public.job_board_jobs FOR SELECT
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert job_board_jobs"
ON public.job_board_jobs FOR INSERT
WITH CHECK ((has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role)) AND ((created_by IS NULL) OR (created_by = auth.uid())));

CREATE POLICY "Admins can delete job_board_jobs"
ON public.job_board_jobs FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can delete own job_board_jobs"
ON public.job_board_jobs FOR DELETE
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

-- RLS for job_board_candidates
CREATE POLICY "Admins can view all job_board_candidates"
ON public.job_board_candidates FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own job_board_candidates"
ON public.job_board_candidates FOR SELECT
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert job_board_candidates"
ON public.job_board_candidates FOR INSERT
WITH CHECK ((has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role)) AND ((created_by IS NULL) OR (created_by = auth.uid())));

CREATE POLICY "Admins can delete job_board_candidates"
ON public.job_board_candidates FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can delete own job_board_candidates"
ON public.job_board_candidates FOR DELETE
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

-- RLS for stakeholders
CREATE POLICY "Admins can view all stakeholders"
ON public.stakeholders FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own stakeholders"
ON public.stakeholders FOR SELECT
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert stakeholders"
ON public.stakeholders FOR INSERT
WITH CHECK ((has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role)) AND ((created_by IS NULL) OR (created_by = auth.uid())));

CREATE POLICY "Admins can update all stakeholders"
ON public.stakeholders FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can update own stakeholders"
ON public.stakeholders FOR UPDATE
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Admins can delete stakeholders"
ON public.stakeholders FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Trigger for stakeholders updated_at
CREATE TRIGGER update_stakeholders_updated_at
BEFORE UPDATE ON public.stakeholders
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();