-- Create storage bucket for CV files
INSERT INTO storage.buckets (id, name, public)
VALUES ('cv-files', 'cv-files', false);

-- RLS policies for CV storage - only recruiters and admins can upload/manage
CREATE POLICY "Recruiters and admins can upload CVs"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'cv-files' AND
    (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'recruiter'))
);

CREATE POLICY "Recruiters and admins can view CVs"
ON storage.objects
FOR SELECT
TO authenticated
USING (
    bucket_id = 'cv-files' AND
    (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'recruiter'))
);

CREATE POLICY "Recruiters and admins can update CVs"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
    bucket_id = 'cv-files' AND
    (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'recruiter'))
);

CREATE POLICY "Admins can delete CVs"
ON storage.objects
FOR DELETE
TO authenticated
USING (
    bucket_id = 'cv-files' AND
    public.has_role(auth.uid(), 'admin')
);

-- Fix candidates table RLS - restrict to recruiters/admins only
DROP POLICY IF EXISTS "Authenticated users can view candidates" ON public.candidates;

CREATE POLICY "Recruiters and admins can view candidates"
ON public.candidates
FOR SELECT
TO authenticated
USING (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);