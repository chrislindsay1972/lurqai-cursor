CREATE POLICY "Users can delete campaign states for their campaigns"
ON public.stakeholder_campaign_states
FOR DELETE
USING (
  campaign_id IN (
    SELECT campaigns.id
    FROM campaigns
    WHERE campaigns.created_by = auth.uid() OR has_role(auth.uid(), 'admin'::app_role)
  )
);