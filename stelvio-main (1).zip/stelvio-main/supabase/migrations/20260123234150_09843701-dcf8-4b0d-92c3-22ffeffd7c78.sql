-- Drop the existing restrictive policy for recruiters viewing stakeholders
DROP POLICY IF EXISTS "Recruiters can view own stakeholders" ON public.stakeholders;

-- Create a new policy that allows recruiters to view:
-- 1. Stakeholders they created directly
-- 2. Stakeholders belonging to companies they created
CREATE POLICY "Recruiters can view related stakeholders" 
ON public.stakeholders 
FOR SELECT 
USING (
  has_role(auth.uid(), 'recruiter'::app_role) 
  AND (
    created_by = auth.uid() 
    OR company_id IN (
      SELECT id FROM public.companies WHERE created_by = auth.uid()
    )
  )
);

-- Also update the UPDATE policy so recruiters can update stakeholders for their companies
DROP POLICY IF EXISTS "Recruiters can update own stakeholders" ON public.stakeholders;

CREATE POLICY "Recruiters can update related stakeholders" 
ON public.stakeholders 
FOR UPDATE 
USING (
  has_role(auth.uid(), 'recruiter'::app_role) 
  AND (
    created_by = auth.uid() 
    OR company_id IN (
      SELECT id FROM public.companies WHERE created_by = auth.uid()
    )
  )
);