
-- Create a staging table to persist unscored jobs across pipeline waves
CREATE TABLE public.pipeline_pending_jobs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  run_id TEXT NOT NULL,
  job_url TEXT NOT NULL,
  job_title TEXT,
  company_name TEXT,
  location TEXT,
  job_content TEXT,
  source_board TEXT,
  discovered_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  scored_at TIMESTAMP WITH TIME ZONE,
  score INTEGER,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, scored, saved, rejected
  rejection_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(candidate_id, job_url)
);

-- Index for efficient querying of pending jobs
CREATE INDEX idx_pipeline_pending_jobs_candidate_status 
  ON public.pipeline_pending_jobs(candidate_id, status);

CREATE INDEX idx_pipeline_pending_jobs_run_id 
  ON public.pipeline_pending_jobs(run_id);

-- Enable RLS
ALTER TABLE public.pipeline_pending_jobs ENABLE ROW LEVEL SECURITY;

-- Policy: Authenticated users can read their own pending jobs
CREATE POLICY "Users can view pending jobs for their candidates"
  ON public.pipeline_pending_jobs
  FOR SELECT
  USING (
    candidate_id IN (
      SELECT id FROM public.candidates WHERE created_by = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Policy: Service role can do everything (for edge functions)
CREATE POLICY "Service role full access to pending jobs"
  ON public.pipeline_pending_jobs
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- Enable realtime for progress tracking
ALTER PUBLICATION supabase_realtime ADD TABLE public.pipeline_pending_jobs;

-- Add comment
COMMENT ON TABLE public.pipeline_pending_jobs IS 'Staging table for unscored jobs that persist across pipeline timeout waves';
