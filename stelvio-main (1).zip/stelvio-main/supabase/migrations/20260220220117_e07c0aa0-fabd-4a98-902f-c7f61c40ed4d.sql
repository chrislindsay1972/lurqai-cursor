
-- Add a unique constraint on (candidate_id, job_url) to prevent the same job URL
-- being inserted more than once per candidate across different pipeline runs.
-- This is the PRIMARY fix for the duplicate problem — dedup at write time, not score time.
-- Use ON CONFLICT DO NOTHING in inserts to silently skip dupes.

-- First clean up existing duplicates (keep the oldest/lowest ID per candidate+url)
DELETE FROM public.pipeline_pending_jobs
WHERE id NOT IN (
  SELECT DISTINCT ON (candidate_id, job_url) id
  FROM public.pipeline_pending_jobs
  ORDER BY candidate_id, job_url, created_at ASC
);

-- Now add the unique index
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_pending_jobs_candidate_url_unique
  ON public.pipeline_pending_jobs (candidate_id, job_url);
