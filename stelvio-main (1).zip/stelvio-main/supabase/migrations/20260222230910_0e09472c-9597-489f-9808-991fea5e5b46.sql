
-- Add board-specific URL filtering and content quality profiles to job_boards
ALTER TABLE public.job_boards 
  ADD COLUMN IF NOT EXISTS url_allow_patterns text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS url_deny_patterns text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS job_id_pattern text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS min_content_length integer DEFAULT 200;

-- Add comment for documentation
COMMENT ON COLUMN public.job_boards.url_allow_patterns IS 'Regex patterns that identify valid job-detail URLs. If non-empty, only matching URLs pass.';
COMMENT ON COLUMN public.job_boards.url_deny_patterns IS 'Regex patterns that identify listing/search/category pages. Matching URLs are rejected pre-scrape.';
COMMENT ON COLUMN public.job_boards.job_id_pattern IS 'Optional regex to extract a unique job ID from URL for deduplication.';
COMMENT ON COLUMN public.job_boards.min_content_length IS 'Minimum content length (chars) required to proceed to AI scoring. Default 200.';
