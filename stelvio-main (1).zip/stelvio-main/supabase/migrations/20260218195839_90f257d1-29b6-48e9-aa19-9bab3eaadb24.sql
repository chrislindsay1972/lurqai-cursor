
-- Drop and recreate the trigger function with service role key for proper auth
CREATE OR REPLACE FUNCTION public.trigger_match_enrichment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_company_id uuid;
  v_enrichment_status text;
BEGIN
  -- Get the company_id from the matched job
  SELECT j.company_id INTO v_company_id
  FROM public.jobs j
  WHERE j.id = NEW.job_id;

  IF v_company_id IS NULL THEN
    RETURN NEW;
  END IF;

  -- Only trigger enrichment if company is still pending
  SELECT enrichment_status INTO v_enrichment_status
  FROM public.companies
  WHERE id = v_company_id;

  IF v_enrichment_status IS DISTINCT FROM 'pending' THEN
    RETURN NEW;
  END IF;

  -- Fire-and-forget call to the auto-enrich-company edge function via pg_net
  PERFORM net.http_post(
    url := 'https://xafgribumnvnfuiuiktm.supabase.co/functions/v1/auto-enrich-company',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'apikey', current_setting('app.settings.service_role_key', true),
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
    ),
    body := jsonb_build_object(
      'company_id', v_company_id,
      'candidate_id', NEW.candidate_id
    )::text
  );

  RETURN NEW;
END;
$$;

-- Drop existing trigger if any, then recreate cleanly
DROP TRIGGER IF EXISTS on_match_insert_enrich_company ON public.matches;

-- Create the trigger on the matches table
CREATE TRIGGER on_match_insert_enrich_company
  AFTER INSERT ON public.matches
  FOR EACH ROW
  EXECUTE FUNCTION public.trigger_match_enrichment();
