SELECT cron.schedule(
  'execute-campaigns-every-5-min',
  '*/5 * * * *',
  $$
  SELECT net.http_post(
    url := 'https://xafgribumnvnfuiuiktm.supabase.co/functions/v1/execute-campaign',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhhZmdyaWJ1bW52bmZ1aXVpa3RtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc3MjY3NTIsImV4cCI6MjA4MzMwMjc1Mn0.DJFzfhdsJ4d2bUvmphamStaGfvk7S9Y6Vxr4lmLwlFU"}'::jsonb,
    body := '{}'::jsonb
  ) AS request_id;
  $$
);