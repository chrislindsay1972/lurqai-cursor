
-- Drop the problematic policy that causes RLS recursion
DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;

-- Create a new policy using the SECURITY DEFINER function to avoid recursion
CREATE POLICY "Admins can manage all roles"
ON public.user_roles
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));
