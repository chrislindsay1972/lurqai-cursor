-- Add posted_at column to store when the job was originally posted on the job board
ALTER TABLE public.jobs ADD COLUMN posted_at TIMESTAMP WITH TIME ZONE;