-- =====================================================
-- FIX: handle_new_user input validation
-- Add input validation for full_name from user metadata
-- =====================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    safe_name TEXT;
BEGIN
    -- =================================================================
    -- SECURITY DEFINER FUNCTION - ELEVATED PRIVILEGES
    -- =================================================================
    -- This function runs with elevated privileges because:
    -- 1. It's a trigger on auth.users (managed by Supabase Auth)
    -- 2. Regular users cannot INSERT into profiles/user_roles directly
    --    during signup due to RLS policies
    -- 3. The function only inserts with NEW.id (the actual user ID)
    --    preventing privilege escalation
    --
    -- SECURITY CONTROLS:
    -- - Fixed search_path = public (prevents search path attacks)
    -- - Input validation on user-supplied metadata
    -- - Only inserts into profiles and user_roles tables
    -- - No dynamic SQL or user-controlled table/column names
    -- =================================================================

    -- Validate and sanitize full_name from user metadata
    -- User provides full_name during signup via Supabase Auth
    safe_name := COALESCE(
        NULLIF(TRIM(NEW.raw_user_meta_data ->> 'full_name'), ''),
        'User'
    );
    
    -- Limit length to prevent abuse (max 100 characters)
    IF LENGTH(safe_name) > 100 THEN
        safe_name := SUBSTRING(safe_name, 1, 100);
    END IF;
    
    -- Create profile with validated name
    INSERT INTO public.profiles (user_id, full_name)
    VALUES (NEW.id, safe_name);
    
    -- Assign default 'viewer' role (lowest privilege)
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'viewer');
    
    RETURN NEW;
END;
$$;

-- Add comments to security definer functions for documentation
COMMENT ON FUNCTION public.handle_new_user() IS 
'SECURITY DEFINER: Trigger function for new user signup. 
Creates profile and assigns default viewer role.
Elevated privileges required because RLS prevents direct inserts during signup.
Input validation: full_name is trimmed, defaulted, and limited to 100 chars.';

COMMENT ON FUNCTION public.has_role(_user_id uuid, _role app_role) IS 
'SECURITY DEFINER: Checks if user has specified role.
Used in RLS policies to enforce role-based access.
Elevated privileges required to query user_roles without causing infinite recursion.
Fixed search_path and parameterized query prevent injection attacks.';

COMMENT ON FUNCTION public.get_user_role(_user_id uuid) IS 
'SECURITY DEFINER: Returns user role for authentication context.
Elevated privileges required to bypass RLS when fetching own role.
Fixed search_path and parameterized query prevent injection attacks.';