-- Add max_employee_count field to job_boards table
ALTER TABLE public.job_boards 
ADD COLUMN max_employee_count integer DEFAULT 500;

-- Add comment for clarity
COMMENT ON COLUMN public.job_boards.max_employee_count IS 'Only match jobs from companies with employee count greater than this threshold';