-- Add new pre-search fields to candidates table
ALTER TABLE public.candidates 
ADD COLUMN IF NOT EXISTS search_city TEXT,
ADD COLUMN IF NOT EXISTS search_country TEXT,
ADD COLUMN IF NOT EXISTS search_distance_km INTEGER DEFAULT 50,
ADD COLUMN IF NOT EXISTS is_remote_worker BOOLEAN DEFAULT false;

-- Create a table for dynamic pre-search questions
CREATE TABLE IF NOT EXISTS public.pre_search_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question_label TEXT NOT NULL,
  question_type TEXT NOT NULL DEFAULT 'text', -- text, select, number
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 0,
  options JSONB DEFAULT '[]'::jsonb, -- for select type questions
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Enable RLS on pre_search_questions
ALTER TABLE public.pre_search_questions ENABLE ROW LEVEL SECURITY;

-- Create policies for pre_search_questions
CREATE POLICY "Everyone can view pre_search_questions"
ON public.pre_search_questions
FOR SELECT
USING (true);

CREATE POLICY "Admins can manage pre_search_questions"
ON public.pre_search_questions
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);

-- Create table to store candidate answers to dynamic questions
CREATE TABLE IF NOT EXISTS public.candidate_pre_search_answers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES public.pre_search_questions(id) ON DELETE CASCADE,
  answer_value TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(candidate_id, question_id)
);

-- Enable RLS on candidate_pre_search_answers
ALTER TABLE public.candidate_pre_search_answers ENABLE ROW LEVEL SECURITY;

-- Create policies for candidate_pre_search_answers
CREATE POLICY "Authenticated users can view pre_search_answers"
ON public.candidate_pre_search_answers
FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert pre_search_answers"
ON public.candidate_pre_search_answers
FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update pre_search_answers"
ON public.candidate_pre_search_answers
FOR UPDATE
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can delete pre_search_answers"
ON public.candidate_pre_search_answers
FOR DELETE
USING (auth.uid() IS NOT NULL);

-- Add trigger for updated_at on pre_search_questions
CREATE TRIGGER update_pre_search_questions_updated_at
BEFORE UPDATE ON public.pre_search_questions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add trigger for updated_at on candidate_pre_search_answers
CREATE TRIGGER update_candidate_pre_search_answers_updated_at
BEFORE UPDATE ON public.candidate_pre_search_answers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();