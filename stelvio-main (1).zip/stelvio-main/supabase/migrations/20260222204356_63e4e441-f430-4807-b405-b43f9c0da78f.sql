-- Add block reason fields to stakeholder_campaign_states
ALTER TABLE public.stakeholder_campaign_states
  ADD COLUMN IF NOT EXISTS blocked_reason_code text,
  ADD COLUMN IF NOT EXISTS blocked_reason_text text;

-- Add comment for clarity
COMMENT ON COLUMN public.stakeholder_campaign_states.blocked_reason_code IS 'Canonical block reason code when status=blocked';
COMMENT ON COLUMN public.stakeholder_campaign_states.blocked_reason_text IS 'Human-readable block reason';
