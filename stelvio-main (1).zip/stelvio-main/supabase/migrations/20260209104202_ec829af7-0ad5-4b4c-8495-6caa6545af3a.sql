-- Add send time preference columns to campaigns table
ALTER TABLE public.campaigns 
ADD COLUMN send_time_hour INTEGER CHECK (send_time_hour >= 1 AND send_time_hour <= 12),
ADD COLUMN send_time_minute INTEGER CHECK (send_time_minute >= 0 AND send_time_minute <= 59),
ADD COLUMN send_time_period TEXT CHECK (send_time_period IN ('AM', 'PM'));

-- Add comment for documentation
COMMENT ON COLUMN public.campaigns.send_time_hour IS 'Hour of day to send emails (1-12)';
COMMENT ON COLUMN public.campaigns.send_time_minute IS 'Minute of the hour to send emails (0-59)';
COMMENT ON COLUMN public.campaigns.send_time_period IS 'AM or PM indicator for send time';