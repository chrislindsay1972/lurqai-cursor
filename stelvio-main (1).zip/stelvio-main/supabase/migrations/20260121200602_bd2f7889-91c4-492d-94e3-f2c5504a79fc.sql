-- Add search_keywords column to store AI-extracted keywords from notes
ALTER TABLE public.candidates 
ADD COLUMN IF NOT EXISTS search_keywords TEXT[] DEFAULT NULL;

COMMENT ON COLUMN public.candidates.search_keywords IS 'AI-extracted keywords from search_notes, editable by recruiters';