-- Create issues table with industry-standard fields
CREATE TABLE public.issues (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  priority TEXT NOT NULL DEFAULT 'medium',
  category TEXT NOT NULL DEFAULT 'bug',
  created_by UUID REFERENCES auth.users(id),
  assigned_to UUID REFERENCES auth.users(id),
  resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.issues ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can manage all issues"
  ON public.issues FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view all issues"
  ON public.issues FOR SELECT
  USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can insert issues"
  ON public.issues FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'recruiter'::app_role) AND (created_by IS NULL OR created_by = auth.uid()));

CREATE POLICY "Recruiters can update their own issues"
  ON public.issues FOR UPDATE
  USING (has_role(auth.uid(), 'recruiter'::app_role) AND created_by = auth.uid());

CREATE POLICY "Viewers can view issues"
  ON public.issues FOR SELECT
  USING (has_role(auth.uid(), 'viewer'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_issues_updated_at
  BEFORE UPDATE ON public.issues
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();