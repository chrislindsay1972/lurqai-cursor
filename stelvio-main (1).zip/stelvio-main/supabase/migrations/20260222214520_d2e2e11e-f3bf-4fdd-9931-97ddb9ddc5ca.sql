-- Add attempt_type column to track tier1 vs tier2 enrichment attempts
ALTER TABLE public.stakeholder_enrichment_attempts 
ADD COLUMN attempt_type text NOT NULL DEFAULT 'tier1';

-- Add index for efficient tier2 eligibility queries
CREATE INDEX idx_sea_attempt_type ON public.stakeholder_enrichment_attempts(stakeholder_id, attempt_type, status);
