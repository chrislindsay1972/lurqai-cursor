-- Add company quality signals columns
ALTER TABLE public.companies 
ADD COLUMN IF NOT EXISTS glassdoor_rating numeric,
ADD COLUMN IF NOT EXISTS funding_status text,
ADD COLUMN IF NOT EXISTS recent_news text[],
ADD COLUMN IF NOT EXISTS quality_signals jsonb DEFAULT '{}',
ADD COLUMN IF NOT EXISTS quality_enriched_at timestamp with time zone;

-- Add salary benchmark columns to matches table
ALTER TABLE public.matches
ADD COLUMN IF NOT EXISTS salary_benchmark jsonb,
ADD COLUMN IF NOT EXISTS salary_percentile integer;

-- Add comments for documentation
COMMENT ON COLUMN public.companies.glassdoor_rating IS 'Company rating from Glassdoor (1-5 scale)';
COMMENT ON COLUMN public.companies.funding_status IS 'Recent funding round info (e.g., "Series B - $50M")';
COMMENT ON COLUMN public.companies.recent_news IS 'Array of recent news headlines';
COMMENT ON COLUMN public.companies.quality_signals IS 'JSON object with various quality indicators';
COMMENT ON COLUMN public.matches.salary_benchmark IS 'Market salary data: {min, max, median, source}';
COMMENT ON COLUMN public.matches.salary_percentile IS 'Where this job salary falls in market (0-100)';