-- Add role_variants JSONB column to email_templates
-- Stores body variants keyed by role category: {"c_suite": "...", "hr_talent": "..."}
-- The main body_html serves as the "general" fallback
ALTER TABLE public.email_templates
ADD COLUMN role_variants jsonb DEFAULT NULL;