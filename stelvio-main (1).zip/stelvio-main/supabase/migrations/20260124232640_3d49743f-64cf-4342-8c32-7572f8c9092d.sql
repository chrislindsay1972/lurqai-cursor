-- Drop the existing policy with this exact name and recreate it
DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;

-- Admins can manage (insert/update/delete) all roles - using direct check, not has_role
CREATE POLICY "Admins can manage roles"
ON public.user_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = auth.uid() AND ur.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = auth.uid() AND ur.role = 'admin'
  )
);