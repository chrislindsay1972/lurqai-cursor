-- Add location column to stakeholders table
ALTER TABLE public.stakeholders 
ADD COLUMN IF NOT EXISTS location text;