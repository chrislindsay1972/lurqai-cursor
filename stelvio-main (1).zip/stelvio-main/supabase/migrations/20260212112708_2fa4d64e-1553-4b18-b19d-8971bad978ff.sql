
-- Fix remaining "always true" UPDATE policies on bulk enrichment tables
DROP POLICY IF EXISTS "Service role can update enrichment items" ON public.bulk_enrichment_items;
CREATE POLICY "Recruiters and admins can update enrichment items"
ON public.bulk_enrichment_items FOR UPDATE
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role) OR
  public.has_role(auth.uid(), 'recruiter'::public.app_role)
);

DROP POLICY IF EXISTS "Service role can update enrichment runs" ON public.bulk_enrichment_runs;
CREATE POLICY "Recruiters and admins can update enrichment runs"
ON public.bulk_enrichment_runs FOR UPDATE
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role) OR
  public.has_role(auth.uid(), 'recruiter'::public.app_role)
);
