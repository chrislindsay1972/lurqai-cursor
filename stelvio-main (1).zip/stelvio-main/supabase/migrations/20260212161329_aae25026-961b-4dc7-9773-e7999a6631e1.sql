
-- Remove the overly permissive INSERT policy that allows any recruiter to insert metrics for any campaign
DROP POLICY IF EXISTS "Recruiters and admins can insert metrics" ON public.campaign_metrics;

-- The remaining "Users can insert metrics for their campaigns" policy already properly 
-- restricts inserts to campaign owners and admins, which is the correct behavior.
