-- Add delete policy for email_templates (missing from Phase 1)
CREATE POLICY "Users can delete their templates"
ON public.email_templates
FOR DELETE
USING ((created_by = auth.uid()) OR has_role(auth.uid(), 'admin'::app_role));

-- Add email sending delay setting to app_settings
INSERT INTO public.app_settings (setting_key, setting_value, setting_type, description)
VALUES ('email_send_delay_seconds', '120', 'number', 'Delay in seconds between sending individual campaign emails to avoid spam detection')
ON CONFLICT (setting_key) DO NOTHING;