-- Drop the problematic policy that causes recursion
DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;

-- The existing "Admins can manage roles" policy already uses a direct EXISTS check
-- which is correct. The "Users can view their own role" policy is also fine.
-- We don't need the "Admins can view all roles" policy because:
-- 1. "Admins can manage roles" already covers SELECT for admins (cmd=ALL)
-- 2. "Users can view their own role" covers users viewing their own role