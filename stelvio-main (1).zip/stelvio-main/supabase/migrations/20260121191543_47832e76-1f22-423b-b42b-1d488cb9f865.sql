-- Add template verification tracking
ALTER TABLE public.job_boards 
ADD COLUMN template_verified boolean NOT NULL DEFAULT false,
ADD COLUMN url_pattern text;