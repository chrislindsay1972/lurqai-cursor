
-- ============================================================
-- 1. Stakeholder Enrichment Attempts (flight recorder)
-- ============================================================
CREATE TABLE public.stakeholder_enrichment_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  stakeholder_id uuid NOT NULL REFERENCES public.stakeholders(id) ON DELETE CASCADE,
  company_id uuid REFERENCES public.companies(id) ON DELETE SET NULL,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  status text NOT NULL DEFAULT 'running',  -- running|succeeded|failed|pending_async|needs_review
  final_email text,
  final_email_status text,
  final_source text,
  trace jsonb NOT NULL DEFAULT '[]'::jsonb,
  error text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_enrichment_attempts_stakeholder ON public.stakeholder_enrichment_attempts (stakeholder_id, started_at DESC);
CREATE INDEX idx_enrichment_attempts_status ON public.stakeholder_enrichment_attempts (status, started_at DESC);

ALTER TABLE public.stakeholder_enrichment_attempts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage enrichment attempts"
  ON public.stakeholder_enrichment_attempts FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view enrichment attempts"
  ON public.stakeholder_enrichment_attempts FOR SELECT
  USING (has_role(auth.uid(), 'recruiter'::app_role));

-- ============================================================
-- 2. BetterContact explicit columns on stakeholders
-- ============================================================
ALTER TABLE public.stakeholders
  ADD COLUMN IF NOT EXISTS bettercontact_task_id text,
  ADD COLUMN IF NOT EXISTS bettercontact_submitted_at timestamptz,
  ADD COLUMN IF NOT EXISTS bettercontact_last_polled_at timestamptz,
  ADD COLUMN IF NOT EXISTS bettercontact_status text,  -- pending|done|not_found|error
  ADD COLUMN IF NOT EXISTS email_confidence numeric;

CREATE INDEX idx_stakeholders_bc_status ON public.stakeholders (bettercontact_status) WHERE bettercontact_status IS NOT NULL;

-- ============================================================
-- 3. Domain validation columns on companies
-- ============================================================
ALTER TABLE public.companies
  ADD COLUMN IF NOT EXISTS domain_status text DEFAULT 'pending',  -- pending|resolved|unresolved|low_confidence
  ADD COLUMN IF NOT EXISTS domain_quality_score numeric,
  ADD COLUMN IF NOT EXISTS domain_candidates jsonb DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS domain_quality_reasons jsonb DEFAULT '{}'::jsonb;

-- ============================================================
-- 4. Company Email Intel (per-company pattern cache)
-- ============================================================
CREATE TABLE public.company_email_intel (
  company_id uuid PRIMARY KEY REFERENCES public.companies(id) ON DELETE CASCADE,
  domain text,
  mx_valid boolean,
  pattern text,  -- first.last, flast, etc.
  pattern_confidence numeric,
  examples jsonb DEFAULT '[]'::jsonb,
  sources jsonb DEFAULT '[]'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.company_email_intel ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage email intel"
  ON public.company_email_intel FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view email intel"
  ON public.company_email_intel FOR SELECT
  USING (has_role(auth.uid(), 'recruiter'::app_role));

-- ============================================================
-- 5. Company Domain Aliases (manual overrides + acquisition mapping)
-- ============================================================
CREATE TABLE public.company_domain_aliases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name_alias text NOT NULL,
  domain text NOT NULL,
  confidence numeric NOT NULL DEFAULT 0.9,
  locked boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX idx_domain_aliases_name ON public.company_domain_aliases (lower(company_name_alias));

ALTER TABLE public.company_domain_aliases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage domain aliases"
  ON public.company_domain_aliases FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view domain aliases"
  ON public.company_domain_aliases FOR SELECT
  USING (has_role(auth.uid(), 'recruiter'::app_role));
