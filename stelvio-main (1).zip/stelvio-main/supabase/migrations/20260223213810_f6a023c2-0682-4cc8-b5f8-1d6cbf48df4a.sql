
-- Prevent duplicate jobs by source_url
CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_source_url_unique 
ON public.jobs (source_url) 
WHERE source_url IS NOT NULL;

-- Prevent duplicate companies by domain (case-insensitive)
CREATE UNIQUE INDEX IF NOT EXISTS idx_companies_domain_unique 
ON public.companies (lower(domain)) 
WHERE domain IS NOT NULL;

-- Prevent duplicate companies by name (case-insensitive) when domain is null
CREATE UNIQUE INDEX IF NOT EXISTS idx_companies_name_no_domain_unique 
ON public.companies (lower(name)) 
WHERE domain IS NULL;
