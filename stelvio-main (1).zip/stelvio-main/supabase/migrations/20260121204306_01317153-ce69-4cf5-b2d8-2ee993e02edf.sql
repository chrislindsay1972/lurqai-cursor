-- Create app_settings table to store configurable settings
CREATE TABLE public.app_settings (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    setting_key TEXT NOT NULL UNIQUE,
    setting_value TEXT NOT NULL,
    setting_type TEXT NOT NULL DEFAULT 'string',
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- Admin and recruiter can read settings
CREATE POLICY "Authenticated users can view settings"
ON public.app_settings
FOR SELECT
USING (auth.role() = 'authenticated');

-- Only admins can modify settings
CREATE POLICY "Admins can manage settings"
ON public.app_settings
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create trigger for updated_at
CREATE TRIGGER update_app_settings_updated_at
BEFORE UPDATE ON public.app_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default match threshold (85%)
INSERT INTO public.app_settings (setting_key, setting_value, setting_type, description)
VALUES ('match_threshold_percent', '85', 'number', 'Minimum match score percentage required for jobs to be saved. Default is 85%.');

-- Insert new AI instruction for board selection
INSERT INTO public.ai_instructions (instruction_key, instruction_name, instruction_prompt, description)
VALUES (
    'job_board_selection',
    'Job Board Selection',
    'You are a recruitment expert. Given a candidate''s skills and job preferences, select the TOP 10 most relevant job boards from the available list.

Candidate Skills: {{candidate_skills}}
{{#candidate_title}}Current Role: {{candidate_title}}{{/candidate_title}}
{{#candidate_location}}Location: {{candidate_location}}{{/candidate_location}}

Available Job Boards (format: name|domain):
{{available_boards}}

SELECTION CRITERIA:
- Industry relevance: Tech boards for developers, healthcare boards for medical roles, etc.
- Geographic coverage: Prioritize boards that serve the candidate''s location/region
- Job level: Senior roles may do better on specialized boards
- Board reliability: Consider well-known boards with good job listings

Return ONLY a JSON array of the top 10 board names (the name before the | separator), ordered by relevance:
["Board Name 1", "Board Name 2", "Board Name 3", ...]

If fewer than 10 boards are available or relevant, return only those that match.
Return only the JSON array, no other text.',
    'Prompt used by AI to dynamically select the most relevant job boards based on candidate skills and preferences. Uses {{candidate_skills}}, {{candidate_title}}, {{candidate_location}}, and {{available_boards}} placeholders.'
);