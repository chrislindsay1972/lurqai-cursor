-- ============================================================
-- 1. system_alerts table for drift detection
-- ============================================================
CREATE TABLE public.system_alerts (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  alert_type text NOT NULL,
  severity text NOT NULL DEFAULT 'warning',
  message text NOT NULL,
  metric_name text,
  metric_value numeric,
  threshold numeric,
  resolved boolean NOT NULL DEFAULT false,
  resolved_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.system_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage system alerts"
  ON public.system_alerts FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view system alerts"
  ON public.system_alerts FOR SELECT
  USING (has_role(auth.uid(), 'recruiter'::app_role));

-- Index for quick queries
CREATE INDEX idx_system_alerts_unresolved ON public.system_alerts (resolved, created_at DESC)
  WHERE resolved = false;

-- ============================================================
-- 2. Validation trigger: prevent enrichment_source=bettercontact_pending when email is set
-- (Using trigger instead of CHECK constraint for flexibility)
-- ============================================================
CREATE OR REPLACE FUNCTION public.validate_stakeholder_enrichment()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  -- Prevent "enriched" appearance while still pending
  IF NEW.enrichment_source = 'bettercontact_pending' AND NEW.email IS NOT NULL THEN
    RAISE EXCEPTION 'Cannot set email while enrichment_source is bettercontact_pending';
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_stakeholder_enrichment
  BEFORE INSERT OR UPDATE ON public.stakeholders
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_stakeholder_enrichment();

-- ============================================================
-- 3. Validation trigger: prevent domain_status=resolved without adequate quality score
-- ============================================================
CREATE OR REPLACE FUNCTION public.validate_company_domain()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.domain_status = 'resolved' AND (NEW.domain_quality_score IS NULL OR NEW.domain_quality_score < 0.70) THEN
    RAISE EXCEPTION 'Cannot set domain_status=resolved without domain_quality_score >= 0.70';
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_company_domain
  BEFORE INSERT OR UPDATE ON public.companies
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_company_domain();

-- ============================================================
-- 4. Drift detection function (called by cron daily)
-- ============================================================
CREATE OR REPLACE FUNCTION public.check_enrichment_drift()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total_sh int;
  v_with_email int;
  v_coverage numeric;
  v_bc_stale_30m int;
  v_bc_stale_24h int;
  v_total_co int;
  v_unresolved_co int;
  v_unresolved_rate numeric;
BEGIN
  -- Email coverage
  SELECT count(*) INTO v_total_sh FROM stakeholders;
  SELECT count(*) INTO v_with_email FROM stakeholders WHERE email IS NOT NULL;
  v_coverage := CASE WHEN v_total_sh > 0 THEN (v_with_email::numeric / v_total_sh) * 100 ELSE 0 END;

  -- BetterContact stale
  SELECT count(*) INTO v_bc_stale_30m
  FROM stakeholders
  WHERE bettercontact_status = 'pending'
    AND bettercontact_submitted_at < now() - interval '30 minutes';

  SELECT count(*) INTO v_bc_stale_24h
  FROM stakeholders
  WHERE bettercontact_status = 'pending'
    AND bettercontact_submitted_at < now() - interval '24 hours';

  -- Domain unresolved
  SELECT count(*) INTO v_total_co FROM companies;
  SELECT count(*) INTO v_unresolved_co FROM companies WHERE domain_status = 'unresolved';
  v_unresolved_rate := CASE WHEN v_total_co > 0 THEN (v_unresolved_co::numeric / v_total_co) * 100 ELSE 0 END;

  -- Insert alerts for threshold breaches (auto-resolve old ones first)
  UPDATE system_alerts SET resolved = true, resolved_at = now()
  WHERE resolved = false AND created_at < now() - interval '1 day';

  -- BC stale > 30m: alert if count > 5
  IF v_bc_stale_30m > 5 THEN
    INSERT INTO system_alerts (alert_type, severity, message, metric_name, metric_value, threshold)
    VALUES ('bc_stale_30m', 'warning',
      format('%s BetterContact tasks pending > 30 minutes', v_bc_stale_30m),
      'bc_stale_30m_count', v_bc_stale_30m, 5);
  END IF;

  -- BC stale > 24h: critical
  IF v_bc_stale_24h > 0 THEN
    INSERT INTO system_alerts (alert_type, severity, message, metric_name, metric_value, threshold)
    VALUES ('bc_stale_24h', 'critical',
      format('%s BetterContact tasks pending > 24 hours', v_bc_stale_24h),
      'bc_stale_24h_count', v_bc_stale_24h, 0);
  END IF;

  -- Domain unresolved rate > 20%
  IF v_unresolved_rate > 20 THEN
    INSERT INTO system_alerts (alert_type, severity, message, metric_name, metric_value, threshold)
    VALUES ('domain_unresolved_rate', 'warning',
      format('Domain unresolved rate is %.1f%% (%s/%s companies)', v_unresolved_rate, v_unresolved_co, v_total_co),
      'domain_unresolved_rate', v_unresolved_rate, 20);
  END IF;

  -- Email coverage drop below 50%
  IF v_coverage < 50 AND v_total_sh > 10 THEN
    INSERT INTO system_alerts (alert_type, severity, message, metric_name, metric_value, threshold)
    VALUES ('low_email_coverage', 'warning',
      format('Email coverage is %.1f%% (%s/%s stakeholders)', v_coverage, v_with_email, v_total_sh),
      'email_coverage_pct', v_coverage, 50);
  END IF;
END;
$$;