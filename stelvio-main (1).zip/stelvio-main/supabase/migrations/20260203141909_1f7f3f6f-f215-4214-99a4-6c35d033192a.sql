-- Add module column to issues table
ALTER TABLE public.issues 
ADD COLUMN module text;