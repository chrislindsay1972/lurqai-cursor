-- Add role_tags column to job_boards for role-based filtering
ALTER TABLE public.job_boards ADD COLUMN IF NOT EXISTS role_tags text[] DEFAULT '{}';

-- Add comment for documentation
COMMENT ON COLUMN public.job_boards.role_tags IS 'Role category tags for filtering boards by candidate role type. E.g. engineering, design, sales, healthcare';
