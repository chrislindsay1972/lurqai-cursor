-- Add pre-search questions columns to candidates table
ALTER TABLE public.candidates
ADD COLUMN IF NOT EXISTS desired_location TEXT,
ADD COLUMN IF NOT EXISTS desired_salary TEXT,
ADD COLUMN IF NOT EXISTS reason_for_looking TEXT,
ADD COLUMN IF NOT EXISTS sponsorship_requirements TEXT,
ADD COLUMN IF NOT EXISTS education TEXT,
ADD COLUMN IF NOT EXISTS certifications TEXT,
ADD COLUMN IF NOT EXISTS pre_search_completed BOOLEAN DEFAULT false;