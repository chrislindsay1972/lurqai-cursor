-- Add new fields for comprehensive AI candidate profiling
ALTER TABLE public.candidates 
ADD COLUMN IF NOT EXISTS ai_summary TEXT,
ADD COLUMN IF NOT EXISTS career_highlights TEXT[],
ADD COLUMN IF NOT EXISTS ideal_role TEXT,
ADD COLUMN IF NOT EXISTS ideal_company_size TEXT,
ADD COLUMN IF NOT EXISTS work_style_preference TEXT,
ADD COLUMN IF NOT EXISTS industries_of_interest TEXT[],
ADD COLUMN IF NOT EXISTS salary_expectation TEXT,
ADD COLUMN IF NOT EXISTS notice_period TEXT,
ADD COLUMN IF NOT EXISTS relocation_willingness TEXT,
ADD COLUMN IF NOT EXISTS languages TEXT[],
ADD COLUMN IF NOT EXISTS soft_skills TEXT[],
ADD COLUMN IF NOT EXISTS technical_proficiency JSONB,
ADD COLUMN IF NOT EXISTS career_goals TEXT,
ADD COLUMN IF NOT EXISTS parsed_at TIMESTAMP WITH TIME ZONE;

-- Add comments for documentation
COMMENT ON COLUMN public.candidates.ai_summary IS 'AI-generated comprehensive candidate profile narrative';
COMMENT ON COLUMN public.candidates.career_highlights IS 'Key achievements and career milestones';
COMMENT ON COLUMN public.candidates.ideal_role IS 'Target job title/role based on career trajectory';
COMMENT ON COLUMN public.candidates.ideal_company_size IS 'Preferred company size (startup, mid-size, enterprise)';
COMMENT ON COLUMN public.candidates.work_style_preference IS 'Remote, hybrid, on-site preference';
COMMENT ON COLUMN public.candidates.industries_of_interest IS 'Industries candidate is interested in';
COMMENT ON COLUMN public.candidates.soft_skills IS 'Interpersonal and leadership skills';
COMMENT ON COLUMN public.candidates.technical_proficiency IS 'Skills with proficiency levels (e.g., {"Python": "expert", "React": "intermediate"})';
COMMENT ON COLUMN public.candidates.career_goals IS 'What the candidate is looking for in their next role';