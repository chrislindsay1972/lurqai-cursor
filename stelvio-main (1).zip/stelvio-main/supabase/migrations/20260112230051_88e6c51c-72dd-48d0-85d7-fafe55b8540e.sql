-- Enable realtime for matches table so job search progress can be shown live
ALTER PUBLICATION supabase_realtime ADD TABLE public.matches;