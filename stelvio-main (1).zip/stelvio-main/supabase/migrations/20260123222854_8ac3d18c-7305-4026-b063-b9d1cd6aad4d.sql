-- Create job board performance tracking table
CREATE TABLE public.job_board_performance (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  job_board_id UUID NOT NULL REFERENCES public.job_boards(id) ON DELETE CASCADE,
  search_date DATE NOT NULL DEFAULT CURRENT_DATE,
  searches_performed INTEGER NOT NULL DEFAULT 0,
  jobs_found INTEGER NOT NULL DEFAULT 0,
  jobs_matched INTEGER NOT NULL DEFAULT 0,
  jobs_saved INTEGER NOT NULL DEFAULT 0,
  avg_match_score NUMERIC(5,2) DEFAULT NULL,
  success_rate NUMERIC(5,2) GENERATED ALWAYS AS (
    CASE WHEN jobs_found > 0 THEN (jobs_matched::NUMERIC / jobs_found::NUMERIC) * 100 ELSE 0 END
  ) STORED,
  conversion_rate NUMERIC(5,2) GENERATED ALWAYS AS (
    CASE WHEN jobs_found > 0 THEN (jobs_saved::NUMERIC / jobs_found::NUMERIC) * 100 ELSE 0 END
  ) STORED,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(job_board_id, search_date)
);

-- Create indexes for efficient querying
CREATE INDEX idx_job_board_performance_board_id ON public.job_board_performance(job_board_id);
CREATE INDEX idx_job_board_performance_date ON public.job_board_performance(search_date DESC);

-- Add lifetime performance columns to job_boards table for quick access
ALTER TABLE public.job_boards 
ADD COLUMN IF NOT EXISTS total_searches INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_jobs_found INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_jobs_matched INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_jobs_saved INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS lifetime_success_rate NUMERIC(5,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS lifetime_conversion_rate NUMERIC(5,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS performance_score INTEGER DEFAULT 50,
ADD COLUMN IF NOT EXISTS last_successful_search TIMESTAMP WITH TIME ZONE DEFAULT NULL;

-- Enable RLS
ALTER TABLE public.job_board_performance ENABLE ROW LEVEL SECURITY;

-- Policies for job_board_performance
CREATE POLICY "Authenticated users can view job board performance" 
ON public.job_board_performance 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Recruiters and admins can insert job board performance" 
ON public.job_board_performance 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('recruiter', 'admin')
  )
);

CREATE POLICY "Recruiters and admins can update job board performance" 
ON public.job_board_performance 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('recruiter', 'admin')
  )
);

-- Function to update job board lifetime stats
CREATE OR REPLACE FUNCTION public.update_job_board_lifetime_stats(board_id UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  stats RECORD;
BEGIN
  -- Aggregate all-time stats from performance table
  SELECT 
    COALESCE(SUM(searches_performed), 0) as total_searches,
    COALESCE(SUM(jobs_found), 0) as total_jobs_found,
    COALESCE(SUM(jobs_matched), 0) as total_jobs_matched,
    COALESCE(SUM(jobs_saved), 0) as total_jobs_saved,
    CASE 
      WHEN COALESCE(SUM(jobs_found), 0) > 0 
      THEN (COALESCE(SUM(jobs_matched), 0)::NUMERIC / COALESCE(SUM(jobs_found), 0)::NUMERIC) * 100 
      ELSE 0 
    END as success_rate,
    CASE 
      WHEN COALESCE(SUM(jobs_found), 0) > 0 
      THEN (COALESCE(SUM(jobs_saved), 0)::NUMERIC / COALESCE(SUM(jobs_found), 0)::NUMERIC) * 100 
      ELSE 0 
    END as conversion_rate,
    MAX(CASE WHEN jobs_found > 0 THEN search_date END) as last_success
  INTO stats
  FROM public.job_board_performance
  WHERE job_board_id = board_id;
  
  -- Calculate performance score (0-100) based on multiple factors
  -- Score = (success_rate * 0.4) + (conversion_rate * 0.4) + (recency_bonus * 0.2)
  DECLARE
    recency_bonus NUMERIC := 0;
    performance_score_calc INTEGER := 50;
  BEGIN
    -- Recency bonus: 100 if searched in last 7 days, decreasing to 0 after 30 days
    IF stats.last_success IS NOT NULL THEN
      IF stats.last_success >= CURRENT_DATE - INTERVAL '7 days' THEN
        recency_bonus := 100;
      ELSIF stats.last_success >= CURRENT_DATE - INTERVAL '30 days' THEN
        recency_bonus := 50;
      ELSE
        recency_bonus := 0;
      END IF;
    END IF;
    
    -- Calculate overall score
    IF stats.total_searches > 0 THEN
      performance_score_calc := LEAST(100, GREATEST(0, 
        (stats.success_rate * 0.4) + 
        (stats.conversion_rate * 0.4) + 
        (recency_bonus * 0.2)
      ))::INTEGER;
    END IF;
    
    -- Update the job_boards table
    UPDATE public.job_boards
    SET 
      total_searches = stats.total_searches,
      total_jobs_found = stats.total_jobs_found,
      total_jobs_matched = stats.total_jobs_matched,
      total_jobs_saved = stats.total_jobs_saved,
      lifetime_success_rate = ROUND(stats.success_rate, 2),
      lifetime_conversion_rate = ROUND(stats.conversion_rate, 2),
      performance_score = performance_score_calc,
      last_successful_search = stats.last_success,
      updated_at = now()
    WHERE id = board_id;
  END;
END;
$$;

-- Trigger to automatically update lifetime stats when performance is recorded
CREATE OR REPLACE FUNCTION public.trigger_update_board_stats()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM public.update_job_board_lifetime_stats(NEW.job_board_id);
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_board_stats_on_performance
AFTER INSERT OR UPDATE ON public.job_board_performance
FOR EACH ROW
EXECUTE FUNCTION public.trigger_update_board_stats();

-- Add updated_at trigger
CREATE TRIGGER update_job_board_performance_updated_at
BEFORE UPDATE ON public.job_board_performance
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();