-- Create job_boards table
CREATE TABLE public.job_boards (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    url TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.job_boards ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can view all job_boards"
ON public.job_boards FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own job_boards"
ON public.job_boards FOR SELECT
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert job_boards"
ON public.job_boards FOR INSERT
WITH CHECK ((has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role)) AND ((created_by IS NULL) OR (created_by = auth.uid())));

CREATE POLICY "Admins can update all job_boards"
ON public.job_boards FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can update own job_boards"
ON public.job_boards FOR UPDATE
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Admins can delete job_boards"
ON public.job_boards FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_job_boards_updated_at
BEFORE UPDATE ON public.job_boards
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();