-- Create pipeline events table for realtime progress updates
CREATE TABLE IF NOT EXISTS public.pipeline_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL,
  created_by uuid NOT NULL,
  event_type text NOT NULL DEFAULT 'info',
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pipeline_events_candidate_created_at
  ON public.pipeline_events (candidate_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_pipeline_events_created_by
  ON public.pipeline_events (created_by);

ALTER TABLE public.pipeline_events ENABLE ROW LEVEL SECURITY;

-- RLS: users can read/write their own events
DO $$ BEGIN
  CREATE POLICY "Users can view their own pipeline events"
  ON public.pipeline_events
  FOR SELECT
  USING (auth.uid() = created_by);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "Users can insert their own pipeline events"
  ON public.pipeline_events
  FOR INSERT
  WITH CHECK (auth.uid() = created_by);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Enable realtime on this table
DO $$
BEGIN
  EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.pipeline_events';
EXCEPTION
  WHEN duplicate_object THEN NULL;
  WHEN undefined_object THEN NULL;
END
$$;