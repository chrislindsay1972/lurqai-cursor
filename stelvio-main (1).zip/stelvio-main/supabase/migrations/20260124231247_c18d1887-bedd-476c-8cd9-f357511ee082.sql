-- Fix circular dependency: user_roles RLS uses has_role which queries user_roles
-- Solution 1: Add a simple self-viewing policy to user_roles that doesn't use has_role

-- First, let's check and ensure the has_role function bypasses RLS properly
CREATE OR REPLACE FUNCTION public.has_role(_role app_role, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.user_roles
        WHERE user_id = _user_id
          AND role = _role
    )
$$;