-- Fix overly permissive RLS on candidate_pre_search_answers
-- Drop the existing overly permissive policies that allow any authenticated user access
DROP POLICY IF EXISTS "Authenticated users can view pre_search_answers" ON public.candidate_pre_search_answers;
DROP POLICY IF EXISTS "Authenticated users can insert pre_search_answers" ON public.candidate_pre_search_answers;
DROP POLICY IF EXISTS "Authenticated users can update pre_search_answers" ON public.candidate_pre_search_answers;
DROP POLICY IF EXISTS "Authenticated users can delete pre_search_answers" ON public.candidate_pre_search_answers;

-- Create proper role-based policies (admins and recruiters only)
CREATE POLICY "Admins can manage all pre_search_answers"
ON public.candidate_pre_search_answers
FOR ALL
USING (public.has_role('admin', auth.uid()))
WITH CHECK (public.has_role('admin', auth.uid()));

CREATE POLICY "Recruiters can manage pre_search_answers for their candidates"
ON public.candidate_pre_search_answers
FOR ALL
USING (
  public.has_role('recruiter', auth.uid())
  AND EXISTS (
    SELECT 1 FROM public.candidates c
    WHERE c.id = public.candidate_pre_search_answers.candidate_id
      AND c.created_by = auth.uid()
  )
)
WITH CHECK (
  public.has_role('recruiter', auth.uid())
  AND EXISTS (
    SELECT 1 FROM public.candidates c
    WHERE c.id = public.candidate_pre_search_answers.candidate_id
      AND c.created_by = auth.uid()
  )
);