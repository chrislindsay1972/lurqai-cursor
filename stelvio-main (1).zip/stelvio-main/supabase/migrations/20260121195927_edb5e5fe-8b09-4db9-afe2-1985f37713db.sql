-- Add search_notes column to candidates for pre-search notes
ALTER TABLE public.candidates 
ADD COLUMN IF NOT EXISTS search_notes TEXT DEFAULT NULL;

-- Add comment explaining the field
COMMENT ON COLUMN public.candidates.search_notes IS 'Free-form notes entered during pre-search questions, used by AI to refine job matching';