
-- Table to track bulk enrichment runs
CREATE TABLE public.bulk_enrichment_runs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'running',
  total INTEGER NOT NULL DEFAULT 0,
  completed INTEGER NOT NULL DEFAULT 0,
  succeeded INTEGER NOT NULL DEFAULT 0,
  failed INTEGER NOT NULL DEFAULT 0,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Table to track per-company progress within a run
CREATE TABLE public.bulk_enrichment_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  run_id UUID NOT NULL REFERENCES public.bulk_enrichment_runs(id) ON DELETE CASCADE,
  company_id UUID NOT NULL,
  company_name TEXT NOT NULL,
  domain_status TEXT NOT NULL DEFAULT 'pending',
  enrich_status TEXT NOT NULL DEFAULT 'pending',
  stakeholder_status TEXT NOT NULL DEFAULT 'pending',
  domain TEXT,
  stakeholders_found INTEGER,
  error TEXT,
  processing_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.bulk_enrichment_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bulk_enrichment_items ENABLE ROW LEVEL SECURITY;

-- RLS: Recruiters and admins can read/create runs
CREATE POLICY "Authenticated users can view enrichment runs"
  ON public.bulk_enrichment_runs FOR SELECT
  USING (public.has_role(auth.uid(), 'recruiter') OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated users can create enrichment runs"
  ON public.bulk_enrichment_runs FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'recruiter') OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Service role can update enrichment runs"
  ON public.bulk_enrichment_runs FOR UPDATE
  USING (true);

CREATE POLICY "Authenticated users can view enrichment items"
  ON public.bulk_enrichment_items FOR SELECT
  USING (public.has_role(auth.uid(), 'recruiter') OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated users can create enrichment items"
  ON public.bulk_enrichment_items FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'recruiter') OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Service role can update enrichment items"
  ON public.bulk_enrichment_items FOR UPDATE
  USING (true);

-- Enable realtime for both tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.bulk_enrichment_runs;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bulk_enrichment_items;

-- Timestamps trigger
CREATE TRIGGER update_bulk_enrichment_runs_updated_at
  BEFORE UPDATE ON public.bulk_enrichment_runs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_bulk_enrichment_items_updated_at
  BEFORE UPDATE ON public.bulk_enrichment_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
