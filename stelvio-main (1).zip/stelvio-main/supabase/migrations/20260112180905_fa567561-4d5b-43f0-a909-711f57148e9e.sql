-- Create a table to store module access permissions per role
CREATE TABLE public.role_module_permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role TEXT NOT NULL,
    module TEXT NOT NULL,
    has_access BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (role, module)
);

-- Enable RLS
ALTER TABLE public.role_module_permissions ENABLE ROW LEVEL SECURITY;

-- Only admins can view permissions
CREATE POLICY "Admins can view all permissions"
ON public.role_module_permissions
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can insert permissions
CREATE POLICY "Admins can insert permissions"
ON public.role_module_permissions
FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can update permissions
CREATE POLICY "Admins can update permissions"
ON public.role_module_permissions
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can delete permissions
CREATE POLICY "Admins can delete permissions"
ON public.role_module_permissions
FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));

-- Create updated_at trigger
CREATE TRIGGER update_role_module_permissions_updated_at
BEFORE UPDATE ON public.role_module_permissions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default permissions (all roles have access to all modules by default)
INSERT INTO public.role_module_permissions (role, module, has_access) VALUES
('admin', 'dashboard', true),
('admin', 'candidates', true),
('admin', 'jobs', true),
('admin', 'companies', true),
('admin', 'stakeholders', true),
('admin', 'job_boards', true),
('admin', 'communications', true),
('admin', 'settings', true),
('recruiter', 'dashboard', true),
('recruiter', 'candidates', true),
('recruiter', 'jobs', true),
('recruiter', 'companies', true),
('recruiter', 'stakeholders', true),
('recruiter', 'job_boards', true),
('recruiter', 'communications', true),
('recruiter', 'settings', false),
('viewer', 'dashboard', true),
('viewer', 'candidates', true),
('viewer', 'jobs', true),
('viewer', 'companies', true),
('viewer', 'stakeholders', true),
('viewer', 'job_boards', true),
('viewer', 'communications', false),
('viewer', 'settings', false);