-- Add DELETE policy for campaign_steps table
CREATE POLICY "Users can delete steps in their campaigns"
ON public.campaign_steps
FOR DELETE
USING (
  campaign_id IN (
    SELECT campaigns.id
    FROM campaigns
    WHERE campaigns.created_by = auth.uid() OR has_role(auth.uid(), 'admin'::app_role)
  )
);