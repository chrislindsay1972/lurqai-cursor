-- Create table for stakeholder targeting rules
CREATE TABLE public.stakeholder_targeting_rules (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    min_employees INTEGER NOT NULL DEFAULT 1,
    max_employees INTEGER,
    target_titles TEXT[] NOT NULL DEFAULT '{}',
    display_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    created_by UUID
);

-- Enable RLS
ALTER TABLE public.stakeholder_targeting_rules ENABLE ROW LEVEL SECURITY;

-- RLS Policies - Admins can manage, others can view
CREATE POLICY "Admins can manage targeting rules"
ON public.stakeholder_targeting_rules
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view targeting rules"
ON public.stakeholder_targeting_rules
FOR SELECT
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Viewers can view targeting rules"
ON public.stakeholder_targeting_rules
FOR SELECT
USING (has_role(auth.uid(), 'viewer'::app_role));

-- Add updated_at trigger
CREATE TRIGGER update_stakeholder_targeting_rules_updated_at
BEFORE UPDATE ON public.stakeholder_targeting_rules
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default rules
INSERT INTO public.stakeholder_targeting_rules (min_employees, max_employees, target_titles, display_order) VALUES
(1, 50, ARRAY['Founder', 'CEO', 'CTO'], 0),
(51, 200, ARRAY['HR Director', 'Head of Engineering'], 1),
(201, 500, ARRAY['VP of Talent', 'Engineering Director'], 2),
(501, NULL, ARRAY['Talent Acquisition Manager', 'Senior Recruiter'], 3);