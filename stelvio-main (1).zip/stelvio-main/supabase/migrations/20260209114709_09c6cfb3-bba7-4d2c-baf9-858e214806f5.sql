-- Restrict upload to recruiters/admins
CREATE POLICY "Recruiters and admins can upload assets"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'assets' AND
  (public.has_role(auth.uid(), 'admin'::public.app_role) OR 
   public.has_role(auth.uid(), 'recruiter'::public.app_role))
);

-- Only owner or admin can update
CREATE POLICY "Users can update own assets"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'assets' AND
  (owner_id::text = auth.uid()::text OR public.has_role(auth.uid(), 'admin'::public.app_role))
);

-- Only owner or admin can delete
CREATE POLICY "Users can delete own assets"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'assets' AND
  (owner_id::text = auth.uid()::text OR public.has_role(auth.uid(), 'admin'::public.app_role))
);