-- Add AI instruction for stakeholder identification
INSERT INTO public.ai_instructions (
  instruction_key,
  instruction_name,
  instruction_prompt,
  description
) VALUES (
  'stakeholder_identification',
  'Stakeholder Identification',
  'Analyze this company to identify the 2 best decision-makers to contact regarding the job role.

COMPANY INFORMATION:
- Name: {{company_name}}
- Domain: {{company_domain}}
- Employee Count: {{employee_count}}
- Industry: {{industry}}
- LinkedIn URL: {{linkedin_url}}

JOB CONTEXT:
- Job Title: {{job_title}}
- Job Description: {{job_description}}

ANALYSIS CRITERIA:
1. Company Size Assessment:
   - Small (1-50 employees): Target Owner, CEO, Founder, or direct department head
   - Medium (51-200 employees): Target HR Manager, Department Director, or VP
   - Large (200+ employees): Target Talent Acquisition Manager, HR Director, or Recruiting Lead

2. Role Relevance:
   - Consider who would be the hiring manager for this specific role
   - Technical roles: May need Engineering Manager or CTO alongside HR
   - Sales roles: Sales Director or VP Sales alongside HR
   - General roles: HR Director or People Operations

3. Decision-Making Authority:
   - Prioritize those with hiring authority for the specific role
   - Consider budget holders and final decision makers

Return JSON array of exactly 2 contacts with format:
[
  {
    "first_name": "likely first name or common name for title",
    "last_name": "likely last name based on research",
    "title": "Job Title",
    "reasoning": "Why this person is ideal to contact"
  }
]

If company is very small (<10 employees), only return 1 contact (the founder/CEO).
Only return valid JSON array, no other text.',
  'AI-powered analysis of company metrics to identify the best decision-makers based on company size, industry, and the specific job role being recruited for.'
) ON CONFLICT (instruction_key) DO UPDATE SET
  instruction_name = EXCLUDED.instruction_name,
  instruction_prompt = EXCLUDED.instruction_prompt,
  description = EXCLUDED.description,
  updated_at = now();