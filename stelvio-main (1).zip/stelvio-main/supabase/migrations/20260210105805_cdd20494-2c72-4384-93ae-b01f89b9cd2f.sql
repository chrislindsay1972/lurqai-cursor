
-- Extend campaigns table for candidate engagement
ALTER TABLE public.campaigns
  ADD COLUMN IF NOT EXISTS campaign_type TEXT DEFAULT 'standard',
  ADD COLUMN IF NOT EXISTS candidate_id UUID REFERENCES public.candidates(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS start_date DATE,
  ADD COLUMN IF NOT EXISTS end_date DATE,
  ADD COLUMN IF NOT EXISTS ai_profile_id UUID,
  ADD COLUMN IF NOT EXISTS rules_json JSONB DEFAULT '{}';

-- Create AI Profiles table for reusable instruction sets
CREATE TABLE IF NOT EXISTS public.ai_profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_name TEXT NOT NULL,
  base_instruction TEXT NOT NULL DEFAULT 'Write an x-day follow-up email sequence for a recruitment consultant. Audience: candidate/prospect. Objective: encourage a reply and/or book a call with the consultant. Keep emails short, skimmable, and personalized using available candidate context. Each email must have one primary CTA and one optional soft CTA. Respect tone settings and locale spelling rules. Do not fabricate details; if missing info, write generically. Include an opt-out line like: "If now isn''t the right time, reply ''stop'' and I won''t follow up."',
  tone_tags TEXT[] DEFAULT '{}',
  language_style TEXT DEFAULT 'UK',
  voice TEXT DEFAULT 'Professional',
  primary_cta TEXT DEFAULT 'Book a call',
  secondary_cta TEXT,
  disallowed_phrases TEXT[] DEFAULT '{}',
  compliance_rules JSONB DEFAULT '{}',
  created_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.ai_profiles ENABLE ROW LEVEL SECURITY;

-- RLS policies for ai_profiles (authenticated users can read/write)
CREATE POLICY "Authenticated users can view ai_profiles"
  ON public.ai_profiles FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert ai_profiles"
  ON public.ai_profiles FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update ai_profiles"
  ON public.ai_profiles FOR UPDATE
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can delete ai_profiles"
  ON public.ai_profiles FOR DELETE
  USING (auth.uid() IS NOT NULL);

-- Add FK constraint for ai_profile_id on campaigns
ALTER TABLE public.campaigns
  ADD CONSTRAINT campaigns_ai_profile_id_fkey
  FOREIGN KEY (ai_profile_id) REFERENCES public.ai_profiles(id) ON DELETE SET NULL;

-- Add updated_at trigger for ai_profiles
CREATE TRIGGER update_ai_profiles_updated_at
  BEFORE UPDATE ON public.ai_profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert a default AI profile
INSERT INTO public.ai_profiles (profile_name, tone_tags, language_style, voice, primary_cta)
VALUES (
  'Standard — Warm Consultative',
  ARRAY['concise', 'confident', 'consultative'],
  'UK',
  'Professional',
  'Book a call'
);
