-- Create deleted_records table for recycle bin functionality
CREATE TABLE public.deleted_records (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    entity_type TEXT NOT NULL,
    entity_id UUID NOT NULL,
    entity_data JSONB NOT NULL,
    deleted_by UUID NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + INTERVAL '30 days'),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster lookups
CREATE INDEX idx_deleted_records_entity_type ON public.deleted_records(entity_type);
CREATE INDEX idx_deleted_records_deleted_by ON public.deleted_records(deleted_by);
CREATE INDEX idx_deleted_records_expires_at ON public.deleted_records(expires_at);

-- Enable RLS
ALTER TABLE public.deleted_records ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Users can manage their own deleted records
CREATE POLICY "Users can view their own deleted records"
ON public.deleted_records
FOR SELECT
USING (auth.uid() = deleted_by);

CREATE POLICY "Users can insert their own deleted records"
ON public.deleted_records
FOR INSERT
WITH CHECK (auth.uid() = deleted_by);

CREATE POLICY "Users can delete their own deleted records"
ON public.deleted_records
FOR DELETE
USING (auth.uid() = deleted_by);

-- Admins can manage all deleted records
CREATE POLICY "Admins can view all deleted records"
ON public.deleted_records
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete all deleted records"
ON public.deleted_records
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create function to auto-purge expired records (can be called by a cron job or edge function)
CREATE OR REPLACE FUNCTION public.purge_expired_deleted_records()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM public.deleted_records
    WHERE expires_at < now();
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$;