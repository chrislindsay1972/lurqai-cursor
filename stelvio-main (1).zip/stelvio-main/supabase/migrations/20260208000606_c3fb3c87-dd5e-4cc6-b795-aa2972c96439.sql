-- =====================================================
-- FIX OVERLY PERMISSIVE RLS POLICIES
-- =====================================================

-- Drop the overly permissive policies
DROP POLICY IF EXISTS "System can insert/update campaign states" ON public.stakeholder_campaign_states;
DROP POLICY IF EXISTS "System can update campaign states" ON public.stakeholder_campaign_states;
DROP POLICY IF EXISTS "System can insert metrics" ON public.campaign_metrics;
DROP POLICY IF EXISTS "System can insert opt-out records" ON public.opt_out_records;

-- Recreate with proper constraints

-- Stakeholder Campaign States: Only allow updates for campaigns user has access to
CREATE POLICY "Users can insert campaign states for their campaigns"
  ON public.stakeholder_campaign_states FOR INSERT
  TO authenticated
  WITH CHECK (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );

CREATE POLICY "Users can update states for their campaigns"
  ON public.stakeholder_campaign_states FOR UPDATE
  TO authenticated
  USING (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  )
  WITH CHECK (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );

-- Campaign Metrics: Only allow inserts for campaigns user has access to
CREATE POLICY "Users can insert metrics for their campaigns"
  ON public.campaign_metrics FOR INSERT
  TO authenticated
  WITH CHECK (
    campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );

-- Opt-out Records: Only allow inserts for campaigns user has access to
CREATE POLICY "Users can insert opt-out records for their campaigns"
  ON public.opt_out_records FOR INSERT
  TO authenticated
  WITH CHECK (
    campaign_id IS NULL OR campaign_id IN (
      SELECT id FROM public.campaigns 
      WHERE created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')
    )
  );