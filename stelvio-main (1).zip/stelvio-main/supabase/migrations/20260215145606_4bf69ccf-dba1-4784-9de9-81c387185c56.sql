-- Add target_countries column to job_boards
-- NULL or empty array means "global" (searched for all candidates)
-- e.g., ['US'] means US-only, ['US','CA'] means US and Canada
ALTER TABLE public.job_boards ADD COLUMN target_countries text[] DEFAULT NULL;

-- Tag US-focused boards
UPDATE public.job_boards SET target_countries = ARRAY['US'] WHERE name IN (
  'Builtin', 'CareerOneStop', 'ClearanceJobs', 'ClearedJobs', 'Craigslist Jobs',
  'FlexJobs', 'Hired', 'Idealist', 'Ladders', 'The Ladders', 'Mediabistro',
  'SimplyHired', 'Snagajob', 'USAJobs', 'Wellfound', 'ZipRecruiter',
  'AngelList', 'Monster', 'CareerBuilder'
);

-- Tag US + Canada boards
UPDATE public.job_boards SET target_countries = ARRAY['US','CA'] WHERE name IN (
  'Indeed', 'Glassdoor', 'LinkedIn', 'Dice', 'Talent'
);

-- Tag UK-focused boards  
UPDATE public.job_boards SET target_countries = ARRAY['GB'] WHERE name IN (
  'Reed', 'Totaljobs', 'CWJobs', 'Technojobs', 'CV-Library', 'IT Job Board',
  'Jobsite', 'Guardian Jobs', 'MiracleWorkers'
);

-- Tag Germany boards
UPDATE public.job_boards SET target_countries = ARRAY['DE'] WHERE name IN (
  'Arbeitsagentur', 'StepStone', 'XING Jobs'
);

-- Tag France boards
UPDATE public.job_boards SET target_countries = ARRAY['FR'] WHERE name IN (
  'Pôle Emploi', 'APEC'
);

-- Tag India boards
UPDATE public.job_boards SET target_countries = ARRAY['IN'] WHERE name IN (
  'Naukri', 'Foundit', 'Shine'
);

-- Tag Australia/NZ boards
UPDATE public.job_boards SET target_countries = ARRAY['AU'] WHERE name IN (
  'Seek', 'CareerOne', 'JobSearch'
);
UPDATE public.job_boards SET target_countries = ARRAY['NZ'] WHERE name IN (
  'Trade Me Jobs'
);

-- Tag Japan boards
UPDATE public.job_boards SET target_countries = ARRAY['JP'] WHERE name IN (
  'Daijob', 'CareerCross', 'GaijinPot Jobs'
);

-- Tag Singapore boards
UPDATE public.job_boards SET target_countries = ARRAY['SG'] WHERE name IN (
  'JobsCentral', 'JobStreet'
);

-- Tag China boards
UPDATE public.job_boards SET target_countries = ARRAY['CN'] WHERE name IN (
  'ChinaHR', 'Zhaopin', '51Job'
);

-- Tag Latin America boards
UPDATE public.job_boards SET target_countries = ARRAY['MX','AR','CO','CL','PE','VE'] WHERE name IN (
  'Computrabajo', 'Bumeran'
);

-- Tag Middle East boards
UPDATE public.job_boards SET target_countries = ARRAY['AE','SA','QA','BH','KW'] WHERE name IN (
  'Bayt', 'GulfTalent'
);

-- Tag Sweden boards
UPDATE public.job_boards SET target_countries = ARRAY['SE'] WHERE name IN (
  'Jobbsafari', 'Lediga Jobb'
);

-- Tag Brazil boards
UPDATE public.job_boards SET target_countries = ARRAY['BR'] WHERE name IN (
  'Catho', 'InfoJobs Brasil'
);

-- Tag Morocco boards
UPDATE public.job_boards SET target_countries = ARRAY['MA'] WHERE name IN (
  'MarocAnnonces'
);

-- Tag Philippines boards
UPDATE public.job_boards SET target_countries = ARRAY['PH'] WHERE name IN (
  'Kalibrr', 'JobsDB'
);

-- Global boards (remote-focused or aggregators) - set to NULL explicitly
UPDATE public.job_boards SET target_countries = NULL WHERE name IN (
  'We Work Remotely', 'Remotive', 'Remote OK', 'Working Nomads',
  'Adzuna', 'CareerJet', 'Jooble', 'Neuvoo', 'GrabJobs',
  'EURES', 'Jobs.com', 'LinkUp'
);