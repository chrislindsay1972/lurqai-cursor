
-- Fix campaign_permissive_policies: restrict "WITH CHECK (true)" policies to recruiter/admin roles

-- 1. stakeholder_campaign_states INSERT
DROP POLICY IF EXISTS "System can insert/update campaign states" ON public.stakeholder_campaign_states;
CREATE POLICY "Recruiters and admins can insert campaign states"
ON public.stakeholder_campaign_states FOR INSERT
TO authenticated
WITH CHECK (
  public.has_role(auth.uid(), 'admin'::public.app_role) OR
  public.has_role(auth.uid(), 'recruiter'::public.app_role)
);

-- 2. stakeholder_campaign_states UPDATE
DROP POLICY IF EXISTS "System can update campaign states" ON public.stakeholder_campaign_states;
CREATE POLICY "Recruiters and admins can update campaign states"
ON public.stakeholder_campaign_states FOR UPDATE
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role) OR
  public.has_role(auth.uid(), 'recruiter'::public.app_role)
);

-- 3. campaign_metrics INSERT
DROP POLICY IF EXISTS "System can insert metrics" ON public.campaign_metrics;
CREATE POLICY "Recruiters and admins can insert metrics"
ON public.campaign_metrics FOR INSERT
TO authenticated
WITH CHECK (
  public.has_role(auth.uid(), 'admin'::public.app_role) OR
  public.has_role(auth.uid(), 'recruiter'::public.app_role)
);

-- 4. opt_out_records INSERT
DROP POLICY IF EXISTS "System can insert opt-out records" ON public.opt_out_records;
CREATE POLICY "Recruiters and admins can insert opt-out records"
ON public.opt_out_records FOR INSERT
TO authenticated
WITH CHECK (
  public.has_role(auth.uid(), 'admin'::public.app_role) OR
  public.has_role(auth.uid(), 'recruiter'::public.app_role)
);
