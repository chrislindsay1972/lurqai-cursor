-- Drop existing broken CV storage policies
DROP POLICY IF EXISTS "Recruiters and admins can view CVs" ON storage.objects;
DROP POLICY IF EXISTS "Recruiters and admins can upload CVs" ON storage.objects;
DROP POLICY IF EXISTS "Recruiters and admins can update CVs" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete CVs" ON storage.objects;

-- Recreate with properly qualified public.has_role function
CREATE POLICY "Recruiters and admins can view CVs"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'cv-files' 
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role) 
    OR public.has_role(auth.uid(), 'recruiter'::public.app_role)
  )
);

CREATE POLICY "Recruiters and admins can upload CVs"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'cv-files' 
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role) 
    OR public.has_role(auth.uid(), 'recruiter'::public.app_role)
  )
);

CREATE POLICY "Recruiters and admins can update CVs"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'cv-files' 
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role) 
    OR public.has_role(auth.uid(), 'recruiter'::public.app_role)
  )
);

CREATE POLICY "Admins can delete CVs"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'cv-files' 
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);