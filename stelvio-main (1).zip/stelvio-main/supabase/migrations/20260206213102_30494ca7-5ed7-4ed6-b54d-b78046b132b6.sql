-- Add comprehensive company fields from Apollo enrichment
-- Organized into logical sections: Basics, Social, Location, Financials, Technology

-- Social & Web Presence
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS blog_url text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS twitter_url text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS facebook_url text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS crunchbase_url text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS angellist_url text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS logo_url text;

-- Company Details
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS founded_year integer;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS short_description text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS seo_description text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS keywords text[];
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS languages text[];

-- Location Details  
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS street_address text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS postal_code text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS country text;

-- Financial & Market Data
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS annual_revenue bigint;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS annual_revenue_printed text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS total_funding bigint;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS total_funding_printed text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS latest_funding_stage text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS latest_funding_round_date date;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS publicly_traded_symbol text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS publicly_traded_exchange text;

-- Technology Stack
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS technology_names text[];

-- Organizational
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS industries text[];
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS retail_location_count integer;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS num_suborganizations integer;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS alexa_ranking integer;

-- Raw Apollo data storage for any additional fields
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS apollo_data jsonb;