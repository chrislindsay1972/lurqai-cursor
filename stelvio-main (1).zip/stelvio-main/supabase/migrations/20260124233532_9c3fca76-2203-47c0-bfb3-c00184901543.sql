-- Fix the remaining circular dependency in Admins can view all roles policy
-- This policy still uses has_role() which queries user_roles, creating recursion

DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;

-- Recreate with direct subquery instead of has_role function
CREATE POLICY "Admins can view all roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = auth.uid() AND ur.role = 'admin'
  )
);