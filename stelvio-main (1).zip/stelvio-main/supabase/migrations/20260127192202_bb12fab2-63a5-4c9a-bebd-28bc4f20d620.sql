-- =====================================================
-- FIX: Grant Recruiters the same operational permissions as Admins
-- for the CV → Job Search → Company → Stakeholder workflow
-- =====================================================

-- =====================================================
-- 1. JOB_BOARDS: Recruiters need to view ALL boards for job search
-- =====================================================
DROP POLICY IF EXISTS "Recruiters can view own job_boards" ON public.job_boards;

CREATE POLICY "Recruiters can view all job_boards"
ON public.job_boards
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

-- =====================================================
-- 2. COMPANIES: Recruiters need to view/update ALL companies
-- (Pipeline creates companies via service role, not user's context)
-- =====================================================
DROP POLICY IF EXISTS "Recruiters can view own companies" ON public.companies;
DROP POLICY IF EXISTS "Recruiters can update own companies" ON public.companies;

CREATE POLICY "Recruiters can view all companies"
ON public.companies
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can update all companies"
ON public.companies
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

-- Allow recruiters to delete companies (same as admins for workflow parity)
CREATE POLICY "Recruiters can delete companies"
ON public.companies
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

-- =====================================================
-- 3. STAKEHOLDERS: Recruiters need to view/update/delete ALL stakeholders
-- =====================================================
DROP POLICY IF EXISTS "Recruiters can view related stakeholders" ON public.stakeholders;
DROP POLICY IF EXISTS "Recruiters can update related stakeholders" ON public.stakeholders;

CREATE POLICY "Recruiters can view all stakeholders"
ON public.stakeholders
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can update all stakeholders"
ON public.stakeholders
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can delete stakeholders"
ON public.stakeholders
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

-- =====================================================
-- 4. JOBS: Recruiters need to view/update ALL jobs
-- (Pipeline creates jobs via service role)
-- =====================================================
DROP POLICY IF EXISTS "Recruiters can view own jobs" ON public.jobs;
DROP POLICY IF EXISTS "Recruiters can update own jobs" ON public.jobs;

CREATE POLICY "Recruiters can view all jobs"
ON public.jobs
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can update all jobs"
ON public.jobs
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can delete jobs"
ON public.jobs
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

-- =====================================================
-- 5. MATCHES: Recruiters need to view/update/delete ALL matches
-- =====================================================
DROP POLICY IF EXISTS "Recruiters can view own matches" ON public.matches;
DROP POLICY IF EXISTS "Recruiters can update own matches" ON public.matches;

CREATE POLICY "Recruiters can view all matches"
ON public.matches
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can update all matches"
ON public.matches
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can delete matches"
ON public.matches
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

-- =====================================================
-- 6. CANDIDATES: Recruiters need to view/update/delete ALL candidates
-- =====================================================
DROP POLICY IF EXISTS "Recruiters can view own candidates" ON public.candidates;
DROP POLICY IF EXISTS "Recruiters can update own candidates" ON public.candidates;

CREATE POLICY "Recruiters can view all candidates"
ON public.candidates
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can update all candidates"
ON public.candidates
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can delete candidates"
ON public.candidates
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

-- =====================================================
-- 7. NOTES: Recruiters need full access to all notes
-- =====================================================
DROP POLICY IF EXISTS "Recruiters can view own notes" ON public.notes;
DROP POLICY IF EXISTS "Recruiters can update own notes" ON public.notes;
DROP POLICY IF EXISTS "Recruiters can delete own notes" ON public.notes;

CREATE POLICY "Recruiters can view all notes"
ON public.notes
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can update all notes"
ON public.notes
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can delete all notes"
ON public.notes
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

-- =====================================================
-- 8. JOB_BOARD_JOBS & JOB_BOARD_CANDIDATES: Full access for recruiters
-- =====================================================
DROP POLICY IF EXISTS "Recruiters can view own job_board_jobs" ON public.job_board_jobs;
DROP POLICY IF EXISTS "Recruiters can delete own job_board_jobs" ON public.job_board_jobs;

CREATE POLICY "Recruiters can view all job_board_jobs"
ON public.job_board_jobs
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can delete all job_board_jobs"
ON public.job_board_jobs
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

DROP POLICY IF EXISTS "Recruiters can view own job_board_candidates" ON public.job_board_candidates;
DROP POLICY IF EXISTS "Recruiters can delete own job_board_candidates" ON public.job_board_candidates;

CREATE POLICY "Recruiters can view all job_board_candidates"
ON public.job_board_candidates
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters can delete all job_board_candidates"
ON public.job_board_candidates
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'recruiter'::app_role));