-- Create notes table with polymorphic relationship
CREATE TABLE public.notes (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    entity_type TEXT NOT NULL,
    entity_id UUID NOT NULL,
    content TEXT NOT NULL,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for efficient lookups
CREATE INDEX idx_notes_entity ON public.notes (entity_type, entity_id);

-- Enable RLS
ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Admins can view all notes"
ON public.notes FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can view own notes"
ON public.notes FOR SELECT
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Recruiters and admins can insert notes"
ON public.notes FOR INSERT
WITH CHECK (
    (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'recruiter'::app_role))
    AND ((created_by IS NULL) OR (created_by = auth.uid()))
);

CREATE POLICY "Admins can update all notes"
ON public.notes FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can update own notes"
ON public.notes FOR UPDATE
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

CREATE POLICY "Admins can delete all notes"
ON public.notes FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Recruiters can delete own notes"
ON public.notes FOR DELETE
USING ((created_by = auth.uid()) AND has_role(auth.uid(), 'recruiter'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_notes_updated_at
BEFORE UPDATE ON public.notes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();