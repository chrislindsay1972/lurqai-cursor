-- Update the enforce function: INSERT returns NULL (rejects row), UPDATE purges children
CREATE OR REPLACE FUNCTION public.enforce_max_company_size()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_max_employees int := 500;
  v_setting text;
BEGIN
  SELECT setting_value INTO v_setting
  FROM public.app_settings
  WHERE setting_key = 'max_company_employees'
  LIMIT 1;
  
  IF v_setting IS NOT NULL THEN
    v_max_employees := v_setting::int;
  END IF;

  IF NEW.employee_count IS NOT NULL AND NEW.employee_count > v_max_employees THEN
    RAISE LOG '[enforce_max_company_size] Oversized company blocked: % (% employees, max %)', NEW.name, NEW.employee_count, v_max_employees;

    IF TG_OP = 'INSERT' THEN
      -- Reject entirely — company never enters the DB
      RETURN NULL;
    END IF;

    -- UPDATE path: purge all children first
    DELETE FROM public.campaign_metrics
    WHERE stakeholder_id IN (SELECT id FROM public.stakeholders WHERE company_id = NEW.id);

    DELETE FROM public.stakeholder_campaign_states
    WHERE stakeholder_id IN (SELECT id FROM public.stakeholders WHERE company_id = NEW.id);

    DELETE FROM public.stakeholder_enrichment_attempts
    WHERE stakeholder_id IN (SELECT id FROM public.stakeholders WHERE company_id = NEW.id);

    DELETE FROM public.stakeholders WHERE company_id = NEW.id;

    DELETE FROM public.matches
    WHERE job_id IN (SELECT id FROM public.jobs WHERE company_id = NEW.id);

    DELETE FROM public.jobs WHERE company_id = NEW.id;

    DELETE FROM public.company_email_intel WHERE company_id = NEW.id;

    -- Mark for deletion by AFTER trigger
    NEW.enrichment_status := 'exceeds_size';
    NEW.enriched_at := now();
  END IF;

  RETURN NEW;
END;
$function$;

-- AFTER UPDATE trigger to delete the company row itself
CREATE OR REPLACE FUNCTION public.delete_oversized_company()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.enrichment_status = 'exceeds_size' THEN
    DELETE FROM public.companies WHERE id = NEW.id;
    RAISE LOG '[delete_oversized_company] Deleted oversized company: % (%)', NEW.name, NEW.id;
  END IF;
  RETURN NULL;
END;
$function$;

CREATE TRIGGER trg_delete_oversized_company
AFTER UPDATE ON public.companies
FOR EACH ROW
WHEN (NEW.enrichment_status = 'exceeds_size')
EXECUTE FUNCTION public.delete_oversized_company();