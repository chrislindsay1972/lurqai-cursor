-- Create companies table
CREATE TABLE public.companies (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    domain TEXT,
    website_url TEXT,
    description TEXT,
    phone TEXT,
    address TEXT,
    employee_count INTEGER,
    industry TEXT,
    linkedin_url TEXT,
    enrichment_status TEXT NOT NULL DEFAULT 'pending',
    enrichment_source TEXT,
    enriched_at TIMESTAMP WITH TIME ZONE,
    clay_data JSONB,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create unique constraint on domain (when not null)
CREATE UNIQUE INDEX idx_companies_domain ON public.companies(domain) WHERE domain IS NOT NULL;

-- Enable RLS
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Recruiters and admins can view companies"
ON public.companies
FOR SELECT
TO authenticated
USING (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Recruiters and admins can insert companies"
ON public.companies
FOR INSERT
TO authenticated
WITH CHECK (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Recruiters and admins can update companies"
ON public.companies
FOR UPDATE
TO authenticated
USING (
    has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'recruiter')
);

CREATE POLICY "Admins can delete companies"
ON public.companies
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'));

-- Trigger for updated_at
CREATE TRIGGER update_companies_updated_at
BEFORE UPDATE ON public.companies
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();