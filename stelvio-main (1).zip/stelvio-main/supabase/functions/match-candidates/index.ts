// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authentication check
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check user role
    const { data: roleData } = await supabaseClient
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    if (!roleData || !['recruiter', 'admin'].includes(roleData.role)) {
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { jobId, candidateIds } = await req.json();

    if (!jobId) {
      return new Response(
        JSON.stringify({ error: 'Job ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch job details
    const { data: job, error: jobError } = await supabaseClient
      .from('jobs')
      .select('*')
      .eq('id', jobId)
      .single();

    if (jobError || !job) {
      return new Response(
        JSON.stringify({ error: 'Job not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch candidates (either specific ones or all)
    let candidatesQuery = supabaseClient.from('candidates').select('*');
    if (candidateIds && Array.isArray(candidateIds) && candidateIds.length > 0) {
      candidatesQuery = candidatesQuery.in('id', candidateIds);
    }
    
    const { data: candidates, error: candidatesError } = await candidatesQuery;

    if (candidatesError || !candidates || candidates.length === 0) {
      return new Response(
        JSON.stringify({ error: 'No candidates found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      return new Response(
        JSON.stringify({ error: 'AI service not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Matching ${candidates.length} candidates to job: ${job.title}`);

    const matches: Array<{
      candidateId: string;
      candidateName: string;
      score: number;
      reason: string;
      skillsMatched: string[];
      skillsMissing: string[];
    }> = [];

    // Process candidates in batches for efficiency
    for (const candidate of candidates) {
      try {
        const systemPrompt = `You are an expert recruitment matching system. Analyze the comprehensive candidate profile against the job requirements and provide a match assessment.

MATCHING CRITERIA (in priority order):
1. Technical skills alignment with job requirements
2. Career trajectory and growth pattern - does this role fit their path?
3. Experience level appropriateness
4. Career highlights and achievements relevant to the role
5. Location compatibility (if specified)
6. Job type fit

SCORING GUIDELINES:
- 85-100: Exceptional match - skills, experience, and career trajectory strongly aligned
- 70-84: Strong match - most requirements met with minor gaps
- 55-69: Moderate match - core skills present but notable gaps exist
- 40-54: Weak match - significant skill or experience gaps
- Below 40: Poor match - fundamental misalignment

Use the AI Summary and Career Highlights to understand the candidate's full value proposition.`;

        // Build rich candidate profile using parsed CV data
        const careerHighlights = (candidate.career_highlights || []).slice(0, 5).join('\n  - ');
        
        const candidateProfile = `
CANDIDATE: ${candidate.name}
Current Title: ${candidate.current_title || 'Not specified'}
Experience: ${candidate.experience_years ? `${candidate.experience_years} years` : 'Not specified'}
Location: ${candidate.address || 'Not specified'}
Skills: ${(candidate.skills || []).join(', ') || 'Not specified'}
Soft Skills: ${(candidate.soft_skills || []).join(', ') || 'Not specified'}

--- AI-GENERATED CANDIDATE SUMMARY ---
${candidate.ai_summary || 'No AI summary available'}

--- CAREER HIGHLIGHTS ---
${careerHighlights ? `  - ${careerHighlights}` : 'No highlights available'}
`;

        const jobDetails = `
JOB: ${job.title}
Description: ${job.description || 'Not provided'}
Requirements: ${job.requirements || 'Not provided'}
Required Skills: ${(job.skills_required || []).join(', ') || 'Not specified'}
Location: ${job.location || 'Not specified'}
Experience Level: ${job.experience_level || 'Not specified'}
Job Type: ${job.job_type || 'Not specified'}
`;

        // Define the tool for structured output extraction
        const matchAnalysisTool = {
          type: "function",
          function: {
            name: "analyze_candidate_match",
            description: "Analyze the candidate-job match and return structured assessment",
            parameters: {
              type: "object",
              properties: {
                score: {
                  type: "number",
                  description: "Overall match percentage between 0-100"
                },
                reason: {
                  type: "string",
                  description: "2-3 sentences explaining why this is or isn't a good match, referencing specific strengths or gaps"
                },
                skills_matched: {
                  type: "array",
                  items: { type: "string" },
                  description: "Skills the candidate has that match job requirements"
                },
                skills_missing: {
                  type: "array",
                  items: { type: "string" },
                  description: "Required skills the candidate lacks"
                }
              },
              required: ["score", "reason", "skills_matched", "skills_missing"],
              additionalProperties: false
            }
          }
        };

        const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: `Match this candidate to the job:\n\n${candidateProfile}\n\n${jobDetails}` }
            ],
            tools: [matchAnalysisTool],
            tool_choice: { type: "function", function: { name: "analyze_candidate_match" } },
          }),
        });

        if (!response.ok) {
          console.error(`AI error for candidate ${candidate.id}: ${response.status}`);
          continue;
        }

        const data = await response.json();
        
        // Extract structured data from tool call response
        const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
        if (!toolCall || toolCall.function?.name !== 'analyze_candidate_match') {
          console.error(`No valid tool call response for candidate ${candidate.id}`);
          continue;
        }

        let parsed;
        try {
          parsed = JSON.parse(toolCall.function.arguments);
        } catch (parseErr) {
          console.error(`Failed to parse tool call arguments for candidate ${candidate.id}:`, parseErr);
          continue;
        }

        matches.push({
          candidateId: candidate.id,
          candidateName: candidate.name,
          score: Math.min(100, Math.max(0, parseInt(parsed.score) || 0)),
          reason: String(parsed.reason || '').slice(0, 500),
          skillsMatched: Array.isArray(parsed.skills_matched) ? parsed.skills_matched.slice(0, 20) : [],
          skillsMissing: Array.isArray(parsed.skills_missing) ? parsed.skills_missing.slice(0, 20) : [],
        });

      } catch (err) {
        console.error(`Error matching candidate ${candidate.id}:`, err);
      }
    }

    // Sort by score descending
    matches.sort((a, b) => b.score - a.score);

    // Store matches in database
    const matchRecords = matches.map(m => ({
      candidate_id: m.candidateId,
      job_id: jobId,
      match_score: m.score,
      match_reason: m.reason,
      skills_matched: m.skillsMatched,
      skills_missing: m.skillsMissing,
      status: 'pending',
      created_by: user.id,
    }));

    if (matchRecords.length > 0) {
      const { error: insertError } = await supabaseClient
        .from('matches')
        .upsert(matchRecords, { 
          onConflict: 'candidate_id,job_id',
          ignoreDuplicates: false 
        });

      if (insertError) {
        console.error('Error storing matches:', insertError);
      }
    }

    console.log(`Successfully matched ${matches.length} candidates to job ${job.title}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        matches,
        total: matches.length,
        jobTitle: job.title
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    // Log detailed error server-side for debugging
    console.error('Error in match-candidates function:', error);
    if (error instanceof Error) {
      console.error('Stack trace:', error.stack);
    }
    
    // Return generic error to client to prevent information leakage
    return new Response(
      JSON.stringify({ 
        error: 'An error occurred while matching candidates. Please try again or contact support if the issue persists.',
        error_code: 'MATCH_CANDIDATES_ERROR'
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
