// Using Deno.serve instead of deprecated std serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

// Parse employee count from various formats
function parseEmployeeCount(text: string): number | null {
  if (!text) return null;
  
  const rangeMatch = text.match(/(\d[\d,]*)\s*[-–]\s*(\d[\d,]*)\s*employee/i);
  if (rangeMatch) {
    const low = parseInt(rangeMatch[1].replace(/,/g, ''));
    const high = parseInt(rangeMatch[2].replace(/,/g, ''));
    return Math.round((low + high) / 2);
  }
  
  const plusMatch = text.match(/(\d[\d,]*)\+?\s*employee/i);
  if (plusMatch) {
    const count = parseInt(plusMatch[1].replace(/,/g, ''));
    if (text.includes('+')) return Math.round(count * 1.5);
    return count;
  }
  
  const numMatch = text.match(/(\d[\d,]+)/);
  if (numMatch) return parseInt(numMatch[1].replace(/,/g, ''));
  
  return null;
}

// Extract employee count from LinkedIn page content
function extractEmployeeCountFromLinkedIn(content: string): number | null {
  if (!content) return null;
  
  const patterns = [
    /(\d[\d,]*)\s*[-–]\s*(\d[\d,]*)\s*employees?/gi,
    /(\d[\d,]+)\+?\s*employees?/gi,
    /employees?[:\s]+(\d[\d,]+)/gi,
    /company size[:\s]+(\d[\d,]*\s*[-–]\s*\d[\d,]*)/gi,
    /company size[:\s]+(\d[\d,]+)/gi,
  ];
  
  for (const pattern of patterns) {
    const matches = content.match(pattern);
    if (matches) {
      for (const match of matches) {
        const count = parseEmployeeCount(match);
        if (count && count > 0) return count;
      }
    }
  }
  
  return null;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Authentication check
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const token = authHeader.replace('Bearer ', '');
    const isServiceRole = token === serviceRoleKey;

    let supabaseClient;

    if (isServiceRole) {
      console.log('Authenticated via service role key (background task)');
      supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        serviceRoleKey
      );
    } else {
      supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
        { global: { headers: { Authorization: authHeader } } }
      );

      const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
      if (userError || !user) {
        return new Response(
          JSON.stringify({ error: 'Unauthorized' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data: role, error: roleError } = await supabaseClient.rpc('get_user_role', {
        _user_id: user.id,
      });

      if (roleError) {
        console.error('Error fetching role (rpc get_user_role):', roleError);
        return new Response(
          JSON.stringify({ error: 'Unable to verify permissions' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (!role || !['recruiter', 'admin'].includes(String(role))) {
        return new Response(
          JSON.stringify({ error: 'Insufficient permissions' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        serviceRoleKey
      );

      console.log(`Authenticated user: ${user.id}`);
    }

    let { domain, companyId } = await req.json();
    
    if (!domain) {
      return new Response(
        JSON.stringify({ error: 'Domain is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const domainRegex = /^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain)) {
      return new Response(
        JSON.stringify({ error: 'Invalid domain format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const domainParts = domain.split('.');
    if (domainParts.length > 2) {
      domain = domainParts.slice(-2).join('.');
      console.log(`Extracted base domain: ${domain}`);
    }

    console.log(`Enriching company domain: ${domain}, companyId: ${companyId}`);

    // Fetch max company employees setting
    let maxCompanyEmployees = 500;
    const { data: settings } = await supabaseClient
      .from('app_settings')
      .select('setting_value')
      .eq('setting_key', 'max_company_employees')
      .single();
    
    if (settings?.setting_value) {
      const parsed = parseInt(settings.setting_value, 10);
      if (!isNaN(parsed)) maxCompanyEmployees = parsed;
    }
    console.log(`Max company employees setting: ${maxCompanyEmployees}`);

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    let FIRECRAWL_API_KEY = Deno.env.get('FIRECRAWL_API_KEY');
    const APOLLO_API_KEY = Deno.env.get('APOLLO_API_KEY');
    // Resolve Firecrawl API key: app_settings override first, then env var
    try {
      const { data: secretSetting } = await supabaseClient
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'secret_firecrawl_api_key')
        .single();
      if (secretSetting?.setting_value) {
        FIRECRAWL_API_KEY = secretSetting.setting_value;
        console.log('Using Firecrawl API key from app_settings');
      }
    } catch (_) { /* ignore, use env fallback */ }
    
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY is not configured');
      return new Response(
        JSON.stringify({ error: 'AI enrichment not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let employeeCountFromScrape: number | null = null;
    let linkedInUrl: string | null = null;
    let scrapedData: Record<string, unknown> = {};
    let glassdoorRating: number | null = null;
    let fundingStatus: string | null = null;
    let recentNews: string[] = [];
    let qualitySignals: Record<string, unknown> = {};
    let apolloData: Record<string, unknown> | null = null;
    let apolloEnriched = false;

    // ===== PHASE 1: Apollo first (fast, authoritative) =====
    // Run Apollo first — if it returns employee_count + LinkedIn, we skip Firecrawl scraping
    
    console.log(`[PHASE 1] Running Apollo enrichment first for ${domain}...`);

    if (APOLLO_API_KEY) {
      try {
        console.log(`[Apollo] Enriching organization for domain: ${domain}...`);
        const apolloResponse = await fetch(
          `https://api.apollo.io/api/v1/organizations/enrich?domain=${encodeURIComponent(domain)}`,
          {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'X-Api-Key': APOLLO_API_KEY,
            },
          }
        );

        if (apolloResponse.ok) {
          const apolloResult = await apolloResponse.json();
          const org = apolloResult.organization;
          
          if (org) {
            apolloEnriched = true;
            apolloData = org;
            
            if (org.estimated_num_employees && typeof org.estimated_num_employees === 'number') {
              employeeCountFromScrape = org.estimated_num_employees;
              console.log(`[Apollo] Found employee count: ${employeeCountFromScrape}`);
            }
            if (org.linkedin_url) {
              linkedInUrl = org.linkedin_url;
              console.log(`[Apollo] Found LinkedIn: ${linkedInUrl}`);
            }
            if (org.annual_revenue) qualitySignals.annual_revenue = org.annual_revenue;
            if (org.annual_revenue_printed) qualitySignals.annual_revenue_printed = org.annual_revenue_printed;
            if (org.founded_year) qualitySignals.founded_year = org.founded_year;
            if (org.publicly_traded_symbol) {
              qualitySignals.publicly_traded = true;
              qualitySignals.stock_symbol = org.publicly_traded_symbol;
            }
            if (org.total_funding) {
              fundingStatus = `$${Math.round(org.total_funding / 1000000)}M raised`;
              qualitySignals.total_funding = org.total_funding;
            }
            if (org.latest_funding_round_date) qualitySignals.latest_funding_date = org.latest_funding_round_date;
            if (org.latest_funding_stage) {
              if (!fundingStatus) fundingStatus = org.latest_funding_stage;
              qualitySignals.latest_funding_stage = org.latest_funding_stage;
            }
            
            console.log(`[Apollo] Successfully enriched with ${Object.keys(org).length} fields`);
          }
        } else {
          console.warn(`[Apollo] API returned ${apolloResponse.status}: ${await apolloResponse.text()}`);
        }
      } catch (apolloError) {
        console.error('[Apollo] Error:', apolloError);
      }
    } else {
      console.log('[Apollo] API key not configured, skipping');
    }

    // ===== PHASE 2: Apollo-first short-circuit =====
    // If Apollo gave us employee count + LinkedIn URL, skip the 3 Firecrawl scraping calls.
    // Only run funding news search if Apollo didn't already provide funding data.
    const apolloSufficient = apolloEnriched && !!employeeCountFromScrape && !!linkedInUrl;
    const apolloHasFunding = !!fundingStatus;

    if (apolloSufficient) {
      console.log(`[SHORT-CIRCUIT] Apollo provided employee count (${employeeCountFromScrape}) + LinkedIn — skipping Firecrawl LinkedIn/website/Glassdoor scraping. Saves ~3 Firecrawl credits.`);
    } else {
      console.log(`[PHASE 2] Apollo insufficient (enriched=${apolloEnriched}, employees=${employeeCountFromScrape}, linkedin=${!!linkedInUrl}), running Firecrawl fallback scraping for ${domain}...`);
    }

    // Conditionally build Firecrawl promises based on Apollo sufficiency
    // Promise 2: Firecrawl LinkedIn search (skip if Apollo already gave us LinkedIn + employee count)
    const firecrawlLinkedInPromise = (async (): Promise<void> => {
      if (apolloSufficient) return; // Short-circuit
      if (!FIRECRAWL_API_KEY) return;
      try {
        console.log(`[Firecrawl] Searching for LinkedIn page for ${domain}...`);
        const searchResponse = await fetch('https://api.firecrawl.dev/v1/search', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            query: `${domain} site:linkedin.com/company`,
            limit: 3,
            scrapeOptions: { formats: ['markdown'] },
          }),
        });

        if (searchResponse.ok) {
          const searchData = await searchResponse.json();
          const linkedInResults = (searchData.data || []).filter((r: { url?: string }) => 
            r.url?.includes('linkedin.com/company')
          );
          
          if (linkedInResults.length > 0) {
            const linkedInResult = linkedInResults[0];
            if (!linkedInUrl) linkedInUrl = linkedInResult.url; // Don't override Apollo
            console.log(`[Firecrawl] Found LinkedIn: ${linkedInResult.url}`);
            
            if (linkedInResult.markdown && !employeeCountFromScrape) {
              employeeCountFromScrape = extractEmployeeCountFromLinkedIn(linkedInResult.markdown);
              if (employeeCountFromScrape) {
                console.log(`[Firecrawl] Extracted employee count: ${employeeCountFromScrape}`);
              }
            }
          }
        } else {
          console.warn(`[Firecrawl] Search failed: ${searchResponse.status}`);
        }
      } catch (firecrawlError) {
        console.error('[Firecrawl] Error:', firecrawlError);
      }
    })();

    // Promise 3: Firecrawl website scrape (for employee count fallback - skip if Apollo sufficient)
    const firecrawlWebsitePromise = (async (): Promise<void> => {
      if (apolloSufficient) return; // Short-circuit: Apollo already gave us what we need
      if (!FIRECRAWL_API_KEY) return;
      try {
        console.log(`[Firecrawl] Scraping company website: ${domain}...`);
        const scrapeResponse = await fetch('https://api.firecrawl.dev/v1/scrape', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            url: `https://${domain}`,
            formats: ['markdown'],
            onlyMainContent: true,
          }),
        });

        if (scrapeResponse.ok) {
          const scrapeResult = await scrapeResponse.json();
          const markdown = scrapeResult.data?.markdown || scrapeResult.markdown || '';
          
          const websiteEmployeeCount = extractEmployeeCountFromLinkedIn(markdown);
          if (websiteEmployeeCount && !employeeCountFromScrape) {
            employeeCountFromScrape = websiteEmployeeCount;
            console.log(`[Firecrawl] Found employee count on website: ${employeeCountFromScrape}`);
          }
          
          scrapedData = { website_content_preview: markdown.slice(0, 1000) };
        }
      } catch (scrapeError) {
        console.error('[Firecrawl] Website scrape error:', scrapeError);
      }
    })();

    // Promise 4: Glassdoor quality signals (skip if Apollo sufficient — Glassdoor rating is a nice-to-have)
    const glassdoorPromise = (async (): Promise<void> => {
      if (apolloSufficient) return; // Short-circuit: save Firecrawl credits
      if (!FIRECRAWL_API_KEY) return;
      try {
        console.log(`[Firecrawl] Searching for quality signals for ${domain}...`);
        // Use description-only search (no scrapeOptions) to save credits — rating is usually in the snippet
        const glassdoorSearch = await fetch('https://api.firecrawl.dev/v1/search', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            query: `${domain} site:glassdoor.com reviews rating`,
            limit: 1,
            // No scrapeOptions — description snippet is sufficient to extract the rating
          }),
        });

        if (glassdoorSearch.ok) {
          const glassdoorData = await glassdoorSearch.json();
          const glassdoorResults = glassdoorData.data || [];
          
          for (const result of glassdoorResults) {
            // Try description snippet first (free), then markdown if available
            const textToSearch = result.description || result.markdown || '';
            if (textToSearch) {
              const ratingMatch = textToSearch.match(/(?:rated?|rating|overall)[:\s]*(\d+\.?\d*)\s*(?:out of 5|\/5)?/i) 
                || textToSearch.match(/(\d+\.?\d*)\s*(?:out of 5|\/5|stars?)/i);
              if (ratingMatch) {
                const rating = parseFloat(ratingMatch[1]);
                if (rating > 0 && rating <= 5) {
                  glassdoorRating = rating;
                  console.log(`[Firecrawl] Found Glassdoor rating: ${glassdoorRating}`);
                  break;
                }
              }
            }
          }
        }
      } catch (glassdoorError) {
        console.error('[Firecrawl] Glassdoor search error:', glassdoorError);
      }
    })();

    // Promise 5: Funding news search
    const fundingPromise = (async (): Promise<void> => {
      if (apolloHasFunding) {
        console.log(`[SHORT-CIRCUIT] Apollo already provided funding data (${fundingStatus}) — skipping Firecrawl funding search`);
        return;
      }
      if (!FIRECRAWL_API_KEY) return;
      try {
        // No scrapeOptions — title + description snippets are sufficient for funding detection
        const fundingSearch = await fetch('https://api.firecrawl.dev/v1/search', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            query: `"${domain}" OR "${domain.replace(/\.[^.]+$/, '')}" funding raised series investment 2024 2025`,
            limit: 2,
            // No scrapeOptions — saves 2 credits per enrichment
          }),
        });

        if (fundingSearch.ok) {
          const fundingData = await fundingSearch.json();
          const fundingResults = fundingData.data || [];
          
          for (const result of fundingResults) {
            // Use title + description snippet (no markdown since we dropped scrapeOptions)
            const textToSearch = [result.title || '', result.description || ''].join(' ');
            if (textToSearch.trim()) {
              const fundingPatterns = [
                /(?:raised|secures?|closes?|announces?)\s+\$?([\d.]+)\s*(million|billion|M|B|m|b)/i,
                /series\s+([A-Z])\s+(?:funding|round|investment)/i,
                /(?:seed|pre-seed)\s+(?:funding|round|investment)/i,
              ];
              
              for (const pattern of fundingPatterns) {
                const match = textToSearch.match(pattern);
                if (match) {
                  if (match[1] && match[2]) {
                    const amount = parseFloat(match[1]);
                    const unit = match[2].toLowerCase().startsWith('b') ? 'B' : 'M';
                    if (!fundingStatus) fundingStatus = `$${amount}${unit} raised`;
                  } else if (match[0].toLowerCase().includes('series')) {
                    if (!fundingStatus) fundingStatus = `Series ${match[1]}`;
                  } else if (match[0].toLowerCase().includes('seed')) {
                    if (!fundingStatus) fundingStatus = match[0].toLowerCase().includes('pre') ? 'Pre-Seed' : 'Seed';
                  }
                  if (fundingStatus) {
                    console.log(`[Firecrawl] Found funding status: ${fundingStatus}`);
                    break;
                  }
                }
              }
              
              // Collect news headlines from title
              if (result.title && recentNews.length < 3) {
                recentNews.push(result.title.slice(0, 200));
              }
            }
          }
        }
      } catch (fundingError) {
        console.error('[Firecrawl] Funding search error:', fundingError);
      }
    })();

    // Wait for remaining Firecrawl calls to complete in parallel
    await Promise.allSettled([
      firecrawlLinkedInPromise,
      firecrawlWebsitePromise,
      glassdoorPromise,
      fundingPromise,
    ]);

    const skippedCount = (apolloSufficient ? 3 : 0) + (apolloHasFunding ? 1 : 0);
    console.log(`[ENRICHMENT] All sources complete for ${domain}. Firecrawl calls skipped: ${skippedCount}/4`);


    // Step 3: Use AI to fill in remaining data
    const prompt = `Research the company with domain "${domain}" thoroughly.

${employeeCountFromScrape ? `IMPORTANT: I already found employee count data: approximately ${employeeCountFromScrape} employees. Use this as the employee_count.` : `CRITICAL: The employee_count field is EXTREMELY IMPORTANT for our business. You MUST provide your best estimate.
- Search your knowledge for any information about this company's size
- Look at industry benchmarks, funding rounds, office locations, job postings
- If the company has been in news, check reported headcounts
- Even if uncertain, provide a reasonable estimate based on company type and age
- NEVER return null for employee_count unless the company literally doesn't exist`}

${linkedInUrl ? `LinkedIn URL found: ${linkedInUrl}` : ''}

Provide the following in JSON format:
{
  "name": "Company legal name",
  "description": "Brief company description (1-2 sentences)",
  "industry": "Primary industry/sector",
  "employee_count": ${employeeCountFromScrape || 'YOUR BEST ESTIMATE as a number (required - do not use null)'},
  "phone": "Main phone number or null",
  "address": "Headquarters address or null",
  "linkedin_url": "${linkedInUrl || 'LinkedIn company page URL or null'}",
  "website_url": "Main website URL"
}

Only respond with valid JSON, no other text.`;

    const aiModels = [
      { id: 'google/gemini-3-flash-preview', supportsTemperature: true },
      { id: 'google/gemini-2.5-flash', supportsTemperature: true },
      { id: 'openai/gpt-5-mini', supportsTemperature: false },
      { id: 'openai/gpt-5-nano', supportsTemperature: false },
    ];
    const systemMessage = 'You are a business research assistant. When asked for employee_count, you MUST provide a number estimate - never null. Use your knowledge of company funding, industry, and market presence to estimate. Even "50" or "100" as an estimate is better than null.';
    
    let aiResponse: Response | null = null;
    for (const { id: model, supportsTemperature } of aiModels) {
      try {
        console.log(`[AI] Trying model: ${model}`);
        const body: Record<string, unknown> = {
          model,
          messages: [
            { role: 'system', content: systemMessage },
            { role: 'user', content: prompt },
          ],
        };
        if (supportsTemperature) body.temperature = 0.3;

        const attempt = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body),
        });
        if (attempt.ok) {
          aiResponse = attempt;
          console.log(`[AI] Success with model: ${model}`);
          break;
        }
        const errText = await attempt.text();
        console.warn(`[AI] Model ${model} returned ${attempt.status}: ${errText}`);
      } catch (modelErr) {
        console.warn(`[AI] Model ${model} threw error:`, modelErr);
      }
    }

    if (!aiResponse) {
      console.error('All AI models failed');
      if (companyId) {
        await supabaseClient
          .from('companies')
          .update({ enrichment_status: 'failed', enriched_at: new Date().toISOString() })
          .eq('id', companyId);
      }
      return new Response(
        JSON.stringify({ error: 'Failed to enrich company data', details: 'All AI gateway models returned errors' }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const aiResult = await aiResponse.json();
    const content = aiResult.choices?.[0]?.message?.content || '';
    
    console.log('AI enrichment raw response:', content.slice(0, 500));

    let companyData;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        companyData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found in response');
      }
    } catch (parseError) {
      console.error('Failed to parse AI response:', parseError);
      if (companyId) {
        await supabaseClient
          .from('companies')
          .update({ enrichment_status: 'failed', enriched_at: new Date().toISOString() })
          .eq('id', companyId);
      }
      return new Response(
        JSON.stringify({ error: 'Failed to parse enrichment data', details: parseError instanceof Error ? parseError.message : String(parseError) }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Determine final employee count
    let finalEmployeeCount: number | null = null;
    
    if (employeeCountFromScrape && employeeCountFromScrape > 0) {
      finalEmployeeCount = employeeCountFromScrape;
      console.log(`Using scraped employee count: ${finalEmployeeCount}`);
    } else if (typeof companyData.employee_count === 'number' && companyData.employee_count > 0) {
      finalEmployeeCount = companyData.employee_count;
      console.log(`Using AI estimated employee count: ${finalEmployeeCount}`);
    } else if (typeof companyData.employee_count === 'string') {
      finalEmployeeCount = parseEmployeeCount(companyData.employee_count);
      console.log(`Parsed AI employee count string: ${finalEmployeeCount}`);
    }

    // Check if employee count exceeds maximum
    if (finalEmployeeCount && finalEmployeeCount > maxCompanyEmployees) {
      console.log(`Company ${domain} has ${finalEmployeeCount} employees, exceeds max ${maxCompanyEmployees} - marking as exceeds_size`);

      if (companyId) {
        let oversizeEnrichmentSource = 'lovable-ai';
        if (apolloEnriched) {
          oversizeEnrichmentSource = FIRECRAWL_API_KEY ? 'apollo+firecrawl+ai' : 'apollo+ai';
        } else if (employeeCountFromScrape) {
          oversizeEnrichmentSource = 'firecrawl+ai';
        }

        const { error: updateError } = await supabaseClient
          .from('companies')
          .update({
            employee_count: finalEmployeeCount,
            enrichment_status: 'exceeds_size',
            enrichment_source: oversizeEnrichmentSource,
            enriched_at: new Date().toISOString(),
            name: (apolloData?.name as string) || companyData.name || null,
            description: (apolloData?.short_description as string) || companyData.description || null,
            phone: (apolloData?.phone as string) || companyData.phone || null,
            address: (apolloData?.raw_address as string) || companyData.address || null,
            industry: (apolloData?.industry as string) || companyData.industry || null,
            linkedin_url: linkedInUrl || (apolloData?.linkedin_url as string) || companyData.linkedin_url || null,
            website_url: (apolloData?.website_url as string) || companyData.website_url || null,
            glassdoor_rating: glassdoorRating,
            funding_status: fundingStatus,
            recent_news: recentNews.length > 0 ? recentNews : null,
            quality_signals: qualitySignals,
            clay_data: {
              ...(typeof companyData === 'object' && companyData ? companyData : {}),
              _apollo_data: apolloData,
              _scraped_employee_count: employeeCountFromScrape,
              _oversize_employee_count: finalEmployeeCount,
              _capped_employee_count: maxCompanyEmployees,
              ...scrapedData,
            },
          })
          .eq('id', companyId);

        if (updateError) console.error('Error updating oversized company:', updateError);

        // Reject any pending/shortlisted matches for this oversized company's jobs
        const { data: oversizedJobs } = await supabaseClient
          .from('jobs')
          .select('id')
          .eq('company_id', companyId);

        if (oversizedJobs && oversizedJobs.length > 0) {
          const jobIds = oversizedJobs.map((j: { id: string }) => j.id);
          const { error: rejectError } = await supabaseClient
            .from('matches')
            .update({ status: 'rejected' })
            .in('job_id', jobIds)
            .in('status', ['pending', 'shortlisted']);
          if (rejectError) console.error('Error rejecting oversized matches:', rejectError);
          else console.log(`Rejected matches for ${jobIds.length} jobs from oversized company ${domain}`);
        }
      }

      return new Response(
        JSON.stringify({
          success: false,
          skipped: true,
          reason: 'exceeds_max_employees',
          employee_count: finalEmployeeCount,
          stored_employee_count: maxCompanyEmployees,
          max_allowed: maxCompanyEmployees,
          message: `Company has ${finalEmployeeCount} employees, exceeding the maximum of ${maxCompanyEmployees}`,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build final quality signals
    const finalQualitySignals = {
      ...qualitySignals,
      glassdoor_rating: glassdoorRating,
      funding_status: fundingStatus,
      recent_news: recentNews,
      enriched_at: new Date().toISOString(),
    };

    let enrichmentSource = 'lovable-ai';
    if (apolloEnriched) {
      enrichmentSource = FIRECRAWL_API_KEY ? 'apollo+firecrawl+ai' : 'apollo+ai';
    } else if (employeeCountFromScrape) {
      enrichmentSource = 'firecrawl+ai';
    }

    const enrichedData: Record<string, unknown> = {
      name: (apolloData?.name as string) || companyData.name || null,
      description: (apolloData?.short_description as string) || (apolloData?.seo_description as string) || companyData.description || null,
      short_description: (apolloData?.short_description as string) || null,
      seo_description: (apolloData?.seo_description as string) || null,
      phone: (apolloData?.phone as string) || companyData.phone || null,
      address: (apolloData?.raw_address as string) || companyData.address || null,
      employee_count: finalEmployeeCount,
      industry: (apolloData?.industry as string) || companyData.industry || null,
      linkedin_url: linkedInUrl || (apolloData?.linkedin_url as string) || companyData.linkedin_url || null,
      website_url: (apolloData?.website_url as string) || companyData.website_url || `https://${domain}`,
      enrichment_status: 'enriched',
      enrichment_source: enrichmentSource,
      enriched_at: new Date().toISOString(),
      blog_url: (apolloData?.blog_url as string) || null,
      twitter_url: (apolloData?.twitter_url as string) || null,
      facebook_url: (apolloData?.facebook_url as string) || null,
      crunchbase_url: (apolloData?.crunchbase_url as string) || null,
      angellist_url: (apolloData?.angellist_url as string) || null,
      logo_url: (apolloData?.logo_url as string) || null,
      founded_year: (apolloData?.founded_year as number) || null,
      keywords: (apolloData?.keywords as string[]) || null,
      languages: (apolloData?.languages as string[]) || null,
      street_address: (apolloData?.street_address as string) || null,
      city: (apolloData?.city as string) || null,
      state: (apolloData?.state as string) || null,
      postal_code: (apolloData?.postal_code as string) || null,
      country: (apolloData?.country as string) || null,
      annual_revenue: (apolloData?.annual_revenue as number) || null,
      annual_revenue_printed: (apolloData?.annual_revenue_printed as string) || null,
      total_funding: (apolloData?.total_funding as number) || null,
      total_funding_printed: (apolloData?.total_funding_printed as string) || null,
      latest_funding_stage: (apolloData?.latest_funding_stage as string) || fundingStatus || null,
      latest_funding_round_date: (apolloData?.latest_funding_round_date as string) || null,
      publicly_traded_symbol: (apolloData?.publicly_traded_symbol as string) || null,
      publicly_traded_exchange: (apolloData?.publicly_traded_exchange as string) || null,
      technology_names: (apolloData?.technology_names as string[]) || null,
      industries: (apolloData?.industries as string[]) || null,
      retail_location_count: (apolloData?.retail_location_count as number) || null,
      num_suborganizations: (apolloData?.num_suborganizations as number) || null,
      alexa_ranking: (apolloData?.alexa_ranking as number) || null,
      glassdoor_rating: glassdoorRating,
      funding_status: fundingStatus || (apolloData?.latest_funding_stage as string) || null,
      recent_news: recentNews.length > 0 ? recentNews : null,
      quality_signals: finalQualitySignals,
      quality_enriched_at: new Date().toISOString(),
      apollo_data: apolloData || null,
      clay_data: {
        ...companyData,
        _scraped_employee_count: employeeCountFromScrape,
        _final_employee_count: finalEmployeeCount,
        ...scrapedData,
      },
    };

    if (companyId) {
      const { error: updateError } = await supabaseClient
        .from('companies')
        .update(enrichedData)
        .eq('id', companyId);

      if (updateError) {
        console.error('Error updating company:', updateError);
        return new Response(
          JSON.stringify({ error: 'Failed to update company record', details: updateError.message }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    console.log(`Successfully enriched company: ${domain}, employee_count: ${finalEmployeeCount}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        data: enrichedData,
        message: companyId ? 'Company updated successfully' : 'Company data retrieved'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in enrich-company function:', error);
    if (error instanceof Error) console.error('Stack trace:', error.stack);

    try {
      const body = await req.clone().json().catch(() => ({}));
      if (body.companyId) {
        const svc = createClient(
          Deno.env.get('SUPABASE_URL') ?? '',
          Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
        );
        await svc
          .from('companies')
          .update({ enrichment_status: 'failed', enriched_at: new Date().toISOString() })
          .eq('id', body.companyId);
      }
    } catch (_) { /* ignore */ }
    
    return new Response(
      JSON.stringify({ 
        error: 'An error occurred while enriching company data. Please try again.',
        details: error instanceof Error ? error.message : String(error),
        error_code: 'ENRICH_COMPANY_ERROR'
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
