// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authentication check
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check user role
    const { data: roleData } = await supabaseClient
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    if (!roleData || !['recruiter', 'admin'].includes(roleData.role)) {
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { jobId } = await req.json();

    if (!jobId) {
      return new Response(
        JSON.stringify({ error: 'Job ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch job with source URL
    const { data: job, error: jobError } = await supabaseClient
      .from('jobs')
      .select('id, title, source_url, status')
      .eq('id', jobId)
      .single();

    if (jobError || !job) {
      return new Response(
        JSON.stringify({ error: 'Job not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!job.source_url) {
      return new Response(
        JSON.stringify({ 
          success: true,
          available: null,
          reason: 'No source URL to check',
          jobId: job.id 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Resolve Firecrawl API key: app_settings override first, then env var
    let apiKey = Deno.env.get('FIRECRAWL_API_KEY');
    try {
      const { data: secretSetting } = await supabaseClient
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'secret_firecrawl_api_key')
        .single();
      if (secretSetting?.setting_value) {
        apiKey = secretSetting.setting_value;
        console.log('Using Firecrawl API key from app_settings');
      }
    } catch (_) { /* ignore, use env fallback */ }
    if (!apiKey) {
      console.error('FIRECRAWL_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'Web scraping service not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Checking job availability: ${job.title} at ${job.source_url}`);

    // Use Firecrawl to check the URL
    const scrapeResponse = await fetch('https://api.firecrawl.dev/v1/scrape', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url: job.source_url,
        formats: ['markdown'],
        onlyMainContent: true,
      }),
    });

    let isAvailable = true;
    let reason = 'Job posting appears to be active';

    if (!scrapeResponse.ok) {
      const status = scrapeResponse.status;
      if (status === 404) {
        isAvailable = false;
        reason = 'Job posting page not found (404)';
      } else if (status >= 400) {
        isAvailable = false;
        reason = `Job posting page returned error (${status})`;
      }
    } else {
      const scrapeData = await scrapeResponse.json();
      const content = scrapeData.data?.markdown || scrapeData.markdown || '';
      const lowerContent = content.toLowerCase();

      // Check for common "job filled/expired" patterns
      const expiredPatterns = [
        'this job has been filled',
        'position has been filled',
        'no longer accepting applications',
        'application closed',
        'job expired',
        'this position is no longer available',
        'vacancy has been filled',
        'role has been filled',
        'this job posting has expired',
        'this listing has expired',
        'job no longer available',
        'position closed',
        'we are no longer accepting',
        'applications are closed',
      ];

      for (const pattern of expiredPatterns) {
        if (lowerContent.includes(pattern)) {
          isAvailable = false;
          reason = `Job appears to be filled: "${pattern}" found on page`;
          break;
        }
      }

      // Check if content is too short (might be a redirect/error page)
      if (content.length < 200) {
        isAvailable = false;
        reason = 'Job posting page has minimal content (may have been removed)';
      }
    }

    // Update job status if no longer available
    if (!isAvailable && job.status !== 'filled') {
      const { error: updateError } = await supabaseClient
        .from('jobs')
        .update({ status: 'filled', updated_at: new Date().toISOString() })
        .eq('id', jobId);

      if (updateError) {
        console.error('Error updating job status:', updateError);
      } else {
        console.log(`Marked job ${job.title} as filled`);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        jobId: job.id,
        jobTitle: job.title,
        available: isAvailable,
        reason,
        statusUpdated: !isAvailable && job.status !== 'filled',
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error checking job availability:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to check job availability' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
