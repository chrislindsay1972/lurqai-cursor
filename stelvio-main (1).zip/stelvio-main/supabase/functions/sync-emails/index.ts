// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface GraphMessage {
  id: string;
  internetMessageId: string;
  subject: string;
  from: { emailAddress: { address: string; name?: string } };
  toRecipients: Array<{ emailAddress: { address: string; name?: string } }>;
  ccRecipients?: Array<{ emailAddress: { address: string; name?: string } }>;
  bccRecipients?: Array<{ emailAddress: { address: string; name?: string } }>;
  sentDateTime: string;
  receivedDateTime?: string;
  body: { contentType: string; content: string };
  hasAttachments: boolean;
  isRead: boolean;
  parentFolderId: string;
}

// Helper to extract domain from email
function extractDomain(email: string): string | null {
  const match = email.match(/@([^@]+)$/);
  return match ? match[1].toLowerCase() : null;
}

// Refresh access token using refresh token
async function refreshAccessToken(refreshToken: string): Promise<{ accessToken: string; newRefreshToken?: string }> {
  const MS365_CLIENT_ID = Deno.env.get("MS365_CLIENT_ID");
  const MS365_CLIENT_SECRET = Deno.env.get("MS365_CLIENT_SECRET");
  const MS365_TENANT_ID = Deno.env.get("MS365_TENANT_ID");

  if (!MS365_CLIENT_ID || !MS365_CLIENT_SECRET || !MS365_TENANT_ID) {
    throw new Error("MS365 credentials not configured");
  }

  const tokenResponse = await fetch(
    `https://login.microsoftonline.com/${MS365_TENANT_ID}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: MS365_CLIENT_ID,
        client_secret: MS365_CLIENT_SECRET,
        refresh_token: refreshToken,
        grant_type: "refresh_token",
        scope: "https://graph.microsoft.com/Mail.Read https://graph.microsoft.com/Mail.ReadWrite https://graph.microsoft.com/User.Read offline_access",
      }),
    }
  );

  if (!tokenResponse.ok) {
    const errorText = await tokenResponse.text();
    console.error("Token refresh failed:", errorText);
    throw new Error("Failed to refresh access token");
  }

  const tokens = await tokenResponse.json();
  return {
    accessToken: tokens.access_token,
    newRefreshToken: tokens.refresh_token,
  };
}

// Fetch messages from a specific folder
async function fetchMessagesFromFolder(
  accessToken: string,
  folderName: string,
  sinceDate?: string
): Promise<GraphMessage[]> {
  const messages: GraphMessage[] = [];
  let url = `https://graph.microsoft.com/v1.0/me/mailFolders/${folderName}/messages?$top=50&$orderby=sentDateTime desc&$select=id,internetMessageId,subject,from,toRecipients,ccRecipients,bccRecipients,sentDateTime,receivedDateTime,body,hasAttachments,isRead,parentFolderId`;
  
  if (sinceDate) {
    url += `&$filter=sentDateTime ge ${sinceDate}`;
  }

  let pageCount = 0;
  const maxPages = 10; // Limit to prevent excessive API calls

  while (url && pageCount < maxPages) {
    const response = await fetch(url, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Failed to fetch ${folderName} messages:`, errorText);
      throw new Error(`Failed to fetch messages from ${folderName}`);
    }

    const data = await response.json();
    messages.push(...(data.value || []));
    url = data["@odata.nextLink"];
    pageCount++;
  }

  return messages;
}

// Sync a single connection
async function syncConnection(
  supabaseClient: any,
  connection: any
): Promise<{ syncedCount: number; errorCount: number }> {
  console.log(`Syncing emails for connection: ${connection.connection_name}`);

  // Check if OAuth is configured
  if (!connection.use_oauth || !connection.oauth_refresh_token) {
    console.log(`Connection ${connection.id} is not OAuth configured, skipping`);
    return { syncedCount: 0, errorCount: 0 };
  }

  // Refresh access token
  let accessToken: string;
  let newRefreshToken: string | undefined;
  
  try {
    const tokens = await refreshAccessToken(connection.oauth_refresh_token);
    accessToken = tokens.accessToken;
    newRefreshToken = tokens.newRefreshToken;
    
    // Update refresh token if a new one was issued
    if (newRefreshToken) {
      await supabaseClient
        .from("email_connections")
        .update({ oauth_refresh_token: newRefreshToken })
        .eq("id", connection.id);
    }
  } catch (error: any) {
    console.error("Token refresh failed:", error);
    await supabaseClient
      .from("email_connections")
      .update({
        last_sync_status: "token_expired",
        updated_at: new Date().toISOString(),
      })
      .eq("id", connection.id);
      
    return { syncedCount: 0, errorCount: 1 };
  }

  // Determine sync date (last sync or 30 days ago for first sync)
  const sinceDate = connection.last_sync_at 
    ? new Date(connection.last_sync_at).toISOString()
    : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

  // Fetch messages from Inbox and Sent Items
  console.log("Fetching messages since:", sinceDate);
  
  const [inboxMessages, sentMessages] = await Promise.all([
    fetchMessagesFromFolder(accessToken, "inbox", sinceDate),
    fetchMessagesFromFolder(accessToken, "sentitems", sinceDate),
  ]);

  console.log(`Fetched ${inboxMessages.length} inbox messages and ${sentMessages.length} sent messages`);

  const allMessages = [
    ...inboxMessages.map(m => ({ ...m, folder: "Inbox" })),
    ...sentMessages.map(m => ({ ...m, folder: "Sent" })),
  ];

  let syncedCount = 0;
  let errorCount = 0;

  // Process each message
  for (const message of allMessages) {
    try {
      await processMessage(supabaseClient, message, connection.id);
      syncedCount++;
    } catch (error) {
      console.error(`Error processing message ${message.id}:`, error);
      errorCount++;
    }
  }

  // --- Reply detection: auto-pause campaigns ---
  // Check incoming emails against active campaign recipients
  for (const msg of inboxMessages) {
    try {
      const senderEmail = msg.from?.emailAddress?.address?.toLowerCase();
      if (!senderEmail) continue;

      // Find any active campaign stakeholder states for this sender
      const { data: stakeholders } = await supabaseClient
        .from("stakeholders")
        .select("id")
        .eq("email", senderEmail)
        .limit(5);

      if (!stakeholders || stakeholders.length === 0) continue;

      const stakeholderIds = stakeholders.map((s: any) => s.id);

      // Find running campaigns with these stakeholders
      const { data: activeStates } = await supabaseClient
        .from("stakeholder_campaign_states")
        .select("id, campaign_id, stakeholder_id, started_at")
        .in("stakeholder_id", stakeholderIds)
        .eq("status", "in_progress");

      if (!activeStates || activeStates.length === 0) continue;

      const emailReceivedAt = msg.receivedDateTime || msg.sentDateTime;

      for (const state of activeStates) {
        // Skip replies that were received before the campaign started
        if (state.started_at && emailReceivedAt) {
          const replyTime = new Date(emailReceivedAt).getTime();
          const campaignStartTime = new Date(state.started_at).getTime();
          if (replyTime < campaignStartTime) {
            console.log(`Skipping reply from ${senderEmail} — received ${emailReceivedAt} before campaign started ${state.started_at}`);
            continue;
          }
        }

        // Pause the stakeholder's campaign state
        await supabaseClient
          .from("stakeholder_campaign_states")
          .update({ status: "paused_reply_detected" })
          .eq("id", state.id);

        // Log metric event
        await supabaseClient.from("campaign_metrics").insert({
          campaign_id: state.campaign_id,
          stakeholder_id: state.stakeholder_id,
          email_address: senderEmail,
          event_type: "reply_detected",
          event_data: {
            subject: msg.subject,
            received_at: emailReceivedAt,
            auto_paused: true,
          },
        });

        console.log(`Reply detected from ${senderEmail} — auto-paused campaign state ${state.id}`);
      }
    } catch (replyErr) {
      console.error("Reply detection error:", replyErr);
    }
  }

  // Update sync status
  await supabaseClient
    .from("email_connections")
    .update({
      last_sync_at: new Date().toISOString(),
      last_sync_status: errorCount === 0 ? "success" : "partial",
      updated_at: new Date().toISOString(),
    })
    .eq("id", connection.id);

  return { syncedCount, errorCount };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    
    // Admin client for database operations
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Parse request body
    let connectionId: string | null = null;
    let syncAll = false;
    
    try {
      const body = await req.json();
      connectionId = body.connectionId;
      syncAll = body.syncAll === true;
    } catch {
      // Empty body is OK for scheduled syncs - will sync all active connections
      syncAll = true;
    }

    // If called with a user token and specific connectionId, verify auth
    if (connectionId && authHeader?.startsWith("Bearer ")) {
      const supabaseUserClient = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_ANON_KEY") ?? "",
        { global: { headers: { Authorization: authHeader } } }
      );

      const { data: { user }, error: userError } = await supabaseUserClient.auth.getUser();
      if (userError || !user) {
        console.error("Auth getUser error:", userError);
        return new Response(
          JSON.stringify({ error: "Unauthorized" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Check user role
      const { data: userRole, error: roleError } = await supabaseClient
        .rpc("get_user_role", { _user_id: user.id });

      if (roleError || !userRole || !["recruiter", "admin"].includes(userRole)) {
        return new Response(
          JSON.stringify({ error: "Insufficient permissions" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      console.log(`Authenticated user: ${user.id}, syncing connection: ${connectionId}`);
    } else if (!syncAll) {
      // If no auth and not syncing all, require connectionId at minimum
      return new Response(
        JSON.stringify({ error: "Connection ID or syncAll flag required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get connections to sync
    let connections;
    if (connectionId) {
      const { data, error } = await supabaseClient
        .from("email_connections")
        .select("*")
        .eq("id", connectionId)
        .single();

      if (error || !data) {
        return new Response(
          JSON.stringify({ error: "Connection not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      connections = [data];
    } else {
      // Sync all active OAuth connections
      const { data, error } = await supabaseClient
        .from("email_connections")
        .select("*")
        .eq("is_active", true)
        .eq("use_oauth", true);

      if (error) {
        throw error;
      }
      connections = data || [];
    }

    console.log(`Syncing ${connections.length} connection(s)`);

    let totalSynced = 0;
    let totalErrors = 0;
    const results: Array<{ connectionId: string; syncedCount: number; errorCount: number }> = [];

    for (const connection of connections) {
      try {
        const { syncedCount, errorCount } = await syncConnection(supabaseClient, connection);
        totalSynced += syncedCount;
        totalErrors += errorCount;
        results.push({ connectionId: connection.id, syncedCount, errorCount });
      } catch (error: any) {
        console.error(`Error syncing connection ${connection.id}:`, error);
        totalErrors++;
        results.push({ connectionId: connection.id, syncedCount: 0, errorCount: 1 });
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        totalSynced,
        totalErrors,
        connectionsProcessed: connections.length,
        results,
        message: `Synced ${totalSynced} emails across ${connections.length} connection(s)${totalErrors > 0 ? `, ${totalErrors} errors` : ""}`,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: any) {
    console.error("Error syncing emails:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// Process a single message and link to entities
async function processMessage(
  supabase: any,
  message: GraphMessage & { folder: string },
  connectionId: string
) {
  const allAddresses = [
    message.from.emailAddress.address,
    ...message.toRecipients.map((t) => t.emailAddress.address),
    ...(message.ccRecipients?.map((c) => c.emailAddress.address) || []),
    ...(message.bccRecipients?.map((c) => c.emailAddress.address) || []),
  ].map(a => a.toLowerCase());

  const domains = [...new Set(allAddresses.map(extractDomain).filter(Boolean))];

  // Find matching company by domain
  let companyId: string | null = null;
  if (domains.length > 0) {
    const { data: companies } = await supabase
      .from("companies")
      .select("id, domain")
      .in("domain", domains)
      .limit(1);

    if (companies && companies.length > 0) {
      companyId = companies[0].id;
    }
  }

  // Find matching stakeholder by email
  let stakeholderId: string | null = null;
  const { data: stakeholders } = await supabase
    .from("stakeholders")
    .select("id, email")
    .in("email", allAddresses)
    .limit(1);

  if (stakeholders && stakeholders.length > 0) {
    stakeholderId = stakeholders[0].id;
  }

  // Determine body content
  const bodyHtml = message.body.contentType === "html" ? message.body.content : null;
  const bodyText = message.body.contentType === "text" ? message.body.content : null;

  // Upsert email record
  const { error: upsertError } = await supabase
    .from("emails")
    .upsert(
      {
        connection_id: connectionId,
        message_id: message.internetMessageId || message.id,
        folder: message.folder,
        subject: message.subject,
        from_address: message.from.emailAddress.address,
        from_name: message.from.emailAddress.name,
        to_addresses: message.toRecipients.map((t) => t.emailAddress.address),
        cc_addresses: message.ccRecipients?.map((c) => c.emailAddress.address) || [],
        bcc_addresses: message.bccRecipients?.map((b) => b.emailAddress.address) || [],
        body_text: bodyText,
        body_html: bodyHtml,
        sent_at: message.sentDateTime,
        received_at: message.receivedDateTime,
        has_attachments: message.hasAttachments,
        is_read: message.isRead,
        company_id: companyId,
        stakeholder_id: stakeholderId,
      },
      { onConflict: "connection_id,message_id" }
    );

  if (upsertError) {
    throw upsertError;
  }
}
