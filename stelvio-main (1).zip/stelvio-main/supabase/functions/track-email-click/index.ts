import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url);
    const campaignId = url.searchParams.get("c");
    const stakeholderId = url.searchParams.get("s");
    const stepId = url.searchParams.get("st");
    const email = url.searchParams.get("e");
    const targetUrl = url.searchParams.get("url");

    if (!targetUrl) {
      return new Response("Missing redirect URL", { status: 400 });
    }

    // Validate targetUrl is a proper URL
    try {
      const parsed = new URL(targetUrl);
      if (!["http:", "https:"].includes(parsed.protocol)) {
        return new Response("Invalid redirect URL", { status: 400 });
      }
    } catch {
      return new Response("Invalid redirect URL", { status: 400 });
    }

    // Record click asynchronously — don't block the redirect
    if (campaignId && stakeholderId && email) {
      // Validate parameter formats before recording
      const validParams = UUID_REGEX.test(campaignId) &&
        UUID_REGEX.test(stakeholderId) &&
        (!stepId || UUID_REGEX.test(stepId)) &&
        EMAIL_REGEX.test(email) && email.length <= 255;

      if (validParams) {
        try {
          const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
          const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
          const supabase = createClient(supabaseUrl, supabaseServiceKey);

          await supabase.from("campaign_metrics").insert({
            campaign_id: campaignId,
            stakeholder_id: stakeholderId,
            step_id: stepId || null,
            email_address: email,
            event_type: "clicked",
            event_data: {
              clicked_url: targetUrl,
              user_agent: req.headers.get("user-agent") || "unknown",
              ip: req.headers.get("x-forwarded-for") || req.headers.get("cf-connecting-ip") || "unknown",
            },
          });
        } catch (dbErr) {
          console.error("Click tracking DB error:", dbErr);
        }
      }
    }

    // 302 redirect to the original URL
    return new Response(null, {
      status: 302,
      headers: {
        Location: targetUrl,
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
      },
    });
  } catch (err) {
    console.error("Click tracking error:", err);
    const url = new URL(req.url);
    const targetUrl = url.searchParams.get("url");
    if (targetUrl) {
      return new Response(null, { status: 302, headers: { Location: targetUrl } });
    }
    return new Response("Redirect failed", { status: 500 });
  }
});
