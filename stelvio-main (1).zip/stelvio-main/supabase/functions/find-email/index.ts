const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface FindEmailRequest {
  domain: string;
  firstName?: string;
  lastName?: string;
}

interface HunterEmailFinderResponse {
  data: {
    first_name: string;
    last_name: string;
    email: string;
    score: number;
    domain: string;
    accept_all: boolean;
    position: string;
    twitter: string | null;
    linkedin_url: string | null;
    phone_number: string | null;
    company: string;
    sources: { domain: string; uri: string; extracted_on: string; last_seen_on: string; still_on_page: boolean }[];
    verification: {
      date: string;
      status: "valid" | "invalid" | "accept_all" | "webmail" | "disposable" | "unknown";
    };
  };
  errors?: { id: string; code: number; details: string }[];
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { domain, firstName, lastName }: FindEmailRequest = await req.json();

    if (!domain) {
      return new Response(
        JSON.stringify({ error: "Domain is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const HUNTER_API_KEY = Deno.env.get("HUNTER_API_KEY");
    if (!HUNTER_API_KEY) {
      console.error("HUNTER_API_KEY not configured");
      return new Response(
        JSON.stringify({ error: "Hunter API key not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let apiUrl = `https://api.hunter.io/v2/email-finder?domain=${encodeURIComponent(domain)}&api_key=${HUNTER_API_KEY}`;
    
    if (firstName) {
      apiUrl += `&first_name=${encodeURIComponent(firstName)}`;
    }
    if (lastName) {
      apiUrl += `&last_name=${encodeURIComponent(lastName)}`;
    }

    console.log(`Finding email for: ${firstName} ${lastName} @ ${domain}`);

    const response = await fetch(apiUrl, { method: "GET" });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Hunter API error:", response.status, errorText);
      
      return new Response(
        JSON.stringify({ 
          found: false,
          error: `Hunter API error: ${response.status}`,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const hunterData: HunterEmailFinderResponse = await response.json();
    console.log("Hunter finder response:", JSON.stringify(hunterData));

    if (hunterData.errors && hunterData.errors.length > 0) {
      return new Response(
        JSON.stringify({ 
          found: false,
          error: hunterData.errors[0].details,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!hunterData.data?.email) {
      return new Response(
        JSON.stringify({ found: false }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let validationStatus: string;
    switch (hunterData.data.verification?.status) {
      case "valid":
        validationStatus = "deliverable";
        break;
      case "invalid":
        validationStatus = "undeliverable";
        break;
      case "accept_all":
        validationStatus = "catch_all";
        break;
      default:
        validationStatus = "unknown";
    }

    return new Response(
      JSON.stringify({
        found: true,
        email: hunterData.data.email,
        score: hunterData.data.score,
        validationStatus,
        acceptAll: hunterData.data.accept_all,
        sources: hunterData.data.sources?.slice(0, 3) || [],
        position: hunterData.data.position,
        company: hunterData.data.company,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Email finder error:", error);
    return new Response(
      JSON.stringify({ 
        found: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
