// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
// Calculate SHA-256 hash of file
async function sha256Hash(data: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // =====================================================
    // AUTHENTICATION CHECK
    // =====================================================
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error("Missing authorization header");
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      console.error("User authentication failed:", userError?.message);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // =====================================================
    // ROLE-BASED AUTHORIZATION (recruiter or admin only)
    // =====================================================
    // NOTE: Do NOT query public.user_roles directly here. It's protected by RLS,
    // which can cause false negatives. Use the SECURITY DEFINER RPC instead.
    const { data: role, error: roleError } = await supabaseClient
      .rpc('get_user_role', { _user_id: user.id });

    if (roleError || !role || !['recruiter', 'admin'].includes(role)) {
      console.error("Insufficient permissions for user:", user.id, role);
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions. Only recruiters and admins can scan files.' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // =====================================================
    // VIRUSTOTAL API CHECK
    // =====================================================
    const VIRUSTOTAL_API_KEY = Deno.env.get('VIRUSTOTAL_API_KEY');
    if (!VIRUSTOTAL_API_KEY) {
      throw new Error('VirusTotal API key not configured');
    }

    const formData = await req.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return new Response(
        JSON.stringify({ error: 'No file provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`User ${user.id} scanning file: ${file.name}, size: ${file.size} bytes`);

    // Get file content and calculate hash
    const fileBuffer = await file.arrayBuffer();
    const fileHash = await sha256Hash(fileBuffer);
    console.log(`File SHA-256: ${fileHash}`);

    // Step 1: Check if file was already scanned by hash (faster, no rate limit)
    const hashCheckResponse = await fetch(
      `https://www.virustotal.com/api/v3/files/${fileHash}`,
      {
        headers: { 'x-apikey': VIRUSTOTAL_API_KEY },
      }
    );

    if (hashCheckResponse.ok) {
      // File already scanned, use existing results
      const existingResult = await hashCheckResponse.json();
      const stats = existingResult.data?.attributes?.last_analysis_stats;
      
      if (stats) {
        const malicious = stats.malicious || 0;
        const suspicious = stats.suspicious || 0;
        const isSafe = malicious === 0 && suspicious === 0;
        
        console.log(`Using cached scan result - Malicious: ${malicious}, Suspicious: ${suspicious}`);
        
        return new Response(
          JSON.stringify({
            status: 'completed',
            safe: isSafe,
            cached: true,
            stats: {
              malicious,
              suspicious,
              harmless: stats.harmless || 0,
              undetected: stats.undetected || 0,
            },
            message: isSafe 
              ? 'File passed virus scan (cached)' 
              : `File flagged by ${malicious + suspicious} security vendors`,
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Step 2: File not in database, upload for scanning
    console.log('File not in VirusTotal database, uploading for scan...');
    
    const uploadFormData = new FormData();
    uploadFormData.append('file', new Blob([fileBuffer]), file.name);

    const uploadResponse = await fetch('https://www.virustotal.com/api/v3/files', {
      method: 'POST',
      headers: {
        'x-apikey': VIRUSTOTAL_API_KEY,
      },
      body: uploadFormData,
    });

    if (!uploadResponse.ok) {
      const errorData = await uploadResponse.json().catch(() => ({}));
      console.error(`VirusTotal upload error (${uploadResponse.status}):`, JSON.stringify(errorData));

      // Handle 401/403 - invalid API key
      if (uploadResponse.status === 401 || uploadResponse.status === 403) {
        console.error('VirusTotal API key invalid or unauthorized');
        throw new Error('VirusTotal API key is invalid. Please update it in settings.');
      }

      // Handle 429 - rate limit exceeded, allow through as we can't scan right now
      if (uploadResponse.status === 429) {
        console.log('VirusTotal rate limit hit - allowing file through');
        return new Response(
          JSON.stringify({ status: 'pending', safe: true, message: 'Scan rate limit reached. File allowed pending verification.' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Handle 409 Conflict - file is already being analyzed
      if (uploadResponse.status === 409) {
        console.log('File already being analyzed, waiting for results...');
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        const retryHashCheck = await fetch(
          `https://www.virustotal.com/api/v3/files/${fileHash}`,
          { headers: { 'x-apikey': VIRUSTOTAL_API_KEY } }
        );
        
        if (retryHashCheck.ok) {
          const retryResult = await retryHashCheck.json();
          const stats = retryResult.data?.attributes?.last_analysis_stats;
          
          if (stats) {
            const malicious = stats.malicious || 0;
            const suspicious = stats.suspicious || 0;
            const isSafe = malicious === 0 && suspicious === 0;
            return new Response(
              JSON.stringify({
                status: 'completed',
                safe: isSafe,
                stats: { malicious, suspicious, harmless: stats.harmless || 0, undetected: stats.undetected || 0 },
                message: isSafe ? 'File passed virus scan' : `File flagged by ${malicious + suspicious} security vendors`,
              }),
              { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
          }
        }
        
        return new Response(
          JSON.stringify({ status: 'pending', safe: true, message: 'Scan in progress. File allowed pending verification.' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      // For any other error, allow the file through rather than blocking the user
      console.log(`VirusTotal upload failed (${uploadResponse.status}) - allowing file through`);
      return new Response(
        JSON.stringify({ status: 'pending', safe: true, message: 'Scan service temporarily unavailable. File allowed.' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const uploadResult = await uploadResponse.json();
    const analysisId = uploadResult.data?.id;

    if (!analysisId) {
      throw new Error('No analysis ID returned from VirusTotal');
    }

    console.log(`Analysis ID: ${analysisId}`);

    // Step 3: Poll for analysis results (with timeout)
    // Edge functions have ~50s limit, so max 15 attempts * 2s = 30s to stay safe
    let analysisComplete = false;
    let attempts = 0;
    const maxAttempts = 15;
    let scanResult = null;

    while (!analysisComplete && attempts < maxAttempts) {
      attempts++;
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const analysisResponse = await fetch(
        `https://www.virustotal.com/api/v3/analyses/${analysisId}`,
        {
          headers: { 'x-apikey': VIRUSTOTAL_API_KEY },
        }
      );

      if (!analysisResponse.ok) {
        console.log(`Analysis check failed, attempt ${attempts}/${maxAttempts}`);
        continue;
      }

      const analysisData = await analysisResponse.json();
      const status = analysisData.data?.attributes?.status;

      if (status === 'completed') {
        analysisComplete = true;
        scanResult = analysisData.data?.attributes?.stats;
        console.log('Scan completed:', scanResult);
      } else {
        console.log(`Scan in progress... attempt ${attempts}/${maxAttempts}`);
      }
    }

    if (!analysisComplete) {
      // Return a "pending" status if scan takes too long
      return new Response(
        JSON.stringify({
          status: 'pending',
          message: 'Virus scan is still in progress. File will be checked.',
          safe: true, // Allow upload but flag for later verification
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if any malicious or suspicious detections
    const malicious = scanResult?.malicious || 0;
    const suspicious = scanResult?.suspicious || 0;
    const isSafe = malicious === 0 && suspicious === 0;

    console.log(`Scan result - Malicious: ${malicious}, Suspicious: ${suspicious}, Safe: ${isSafe}`);

    return new Response(
      JSON.stringify({
        status: 'completed',
        safe: isSafe,
        stats: {
          malicious,
          suspicious,
          harmless: scanResult?.harmless || 0,
          undetected: scanResult?.undetected || 0,
        },
        message: isSafe 
          ? 'File passed virus scan' 
          : `File flagged by ${malicious + suspicious} security vendors`,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Virus scan error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'An error occurred while scanning the file',
        safe: false,
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
