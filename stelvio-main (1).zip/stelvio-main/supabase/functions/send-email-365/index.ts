// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface InlineAttachment {
  contentId: string;
  contentBytes: string; // base64-encoded
  contentType: string;
  name: string;
}

interface SendEmailRequest {
  connectionId?: string;
  to: string | string[];
  cc?: string[];
  bcc?: string[];
  subject: string;
  body: string;
  bodyText?: string;
  isHtml?: boolean;
  customHeaders?: Record<string, string>;
  inlineAttachments?: InlineAttachment[];
}

// Sanitize email header to prevent injection attacks
function sanitizeEmailHeader(input: string): string {
  return input.replace(/[\r\n]/g, '').trim();
}

// Validate email format
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254;
}

// Refresh access token using refresh token
async function refreshAccessToken(refreshToken: string): Promise<{ accessToken: string; newRefreshToken?: string }> {
  const MS365_CLIENT_ID = Deno.env.get("MS365_CLIENT_ID");
  const MS365_CLIENT_SECRET = Deno.env.get("MS365_CLIENT_SECRET");
  const MS365_TENANT_ID = Deno.env.get("MS365_TENANT_ID");

  if (!MS365_CLIENT_ID || !MS365_CLIENT_SECRET || !MS365_TENANT_ID) {
    throw new Error("MS365 OAuth credentials not configured");
  }

  const tokenResponse = await fetch(
    `https://login.microsoftonline.com/${MS365_TENANT_ID}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: MS365_CLIENT_ID,
        client_secret: MS365_CLIENT_SECRET,
        refresh_token: refreshToken,
        grant_type: "refresh_token",
        scope: "https://graph.microsoft.com/Mail.Send https://graph.microsoft.com/Mail.ReadWrite https://graph.microsoft.com/User.Read offline_access",
      }),
    }
  );

  if (!tokenResponse.ok) {
    const errorText = await tokenResponse.text();
    console.error("Token refresh failed:", errorText);
    throw new Error("Failed to refresh access token");
  }

  const tokens = await tokenResponse.json();
  return {
    accessToken: tokens.access_token,
    newRefreshToken: tokens.refresh_token,
  };
}

// Send via Microsoft Graph API
async function sendViaGraph(
  accessToken: string,
  to: string[],
  cc: string[] | undefined,
  bcc: string[] | undefined,
  subject: string,
  body: string,
  isHtml: boolean,
  customHeaders?: Record<string, string>,
  inlineAttachments?: InlineAttachment[],
): Promise<void> {
  const messagePayload: any = {
    message: {
      subject: subject,
      body: {
        contentType: isHtml ? "HTML" : "Text",
        content: body,
      },
      toRecipients: to.map((email) => ({
        emailAddress: { address: email },
      })),
    },
    saveToSentItems: true,
  };

  if (cc && cc.length > 0) {
    messagePayload.message.ccRecipients = cc.map((email) => ({
      emailAddress: { address: email },
    }));
  }

  if (bcc && bcc.length > 0) {
    messagePayload.message.bccRecipients = bcc.map((email) => ({
      emailAddress: { address: email },
    }));
  }

  // Add custom internet message headers (List-Unsubscribe, etc.)
  if (customHeaders && Object.keys(customHeaders).length > 0) {
    messagePayload.message.internetMessageHeaders = Object.entries(customHeaders).map(
      ([name, value]) => ({ name, value })
    );
  }

  // Add attachments (inline CID images and regular file attachments)
  if (inlineAttachments && inlineAttachments.length > 0) {
    messagePayload.message.attachments = inlineAttachments.map((att) => ({
      "@odata.type": "#microsoft.graph.fileAttachment",
      name: att.name,
      contentType: att.contentType,
      contentBytes: att.contentBytes,
      ...(att.contentId ? { contentId: att.contentId, isInline: true } : { isInline: false }),
    }));
  }

  console.log("Sending email via Graph API:", {
    to: to,
    cc: cc,
    bcc: bcc,
    subject: subject,
    bodyLength: body.length,
    isHtml: isHtml,
    customHeaders: customHeaders ? Object.keys(customHeaders) : [],
    inlineAttachments: inlineAttachments?.length || 0,
  });

  const sendResponse = await fetch(
    "https://graph.microsoft.com/v1.0/me/sendMail",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(messagePayload),
    }
  );

  const responseStatus = sendResponse.status;
  const responseHeaders: Record<string, string> = {};
  sendResponse.headers.forEach((value, key) => {
    responseHeaders[key] = value;
  });

  console.log("Graph API response status:", responseStatus);

  if (!sendResponse.ok) {
    const errorText = await sendResponse.text();
    console.error("Graph API send failed:", {
      status: responseStatus,
      headers: responseHeaders,
      body: errorText,
    });
    throw new Error(`Failed to send email (${responseStatus}): ${errorText}`);
  }

  const responseBody = await sendResponse.text();
  console.log("Graph API response body:", responseBody || "(empty - expected for 202 Accepted)");
  console.log("Email successfully queued for delivery");
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Auth check
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Authentication required" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const isServiceRole = token === serviceRoleKey;

    // Admin client for DB operations
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      serviceRoleKey
    );

    if (!isServiceRole) {
      // Validate user auth for non-service-role calls
      const supabaseUserClient = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_ANON_KEY") ?? "",
        { global: { headers: { Authorization: authHeader } } }
      );

      const { data: { user }, error: userError } = await supabaseUserClient.auth.getUser();
      if (userError || !user) {
        console.error("User authentication failed:", userError?.message);
        return new Response(
          JSON.stringify({ error: "Unauthorized" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Check user role
      const { data: userRole, error: roleError } = await supabaseClient
        .rpc("get_user_role", { _user_id: user.id });

      if (roleError || !userRole || !["recruiter", "admin"].includes(userRole)) {
        return new Response(
          JSON.stringify({ error: "Insufficient permissions. Only recruiters and admins can send emails." }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Parse request
    const { connectionId, to, cc, bcc, subject, body, bodyText, isHtml = false, customHeaders, inlineAttachments }: SendEmailRequest = await req.json();

    if (!to || !subject || !body) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: to, subject, body" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Sanitize subject
    const sanitizedSubject = sanitizeEmailHeader(subject);
    if (sanitizedSubject.length > 200) {
      return new Response(
        JSON.stringify({ error: "Subject line too long (max 200 characters)" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate recipients
    const rawRecipients = Array.isArray(to) ? to : [to];
    if (rawRecipients.length > 50) {
      return new Response(
        JSON.stringify({ error: "Too many recipients (max 50)" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const recipients: string[] = [];
    for (const recipient of rawRecipients) {
      const sanitizedRecipient = sanitizeEmailHeader(recipient);
      if (!isValidEmail(sanitizedRecipient)) {
        return new Response(
          JSON.stringify({ error: `Invalid email address: ${sanitizedRecipient}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      recipients.push(sanitizedRecipient);
    }

    // Validate body length
    if (body.length > 500000) {
      return new Response(
        JSON.stringify({ error: "Email body too large (max 500KB)" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get connection for OAuth
    let connection;
    if (connectionId) {
      const { data, error } = await supabaseClient
        .from("email_connections")
        .select("*")
        .eq("id", connectionId)
        .single();
      
      if (error || !data) {
        return new Response(
          JSON.stringify({ error: "Connection not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      connection = data;
    } else {
      // Get first active OAuth connection
      const { data, error } = await supabaseClient
        .from("email_connections")
        .select("*")
        .eq("is_active", true)
        .eq("use_oauth", true)
        .limit(1)
        .maybeSingle();
      
      if (error || !data) {
        return new Response(
          JSON.stringify({ error: "No active email connection found. Please connect an Office 365 account." }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      connection = data;
    }

    if (!connection.use_oauth || !connection.oauth_refresh_token) {
      return new Response(
        JSON.stringify({ error: "OAuth not configured for this connection" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Refresh access token
    let accessToken: string;
    let newRefreshToken: string | undefined;

    try {
      const tokens = await refreshAccessToken(connection.oauth_refresh_token);
      accessToken = tokens.accessToken;
      newRefreshToken = tokens.newRefreshToken;

      if (newRefreshToken) {
        await supabaseClient
          .from("email_connections")
          .update({ oauth_refresh_token: newRefreshToken })
          .eq("id", connection.id);
      }
    } catch (error: any) {
      console.error("Token refresh failed:", error);
      await supabaseClient
        .from("email_connections")
        .update({
          last_sync_status: "token_expired",
          updated_at: new Date().toISOString(),
        })
        .eq("id", connection.id);

      return new Response(
        JSON.stringify({ error: "OAuth token expired. Please reconnect your Office 365 account." }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Send via Graph API
    console.log(`${isServiceRole ? "Service-role" : "User"} sending email to ${recipients.join(", ")}`);

    try {
      await sendViaGraph(accessToken, recipients, cc, bcc, sanitizedSubject, body, isHtml, customHeaders, inlineAttachments);
      console.log(`Email sent successfully to ${recipients.join(", ")}`);

      return new Response(
        JSON.stringify({
          success: true,
          message: `Email sent to ${recipients.join(", ")}`,
          results: recipients.map(email => ({ email, success: true })),
          totalSent: recipients.length,
          totalFailed: 0,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (error: any) {
      console.error("Failed to send email:", error);
      return new Response(
        JSON.stringify({
          success: false,
          error: error.message,
          results: recipients.map(email => ({ email, success: false, error: error.message })),
          totalSent: 0,
          totalFailed: recipients.length,
        }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (error: any) {
    console.error("Error in send-email-365 function:", error.message);
    return new Response(
      JSON.stringify({ error: "An error occurred while processing your request" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};

Deno.serve(handler);
