// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

// Shared list of known large/enterprise companies for pre-filtering and post-scoring rejection
// Maintain in ONE place to avoid drift between the two usages
const KNOWN_LARGE_COMPANIES = [
  'microsoft', 'microsoft corporation', 'google', 'alphabet', 'amazon', 'aws', 'meta', 'facebook',
  'apple', 'ibm', 'oracle', 'salesforce', 'salesforce.com', 'cisco', 'intel', 'adobe', 'vmware',
  'dell', 'hp', 'hewlett packard', 'hpe', 'sap', 'accenture', 'deloitte', 'ey', 'ernst & young',
  'pwc', 'pricewaterhousecoopers', 'kpmg', 'mckinsey', 'bain', 'bcg', 'boston consulting',
  'jpmorgan', 'jp morgan', 'jpmorganchase', 'jpmorgan chase', 'chase', 'goldman sachs', 'morgan stanley', 'bank of america', 'wells fargo',
  'citigroup', 'citi', 'citibank', 'barclays', 'hsbc', 'ubs', 'credit suisse', 'deutsche bank',
  'walmart', 'target', 'costco', 'home depot', 'lowes', 'cvs', 'walgreens',
  'at&t', 'verizon', 't-mobile', 'comcast', 'disney', 'netflix', 'spotify',
  'uber', 'lyft', 'airbnb', 'booking.com', 'expedia', 'paypal', 'visa', 'mastercard',
  'nvidia', 'amd', 'qualcomm', 'broadcom', 'texas instruments', 'micron',
  'boeing', 'lockheed martin', 'raytheon', 'northrop grumman', 'general dynamics',
  'general electric', 'ge', 'siemens', 'honeywell', 'johnson & johnson', 'pfizer', 'merck',
  'coca-cola', 'pepsico', 'nestle', 'unilever', 'procter & gamble', 'p&g',
  'fedex', 'ups', 'dhl', 'usps', 'linkedin', 'twitter', 'x corp', 'snap', 'snapchat',
  'tiktok', 'bytedance', 'zoom', 'slack', 'servicenow', 'workday', 'snowflake', 'databricks',
  'crowdstrike', 'palo alto networks', 'fortinet', 'splunk', 'datadog',
  'ebay', 'shopify', 'square', 'block', 'intuit', 'autodesk', 'citrix',
  'red hat', 'github', 'gitlab', 'atlassian', 'zendesk', 'hubspot', 'twilio',
  'dropbox', 'box', 'docusign', 'okta', 'cloudflare', 'akamai', 'fastly',
  'guidehouse', 'booz allen', 'booz allen hamilton', 'capgemini', 'cognizant', 'infosys', 'tcs', 'wipro', 'hcl',
  'contact government services', 'cgs', 'allstate', 'allstate insurance', 'state farm', 'geico', 'progressive',
  'coforge', 'niit', 'tech mahindra', 'l&t infotech', 'mphasis', 'mindtree', 'hexaware',
  'photon', 'turing',
];

// Helper function to check if a company name matches the known large companies list
function isKnownLargeCompanyMatch(companyName: string): boolean {
  const companyNameLower = companyName.toLowerCase().trim();
  return KNOWN_LARGE_COMPANIES.some(name => {
    if (companyNameLower === name) return true;
    if (companyNameLower.startsWith(name + ' ') || companyNameLower.startsWith(name + ',')) return true;
    if (companyNameLower.endsWith(' ' + name)) return true;
    if (companyNameLower.includes(' ' + name + ' ')) return true;
    const knownWords = name.split(' ');
    if (knownWords.length > 1) {
      const companyWords = companyNameLower.split(/[\s,&]+/);
      let matchIdx = 0;
      for (const word of companyWords) {
        if (word === knownWords[matchIdx]) {
          matchIdx++;
          if (matchIdx === knownWords.length) return true;
        } else if (matchIdx > 0) { matchIdx = 0; }
      }
    }
    return false;
  });
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const runId = crypto.randomUUID();

    // Authentication check
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse body ONCE here — req.body can only be consumed once in Deno.
    // Both the isSystemCaller branch and the main param destructure use this.
    let requestBodyText = '';
    let requestBody: any = {};
    try {
      requestBodyText = await req.text();
      requestBody = requestBodyText ? JSON.parse(requestBodyText) : {};
    } catch { /* malformed body — continue with empty object */ }

    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? '';
    const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';

    // Admin client for server-side writes.
    const supabaseAdmin = createClient(
      supabaseUrl,
      supabaseServiceRoleKey
    );

    // Detect system/service-role caller (e.g. cron resume job)
    // Service role key is passed as Bearer token — skip user auth, use candidate creator as acting user
    const isSystemCaller = authHeader === `Bearer ${supabaseServiceRoleKey}`;

    let userId: string;

    if (isSystemCaller) {
      const { candidateId: earlyId } = requestBody;

      if (!earlyId) {
        return new Response(JSON.stringify({ error: 'Candidate ID is required' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Look up the candidate's creator to use as acting user
      const { data: creatorRow } = await supabaseAdmin
        .from('candidates')
        .select('created_by')
        .eq('id', earlyId)
        .single();

      if (!creatorRow?.created_by) {
        return new Response(JSON.stringify({ error: 'Cannot determine acting user for system call' }), {
          status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      userId = creatorRow.created_by;
      console.log(`[System] Resuming pipeline for candidate ${earlyId} as user ${userId}`);

      // Re-create request with the parsed body so downstream code can re-read it
      // We monkey-patch req.json to return the parsed body
      const origJson = req.json.bind(req);
      req = new Request(req.url, {
        method: req.method,
        headers: req.headers,
        body: requestBodyText,
      });

    } else {
      const supabaseClient = createClient(
        supabaseUrl,
        supabaseAnonKey,
        { global: { headers: { Authorization: authHeader } } }
      );

      const { data: userData, error: userError } = await supabaseClient.auth.getUser();
      
      if (userError || !userData?.user) {
        console.error('Auth error:', userError);
        return new Response(
          JSON.stringify({ error: 'Unauthorized' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      userId = userData.user.id;

      const { data: userRole, error: roleError } = await supabaseClient.rpc('get_user_role', {
        _user_id: userId,
      });

      if (roleError || !userRole || !['recruiter', 'admin'].includes(userRole)) {
        return new Response(
          JSON.stringify({ error: 'Insufficient permissions' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    const user = { id: userId };

    // Re-create supabaseClient using admin for system calls (no user JWT available)
    const supabaseClient = isSystemCaller
      ? supabaseAdmin
      : createClient(supabaseUrl, supabaseAnonKey, { global: { headers: { Authorization: authHeader } } });

    // DECOUPLED ARCHITECTURE: mode = 'scrape' | 'score' (default = 'scrape')
    // - 'scrape': Only search job boards, store raw results to pipeline_pending_jobs (no AI calls)
    // - 'score': Only process pending jobs with AI scoring (no board searching)
    // Frontend chains: scrape → score → score... until target reached or pending exhausted → more scrape if boards remain
    // Use the pre-parsed requestBody (body was read once at the top of the handler)
    const { candidateId, extractKeywordsOnly, continueFromBoard, mode = 'scrape', targetBoardIds, batchIndex = 0 } = requestBody;

    if (!candidateId) {
      return new Response(
        JSON.stringify({ error: 'Candidate ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch candidate
    const { data: candidate, error: candidateError } = await supabaseClient
      .from('candidates')
      .select('*')
      .eq('id', candidateId)
      .single();

    if (candidateError || !candidate) {
      return new Response(
        JSON.stringify({ error: 'Candidate not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Running pipeline (runId=${runId}, mode=${mode}) for candidate: ${candidate.name}${extractKeywordsOnly ? ' (keywords only)' : ''}${continueFromBoard ? ` (continue from board ${continueFromBoard})` : ''}`);

    // Track start time for timeout management (Edge Functions have 60s limit)
    const PIPELINE_START_TIME = Date.now();
    // Give each mode its own full budget since they're separate phases
    const MAX_PIPELINE_DURATION_MS = mode === 'auto' ? 50000 : 55000;
    const isTimeoutImminent = () => (Date.now() - PIPELINE_START_TIME) > MAX_PIPELINE_DURATION_MS;
    const isCriticalTimeout = () => (Date.now() - PIPELINE_START_TIME) > 58000;

    const DB_WRITE_RESERVE_MS = 5000;
    const msElapsed = () => Date.now() - PIPELINE_START_TIME;
    const msRemainingInBudget = () => Math.max(0, MAX_PIPELINE_DURATION_MS - msElapsed());
    const shouldStopScoringForWrites = () => msElapsed() > (MAX_PIPELINE_DURATION_MS - DB_WRITE_RESERVE_MS);

    const fetchWithTimeout = async (
      url: string,
      init: RequestInit,
      timeoutMs: number,
      label: string
    ): Promise<Response> => {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);
      try {
        return await fetch(url, { ...init, signal: controller.signal });
      } finally {
        clearTimeout(timeout);
      }
    };

    // ================================================================
    // FIRECRAWL CONCURRENCY LIMITER (max 5 concurrent requests)
    // On 429: single retry after 2s, then fail fast (frontend will continue from where it left off)
    // ================================================================
    const FIRECRAWL_MAX_CONCURRENT = 2; // Conservative: each board may fire multiple calls
    let firecrawlActiveCount = 0;
    const firecrawlQueue: Array<() => void> = [];
    let consecutive429Count = 0; // Track consecutive 429s to detect sustained rate limiting
    let firecrawlCallCount = 0;  // Track total successful API calls for credit estimation

    async function firecrawlFetch(
      url: string,
      init: RequestInit,
      timeoutMs: number,
      label: string
    ): Promise<Response> {
      // If we've hit 5+ consecutive 429s, the account is rate-limited — fail immediately
      if (consecutive429Count >= 5) {
        console.log(`[429] ${label}: Skipping (${consecutive429Count} consecutive 429s — account rate limited)`);
        return new Response(JSON.stringify({ error: 'Rate limited' }), { status: 429 });
      }

      // Wait for a slot if at capacity
      if (firecrawlActiveCount >= FIRECRAWL_MAX_CONCURRENT) {
        await new Promise<void>(resolve => firecrawlQueue.push(resolve));
      }
      firecrawlActiveCount++;
      try {
        const resp = await fetchWithTimeout(url, init, timeoutMs, label);
        if (resp.status === 429) {
          consecutive429Count++;
          // Single retry after 2s delay
          console.log(`[429] ${label}: Rate limited, retrying once in 2s (consecutive: ${consecutive429Count})`);
          await new Promise(r => setTimeout(r, 2000));
          const retry = await fetchWithTimeout(url, init, timeoutMs, label);
          if (retry.status === 429) {
            consecutive429Count++;
            return retry;
          }
          consecutive429Count = 0; // Reset on success
          if (retry.ok) firecrawlCallCount++;
          return retry;
        }
        consecutive429Count = 0; // Reset on success
        // Count successful calls (2xx) — each costs ~1 Firecrawl credit
        if (resp.ok) firecrawlCallCount++;
        return resp;
      } finally {
        firecrawlActiveCount--;
        if (firecrawlQueue.length > 0) {
          const next = firecrawlQueue.shift()!;
          next();
        }
      }
    }

    const safeTimeoutMs = (desiredMs: number, priority: 'critical' | 'normal' | 'scrape' = 'normal') => {
      const remaining = msRemainingInBudget();
      // Scrapes need a guaranteed minimum of 8s - never let the budget squeeze below that
      if (priority === 'scrape') return Math.min(desiredMs, Math.max(8000, remaining - 5000));
      const reserveToKeep = priority === 'critical' ? 5000 : DB_WRITE_RESERVE_MS;
      const usable = Math.max(500, remaining - reserveToKeep);
      return Math.min(desiredMs, usable);
    };

    async function writePipelineEvent(eventType: string, message: string) {
      try {
        await supabaseAdmin.from('pipeline_events').insert({
          candidate_id: candidateId,
          created_by: user!.id,
          event_type: eventType,
          message,
        });
      } catch (err) {
        console.error('Failed to write pipeline event:', err);
      }
    }

    async function writeDebugEvent(payload: Record<string, unknown>) {
      try {
        await supabaseAdmin.from('pipeline_events').insert({
          candidate_id: candidateId,
          created_by: user!.id,
          event_type: 'debug',
          message: JSON.stringify({
            runId,
            at: new Date().toISOString(),
            msElapsed: msElapsed(),
            ...payload,
          }),
        });
      } catch (err) {
        console.error('Failed to write debug pipeline event:', err);
      }
    }

    let stopRequested = false;
    async function checkStopRequested(): Promise<boolean> {
      if (stopRequested) return true;
      try {
        const { data: stopEvents } = await supabaseAdmin
          .from('pipeline_events')
          .select('created_at')
          .eq('candidate_id', candidateId)
          .eq('event_type', 'stop_requested')
          .gte('created_at', new Date(PIPELINE_START_TIME).toISOString())
          .limit(1);
        
        if (stopEvents && stopEvents.length > 0) {
          stopRequested = true;
          console.log('Stop requested by user');
          return true;
        }
      } catch (err) {
        console.error('Error checking stop request:', err);
      }
      return false;
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    let FIRECRAWL_API_KEY = Deno.env.get('FIRECRAWL_API_KEY');
    // Resolve Firecrawl API key: app_settings override first, then env var
    try {
      const { data: secretSetting } = await supabaseAdmin
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'secret_firecrawl_api_key')
        .single();
      if (secretSetting?.setting_value) {
        FIRECRAWL_API_KEY = secretSetting.setting_value;
        console.log('Using Firecrawl API key from app_settings');
      }
    } catch (_) { /* ignore, use env fallback */ }

    if (!LOVABLE_API_KEY) {
      return new Response(
        JSON.stringify({ error: 'AI service not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get today's date for AI prompts
    const todayISO = new Date().toISOString().split('T')[0];
    
    // Fetch app settings
    let EXTERNAL_MATCH_THRESHOLD = 50;
    let MAX_COMPANY_EMPLOYEES = 500;
    let MAX_JOB_AGE_DAYS = 14;
    let TARGET_MATCHES = 20;

    try {
      const { data: settings } = await supabaseClient
        .from('app_settings')
        .select('setting_key, setting_value')
        .in('setting_key', ['match_threshold_percent', 'max_company_employees', 'max_job_age_days', 'target_matches']);
      
      for (const s of settings || []) {
        const val = parseInt(s.setting_value, 10);
        if (!isNaN(val)) {
          if (s.setting_key === 'match_threshold_percent') EXTERNAL_MATCH_THRESHOLD = val;
          if (s.setting_key === 'max_company_employees') MAX_COMPANY_EMPLOYEES = val;
          if (s.setting_key === 'max_job_age_days') MAX_JOB_AGE_DAYS = val;
          if (s.setting_key === 'target_matches') TARGET_MATCHES = val;
        }
      }
    } catch (e) {
      console.log('Using default settings');
    }

    console.log(`Settings: threshold=${EXTERNAL_MATCH_THRESHOLD}%, maxEmployees=${MAX_COMPANY_EMPLOYEES}, maxAge=${MAX_JOB_AGE_DAYS}d, target=${TARGET_MATCHES}`);

    // Fetch custom AI instruction for job matching
    let jobMatchPromptTemplate = `Analyze job posting for candidate with the following profile:

=== CANDIDATE PROFILE ===
Current Skills: {{candidate_skills}}
{{#candidate_title}}Current Role: {{candidate_title}}{{/candidate_title}}
{{#ideal_role}}TARGET ROLE (what they WANT): {{ideal_role}}{{/ideal_role}}
{{#career_goals}}CAREER GOALS: {{career_goals}}{{/career_goals}}
{{#industries_of_interest}}TARGET INDUSTRIES: {{industries_of_interest}}{{/industries_of_interest}}
{{#ai_summary}}CANDIDATE SUMMARY: {{ai_summary}}{{/ai_summary}}
{{#career_highlights}}KEY ACHIEVEMENTS: {{career_highlights}}{{/career_highlights}}

TODAY'S DATE: {{today_date}}

=== SCORING PHILOSOPHY ===
Score based on BOTH:
1. SKILL ALIGNMENT (50%): Does the candidate have the required technical skills?
2. CAREER TRAJECTORY FIT (50%): Does this job align with what the candidate WANTS?
   - Match their ideal_role and career_goals, not just past experience
   - Consider if this role advances their career trajectory
   - Favor jobs matching their target industries

A job that matches skills but conflicts with career goals should score LOWER.
A job that aligns with aspirations but has skill gaps may still score well if trainable.

CRITICAL EXTRACTION INSTRUCTIONS - Search thoroughly before returning "Unknown":

1. JOB LOCATION (REQUIRED - search extensively):
   - Look in job header, sidebar, "Location:" field, "Where:" field
   - Check footer for office address or headquarters
   - Look for phrases like "based in", "located in", "position in", "office in", "work from"
   - Check for city names embedded in text (e.g., "Our NYC team", "London office")
   - If remote, look for "Remote", "Work from home", "WFH", "Distributed", "Anywhere"
   - Check for hybrid mentions: "Hybrid - San Francisco", "Remote with office in Austin"
   - Look for country indicators: zip codes (US), postcodes (UK), country codes
   - If truly not found after thorough search, return "Unknown"

2. SALARY/COMPENSATION (search thoroughly):
   - Look for "$", "£", "€", "salary", "compensation", "pay", "OTE", "base"
   - Check for ranges: "$80,000 - $120,000", "80-120k", "$150K+"
   - Look for hourly rates: "$50/hr", "$45-60 per hour"
    - Check benefits section for salary mentions
    - IMPORTANT: If the salary is "Competitive", "Negotiable", "DOE", "Based on experience", "Market rate", or any other vague/non-numeric description, return "Not specified"
    - ONLY return actual numeric salary values (e.g., "$80,000 - $120,000", "£50k", "$45/hr")
    - If not found or only vague descriptions exist, return "Not specified"

3. JOB TYPE:
   - Look for "Full-time", "Part-time", "Contract", "Freelance", "Temporary", "Permanent"
   - Check for "FTE", "W2", "1099", "Corp-to-Corp"
   - If not explicit, infer from context (most are Full-time)

Extract and return:
- job_title: The position/role name
- company_name: The hiring company (REQUIRED - look for company name in the posting, not the job board name)
- job_location: Location as extracted above (be thorough!)
- job_type: Full-time, Part-time, Contract, etc.
- industry: Industry sector
- experience_level: Junior, Mid-level, Senior, Lead, Executive
- salary_range: Salary/compensation as extracted above
- posted_date: YYYY-MM-DD format (convert relative dates like "3 days ago" using TODAY'S DATE)
- match_score: 0-100 based on BOTH skill alignment AND career trajectory fit
- match_reason: Reference BOTH skills AND how this fits their career goals
- skills_matched: Skills candidate has
- skills_missing: Required skills candidate lacks
- is_job_posting: false if this is a search results page, profile page, PDF, or non-job content

IMPORTANT: company_name and job_location are critical - extract them carefully from the job posting content. Search the ENTIRE document before giving up.`;

    try {
      const { data: aiInstruction } = await supabaseClient
        .from('ai_instructions')
        .select('instruction_prompt')
        .eq('instruction_key', 'job_match_scoring')
        .single();
      
      if (aiInstruction?.instruction_prompt) {
        jobMatchPromptTemplate = aiInstruction.instruction_prompt;
      }
    } catch (e) {
      // Use default
    }

    // Enhanced interface for candidate profile data
    interface CandidateProfile {
      skills: string[];
      current_title: string | null;
      ideal_role: string | null;
      career_goals: string | null;
      industries_of_interest: string[] | null;
      ai_summary: string | null;
      career_highlights: string[] | null;
    }

    function buildMatchPrompt(candidateProfile: CandidateProfile): string {
      let prompt = jobMatchPromptTemplate;
      prompt = prompt.replace(/\{\{candidate_skills\}\}/g, candidateProfile.skills.join(', ') || 'Not specified');
      prompt = prompt.replace(/\{\{today_date\}\}/g, todayISO);
      
      // Current title
      if (candidateProfile.current_title) {
        prompt = prompt.replace(/\{\{#candidate_title\}\}(.*?)\{\{\/candidate_title\}\}/gs, '$1');
        prompt = prompt.replace(/\{\{candidate_title\}\}/g, candidateProfile.current_title);
      } else {
        prompt = prompt.replace(/\{\{#candidate_title\}\}.*?\{\{\/candidate_title\}\}/gs, '');
      }
      
      // Ideal role (what they WANT)
      if (candidateProfile.ideal_role) {
        prompt = prompt.replace(/\{\{#ideal_role\}\}(.*?)\{\{\/ideal_role\}\}/gs, '$1');
        prompt = prompt.replace(/\{\{ideal_role\}\}/g, candidateProfile.ideal_role);
      } else {
        prompt = prompt.replace(/\{\{#ideal_role\}\}.*?\{\{\/ideal_role\}\}/gs, '');
      }
      
      // Career goals
      if (candidateProfile.career_goals) {
        prompt = prompt.replace(/\{\{#career_goals\}\}(.*?)\{\{\/career_goals\}\}/gs, '$1');
        prompt = prompt.replace(/\{\{career_goals\}\}/g, candidateProfile.career_goals);
      } else {
        prompt = prompt.replace(/\{\{#career_goals\}\}.*?\{\{\/career_goals\}\}/gs, '');
      }
      
      // Industries of interest
      if (candidateProfile.industries_of_interest?.length) {
        prompt = prompt.replace(/\{\{#industries_of_interest\}\}(.*?)\{\{\/industries_of_interest\}\}/gs, '$1');
        prompt = prompt.replace(/\{\{industries_of_interest\}\}/g, candidateProfile.industries_of_interest.join(', '));
      } else {
        prompt = prompt.replace(/\{\{#industries_of_interest\}\}.*?\{\{\/industries_of_interest\}\}/gs, '');
      }
      
      // AI summary
      if (candidateProfile.ai_summary) {
        prompt = prompt.replace(/\{\{#ai_summary\}\}(.*?)\{\{\/ai_summary\}\}/gs, '$1');
        prompt = prompt.replace(/\{\{ai_summary\}\}/g, candidateProfile.ai_summary.slice(0, 500)); // Limit length
      } else {
        prompt = prompt.replace(/\{\{#ai_summary\}\}.*?\{\{\/ai_summary\}\}/gs, '');
      }
      
      // Career highlights
      if (candidateProfile.career_highlights?.length) {
        prompt = prompt.replace(/\{\{#career_highlights\}\}(.*?)\{\{\/career_highlights\}\}/gs, '$1');
        prompt = prompt.replace(/\{\{career_highlights\}\}/g, candidateProfile.career_highlights.slice(0, 5).join('; '));
      } else {
        prompt = prompt.replace(/\{\{#career_highlights\}\}.*?\{\{\/career_highlights\}\}/gs, '');
      }
      
      return prompt;
    }

    // Helper function to normalize company names for deduplication
    // Handles case variations, punctuation, and spacing differences
    function normalizeCompanyName(name: string): string {
      return name
        .toLowerCase()
        .trim()
        .replace(/\s+/g, ' ') // Normalize whitespace
        .replace(/[^\w\s&]/g, '') // Remove punctuation except &
        .trim();
    }

    // ================================================================
    // CROSS-BOARD DEDUPLICATION HELPERS
    // Detect the same job posted on multiple boards to avoid scoring it twice
    // ================================================================

    // Normalize a job URL to a canonical form by stripping tracking params
    // so the same job linked from different sources can be matched
    function canonicalizeJobUrl(rawUrl: string): string {
      try {
        const u = new URL(rawUrl);
        // Strip common tracking / session parameters
        const trackingParams = [
          'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content',
          'ref', 'referer', 'referrer', 'source', 'src', 'from', 'fbclid', 'gclid',
          'clickid', 'mc_cid', 'mc_eid', 'trk', 'trkInfo', 'originalSubdomain',
          'position', 'pageNum', 'fromSearchCard', 'tracking', 'tk', 'fccid',
          'vjs', 'vjk', 'advn', 'adid', 'sjdu', 'aceid', 'hl',
        ];
        for (const p of trackingParams) {
          u.searchParams.delete(p);
        }
        // Remove hash fragments
        u.hash = '';
        // Lowercase host
        const canonical = `${u.protocol}//${u.hostname.replace(/^www\./, '')}${u.pathname.replace(/\/+$/, '')}`;
        // Only keep meaningful params
        const remaining = u.searchParams.toString();
        return remaining ? `${canonical}?${remaining}` : canonical;
      } catch {
        return rawUrl.toLowerCase().trim();
      }
    }

    // Build a lightweight fingerprint from job title + company name (from URL)
    // for detecting the same job across different boards
    function buildJobFingerprint(url: string, title: string): string | null {
      const company = guessCompanyNameFromUrl(url);
      if (!company || !title) return null;
      // Normalize: lowercase, strip non-alpha, collapse spaces
      const normTitle = title.toLowerCase().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
      const normCompany = company.toLowerCase().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
      if (normTitle.length < 5 || normCompany.length < 2) return null;
      return `${normCompany}::${normTitle}`;
    }

    // Helper function to check if a job is too old
    function isJobTooOld(postedDate: string | null | undefined): { tooOld: boolean; ageInDays: number | null } {
      // If no date can be parsed, default to REJECTING the job — 
      // better to miss a new job than to surface a 57-day-old one
      if (!postedDate) return { tooOld: true, ageInDays: null };
      
      try {
        const posted = new Date(postedDate);
        if (isNaN(posted.getTime())) return { tooOld: true, ageInDays: null };
        
        const today = new Date(todayISO);
        const diffMs = today.getTime() - posted.getTime();
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        
        return { tooOld: diffDays > MAX_JOB_AGE_DAYS, ageInDays: diffDays };
      } catch {
        return { tooOld: true, ageInDays: null };
      }
    }

    // Helper function to check if job location matches candidate's target location
    // STRICT MODE: Jobs must match EITHER the candidate's resume address OR pre-search country/city
    // searchDistanceKm controls how aggressively we expand metro area matches
    function isLocationMismatch(
      jobLocation: string | null | undefined,
      candidateCity: string | null | undefined,
      candidateCountry: string | null | undefined,
      candidateDesiredLocation: string | null | undefined,
      isRemoteWorker: boolean | null | undefined,
      candidateAddress: string | null | undefined,
      searchDistanceKm: number | null | undefined
    ): { mismatch: boolean; reason: string } {
      // STRICT: Reject jobs that have no location extracted
      if (!jobLocation || jobLocation.trim() === '' || jobLocation.toLowerCase() === 'unknown' || jobLocation.toLowerCase() === 'not specified') {
        return { mismatch: true, reason: 'location_missing' };
      }

      const jobLoc = jobLocation.toLowerCase().trim();
      const targetCity = (candidateCity || '').toLowerCase().trim();
      const targetCountry = (candidateCountry || '').toLowerCase().trim();
      const desiredLoc = (candidateDesiredLocation || '').toLowerCase().trim();
      const resumeAddress = (candidateAddress || '').toLowerCase().trim();

      // Normalize multi-location strings: split on "/" or "|" to check each segment
      const locationSegments = jobLoc.split(/\s*[\/|]\s*/).map(s => s.trim()).filter(Boolean);
      
      // Check if job is explicitly remote (ONLY if ALL segments are remote-only)
      const jobIsRemote = jobLoc.includes('remote') || jobLoc.includes('work from home') || jobLoc.includes('wfh') || 
                          jobLoc.includes('anywhere') || jobLoc.includes('distributed');
      
      // Check if candidate's target city appears in ANY segment of the job location
      const candidateCityInJobLoc = targetCity && locationSegments.some(seg => seg.includes(targetCity));
      
      // CRITICAL: If candidate does NOT prefer remote work, reject remote-only jobs
      // BUT: Allow if the job also lists the candidate's target city (hybrid/multi-office)
      if (jobIsRemote && !isRemoteWorker) {
        const isHybridWithLocation = candidateCityInJobLoc || (
          jobLoc.includes('hybrid') && (
            (targetCity && jobLoc.includes(targetCity)) ||
            (targetCountry && jobLoc.includes(targetCountry))
          )
        );
        if (!isHybridWithLocation) {
          return { mismatch: true, reason: 'remote_job_for_non_remote_candidate' };
        }
      }
      
      // If candidate prefers remote and job is remote, it's a match
      if (isRemoteWorker && jobIsRemote) {
        return { mismatch: false, reason: '' };
      }
      
      // REMOTE WORKER COUNTRY MATCH: If candidate is remote worker and job is in the same country,
      // accept regardless of specific city (they can work remotely from anywhere in that country)
      if (isRemoteWorker && targetCountry) {
        const usIndicators = ['usa', 'us', 'u.s.', 'u.s.a.', 'united states', 'america'];
        const ukIndicators = ['uk', 'u.k.', 'united kingdom', 'england', 'scotland', 'wales', 'britain'];
        const canadaIndicators = ['canada', 'ca,', ', ca'];
        const australiaIndicators = ['australia', 'au,', ', au'];
        
        const targetIsUS = usIndicators.some(i => targetCountry.includes(i));
        const targetIsUK = ukIndicators.some(i => targetCountry.includes(i));
        const targetIsCanada = canadaIndicators.some(i => targetCountry.includes(i)) || targetCountry === 'canada';
        const targetIsAustralia = australiaIndicators.some(i => targetCountry.includes(i)) || targetCountry === 'australia';
        
        // Check if job is in a US location (state abbreviations, city names, or explicit US mention)
        const usStateAbbrevs = ['al', 'ak', 'az', 'ar', 'ca', 'co', 'ct', 'de', 'fl', 'ga', 'hi', 'id', 'il', 'in', 'ia', 'ks', 'ky', 'la', 'me', 'md', 'ma', 'mi', 'mn', 'ms', 'mo', 'mt', 'ne', 'nv', 'nh', 'nj', 'nm', 'ny', 'nc', 'nd', 'oh', 'ok', 'or', 'pa', 'ri', 'sc', 'sd', 'tn', 'tx', 'ut', 'vt', 'va', 'wa', 'wv', 'wi', 'wy', 'dc'];
        const jobInUS = usIndicators.some(i => jobLoc.includes(i)) || 
                        usStateAbbrevs.some(abbr => {
                          // Match state abbreviation at word boundary (e.g., ", TX" or "TX," but not "TEXT")
                          const regex = new RegExp(`(^|[^a-z])${abbr}([^a-z]|$)`, 'i');
                          return regex.test(jobLoc);
                        });
        
        const jobInUK = ukIndicators.some(i => jobLoc.includes(i));
        const jobInCanada = jobLoc.includes('canada') || /,\s*ca\b/i.test(jobLocation);
        const jobInAustralia = jobLoc.includes('australia') || /,\s*au\b/i.test(jobLocation);
        
        // Remote worker in same country = match
        if (targetIsUS && jobInUS) {
          return { mismatch: false, reason: '' };
        }
        if (targetIsUK && jobInUK) {
          return { mismatch: false, reason: '' };
        }
        if (targetIsCanada && jobInCanada) {
          return { mismatch: false, reason: '' };
        }
        if (targetIsAustralia && jobInAustralia) {
          return { mismatch: false, reason: '' };
        }
      }
      
      // STRICT: Reject vague country-level locations like just "USA" or "United States" without city/state
      // These typically indicate remote or unclear postings
      const isVagueCountryOnly = (
        jobLoc === 'usa' || 
        jobLoc === 'us' || 
        jobLoc === 'u.s.' || 
        jobLoc === 'u.s.a.' ||
        jobLoc === 'united states' || 
        jobLoc === 'united states of america' ||
        jobLoc === 'uk' ||
        jobLoc === 'u.k.' ||
        jobLoc === 'united kingdom' ||
        jobLoc === 'canada' ||
        jobLoc === 'australia'
      );
      if (isVagueCountryOnly) {
        return { mismatch: true, reason: 'vague_country_only_location' };
      }

      // Build list of acceptable location terms from candidate preferences AND resume address
      const acceptableTerms: string[] = [];
      
      // Add terms from candidate's resume address (parsed from CV)
      if (resumeAddress) {
        const addressParts = resumeAddress.split(',').map(p => p.trim().toLowerCase()).filter(p => p.length > 1);
        for (const part of addressParts) {
          // Skip very short parts (state abbrevs handled separately) and country-level terms
          if (part.length > 2) {
            acceptableTerms.push(part);
          }
          // Add 2-letter state abbreviations
          if (part.length === 2) {
            acceptableTerms.push(part);
          }
        }
      }
      
      // Add city
      if (targetCity) {
        acceptableTerms.push(targetCity);
        // Handle city variations (e.g., "Fort Worth" matches "Ft. Worth", "Ft Worth")
        if (targetCity.includes('fort ')) acceptableTerms.push(targetCity.replace('fort ', 'ft '), targetCity.replace('fort ', 'ft. '));
        if (targetCity.includes('saint ')) acceptableTerms.push(targetCity.replace('saint ', 'st '), targetCity.replace('saint ', 'st. '));
        // Add metro area cities based on search_distance_km
        // Wider radius = more neighboring cities accepted
        const distKm = searchDistanceKm ?? 40; // Default ~25 miles if not set
        const distMi = Math.round(distKm * 0.621371);
        
        // Metro area definitions: [core cities within ~25mi, extended cities within ~50mi, wide cities within ~80mi+]
        const metroAreas: Record<string, { core: string[]; extended: string[]; wide: string[] }> = {
          'san francisco': {
            core: ['sf', 'bay area', 'san mateo', 'oakland', 'berkeley', 'palo alto', 'mountain view', 'sunnyvale', 'redwood city', 'menlo park'],
            extended: ['santa clara', 'san jose', 'fremont', 'hayward', 'daly city', 'walnut creek', 'pleasanton', 'milpitas', 'cupertino', 'campbell'],
            wide: ['santa cruz', 'stockton', 'modesto', 'sacramento', 'napa', 'santa rosa', 'gilroy', 'salinas', 'monterey'],
          },
          'new york': {
            core: ['nyc', 'manhattan', 'brooklyn', 'queens', 'jersey city', 'hoboken', 'bronx', 'staten island'],
            extended: ['newark', 'yonkers', 'white plains', 'stamford', 'new rochelle', 'long island', 'nassau', 'suffolk'],
            wide: ['bridgeport', 'new haven', 'trenton', 'princeton', 'albany', 'poughkeepsie', 'atlantic city'],
          },
          'los angeles': {
            core: ['la', 'santa monica', 'pasadena', 'burbank', 'culver city', 'beverly hills', 'glendale', 'west hollywood', 'inglewood'],
            extended: ['long beach', 'torrance', 'anaheim', 'irvine', 'costa mesa', 'el segundo', 'pomona', 'ontario'],
            wide: ['san diego', 'riverside', 'san bernardino', 'ventura', 'oxnard', 'palm springs', 'santa barbara'],
          },
          'chicago': {
            core: ['evanston', 'naperville', 'schaumburg', 'oak park', 'cicero', 'skokie', 'des plaines'],
            extended: ['aurora', 'joliet', 'elgin', 'waukegan', 'arlington heights', 'bolingbrook'],
            wide: ['rockford', 'gary', 'milwaukee', 'south bend', 'kalamazoo'],
          },
          'seattle': {
            core: ['bellevue', 'redmond', 'kirkland', 'renton', 'kent', 'bothell'],
            extended: ['tacoma', 'everett', 'olympia', 'federal way', 'auburn', 'lynnwood', 'bremerton'],
            wide: ['portland', 'spokane', 'vancouver'],
          },
          'boston': {
            core: ['cambridge', 'somerville', 'brookline', 'quincy', 'newton', 'waltham', 'malden'],
            extended: ['worcester', 'lowell', 'brockton', 'fall river', 'new bedford', 'framingham', 'lynn'],
            wide: ['providence', 'springfield', 'hartford', 'manchester', 'portsmouth'],
          },
          'austin': {
            core: ['round rock', 'cedar park', 'pflugerville', 'georgetown', 'kyle', 'leander'],
            extended: ['san marcos', 'new braunfels', 'temple', 'killeen'],
            wide: ['san antonio', 'houston', 'dallas', 'waco'],
          },
          'denver': {
            core: ['boulder', 'aurora', 'littleton', 'lakewood', 'westminster', 'thornton', 'broomfield'],
            extended: ['fort collins', 'colorado springs', 'loveland', 'greeley', 'longmont', 'castle rock'],
            wide: ['pueblo', 'grand junction'],
          },
          'dallas': {
            core: ['fort worth', 'plano', 'irving', 'arlington', 'frisco', 'dfw', 'richardson', 'garland', 'mckinney'],
            extended: ['denton', 'lewisville', 'carrollton', 'allen', 'mesquite', 'grand prairie'],
            wide: ['waco', 'tyler', 'texarkana', 'oklahoma city'],
          },
          'washington': {
            core: ['dc', 'arlington', 'alexandria', 'bethesda', 'silver spring', 'mclean', 'tysons', 'reston'],
            extended: ['fairfax', 'rockville', 'college park', 'annapolis', 'columbia', 'germantown'],
            wide: ['baltimore', 'richmond', 'charlottesville', 'fredericksburg'],
          },
          'atlanta': {
            core: ['decatur', 'sandy springs', 'marietta', 'roswell', 'alpharetta', 'dunwoody', 'buckhead'],
            extended: ['kennesaw', 'lawrenceville', 'duluth', 'johns creek', 'smyrna', 'peachtree city'],
            wide: ['athens', 'macon', 'savannah', 'chattanooga', 'greenville'],
          },
          'miami': {
            core: ['fort lauderdale', 'hollywood', 'coral gables', 'boca raton', 'hialeah', 'doral'],
            extended: ['west palm beach', 'pompano beach', 'delray beach', 'aventura', 'plantation'],
            wide: ['orlando', 'tampa', 'naples', 'key west', 'jacksonville'],
          },
          'houston': {
            core: ['sugar land', 'the woodlands', 'pasadena', 'pearland', 'katy', 'league city', 'cypress'],
            extended: ['galveston', 'conroe', 'baytown', 'missouri city', 'spring'],
            wide: ['austin', 'san antonio', 'beaumont', 'college station'],
          },
          'philadelphia': {
            core: ['camden', 'cherry hill', 'king of prussia', 'conshohocken', 'norristown', 'wilmington'],
            extended: ['trenton', 'reading', 'allentown', 'lancaster'],
            wide: ['baltimore', 'atlantic city', 'harrisburg'],
          },
          'san diego': {
            core: ['la jolla', 'chula vista', 'oceanside', 'carlsbad', 'escondido', 'el cajon'],
            extended: ['temecula', 'murrieta', 'encinitas', 'vista', 'san marcos'],
            wide: ['los angeles', 'riverside', 'palm springs', 'tijuana'],
          },
          'phoenix': {
            core: ['scottsdale', 'tempe', 'mesa', 'chandler', 'glendale', 'gilbert', 'peoria'],
            extended: ['surprise', 'goodyear', 'avondale', 'buckeye', 'cave creek', 'fountain hills'],
            wide: ['tucson', 'flagstaff', 'prescott', 'sedona'],
          },
          'minneapolis': {
            core: ['st paul', 'saint paul', 'bloomington', 'eden prairie', 'plymouth', 'minnetonka', 'edina'],
            extended: ['burnsville', 'maple grove', 'woodbury', 'eagan', 'lakeville'],
            wide: ['rochester', 'duluth', 'st cloud', 'madison'],
          },
        };
        
        const metro = metroAreas[targetCity];
        if (metro) {
          // Always include core cities (within ~25mi)
          acceptableTerms.push(...metro.core);
          // Include extended if distance >= 50km (~30mi)
          if (distKm >= 50) {
            acceptableTerms.push(...metro.extended);
          }
          // Include wide if distance >= 100km (~60mi)
          if (distKm >= 100) {
            acceptableTerms.push(...metro.wide);
          }
        }
      }
      
      // Add country and common abbreviations
      if (targetCountry) {
        // Note: We DON'T add the country itself as an acceptable term anymore
        // because we want city/state-level matching, not just "anywhere in the country"
        
        // Add common abbreviations for state extraction from desired location
        const countryAbbrevs: Record<string, string[]> = {
          'united states': ['usa', 'us', 'u.s.', 'u.s.a.'],
          'united kingdom': ['uk', 'u.k.', 'britain', 'england', 'scotland', 'wales'],
          'canada': ['ca'],
          'australia': ['au'],
        };
        // Don't add country abbreviations as acceptable terms - require specific location
      }
      
      // Parse desired location for additional terms (e.g., "Fort Worth, TX, USA")
      if (desiredLoc) {
        const parts = desiredLoc.split(',').map(p => p.trim().toLowerCase());
        // Only add city and state parts, not country-level
        if (parts.length >= 2) {
          acceptableTerms.push(parts[0]); // City
          acceptableTerms.push(parts[1]); // State
        } else if (parts.length === 1 && parts[0].length > 2) {
          acceptableTerms.push(parts[0]); // Just city
        }
        // Add state if present (for US - 2 letter abbreviations)
        parts.forEach(part => {
          if (part.length === 2) {
            acceptableTerms.push(part); // State abbreviation like 'tx'
          }
        });
      }

      // Add state name mappings for US states
      const stateAbbrevToName: Record<string, string> = {
        'tx': 'texas', 'ca': 'california', 'ny': 'new york', 'fl': 'florida',
        'il': 'illinois', 'pa': 'pennsylvania', 'oh': 'ohio', 'ga': 'georgia',
        'nc': 'north carolina', 'mi': 'michigan', 'nj': 'new jersey', 'va': 'virginia',
        'wa': 'washington', 'az': 'arizona', 'ma': 'massachusetts', 'tn': 'tennessee',
        'in': 'indiana', 'mo': 'missouri', 'md': 'maryland', 'wi': 'wisconsin',
        'co': 'colorado', 'mn': 'minnesota', 'sc': 'south carolina', 'al': 'alabama',
        'la': 'louisiana', 'ky': 'kentucky', 'or': 'oregon', 'ok': 'oklahoma',
        'ct': 'connecticut', 'ut': 'utah', 'ia': 'iowa', 'nv': 'nevada',
        'ar': 'arkansas', 'ms': 'mississippi', 'ks': 'kansas', 'nm': 'new mexico',
        'ne': 'nebraska', 'id': 'idaho', 'wv': 'west virginia', 'hi': 'hawaii',
        'nh': 'new hampshire', 'me': 'maine', 'mt': 'montana', 'ri': 'rhode island',
        'de': 'delaware', 'sd': 'south dakota', 'nd': 'north dakota', 'ak': 'alaska',
        'vt': 'vermont', 'wy': 'wyoming',
      };
      
      acceptableTerms.forEach(term => {
        if (stateAbbrevToName[term]) {
          acceptableTerms.push(stateAbbrevToName[term]);
        }
      });

      // Remove duplicates and empty strings
      const uniqueTerms = [...new Set(acceptableTerms.filter(t => t.length > 0))];

      // If no acceptable terms defined, allow through (shouldn't happen normally)
      if (uniqueTerms.length === 0) {
        return { mismatch: false, reason: '' };
      }

      // Word-boundary-aware matching for short terms to prevent false positives
      // e.g., "ca" (California) should NOT match inside "caracas"
      function termMatchesLocation(term: string, location: string): boolean {
        if (term.length <= 3) {
          // Use word boundary regex for short terms (state abbreviations, etc.)
          const regex = new RegExp(`(^|[^a-z])${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z]|$)`, 'i');
          return regex.test(location);
        }
        return location.includes(term);
      }

      // Also normalize country abbreviations in the job location for matching
      // e.g., "San Francisco, CA, US" should match when target is "United States"
      const countryNormMap: Record<string, string[]> = {
        'united states': ['us', 'usa', 'u.s.', 'u.s.a.'],
        'united kingdom': ['uk', 'u.k.'],
        'canada': ['ca'],
        'australia': ['au'],
      };
      
      // Check if job location contains any acceptable term
      const hasMatch = uniqueTerms.some(term => termMatchesLocation(term, jobLoc));
      
      // STATE-LEVEL MATCHING: Accept if job is in the same state as the target city
      // Extract state from target location
      let targetState = '';
      if (desiredLoc) {
        const parts = desiredLoc.split(',').map(p => p.trim().toLowerCase());
        // Find 2-letter state abbreviation
        for (const part of parts) {
          if (part.length === 2 && stateAbbrevToName[part]) {
            targetState = part;
            break;
          }
        }
      }
      // Special case: If searching in San Francisco, add California
      if (targetCity === 'san francisco' && !targetState) {
        targetState = 'ca';
      }
      
      const sameState = targetState && (
        termMatchesLocation(targetState, jobLoc) ||
        (stateAbbrevToName[targetState] && jobLoc.includes(stateAbbrevToName[targetState]))
      );

      // STRICT CHECK: Job must be in the same country at minimum
      // For international jobs (clearly different country), reject
      const internationalIndicators = [
        ', in', ', india', 'bangalore', 'hyderabad', 'mumbai', 'chennai', 'pune', // India
        ', uk', ', england', 'london', 'manchester', 'birmingham', // UK (if target is US)
        ', de', ', germany', 'berlin', 'munich', 'frankfurt', // Germany
        ', ca,', 'toronto', 'vancouver', 'montreal', // Canada (if target is US)
        ', au', ', australia', 'sydney', 'melbourne', // Australia
        ', ph', ', philippines', 'manila', // Philippines
        ', sg', ', singapore', // Singapore
      ];

      // Only reject if it's clearly a different country
      const isInternational = internationalIndicators.some(indicator => {
        // Don't match if the target country is that country
        if (targetCountry.includes(indicator.replace(', ', '').trim())) return false;
        return jobLoc.includes(indicator);
      });

      if (isInternational) {
        return { mismatch: true, reason: `location_mismatch: ${jobLocation}` };
      }

      // If job matches city/metro terms or is in same state, it's acceptable
      if (hasMatch || sameState) {
        return { mismatch: false, reason: '' };
      }

      // STRICT: If we got here and couldn't match city/state, reject the job
      // This prevents vague locations like "USA" or unrelated cities from passing
      return { mismatch: true, reason: `location_mismatch: ${jobLocation} not in ${targetCity || desiredLoc}` };
    }

    function safeParseFirstJsonObject(text: string): any | null {
      const t = (text || '').trim();
      if (!t) return null;

      let s = t;
      if (s.startsWith('```json')) s = s.slice(7);
      else if (s.startsWith('```')) s = s.slice(3);
      if (s.endsWith('```')) s = s.slice(0, -3);
      s = s.trim();

      try {
        return JSON.parse(s);
      } catch {
        const start = s.indexOf('{');
        const end = s.lastIndexOf('}');
        if (start >= 0 && end > start) {
          try {
            return JSON.parse(s.slice(start, end + 1));
          } catch {
            return null;
          }
        }
        return null;
      }
    }

    function normalizeText(s: unknown): string {
      return String(s ?? '').replace(/\s+/g, ' ').replace(/\u00a0/g, ' ').trim();
    }

    function guessCompanyNameFromTitle(title: string): string | null {
      const t = normalizeText(title);
      if (!t) return null;
      
      // Pattern 1: "Role at Company" or "Role @ Company"
      const atMatch = t.match(/\s(?:at|@)\s([^|•\-–—]+?)(?:\s[|•\-–—]|$)/i);
      if (atMatch?.[1]) {
        const name = normalizeText(atMatch[1]);
        if (name && name.length >= 2 && !isGenericJobBoardName(name)) return name;
      }
      
      // Pattern 2: "Company - Role" or "Company | Role"
      const prefixMatch = t.match(/^([^|•\-–—]+?)\s*[|•\-–—]\s*(?:hiring|looking|seeking|job|position|role|career)/i);
      if (prefixMatch?.[1]) {
        const name = normalizeText(prefixMatch[1]);
        if (name && name.length >= 2 && !isGenericJobBoardName(name)) return name;
      }
      
      // Pattern 3: "Role - Company (Location)" with company before location
      const dashCompanyMatch = t.match(/\s[-–—]\s([A-Z][A-Za-z0-9\s&.,]+?)(?:\s*[-–—(]|$)/);
      if (dashCompanyMatch?.[1]) {
        const name = normalizeText(dashCompanyMatch[1]);
        if (name && name.length >= 2 && !isGenericJobBoardName(name)) return name;
      }
      
      return null;
    }
    
    // Helper to filter out job board names mistakenly extracted as company names
    function isGenericJobBoardName(name: string): boolean {
      const lowerName = name.toLowerCase().trim();
      const genericNames = [
        'linkedin', 'indeed', 'glassdoor', 'ziprecruiter', 'monster', 'dice',
        'builtin', 'reed', 'totaljobs', 'jobsite', 'cwjobs', 'technojobs',
        'stackoverflow', 'github', 'angellist', 'hired', 'triplebyte',
        'remote', 'onsite', 'hybrid', 'full time', 'part time', 'contract',
        'jobs', 'careers', 'hiring', 'opportunities', 'employment',
        'confidential', 'stealth', 'startup', 'company confidential',
        'unknown', 'not specified', 'n/a', 'tbd', 'various',
        'weworkremotely', 'we work remotely', 'remotive', 'careerjet',
        'grabjobs', 'naukri', 'jooble', 'adzuna', 'simplyhired', 'simply hired',
        'flexjobs', 'remote ok', 'remoteok', 'jobspresso', 'working nomads',
        'arc', 'gun.io', 'toptal', 'turing', 'crossover', 'andela',
      ];
      // Exact match or starts/ends with
      if (genericNames.some(g => lowerName === g || lowerName.startsWith(g + ' ') || lowerName.endsWith(' ' + g))) {
        return true;
      }
      // Also reject if it contains only generic job-related words
      const onlyGenericWords = /^(remote|full[- ]?time|part[- ]?time|contract|senior|junior|lead|staff|principal|software|developer|engineer|architect|manager|jobs?|position|opportunity|openings?)\s*[-|/]?\s*(remote|full[- ]?time|part[- ]?time|contract|senior|junior|lead|staff|principal|software|developer|engineer|architect|manager|jobs?|position|opportunity|openings?)?$/i;
      if (onlyGenericWords.test(lowerName)) {
        return true;
      }
      return false;
    }
    
    // Helper to detect if a URL is a category/listing page rather than an actual job
    function isCategoryOrListingPage(url: string): boolean {
      const lowerUrl = url.toLowerCase();
      const listingPatterns = [
        // WeWorkRemotely category pages
        /weworkremotely\.com\/(remote-jobs|categories|remote-full-time-jobs|remote-part-time-jobs)/,
        // Remotive category pages
        /remotive\.com\/remote\/jobs\/[a-z-]+$/,  // Category without job ID
        // Careerjet search results (no specific job ID)
        /careerjet\.com\/[a-z-]+-jobs\/?$/,
        /careerjet\.com\/[a-z-]+-jobs\/[A-Za-z-]+$/,  // Location search results
        // Indeed search results
        /indeed\.com\/jobs\?/,
        /indeed\.com\/q-/,
        // Glassdoor search/category pages
        /glassdoor\.com\/Job\/[a-z-]+-jobs/i,
        // Dice search result pages (valid job detail URLs are /job-detail/UUID)
        /dice\.com\/jobs\//,  // e.g., dice.com/jobs/q-Principal+Engineer-l-New+York
        /dice\.com\/job\//,   // Some older URL format without -detail
        // ZipRecruiter search pages
        /ziprecruiter\.com\/jobs\//,  // Search results have /jobs/, job details have /c/
        /ziprecruiter\.com\/jobs-in-/,
        // Monster search pages
        /monster\.com\/jobs\/search/,
        /monster\.com\/jobs\/q-/,
        // LinkedIn search pages (valid job URLs are /jobs/view/ID)
        /linkedin\.com\/jobs\/search/,
        /linkedin\.com\/jobs\/[a-z-]+-jobs/,  // e.g., /jobs/software-engineer-jobs
        /linkedin\.com\/jobs\/[a-z-]+-jobs-[a-z-]+/,  // e.g., /jobs/senior-software-engineer-jobs-san-francisco-ca
        /linkedin\.com\/jobs\/remote-[a-z-]+-jobs/,    // e.g., /jobs/remote-senior-software-engineer-jobs-*
        // StackOverflow — user profiles & meta are NOT job postings
        /stackoverflow\.com\/users\//,         // User profile pages
        /meta\.stackoverflow\.com\//,          // Meta discussion pages
        /stackoverflow\.com\/questions\//,     // Q&A pages
        /stackexchange\.com\//,                // Any StackExchange site
        // General patterns for listing pages
        /\/jobs\/?(\?|$)/,
        /\/careers\/?(\?|$)/,
        /\/all-jobs\/?$/,
        /[?&]page=\d+/,  // Paginated results
      ];
      
      // EXCEPTION: Allow known valid job detail URL patterns through
      const validJobDetailPatterns = [
        /dice\.com\/job-detail\/[a-f0-9-]+/i,  // Dice job detail with UUID
        /linkedin\.com\/jobs\/view\/\d+/,       // LinkedIn job view with ID
        /indeed\.com\/viewjob/,                  // Indeed viewjob
        /indeed\.com\/rc\/clk/,                  // Indeed click-through
        /glassdoor\.com\/job-listing\//,         // Glassdoor job listing
        /glassdoor\.com\/partner\/jobListing/,   // Glassdoor partner listing
        /ziprecruiter\.com\/c\//,                // ZipRecruiter company job page
        /builtin\.com\/job\//,                   // Builtin job detail
        /monster\.com\/job-openings\//,          // Monster specific job
      ];
      
      // If URL matches a valid job detail pattern, it's NOT a listing page
      if (validJobDetailPatterns.some(pattern => pattern.test(lowerUrl))) {
        return false;
      }
      
      return listingPatterns.some(pattern => pattern.test(lowerUrl));
    }

    function guessCompanyNameFromUrl(jobUrl: string): string | null {
      try {
        const u = new URL(jobUrl);
        const host = u.hostname.toLowerCase();
        const path = u.pathname.toLowerCase();
        
        // LinkedIn pattern: /jobs/view/job-title-at-company-name-12345678
        if (host.includes('linkedin.com') && path.includes('/jobs/')) {
          const fullPath = u.pathname;
          // Match "-at-company-name-" followed by job ID
          const atMatch = fullPath.match(/-at-([a-z0-9-]+)-\d{5,}/i);
          if (atMatch?.[1]) {
            const parts = atMatch[1].split('-').filter(Boolean);
            if (parts.length > 0) {
              const name = parts.map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
              if (!isGenericJobBoardName(name)) return name;
            }
          }
        }
        
        // Indeed pattern: /viewjob?jk=xxx or /rc/clk?jk=xxx with company in path/params
        if (host.includes('indeed.com')) {
          // Check for company parameter
          const companyParam = u.searchParams.get('company') || u.searchParams.get('cmp');
          if (companyParam) {
            const name = normalizeText(decodeURIComponent(companyParam));
            if (name && name.length >= 2 && !isGenericJobBoardName(name)) return name;
          }
        }
        
        // Glassdoor pattern: /job-listing/title-company-JV_xxx
        if (host.includes('glassdoor.com') && path.includes('/job-listing/')) {
          const slug = path.split('/job-listing/')[1] || '';
          // Pattern: some-title-company-name-JV_xxx
          const jvMatch = slug.match(/(.+)-JV_/i);
          if (jvMatch?.[1]) {
            const parts = jvMatch[1].split('-');
            // Company name is usually the last few parts before JV_
            if (parts.length >= 2) {
              // Try to find where company name starts (heuristic: after common role words)
              const roleWords = ['senior', 'junior', 'lead', 'manager', 'engineer', 'developer', 'analyst', 'specialist', 'director'];
              let startIdx = 0;
              for (let i = 0; i < parts.length; i++) {
                if (roleWords.some(w => parts[i].toLowerCase() === w)) {
                  startIdx = i + 1;
                }
              }
              if (startIdx < parts.length) {
                const companyParts = parts.slice(startIdx);
                const name = companyParts.map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
                if (!isGenericJobBoardName(name)) return name;
              }
            }
          }
        }
        
        // Builtin pattern: /job/company-name/job-id
        if (host.includes('builtin.com') && path.includes('/job/')) {
          const pathParts = path.split('/job/')[1]?.split('/') || [];
          if (pathParts[0]) {
            const name = pathParts[0].split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
            if (!isGenericJobBoardName(name)) return name;
          }
        }
        
        // ZipRecruiter, Dice, Monster - often have company in subdomain or path
        if (host.includes('ziprecruiter.com') || host.includes('dice.com') || host.includes('monster.com')) {
          // Check for company subdomain
          const subParts = host.split('.');
          if (subParts.length > 2 && !['www', 'jobs', 'careers', 'm'].includes(subParts[0])) {
            const name = subParts[0].split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
            if (!isGenericJobBoardName(name)) return name;
          }
        }
        
        // Generic company career pages: careers.company.com or company.com/careers
        const subdomainMatch = host.match(/^(?:careers?|jobs?|work)\.([^.]+)\./);
        if (subdomainMatch?.[1]) {
          const name = subdomainMatch[1].split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
          if (!isGenericJobBoardName(name)) return name;
        }
        
      } catch {}
      return null;
    }
    
    // Extract company name from job content using multiple fallback patterns
    function extractCompanyNameFallback(content: string): string | null {
      if (!content || content.length < 50) return null;
      
      // Take a larger sample for analysis
      const text = content.slice(0, 8000);
      
      const patterns = [
        // "About [Company Name]" section header
        /About\s+([A-Z][A-Za-z0-9\s&.,'-]+?)(?:\n|\r|:|\s{2,}|About Us)/,
        // "Company: Name" or "Employer: Name"
        /(?:Company|Employer|Organization|Hiring\s+Company)[:\s]+([A-Z][A-Za-z0-9\s&.,'-]+?)(?:\n|\r|[|•\-–—])/i,
        // "at [Company Name]" in job description
        /(?:position|role|job|opportunity)\s+(?:at|with)\s+([A-Z][A-Za-z0-9\s&.,'-]+?)(?:[.,]|\s+(?:is|we|in|for|where))/i,
        // "[Company Name] is hiring" or "[Company Name] is looking"
        /^([A-Z][A-Za-z0-9\s&.,'-]+?)\s+(?:is\s+)?(?:hiring|looking|seeking|recruiting)/im,
        // "Join [Company Name]" or "Join the [Company Name] team"
        /Join\s+(?:the\s+)?([A-Z][A-Za-z0-9\s&.,'-]+?)(?:\s+team|\s+family|[!.,])/i,
        // "Work at [Company Name]" or "Working at [Company Name]"
        /Work(?:ing)?\s+(?:at|for|with)\s+([A-Z][A-Za-z0-9\s&.,'-]+?)(?:[.,!]|\s+(?:means|is|you|where))/i,
        // "[Company Name], a leading..." or "[Company Name], an innovative..."
        /^([A-Z][A-Za-z0-9\s&.,'-]+?),\s+(?:a|an)\s+(?:leading|innovative|global|growing|fast-growing|premier)/im,
        // "Posted by [Company Name]"
        /Posted\s+by\s+([A-Z][A-Za-z0-9\s&.,'-]+?)(?:\n|\r|[|•\-–—])/i,
        // LinkedIn format: "Company Name · Location"
        /^([A-Z][A-Za-z0-9\s&.,'-]+?)\s*[·•]\s*(?:[A-Z][a-z]+(?:,|\s))/m,
        // Indeed format: Company name on its own line after job title
        /^([A-Z][A-Za-z0-9\s&.,'-]{2,50})\n(?:[0-9.]+\s*(?:★|star)|(?:Remote|Hybrid|On-?site)|\$|£|€|Location)/im,
      ];
      
      for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match?.[1]) {
          let name = normalizeText(match[1]);
          // Clean up the name
          name = name.replace(/[.,!]+$/, '').trim();
          // Remove trailing location-like words
          name = name.replace(/\s+(?:Inc|LLC|Ltd|Corp|Company|Co|PLC|GmbH|AG|SA|SAS|BV|NV|Pty|Limited)\.?$/i, '').trim();
          // Add back common suffixes cleanly
          const origMatch = match[1].match(/\s+(Inc|LLC|Ltd|Corp|PLC|GmbH|AG|SA|SAS|BV|NV|Pty|Limited)\.?$/i);
          if (origMatch) {
            name = name + ' ' + origMatch[1];
          }
          
          if (name.length >= 2 && name.length <= 80 && !isGenericJobBoardName(name)) {
            console.log(`Fallback company extraction found: "${name}"`);
            return name;
          }
        }
      }
      
      return null;
    }

    // Track results

    const results: {
      pendingJobsStored: number;
      pendingJobsScored: number;
      matchesSaved: number;
      jobsRejected: number;
      boardsSearched: Array<{ name: string; boardId: string; status: string; jobsFound: number }>;
      stoppedDueToTimeout: boolean;
      nextBoardIndex: number;
      totalBoardsAvailable: number;
      hasPendingJobs: boolean;
      mode: string;
      firecrawlQuotaExceeded: boolean;
      firecrawl402Count: number;
    } = {
      pendingJobsStored: 0,
      pendingJobsScored: 0,
      matchesSaved: 0,
      jobsRejected: 0,
      boardsSearched: [],
      stoppedDueToTimeout: false,
      nextBoardIndex: typeof continueFromBoard === 'number' ? continueFromBoard : 0,
      totalBoardsAvailable: 0,
      hasPendingJobs: false,
      mode,
      firecrawlQuotaExceeded: false,
      firecrawl402Count: 0,
    };

    // ===============================================================
    // SHARED: Build board profiles lookup (needed by both scrape and score modes)
    // ===============================================================
    const { data: activeBoards } = await supabaseAdmin
      .from('job_boards')
      .select('id, url, name, search_url_template, performance_score, lifetime_success_rate, target_countries, role_tags, url_allow_patterns, url_deny_patterns, job_id_pattern, min_content_length, total_searches, total_jobs_found')
      .eq('is_active', true);

    const boardProfiles = new Map<string, { allowPatterns: RegExp[]; denyPatterns: RegExp[]; jobIdPattern: RegExp | null; minContentLength: number }>();
    for (const b of (activeBoards || [])) {
      const allowPatterns: RegExp[] = [];
      const denyPatterns: RegExp[] = [];
      let jobIdPattern: RegExp | null = null;
      for (const p of (b.url_allow_patterns || [])) {
        try { allowPatterns.push(new RegExp(p, 'i')); } catch { console.log(`Invalid allow regex for ${b.name}: ${p}`); }
      }
      for (const p of (b.url_deny_patterns || [])) {
        try { denyPatterns.push(new RegExp(p, 'i')); } catch { console.log(`Invalid deny regex for ${b.name}: ${p}`); }
      }
      if (b.job_id_pattern) {
        try { jobIdPattern = new RegExp(b.job_id_pattern, 'i'); } catch { /* ignore */ }
      }
      boardProfiles.set(b.id, { allowPatterns, denyPatterns, jobIdPattern, minContentLength: b.min_content_length ?? 200 });
    }

    // ===============================================================
    // MODE: SCRAPE - Search job boards and store raw results to staging
    // No AI scoring in this phase - just discovery and storage
    // ===============================================================
    if (mode === 'scrape' || mode === 'all') {
      if (!FIRECRAWL_API_KEY) {
        console.log('Firecrawl not configured - skipping scrape phase');
      } else if (candidate.skills && candidate.skills.length > 0) {
        await writePipelineEvent('info', `Starting ${mode === 'scrape' ? 'scrape-only' : 'combined'} search...`);

        // Helper: check if a URL passes a board's allow/deny profile
        function urlPassesBoardProfile(url: string, boardId: string): { pass: boolean; reason?: string } {
          const profile = boardProfiles.get(boardId);
          if (!profile) return { pass: true };
          // Deny patterns: reject if any match
          if (profile.denyPatterns.length > 0) {
            for (const dp of profile.denyPatterns) {
              if (dp.test(url)) return { pass: false, reason: `board_deny_pattern: ${dp.source}` };
            }
          }
          // Allow patterns: if configured, URL must match at least one
          if (profile.allowPatterns.length > 0) {
            const allowed = profile.allowPatterns.some(ap => ap.test(url));
            if (!allowed) return { pass: false, reason: 'no_allow_pattern_match' };
          }
          return { pass: true };
        }

        const allBoardsWithTemplates = (activeBoards || []).filter((b: any) => b.search_url_template);
        results.totalBoardsAvailable = allBoardsWithTemplates.length;
        
        if (allBoardsWithTemplates.length === 0) {
          console.log('No active job boards configured');
          await writePipelineEvent('info', 'No active job boards configured');
        } else {
          // Build search query with proper country scoping
          const searchCountry = candidate.search_country || '';
          const searchCity = candidate.search_city || '';
          const desiredLocation = candidate.desired_location || '';
          const isRemotePreferred = searchCity.toLowerCase().includes('remote') || 
            searchCountry.toLowerCase().includes('remote') ||
            desiredLocation.toLowerCase().includes('remote') ||
            candidate.is_remote_worker === true;
          
          // Determine the target country - critical for location-scoped searches
          let targetCountry = searchCountry;
          if (!targetCountry && desiredLocation) {
            // Try to extract country from desired_location (e.g., "Austin, TX, USA" → "USA")
            const parts = desiredLocation.split(',').map((p: string) => p.trim());
            if (parts.length > 0) {
              const lastPart = parts[parts.length - 1];
              // Common country indicators
              const countryMap: Record<string, string> = {
                'usa': 'United States', 'us': 'United States', 'united states': 'United States',
                'uk': 'United Kingdom', 'united kingdom': 'United Kingdom', 'england': 'United Kingdom',
                'canada': 'Canada', 'ca': 'Canada',
                'australia': 'Australia', 'au': 'Australia',
                'germany': 'Germany', 'de': 'Germany',
                'france': 'France', 'fr': 'France',
                'india': 'India', 'in': 'India',
              };
              const normalized = lastPart.toLowerCase();
              targetCountry = countryMap[normalized] || lastPart;
            }
          }
          
          // For US cities, infer country if not set
          if (!targetCountry && searchCity) {
            const usStateAbbreviations = ['AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY'];
            const cityParts = searchCity.split(',').map((p: string) => p.trim().toUpperCase());
            const hasUsState = cityParts.some((p: string) => usStateAbbreviations.includes(p));
            if (hasUsState) {
              targetCountry = 'United States';
            }
          }
          
          // Build location string with country context
          let searchLocation = '';
          if (isRemotePreferred) {
            // Remote searches MUST be country-scoped
            if (targetCountry) {
              searchLocation = `remote ${targetCountry}`;
            } else {
              // Fallback - still try to get some location context
              searchLocation = 'remote';
              console.warn('Remote search without country - results may include international jobs');
            }
          } else if (searchCity && targetCountry) {
            searchLocation = `${searchCity} ${targetCountry}`;
          } else if (searchCity) {
            searchLocation = searchCity;
          } else if (targetCountry) {
            searchLocation = targetCountry;
          } else if (desiredLocation) {
            searchLocation = desiredLocation.split(',')[0].trim();
          }
          
          // Store target country for AI scoring context
          const candidateTargetCountry = targetCountry;

          // Build search queries - prioritize search_keywords if set, otherwise derive from profile
          let searchQueries: string[] = [];
          
          // 1. Use explicit search_keywords if available
          if (candidate.search_keywords && candidate.search_keywords.length > 0) {
            searchQueries = candidate.search_keywords.map((kw: string) => `${kw} ${searchLocation}`.trim());
          } else {
            // 2. Build queries from ideal_role (contains multiple target roles)
            const idealRole = candidate.ideal_role || '';
            if (idealRole) {
              // Split by / or , to get individual role variants
              const roleVariants = idealRole.split(/[\/,]/).map((r: string) => r.trim()).filter((r: string) => r.length > 3);
              for (const role of roleVariants.slice(0, 3)) {
                // Clean parenthetical content for cleaner search
                const cleanRole = role.replace(/\([^)]*\)/g, '').trim();
                if (cleanRole.length > 3) {
                  searchQueries.push(`${cleanRole} ${searchLocation}`.trim());
                }
              }
            }
            
            // 3. Add current_title as fallback query
            let coreTitle = candidate.current_title || '';
            coreTitle = coreTitle.split(' - ')[0].split(' – ')[0].trim();
            if (coreTitle && coreTitle.length > 5 && !searchQueries.some(q => q.toLowerCase().includes(coreTitle.toLowerCase()))) {
              searchQueries.push(`${coreTitle} ${searchLocation}`.trim());
            }
            
            // 4. If still empty, use top skills
            if (searchQueries.length === 0) {
              const topSkills = candidate.skills.slice(0, 3).join(' ');
              searchQueries.push(`${topSkills} developer ${searchLocation}`.trim());
            }
          }
          
          // Deduplicate and limit to 3 query variations for efficiency
          searchQueries = [...new Set(searchQueries)].slice(0, 5); // Allow up to 5 before feedback-based pruning
          
          // FEEDBACK LOOP: Prioritize queries using keyword_performance data
          try {
            const { data: kwPerf } = await supabaseAdmin
              .from('keyword_performance')
              .select('keyword, effectiveness_score, matches_produced, times_used')
              .eq('candidate_id', candidateId);
            
            if (kwPerf && kwPerf.length > 0) {
              const perfMap = new Map(kwPerf.map(kp => [kp.keyword.toLowerCase(), kp]));
              
              // Score each query by matching keywords
              const scoredQueries = searchQueries.map(q => {
                const qLower = q.replace(new RegExp(searchLocation.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '').trim().toLowerCase();
                const perf = perfMap.get(qLower);
                const score = perf ? (perf.effectiveness_score || 50) : 50; // Default 50 for unknown
                return { query: q, score, timesUsed: perf?.times_used || 0 };
              });
              
              // Sort by effectiveness (best first), but keep unused queries with moderate priority
              scoredQueries.sort((a, b) => {
                // Penalize queries that have been tried many times with low effectiveness
                const aEffective = a.timesUsed >= 3 ? a.score : 55; // Give untested queries slight boost
                const bEffective = b.timesUsed >= 3 ? b.score : 55;
                return bEffective - aEffective;
              });
              
              // Drop queries with very low effectiveness (< 15) if we have better options
              const goodQueries = scoredQueries.filter(q => q.score >= 15 || q.timesUsed < 3);
              if (goodQueries.length >= 2) {
                searchQueries = goodQueries.slice(0, 3).map(q => q.query);
                console.log(`[Feedback] Reordered queries by effectiveness: ${JSON.stringify(scoredQueries.map(q => `${q.query.split(' ')[0]}(${q.score})`))}`);
              } else {
                searchQueries = searchQueries.slice(0, 3);
              }
            } else {
              searchQueries = searchQueries.slice(0, 3);
            }
          } catch (fbErr) {
            console.log(`[Feedback] Could not load keyword performance: ${fbErr}`);
            searchQueries = searchQueries.slice(0, 3);
          }
          
          const distKm = candidate.search_distance_km ?? 40;
          const distMi = Math.round(distKm * 0.621371);
          console.log(`Search queries: ${JSON.stringify(searchQueries)} (target country: ${targetCountry || 'not set'}, remote: ${isRemotePreferred}, radius: ${distKm}km / ${distMi}mi)`);
          
          // GEO-FILTER: Only search boards relevant to the candidate's country
          // Map candidate country name to ISO code for matching against target_countries
          const countryNameToCode: Record<string, string> = {
            'united states': 'US', 'usa': 'US', 'us': 'US', 'america': 'US',
            'united kingdom': 'GB', 'uk': 'GB', 'england': 'GB', 'britain': 'GB',
            'canada': 'CA', 'australia': 'AU', 'germany': 'DE', 'france': 'FR',
            'india': 'IN', 'japan': 'JP', 'china': 'CN', 'singapore': 'SG',
            'brazil': 'BR', 'mexico': 'MX', 'spain': 'ES', 'italy': 'IT',
            'netherlands': 'NL', 'sweden': 'SE', 'norway': 'NO', 'denmark': 'DK',
            'new zealand': 'NZ', 'ireland': 'IE', 'switzerland': 'CH',
            'south korea': 'KR', 'philippines': 'PH', 'indonesia': 'ID',
            'malaysia': 'MY', 'thailand': 'TH', 'vietnam': 'VN',
            'argentina': 'AR', 'colombia': 'CO', 'chile': 'CL', 'peru': 'PE',
            'venezuela': 'VE', 'morocco': 'MA', 'south africa': 'ZA',
            'united arab emirates': 'AE', 'uae': 'AE', 'saudi arabia': 'SA',
            'qatar': 'QA', 'bahrain': 'BH', 'kuwait': 'KW',
            'poland': 'PL', 'portugal': 'PT', 'austria': 'AT', 'belgium': 'BE',
            'finland': 'FI', 'czech republic': 'CZ', 'romania': 'RO',
          };
          
          const candidateCountryCode = targetCountry 
            ? (countryNameToCode[targetCountry.toLowerCase().trim()] || targetCountry.toUpperCase().trim().slice(0, 2))
            : null;
          
          // ================================================================
          // ROLE-BASED FILTERING: Map candidate role to board role_tags
          // Skip boards that don't serve the candidate's role category
          // ================================================================
          const candidateRoleTags = new Set<string>();
          const roleLower = ((candidate.ideal_role || candidate.current_title || '') + ' ' + (candidate.skills || []).join(' ')).toLowerCase();
          
          // Map candidate profile to role categories
          if (/architect|engineer|developer|devops|sre|backend|frontend|fullstack|full.?stack|platform|infrastructure|software|mobile|ios|android|embedded|firmware/.test(roleLower)) candidateRoleTags.add('engineering');
          if (/data|analytics|bi\b|tableau|power bi|etl|spark|kafka|airflow|databricks/.test(roleLower)) candidateRoleTags.add('data');
          if (/\bai\b|machine learning|ml\b|deep learning|nlp|llm|computer vision|genai/.test(roleLower)) candidateRoleTags.add('ai');
          if (/security|cybersecurity|infosec|penetration|soc\b|devsecops|appsec/.test(roleLower)) candidateRoleTags.add('security');
          if (/devops|sre|site reliability|kubernetes|docker|terraform|cicd|ci\/cd/.test(roleLower)) candidateRoleTags.add('devops');
          if (/product manager|product management|product owner|product lead/.test(roleLower)) candidateRoleTags.add('product');
          if (/designer|ux|ui|user experience|user interface|figma/.test(roleLower)) candidateRoleTags.add('design');
          if (/sales|account executive|business development|pre-sales/.test(roleLower)) candidateRoleTags.add('sales');
          if (/marketing|growth|seo|content|brand/.test(roleLower)) candidateRoleTags.add('marketing');
          if (/healthcare|medical|clinical|nurse|physician/.test(roleLower)) candidateRoleTags.add('healthcare');
          if (/education|teaching|professor|instructor/.test(roleLower)) candidateRoleTags.add('education');
          
          console.log(`Candidate role tags: [${[...candidateRoleTags].join(', ')}]`);
          
          let boardsWithTemplates: any[];
          let geoSkipped = 0;
          let roleSkipped = 0;
          
          boardsWithTemplates = allBoardsWithTemplates.filter((b: any) => {
            // GEO-FILTER: Skip boards outside candidate's country
            // Allow boards with "Global", "Any", or "ALL" in target_countries
            if (candidateCountryCode && b.target_countries && b.target_countries.length > 0) {
              const globalWildcards = ['global', 'any', 'all', 'worldwide', 'international'];
              const hasWildcard = b.target_countries.some((tc: string) => 
                globalWildcards.includes(tc.toLowerCase().trim())
              );
              if (!hasWildcard && !b.target_countries.some((tc: string) => 
                tc.toUpperCase().trim() === candidateCountryCode
              )) {
                geoSkipped++;
                return false;
              }
            }
            
            // ROLE-TAG FILTER: Skip boards irrelevant to candidate's role
            if (candidateRoleTags.size > 0 && b.role_tags && b.role_tags.length > 0) {
              const hasOverlap = b.role_tags.some((tag: string) => candidateRoleTags.has(tag));
              if (!hasOverlap) {
                roleSkipped++;
                console.log(`[RoleFilter] Skipping ${b.name}: tags [${b.role_tags.join(',')}] don't match candidate [${[...candidateRoleTags].join(',')}]`);
                return false;
              }
            }
            
            return true;
          });
          
          console.log(`Board filtering: ${boardsWithTemplates.length} boards pass (geo-skipped: ${geoSkipped}, role-skipped: ${roleSkipped}, country: ${candidateCountryCode || 'any'})`);
          
          results.totalBoardsAvailable = boardsWithTemplates.length;

          // If targetBoardIds provided, filter to only those boards (used for targeted single-board runs)
          const filteredBoards = targetBoardIds && targetBoardIds.length > 0
            ? boardsWithTemplates.filter((b: any) => targetBoardIds.includes(b.id))
            : boardsWithTemplates;

          // GUARANTEED BOARDS: BuiltIn is always included for US candidates regardless of performance score ordering
          const BUILTIN_BOARD_ID = '77b0eb97-cb3d-4c69-b587-8611273c683b';
          const guaranteedBoardIds = [BUILTIN_BOARD_ID];

          // ============================================================
          // DEAD_BOARDS: Boards with consistently zero match value.
          // Determined empirically from production data (save rate analysis).
          // These boards are NEVER searched regardless of what's in the DB.
          // Review monthly — a board may recover after template changes.
          // ============================================================
          const DEAD_BOARDS_BLOCKLIST = new Set([
            'goinhouse',        // avg score 3.1, 0 saves from 300+ discoveries — legal/counsel roles only
            'hospitalrecruiting', // avg score 11.8, 3 saves from 156 — healthcare-specific, wrong profile
            'kijiji',           // avg score 3.2, 0 saves from 90 — classifieds, not tech jobs
            'internshala',      // avg score 7.3, 0 saves from 74 — Indian internships only
            'retailjobsweb',    // avg score 4.9, 0 saves from 51 — retail-only, wrong profile
            'secsinthecity',    // avg score 1.7, 0 saves from 80 — legal secretaries only
            'jobbsafari',       // Aggregator producing category pages, low quality
            'aimbridgehospitality', // Hospitality-only, wrong profile
            'foundationlist',   // Nonprofit-only, wrong profile
            'hiredchina',       // Chinese market jobs, irrelevant for most candidates
            'jobthai',          // Thai market jobs, irrelevant for most candidates
            'wuzzuf',           // Middle East market jobs, irrelevant for most candidates
            'clearancejobs',    // 92 discoveries, 0 saves — security clearance jobs only
            'jobsdb',           // 50 discoveries, 0 saves — Asian market aggregator
            'remoteok',         // 54 discoveries, 0 saves — mostly non-tech remote roles
          ]);

          // Sort boards by performance AND skip boards that have been searched but never found anything
          // Guaranteed boards bypass the dead-board filter
          const sortedBoards = [...filteredBoards]
            .filter((b: any) => {
              // Guaranteed boards always pass the filter
              if (guaranteedBoardIds.includes(b.id)) return true;
              // Hard blocklist — never search these boards
              const boardNameLower = (b.name || '').toLowerCase().replace(/[^a-z]/g, '');
              if (DEAD_BOARDS_BLOCKLIST.has(boardNameLower)) {
                console.log(`[Perf] Skipping blocklisted board: ${b.name}`);
                return false;
              }
              // Skip boards that have been searched multiple times but never found any jobs
              if ((b.total_searches ?? 0) >= 3 && (b.total_jobs_found ?? 0) === 0) {
                console.log(`[Perf] Skipping dead board: ${b.name} (${b.total_searches} searches, 0 jobs found)`);
                return false;
              }
              // Skip boards with very low lifetime success rate after enough data
              // Lower threshold from 1% to 2% — boards with <2% success are consistently poor
              if ((b.total_searches ?? 0) >= 5 && (b.lifetime_success_rate ?? 0) < 2) {
                console.log(`[Perf] Skipping low-yield board: ${b.name} (success rate: ${b.lifetime_success_rate}%)`);
                return false;
              }
              return true;
            })
            .sort((a: any, b: any) => {
              // Guaranteed boards go first
              const aGuaranteed = guaranteedBoardIds.includes(a.id) ? 1000 : 0;
              const bGuaranteed = guaranteedBoardIds.includes(b.id) ? 1000 : 0;
              if (aGuaranteed !== bGuaranteed) return bGuaranteed - aGuaranteed;
              const scoreA = a.performance_score ?? 50;
              const scoreB = b.performance_score ?? 50;
              return scoreB - scoreA;
            });

          // Start from continueFromBoard if specified (skip for targeted runs)
          const startIdx = (targetBoardIds && targetBoardIds.length > 0) ? 0 : (typeof continueFromBoard === 'number' ? continueFromBoard : 0);
          const boardsToSearch = sortedBoards.slice(startIdx);
          
          // Extract state info for template substitution
          const stateNameToAbbrev: Record<string, string> = {
            'alabama': 'AL', 'alaska': 'AK', 'arizona': 'AZ', 'arkansas': 'AR',
            'california': 'CA', 'colorado': 'CO', 'connecticut': 'CT', 'delaware': 'DE',
            'florida': 'FL', 'georgia': 'GA', 'hawaii': 'HI', 'idaho': 'ID',
            'illinois': 'IL', 'indiana': 'IN', 'iowa': 'IA', 'kansas': 'KS',
            'kentucky': 'KY', 'louisiana': 'LA', 'maine': 'ME', 'maryland': 'MD',
            'massachusetts': 'MA', 'michigan': 'MI', 'minnesota': 'MN', 'mississippi': 'MS',
            'missouri': 'MO', 'montana': 'MT', 'nebraska': 'NE', 'nevada': 'NV',
            'new hampshire': 'NH', 'new jersey': 'NJ', 'new mexico': 'NM', 'new york': 'NY',
            'north carolina': 'NC', 'north dakota': 'ND', 'ohio': 'OH', 'oklahoma': 'OK',
            'oregon': 'OR', 'pennsylvania': 'PA', 'rhode island': 'RI', 'south carolina': 'SC',
            'south dakota': 'SD', 'tennessee': 'TN', 'texas': 'TX', 'utah': 'UT',
            'vermont': 'VT', 'virginia': 'VA', 'washington': 'WA', 'west virginia': 'WV',
            'wisconsin': 'WI', 'wyoming': 'WY',
          };
          const abbrevToStateName: Record<string, string> = {};
          for (const [name, abbr] of Object.entries(stateNameToAbbrev)) {
            abbrevToStateName[abbr] = name.split(' ').map(w => w[0].toUpperCase() + w.slice(1)).join(' ');
          }
          
          // Determine candidate state from location
          let candidateStateAbbr = '';
          let candidateStateFull = '';
          const locParts = (desiredLocation || searchCity || '').split(',').map((p: string) => p.trim());
          for (const part of locParts) {
            const upper = part.toUpperCase();
            if (upper.length === 2 && abbrevToStateName[upper]) {
              candidateStateAbbr = upper;
              candidateStateFull = abbrevToStateName[upper];
              break;
            }
            const lower = part.toLowerCase();
            if (stateNameToAbbrev[lower]) {
              candidateStateAbbr = stateNameToAbbrev[lower];
              candidateStateFull = part.split(' ').map(w => w[0].toUpperCase() + w.slice(1)).join(' ');
              break;
            }
          }
          // Infer state from well-known cities
          if (!candidateStateAbbr && searchCity) {
            const cityToState: Record<string, [string, string]> = {
              'san francisco': ['CA', 'California'], 'los angeles': ['CA', 'California'],
              'san diego': ['CA', 'California'], 'san jose': ['CA', 'California'],
              'new york': ['NY', 'New York'], 'chicago': ['IL', 'Illinois'],
              'houston': ['TX', 'Texas'], 'dallas': ['TX', 'Texas'], 'austin': ['TX', 'Texas'],
              'phoenix': ['AZ', 'Arizona'], 'seattle': ['WA', 'Washington'],
              'denver': ['CO', 'Colorado'], 'boston': ['MA', 'Massachusetts'],
              'atlanta': ['GA', 'Georgia'], 'miami': ['FL', 'Florida'],
              'minneapolis': ['MN', 'Minnesota'], 'portland': ['OR', 'Oregon'],
              'detroit': ['MI', 'Michigan'], 'philadelphia': ['PA', 'Pennsylvania'],
              'charlotte': ['NC', 'North Carolina'], 'nashville': ['TN', 'Tennessee'],
              'salt lake city': ['UT', 'Utah'], 'raleigh': ['NC', 'North Carolina'],
              'pittsburgh': ['PA', 'Pennsylvania'], 'columbus': ['OH', 'Ohio'],
              'indianapolis': ['IN', 'Indiana'], 'tampa': ['FL', 'Florida'],
              'orlando': ['FL', 'Florida'], 'las vegas': ['NV', 'Nevada'],
            };
            const match = cityToState[searchCity.toLowerCase().split(',')[0].trim()];
            if (match) {
              candidateStateAbbr = match[0];
              candidateStateFull = match[1];
            }
          }
          
          const candidateCityClean = searchCity.split(',')[0].trim();
          console.log(`Template params: city=${candidateCityClean}, state=${candidateStateAbbr}/${candidateStateFull}, radius=${distMi}mi, maxAge=${MAX_JOB_AGE_DAYS}d`);
          
          // BuiltIn category selection: AI-powered using DB catalog
          // Loads active categories from builtin_job_categories, asks AI to pick top 1-3
          // Falls back to local heuristic if AI/DB fails
          let _builtinCategoryCache: { slugs: string[]; confidence: number[]; rationale: string } | null = null;

          async function selectBuiltinCategories(): Promise<{ slugs: string[]; confidence: number[]; rationale: string }> {
            if (_builtinCategoryCache) return _builtinCategoryCache;

            // Load active categories from DB
            const { data: dbCategories } = await supabaseAdmin
              .from('builtin_job_categories')
              .select('slug, label, parent_slug')
              .eq('is_active', true);

            const catalog = (dbCategories || []).map((c: any) => ({
              slug: c.slug,
              label: c.label,
              parent_slug: c.parent_slug,
            }));

            if (catalog.length === 0) {
              // Fallback to local heuristic
              const fallbackSlug = resolveBuiltInCategoryLocal();
              _builtinCategoryCache = { slugs: [fallbackSlug], confidence: [0.7], rationale: 'DB catalog empty, used local heuristic' };
              return _builtinCategoryCache;
            }

            // Ask AI to pick the best categories
            try {
              const candidateContext = [
                candidate.current_title ? `Current Title: ${candidate.current_title}` : '',
                candidate.ideal_role ? `Target Role: ${candidate.ideal_role}` : '',
                (candidate.skills || []).length ? `Skills: ${candidate.skills.join(', ')}` : '',
                candidate.ai_summary ? `Summary: ${candidate.ai_summary.slice(0, 300)}` : '',
                (candidate.industries_of_interest || []).length ? `Industries: ${candidate.industries_of_interest.join(', ')}` : '',
                candidate.experience_years ? `Experience: ${candidate.experience_years} years` : '',
              ].filter(Boolean).join('\n');

              const aiResp = await fetchWithTimeout('https://ai.gateway.lovable.dev/v1/chat/completions', {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${LOVABLE_API_KEY}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  model: 'google/gemini-2.5-flash-lite',
                  messages: [
                    {
                      role: 'system',
                      content: `You are selecting BuiltIn.com job category slugs for a candidate.
Given the candidate profile and the available category catalog, select 1-3 best matching category slugs.
You MUST only choose slugs from the provided catalog. Return JSON only.

Available categories:
${JSON.stringify(catalog)}

Return format:
{
  "selections": [
    { "slug": "exact-slug-from-catalog", "confidence": 0.0-1.0 }
  ],
  "rationale": "brief explanation"
}`
                    },
                    { role: 'user', content: candidateContext }
                  ],
                  temperature: 0.1,
                  max_tokens: 300,
                }),
              }, 10000, 'builtin-category-ai');

              if (aiResp.ok) {
                const aiData = await aiResp.json();
                const content = aiData.choices?.[0]?.message?.content || '';
                const parsed = safeParseFirstJsonObject(content);

                if (parsed?.selections && Array.isArray(parsed.selections)) {
                  const validSlugs = new Set(catalog.map((c: any) => c.slug));
                  const selections = parsed.selections
                    .filter((s: any) => validSlugs.has(s.slug) && (s.confidence || 0) >= 0.85)
                    .slice(0, 3);

                  if (selections.length > 0) {
                    // If all confidence < 0.85, add a fallback category
                    const hasHighConfidence = selections.some((s: any) => (s.confidence || 0) >= 0.85);
                    const slugs = selections.map((s: any) => s.slug);
                    const confidences = selections.map((s: any) => s.confidence || 0.5);

                    if (!hasHighConfidence) {
                      const fallback = resolveBuiltInCategoryLocal();
                      if (!slugs.includes(fallback)) {
                        slugs.push(fallback);
                        confidences.push(0.5);
                      }
                      console.log(`[BuiltIn AI] Low confidence, added fallback: ${fallback}`);
                    }

                    _builtinCategoryCache = {
                      slugs,
                      confidence: confidences,
                      rationale: parsed.rationale || 'AI selected',
                    };

                    console.log(`[BuiltIn AI] Selected categories: ${slugs.join(', ')} (confidence: ${confidences.map((c: number) => c.toFixed(2)).join(', ')})`);
                    await writePipelineEvent('info', `BuiltIn categories: ${slugs.join(', ')} (${parsed.rationale || 'AI'})`);
                    return _builtinCategoryCache;
                  }
                }
              }
            } catch (aiErr) {
              console.log(`[BuiltIn AI] Category selection failed: ${aiErr}`);
            }

            // Fallback to local heuristic
            const fallbackSlug = resolveBuiltInCategoryLocal();
            _builtinCategoryCache = { slugs: [fallbackSlug], confidence: [0.6], rationale: 'AI failed, local heuristic' };
            console.log(`[BuiltIn] Fallback category: ${fallbackSlug}`);
            return _builtinCategoryCache;
          }

          // Local heuristic fallback (original logic)
          function resolveBuiltInCategoryLocal(): string {
            const titleLower = (candidate.current_title || candidate.ideal_role || '').toLowerCase();
            const skillsLower = (candidate.skills || []).map((s: string) => s.toLowerCase());
            const industriesLower = (candidate.industries_of_interest || []).map((i: string) => i.toLowerCase());
            const allText = [titleLower, ...skillsLower, ...industriesLower].join(' ');

            const categoryMap: Array<{ slug: string; triggers: string[] }> = [
              { slug: 'dev-engineering', triggers: [
                'software engineer', 'software developer', 'backend', 'frontend', 'full stack', 'fullstack',
                'architect', 'solutions architect', 'technical architect', 'cloud architect', 'principal architect',
                'enterprise architect', 'infrastructure architect', 'platform architect', 'system architect',
                'devops', 'sre', 'site reliability', 'platform engineer', 'infrastructure engineer',
                'engineering manager', 'tech lead', 'technical lead', 'staff engineer', 'principal engineer',
                'mobile developer', 'ios developer', 'android developer', 'web developer',
                'embedded', 'firmware', 'systems engineer', 'qa engineer', 'test engineer', 'sdet',
                'release engineer', 'build engineer', 'tooling engineer',
              ]},
              { slug: 'ai-machine-learning', triggers: [
                'ai', 'machine learning', 'ml', 'artificial intelligence', 'deep learning', 'nlp',
                'computer vision', 'generative', 'llm', 'neural', 'data science', 'data scientist',
                'ai engineer', 'ml engineer', 'mlops', 'research scientist', 'applied research',
                'prompt engineer', 'genai', 'gen ai',
              ]},
              { slug: 'data-analytics', triggers: [
                'data analyst', 'business intelligence', 'bi developer', 'tableau', 'power bi', 'looker', 'dbt',
                'data engineer', 'data pipeline', 'etl', 'spark', 'kafka', 'airflow', 'databricks',
                'analytics engineer', 'data architect',
              ]},
              { slug: 'cybersecurity', triggers: [
                'security engineer', 'cybersecurity', 'penetration', 'soc analyst', 'devsecops', 'appsec',
                'security architect', 'information security', 'infosec', 'cloud security',
              ]},
              { slug: 'product-management', triggers: [
                'product manager', 'product management', 'product owner', 'roadmap', 'product lead',
              ]},
              { slug: 'design', triggers: [
                'ux designer', 'ui designer', 'product designer', 'design', 'user experience', 'user interface',
                'visual designer', 'interaction designer', 'design system',
              ]},
              { slug: 'project-management', triggers: [
                'project manager', 'program manager', 'scrum master', 'agile coach', 'delivery manager',
                'technical program manager', 'tpm',
              ]},
              { slug: 'sales', triggers: [
                'sales engineer', 'solutions engineer', 'pre-sales', 'account executive', 'sales',
              ]},
              { slug: 'consulting', triggers: [
                'consultant', 'consulting', 'advisory', 'implementation consultant',
              ]},
              { slug: 'marketing', triggers: [
                'marketing', 'growth', 'seo', 'content', 'digital marketing',
              ]},
              { slug: 'operations', triggers: [
                'operations', 'it support', 'system admin', 'helpdesk', 'support engineer',
              ]},
              { slug: 'hr', triggers: [
                'recruiter', 'hr', 'human resources', 'talent acquisition', 'people ops',
              ]},
            ];

            let bestSlug = '';
            let bestScore = 0;
            for (const { slug, triggers } of categoryMap) {
              const score = triggers.filter(t => allText.includes(t)).length;
              if (score > bestScore) {
                bestScore = score;
                bestSlug = slug;
              }
            }

            if (!bestSlug && (candidate.skills || []).length > 0) {
              bestSlug = 'dev-engineering';
            }

            return bestSlug || 'dev-engineering';
          }

          // Build native search URL from template by substituting placeholders
          // For BuiltIn, the category is resolved separately via selectBuiltinCategories()
          function buildNativeSearchUrl(template: string, keywords: string, builtinCategorySlug?: string): string {
            // {work_mode} resolves to BuiltIn-style path segment based on candidate preference
            // Remote workers → "remote", on-site workers → "office"
            const workModeSegment = isRemotePreferred ? 'remote' : 'office';

            // For BuiltIn, resolve the {builtin_category} placeholder
            let resolvedTemplate = template;
            if (template.includes('{builtin_category}')) {
              const category = builtinCategorySlug || 'dev-engineering';
              resolvedTemplate = template.replace(/\{builtin_category\}/g, category);
              console.log(`[BuiltIn] Using category: ${category}, search: ${keywords}`);
            }

            // Compute {location} intelligently based on country context
            // Non-US candidates should NOT get "City, ST" format
            let locationValue = '';
            if (isRemotePreferred) {
              // Remote: "Remote, Country" or just "Remote"
              locationValue = targetCountry ? `Remote, ${targetCountry}` : 'Remote';
            } else if (candidateCountryCode === 'US' && candidateCityClean && candidateStateAbbr) {
              // US with state: "City, ST"
              locationValue = `${candidateCityClean}, ${candidateStateAbbr}`;
            } else if (candidateCityClean && targetCountry) {
              // Non-US with city: "City, Country"
              locationValue = `${candidateCityClean}, ${targetCountry}`;
            } else if (candidateCityClean) {
              locationValue = candidateCityClean;
            } else if (targetCountry) {
              locationValue = targetCountry;
            }

            // Compute country values
            const countryName = targetCountry || '';
            const countryCode = candidateCountryCode || '';

            // Substitute all placeholders, degrading gracefully for missing values
            let url = resolvedTemplate
              .replace(/\{keywords\}/g, encodeURIComponent(keywords))
              .replace(/\{query\}/g, encodeURIComponent(keywords))
              .replace(/\{location\}/g, encodeURIComponent(locationValue))
              .replace(/\{city\}/g, encodeURIComponent(candidateCityClean))
              .replace(/\{state_full\}/g, encodeURIComponent(candidateStateFull))
              .replace(/\{state\}/g, encodeURIComponent(candidateStateFull))
              .replace(/\{state_abbr\}/g, candidateStateAbbr || '')
              .replace(/\{radius_mi\}/g, String(distMi))
              .replace(/\{max_age_days\}/g, String(MAX_JOB_AGE_DAYS))
              .replace(/\{country_code\}/g, countryCode || 'US')
              .replace(/\{country\}/g, encodeURIComponent(countryName))
              .replace(/\{work_type\}/g, workModeSegment)
              .replace(/\{work_mode\}/g, workModeSegment);

            // Degrade gracefully: strip any unresolved placeholders to avoid injecting literal "{xxx}" into URLs
            url = url.replace(/\{[a-z_]+\}/g, '');
            // Clean up double slashes (except protocol) and trailing ampersands from removed params
            url = url.replace(/([^:])\/\//g, '$1/').replace(/[&?]+$/, '');

            return url;
          }
          
          // Check if a URL is a job detail page (not a search/listing page)
          function isJobDetailUrl(url: string, boardDomain: string): boolean {
            if (isCategoryOrListingPage(url)) return false;
            const lowerUrl = url.toLowerCase();
            const d = boardDomain.toLowerCase();
            if (d.includes('indeed') && (lowerUrl.includes('/viewjob') || lowerUrl.includes('/rc/clk') || lowerUrl.includes('/pagead/'))) return true;
            if (d.includes('linkedin') && /\/jobs\/view\/\d+/.test(lowerUrl)) return true;
            if (d.includes('builtin') && /\/job\/[^/]+\/\d+/.test(lowerUrl)) return true;
            if (d.includes('dice') && lowerUrl.includes('/job-detail/')) return true;
            if (d.includes('glassdoor') && (lowerUrl.includes('/job-listing/') || lowerUrl.includes('/partner/joblisting'))) return true;
            if (d.includes('ziprecruiter') && lowerUrl.includes('/c/')) return true;
            if (d.includes('careerbuilder') && /\/job\/[a-z0-9]+/i.test(lowerUrl)) return true;
            if (d.includes('theladders') && lowerUrl.includes('/job/')) return true;
            if (d.includes('talent.com') && lowerUrl.includes('/view')) return true;
            if (d.includes('monster') && lowerUrl.includes('/job-openings/')) return true;
            if (d.includes('careerjet') && /\/job\/[a-z0-9]+/i.test(lowerUrl)) return true;
            if (d.includes('careeronestop') && lowerUrl.includes('/jobdetail/')) return true;
            if (d.includes('idealist') && /\/jobs?\/[a-f0-9-]+/.test(lowerUrl)) return true;
            // Generic: URL contains a job ID pattern
            if (/\/job[s]?[-/][a-f0-9-]{8,}/i.test(lowerUrl)) return true;
            if (/\/[\d]{6,}/.test(lowerUrl) && !lowerUrl.includes('?page=')) return true;
            return false;
          }
          
          // Check if template has any valid search parameters (keywords, location, or rich params)
          // ANY template with at least {keywords}, {query}, or {builtin_category} qualifies for native URL strategy
          function hasUsableTemplate(template: string): boolean {
            return template.includes('{keywords}') || template.includes('{query}') || template.includes('{builtin_category}');
          }
          
          // Check if template has rich parameters beyond basic {keywords}/{location}
          function hasRichTemplate(template: string): boolean {
            return template.includes('{city}') || template.includes('{state') || 
                   template.includes('{state_abbr}') || template.includes('{radius_mi}') || 
                   template.includes('{max_age_days}');
          }

          console.log(`Searching ${boardsToSearch.length} boards (starting from index ${startIdx})`);
          
          const BATCH_SIZE = 2; // 2 boards at a time — each board may fire 2-3 Firecrawl calls, staying under 5 concurrent limit

          // Load scraping caps from app_settings (fallback to defaults)
          let PER_BOARD_MAX_URLS = 40;
          let GLOBAL_MAX_URLS = 250;
          try {
            const { data: capSettings } = await supabaseAdmin
              .from('app_settings')
              .select('setting_key, setting_value')
              .in('setting_key', ['per_board_max_urls', 'global_max_urls']);
            for (const row of capSettings || []) {
              const v = parseInt(row.setting_value, 10);
              if (!isNaN(v) && v > 0) {
                if (row.setting_key === 'per_board_max_urls') PER_BOARD_MAX_URLS = v;
                if (row.setting_key === 'global_max_urls') GLOBAL_MAX_URLS = v;
              }
            }
            console.log(`Scraping caps: ${PER_BOARD_MAX_URLS}/board, ${GLOBAL_MAX_URLS}/run`);
          } catch (e) {
            console.warn('Failed to load scraping caps from settings, using defaults');
          }
          let boardsProcessed = 0;
          let totalJobsDiscovered = 0;
          
          // Pre-fetch existing pending/scored URLs for this candidate to ensure idempotency
          const { data: existingPendingUrls } = await supabaseAdmin
            .from('pipeline_pending_jobs')
            .select('job_url')
            .eq('candidate_id', candidateId)
            .in('status', ['pending', 'saved', 'scored', 'rejected']);
          const alreadyProcessedUrls = new Set((existingPendingUrls || []).map(r => canonicalizeJobUrl(r.job_url)));
          console.log(`[Idempotency] ${alreadyProcessedUrls.size} URLs already processed for this candidate`);
          
          for (let i = 0; i < boardsToSearch.length && !isTimeoutImminent() && !stopRequested; i += BATCH_SIZE) {
            // Abort early if Firecrawl is consistently rate-limiting us
            if (consecutive429Count >= 5) {
              console.log(`[Rate Limit] Aborting board search after ${consecutive429Count} consecutive 429s (searched ${boardsProcessed} boards)`);
              await writePipelineEvent('warning', `Rate limited by search API — pausing after ${boardsProcessed} boards. Will auto-continue.`);
              break;
            }
            // Global URL cap reached — stop searching more boards
            if (totalJobsDiscovered >= GLOBAL_MAX_URLS) {
              console.log(`[Cap] Global URL cap reached (${totalJobsDiscovered}/${GLOBAL_MAX_URLS}) — stopping board search`);
              await writePipelineEvent('info', `Global URL cap reached (${GLOBAL_MAX_URLS}) — stopping board search after ${boardsProcessed} boards.`);
              break;
            }
            if (i % 10 === 0) {
              await checkStopRequested();
              if (stopRequested) break;
            }
            
            const batch = boardsToSearch.slice(i, i + BATCH_SIZE);
            
            // Emit per-board events in a single batch insert for efficiency
            try {
              await supabaseAdmin.from('pipeline_events').insert(
                batch.map((board: any) => ({
                  candidate_id: candidateId,
                  created_by: user.id,
                  event_type: 'info',
                  message: `Searching ${board.name}...`,
                }))
              );
            } catch (e) { /* non-critical */ }

            const batchResults = await Promise.all(batch.map(async (board: any) => {
              try {
                let boardDomain = '';
                try {
                  boardDomain = new URL(board.url).hostname.replace(/^www\./, '');
                } catch {
                  return { board, jobs: [], status: 'failed' };
                }
                
                const allJobs: any[] = [];
                const seenUrls = new Set<string>();
                const template = board.search_url_template || '';
                const isBuiltIn = board.id === BUILTIN_BOARD_ID || boardDomain.includes('builtin.com');
                const useNativeUrl = hasUsableTemplate(template) && (candidateCityClean || searchLocation);
                
                // ============================================================
                // STRATEGY 1A: BuiltIn-specific category-aware pagination
                // Uses AI-selected categories + page= pagination
                // ============================================================
                if (isBuiltIn && useNativeUrl) {
                  const categoryResult = await selectBuiltinCategories();
                  const BUILTIN_MAX_PAGES = 5;
                  const BUILTIN_MAX_PER_CATEGORY = 50;

                  await writePipelineEvent('info', JSON.stringify({
                    type: 'builtin_categories',
                    slugs: categoryResult.slugs,
                    confidence: categoryResult.confidence,
                    rationale: categoryResult.rationale,
                  }));

                  for (const categorySlug of categoryResult.slugs) {
                    if (isTimeoutImminent()) break;
                    if (allJobs.length >= PER_BOARD_MAX_URLS) break;

                    let categoryJobCount = 0;

                    for (let page = 1; page <= BUILTIN_MAX_PAGES; page++) {
                      if (isTimeoutImminent()) break;
                      if (allJobs.length >= PER_BOARD_MAX_URLS) break;
                      if (categoryJobCount >= BUILTIN_MAX_PER_CATEGORY) break;

                      // Build paginated URL for this category — BuiltIn uses category browsing, no keywords in URL
                      let pageUrl = buildNativeSearchUrl(template, '', categorySlug);
                      if (page > 1) {
                        pageUrl += (pageUrl.includes('?') ? '&' : '?') + `page=${page}`;
                      }
                      
                      console.log(`[BuiltIn] Category ${categorySlug} page ${page}: ${pageUrl}`);

                      try {
                        const resp = await firecrawlFetch('https://api.firecrawl.dev/v1/scrape', {
                          method: 'POST',
                          headers: {
                            'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify({
                            url: pageUrl,
                            formats: ['links'],
                            waitFor: 3000,
                          }),
                        }, safeTimeoutMs(15000, 'critical'), `builtin:${categorySlug}:p${page}`);

                        if (!resp.ok) {
                          console.log(`[BuiltIn] Page ${page} failed: ${resp.status}`);
                          if (resp.status === 402) {
                            results.firecrawl402Count++;
                            if (results.firecrawl402Count >= 3) results.firecrawlQuotaExceeded = true;
                          }
                          break; // Stop paginating on error
                        }

                        const data = await resp.json();
                        const links: string[] = data?.data?.links || data?.links || [];

                        // Filter for BuiltIn job detail URLs
                        let pageJobCount = 0;
                        for (const link of links) {
                          if (!link) continue;
                          if (seenUrls.has(link)) continue;
                          try {
                            const linkHost = new URL(link).hostname.replace(/^www\./, '').toLowerCase();
                            if (!linkHost.includes('builtin.com')) continue;
                          } catch { continue; }
                          if (!isJobDetailUrl(link, boardDomain)) continue;
                          if (isCategoryOrListingPage(link)) continue;
                          const profileCheck = urlPassesBoardProfile(link, board.id);
                          if (!profileCheck.pass) continue;
                          const canonical = canonicalizeJobUrl(link);
                          if (alreadyProcessedUrls.has(canonical)) continue;
                          if (allJobs.length >= PER_BOARD_MAX_URLS) break;
                          if (totalJobsDiscovered + allJobs.length >= GLOBAL_MAX_URLS) break;

                          seenUrls.add(link);
                          allJobs.push({
                            url: link,
                            title: '',
                            content: '',
                            source: board.name,
                            boardId: board.id,
                            sourceQuery: `builtin:${categorySlug}`,
                          });
                          pageJobCount++;
                          categoryJobCount++;
                        }

                        console.log(`[BuiltIn] Category ${categorySlug} page ${page}: ${pageJobCount} jobs from ${links.length} links`);

                        // Stop pagination if page yielded 0 job cards
                        if (pageJobCount === 0) {
                          console.log(`[BuiltIn] Category ${categorySlug}: empty page ${page}, stopping pagination`);
                          break;
                        }
                      } catch (err) {
                        console.log(`[BuiltIn] Category ${categorySlug} page ${page} error: ${err}`);
                        break;
                      }
                    }

                    console.log(`[BuiltIn] Category ${categorySlug}: ${categoryJobCount} jobs discovered`);
                  }

                  // Log BuiltIn-specific diagnostics
                  await writePipelineEvent('diagnostics', JSON.stringify({
                    type: 'builtin_discovery',
                    categories_searched: categoryResult.slugs,
                    category_confidence: categoryResult.confidence,
                    total_jobs: allJobs.length,
                    rationale: categoryResult.rationale,
                  }));
                }
                // ============================================================
                // STRATEGY 1B: Standard native search URL (non-BuiltIn boards)
                // Uses the board's own search with city, state, radius, freshness
                // ============================================================
                else if (useNativeUrl) {
                  for (const baseQuery of searchQueries) {
                    if (isTimeoutImminent()) break;
                    
                    // Strip location from query since template handles it
                    const keywordsOnly = baseQuery
                      .replace(new RegExp(searchLocation.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '')
                      .trim();
                    const nativeUrl = buildNativeSearchUrl(template, keywordsOnly || baseQuery);
                    console.log(`[Native] ${board.name}: ${nativeUrl}`);
                    
                    try {
                      const resp = await firecrawlFetch('https://api.firecrawl.dev/v1/scrape', {
                        method: 'POST',
                        headers: {
                          'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
                          'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                          url: nativeUrl,
                          formats: ['links'],
                          waitFor: 3000,
                        }),
                      }, safeTimeoutMs(15000, 'critical'), `native:${board.name}`);
                      
                      if (resp.ok) {
                        const data = await resp.json();
                        const links: string[] = data?.data?.links || data?.links || [];
                        
                        // Filter for job detail URLs on this board's domain
                        // Apply allow/deny patterns + listing page check IMMEDIATELY at extraction
                        let linksDomainFiltered = 0;
                        let linksNotJobDetail = 0;
                        let linksBoardProfileRejected = 0;
                        let linksDuplicate = 0;
                        
                        const jobLinks = links.filter((link: string) => {
                          if (!link) return false;
                          if (seenUrls.has(link)) { linksDuplicate++; return false; }
                          try {
                            const linkHost = new URL(link).hostname.replace(/^www\./, '').toLowerCase();
                            if (!linkHost.includes(boardDomain.replace('www.', '').toLowerCase())) { linksDomainFiltered++; return false; }
                          } catch { return false; }
                          if (!isJobDetailUrl(link, boardDomain)) { linksNotJobDetail++; return false; }
                          if (isCategoryOrListingPage(link)) { linksNotJobDetail++; return false; }
                          // Apply board-specific allow/deny patterns
                          const profileCheck = urlPassesBoardProfile(link, board.id);
                          if (!profileCheck.pass) { linksBoardProfileRejected++; return false; }
                          return true;
                        });
                        
                        for (const link of jobLinks) {
                          // Per-board URL cap
                          if (allJobs.length >= PER_BOARD_MAX_URLS) break;
                          // Global cap
                          if (totalJobsDiscovered + allJobs.length >= GLOBAL_MAX_URLS) break;
                          // Idempotency: skip URLs already processed in prior runs
                          const canonical = canonicalizeJobUrl(link);
                          if (alreadyProcessedUrls.has(canonical)) continue;
                          
                          seenUrls.add(link);
                          allJobs.push({
                            url: link,
                            title: '', // Will be extracted during scoring
                            content: '', // Will be scraped during scoring
                            source: board.name,
                            boardId: board.id,
                            sourceQuery: keywordsOnly || baseQuery,
                          });
                        }
                        
                        console.log(`[Native] ${board.name}: ${jobLinks.length} job links from ${links.length} total (domain: -${linksDomainFiltered}, not-job: -${linksNotJobDetail}, profile: -${linksBoardProfileRejected}, dupe: -${linksDuplicate})`);
                      } else {
                        console.log(`[Native] ${board.name} failed: ${resp.status} - falling back to search`);
                        if (resp.status === 402) {
                          results.firecrawl402Count++;
                          if (results.firecrawl402Count >= 3) {
                            results.firecrawlQuotaExceeded = true;
                            console.error('[Quota] Firecrawl API returned 402 (Payment Required) - credits exhausted');
                          }
                        }
                      }
                    } catch (nativeErr) {
                      console.log(`[Native] ${board.name} error: ${nativeErr} - falling back to search`);
                    }
                  }
                }
                
                // ============================================================
                // STRATEGY 2: Firecrawl web search with site: filter (fallback)
                // Used when native URL not available or returned few results
                // ============================================================
                const nativeFoundEnough = allJobs.length >= 5;
                if (!nativeFoundEnough) {
                  let siteFilter = `site:${boardDomain}`;
                  const domain = boardDomain.toLowerCase();
                  if (domain.includes('indeed.')) siteFilter = `site:${boardDomain} (inurl:viewjob OR inurl:/rc/clk)`;
                  else if (domain.includes('glassdoor.')) siteFilter = `site:${boardDomain} (inurl:job-listing OR inurl:partner/jobListing)`;
                  else if (domain.includes('linkedin.')) siteFilter = `site:linkedin.com/jobs (inurl:view OR inurl:jobs/)`;
                  else if (domain.includes('builtin')) siteFilter = `site:${boardDomain}/job/`;
                  
                  let consecutiveEmpty = 0;
                  for (const baseQuery of searchQueries) {
                    if (isTimeoutImminent()) break;
                    // EARLY TERMINATION: If first keyword returned 0, skip remaining keywords for this board
                    if (consecutiveEmpty >= 1 && allJobs.length === 0) {
                      console.log(`[Search] ${board.name}: Skipping remaining keywords (first returned 0)`);
                      break;
                    }
                    
                    const searchQuery = `${baseQuery} ${siteFilter}`;
                    console.log(`[Search] ${board.name}: ${searchQuery}`);
                    
                    const prevCount = allJobs.length;
                    try {
                      const resp = await firecrawlFetch('https://api.firecrawl.dev/v1/search', {
                        method: 'POST',
                        headers: {
                          'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
                          'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                          query: searchQuery,
                          limit: 10,
                          // No scrapeOptions — URLs are stored and scraped individually during scoring phase
                          // to avoid paying for full-page scrapes we'd discard after URL extraction
                        }),
                      }, safeTimeoutMs(12000, 'critical'), `search:${board.name}`);
                      
                      if (!resp.ok) {
                        console.log(`[Search] ${board.name} query "${baseQuery}": ${resp.status}`);
                        if (resp.status === 402) {
                          results.firecrawl402Count++;
                          if (results.firecrawl402Count >= 3) {
                            results.firecrawlQuotaExceeded = true;
                            console.error('[Quota] Firecrawl API returned 402 (Payment Required) - credits exhausted');
                          }
                        }
                        consecutiveEmpty++;
                        continue;
                      }
                      
                      const data = await resp.json();
                      const searchResults = (data?.data || []) as any[];
                      
                      for (const r of searchResults) {
                        if (!r.url || seenUrls.has(r.url)) continue;
                        if (!((r.markdown && r.markdown.length >= 100) || (r.description && r.description.length >= 100))) continue;
                        // Per-board + global caps
                        if (allJobs.length >= PER_BOARD_MAX_URLS) break;
                        if (totalJobsDiscovered + allJobs.length >= GLOBAL_MAX_URLS) break;
                        // Idempotency: skip already-processed URLs
                        const canonical = canonicalizeJobUrl(r.url);
                        if (alreadyProcessedUrls.has(canonical)) continue;
                        // Apply board profile + listing page filter
                        if (isCategoryOrListingPage(r.url)) continue;
                        const profileCheck = urlPassesBoardProfile(r.url, board.id);
                        if (!profileCheck.pass) continue;
                        
                        seenUrls.add(r.url);
                        allJobs.push({
                          url: r.url,
                          title: r.title || '',
                          content: r.markdown || r.description || '',
                          source: board.name,
                          boardId: board.id,
                          sourceQuery: baseQuery,
                        });
                      }
                      
                      if (allJobs.length === prevCount) consecutiveEmpty++;
                      else consecutiveEmpty = 0;
                    } catch (queryErr) {
                      console.log(`[Search] ${board.name} error: ${queryErr}`);
                      consecutiveEmpty++;
                    }
                  }
                }
                
                console.log(`${board.name}: Found ${allJobs.length} unique jobs (native: ${useNativeUrl}, fallback: ${!nativeFoundEnough})`);
                
                return {
                  board,
                  jobs: allJobs,
                  status: allJobs.length > 0 ? 'success' : 'empty',
                };
              } catch (err) {
                console.error(`Error searching ${board.name}:`, err);
                return { board, jobs: [], status: 'failed' };
              }
            }));
            
            // Store discovered jobs to staging table
            const allJobs = batchResults.flatMap(r => r.jobs);
            // Global cap enforcement
            const cappedJobs = allJobs.slice(0, Math.max(0, GLOBAL_MAX_URLS - totalJobsDiscovered));
            
            if (cappedJobs.length > 0) {
              // At this point, allow/deny and listing page filters were already applied at extraction.
              // Only canonicalize and map for insert.
              const pendingRecords = cappedJobs.map(job => ({
                candidate_id: candidateId,
                run_id: runId,
                job_url: canonicalizeJobUrl(job.url),
                job_title: job.title || null,
                job_content: (job.content || '').slice(0, 15000) || null,
                source_board: job.source,
                source_query: job.sourceQuery || null,
                status: 'pending' as const,
              }));
              
              try {
                const { error: insertError } = await supabaseAdmin
                  .from('pipeline_pending_jobs')
                  .upsert(pendingRecords, { onConflict: 'candidate_id,job_url', ignoreDuplicates: true });
                
                if (!insertError) {
                  results.pendingJobsStored += cappedJobs.length;
                  totalJobsDiscovered += cappedJobs.length;
                  console.log(`Stored ${cappedJobs.length} pending jobs (total: ${totalJobsDiscovered}/${GLOBAL_MAX_URLS} cap)`);
                } else {
                  console.error('Error storing pending jobs:', insertError);
                }
              } catch (err) {
                console.error('Failed to store pending jobs:', err);
              }
            }
            
            // Update board stats, persist to job_board_performance, and emit per-board diagnostics
            for (const r of batchResults) {
              results.boardsSearched.push({
                name: r.board.name,
                boardId: r.board.id,
                status: r.status,
                jobsFound: r.jobs.length,
              });
              boardsProcessed++;
              
              // Persist per-board discovery stats to job_board_performance
              if (r.status === 'success' || r.jobs.length > 0) {
                try {
                  await supabaseAdmin.from('job_board_performance').insert({
                    job_board_id: r.board.id,
                    candidate_id: candidateId,
                    searches_performed: 1,
                    jobs_found: r.jobs.length,
                    jobs_matched: 0, // Updated after scoring
                    jobs_saved: 0,   // Updated after scoring
                    search_date: new Date().toISOString().split('T')[0],
                  });
                } catch (perfErr) {
                  console.log(`[Perf] Failed to insert board performance for ${r.board.name}: ${perfErr}`);
                }
              }
              
              // Emit structured per-board diagnostics event
              await writePipelineEvent('board_result', JSON.stringify({
                board_name: r.board.name,
                board_id: r.board.id,
                status: r.status,
                jobs_found: r.jobs.length,
                capped_at: PER_BOARD_MAX_URLS,
                template_used: !!r.board.search_url_template,
              }));
            }
            
            await writePipelineEvent('info', `Searched ${boardsProcessed} boards, discovered ${totalJobsDiscovered} jobs...`);
            
            // Emit comprehensive scrape_summary event
            await writePipelineEvent('diagnostics', JSON.stringify({
              type: 'scrape_summary',
              boards_searched: boardsProcessed,
              total_boards_available: boardsToSearch.length,
              jobs_discovered: totalJobsDiscovered,
              global_cap: GLOBAL_MAX_URLS,
              per_board_cap: PER_BOARD_MAX_URLS,
              already_processed_urls: alreadyProcessedUrls.size,
              firecrawl_calls: firecrawlCallCount,
              rate_limit_aborted: consecutive429Count >= 5,
              geo_skipped: geoSkipped,
              role_skipped: roleSkipped,
              boards: results.boardsSearched.map(b => ({ name: b.name, status: b.status, found: b.jobsFound })),
            }));
          }
          
          // ============================================================
          // BONUS PASS: Google Jobs search for LinkedIn-indexed listings
          // Google indexes LinkedIn job postings publicly — no auth needed
          // ============================================================
          if (!isTimeoutImminent() && !stopRequested && !results.firecrawlQuotaExceeded && totalJobsDiscovered < GLOBAL_MAX_URLS) {
            try {
              console.log('[Google Jobs] Starting supplemental LinkedIn discovery...');
              const googleJobsFound: any[] = [];
              const googleSeenUrls = new Set<string>();
              
              // Collect already-stored URLs to avoid duplicates
              const { data: existingPending } = await supabaseAdmin
                .from('pipeline_pending_jobs')
                .select('job_url')
                .eq('candidate_id', candidateId);
              for (const ep of existingPending || []) {
                googleSeenUrls.add(ep.job_url);
              }
              
              // Run up to 2 Google queries targeting LinkedIn job pages
              const googleQueries = searchQueries.slice(0, 2);
              for (const baseQuery of googleQueries) {
                if (isTimeoutImminent()) break;
                
                const keywordsOnly = baseQuery
                  .replace(new RegExp(searchLocation.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '')
                  .trim();
                const googleQuery = `${keywordsOnly || baseQuery} ${searchLocation} site:linkedin.com/jobs`;
                console.log(`[Google Jobs] Query: ${googleQuery}`);
                
                try {
                  const resp = await firecrawlFetch('https://api.firecrawl.dev/v1/search', {
                    method: 'POST',
                    headers: {
                      'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
                      'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                      query: googleQuery,
                      limit: 15,
                      // No scrapeOptions — URL-only discovery, content fetched during scoring phase
                    }),
                  }, safeTimeoutMs(12000, 'critical'), 'search:GoogleJobs');
                  
              if (resp.ok) {
                    const data = await resp.json();
                    const results_arr = (data?.data || []) as any[];
                    let googleAccepted = 0;
                    let googleRejectedListing = 0;
                    let googleRejectedNoJobView = 0;
                    let googleRejectedDupe = 0;
                    
                    for (const r of results_arr) {
                      if (!r.url) continue;
                      if (!r.url.includes('linkedin.com/jobs')) continue;
                      
                      // CRITICAL FIX: Filter for actual job detail pages, not search/listing pages
                      if (isCategoryOrListingPage(r.url)) {
                        googleRejectedListing++;
                        continue;
                      }
                      // LinkedIn job detail URLs must contain /jobs/view/ID
                      if (!/\/jobs\/view\/\d+/.test(r.url)) {
                        googleRejectedNoJobView++;
                        continue;
                      }
                      
                      const canonicalGoogleUrl = canonicalizeJobUrl(r.url);
                      if (googleSeenUrls.has(r.url) || googleSeenUrls.has(canonicalGoogleUrl) || alreadyProcessedUrls.has(canonicalGoogleUrl)) {
                        googleRejectedDupe++;
                        continue;
                      }
                      
                      googleSeenUrls.add(r.url);
                      googleSeenUrls.add(canonicalGoogleUrl);
                      googleJobsFound.push({
                        candidate_id: candidateId,
                        run_id: runId,
                        job_url: canonicalGoogleUrl,
                        job_title: r.title || null,
                        job_content: (r.description || '').slice(0, 15000) || null,
                        source_board: 'LinkedIn (via Google)',
                        source_query: keywordsOnly || baseQuery,
                        status: 'pending' as const,
                      });
                      googleAccepted++;
                    }
                    
                    console.log(`[Google Jobs] Query results: ${results_arr.length} total, ${googleAccepted} accepted, ${googleRejectedListing} listing pages, ${googleRejectedNoJobView} no job view URL, ${googleRejectedDupe} dupes`);
                  } else {
                    console.log(`[Google Jobs] Search failed: ${resp.status}`);
                    if (resp.status === 402) results.firecrawl402Count++;
                  }
                } catch (gErr) {
                  console.log(`[Google Jobs] Error: ${gErr}`);
                }
              }
              
            if (googleJobsFound.length > 0) {
                const { error: gInsertErr } = await supabaseAdmin
                  .from('pipeline_pending_jobs')
                  .upsert(googleJobsFound, { onConflict: 'candidate_id,job_url', ignoreDuplicates: true });
                if (!gInsertErr) {
                  totalJobsDiscovered += googleJobsFound.length;
                  results.pendingJobsStored += googleJobsFound.length;
                  console.log(`[Google Jobs] Discovered ${googleJobsFound.length} additional LinkedIn jobs`);
                  await writePipelineEvent('info', `Google Jobs: Found ${googleJobsFound.length} LinkedIn listings`);
                }
              } else {
                console.log('[Google Jobs] No additional LinkedIn jobs found');
                await writePipelineEvent('warning', `Google Jobs: 0 LinkedIn listings found. Queries tried: ${googleQueries.length}. This may indicate LinkedIn is blocking indexed results or queries need refinement.`);
              }
            } catch (googleErr) {
              console.log(`[Google Jobs] Pass failed: ${googleErr}`);
            }
          }
          
          results.nextBoardIndex = startIdx + boardsProcessed;
          
          // Check if we timed out with boards remaining
          if (isTimeoutImminent() && results.nextBoardIndex < results.totalBoardsAvailable) {
            results.stoppedDueToTimeout = true;
            const remaining = results.totalBoardsAvailable - results.nextBoardIndex;
            await writePipelineEvent('warning', `Scrape paused - time limit reached. Searched ${results.nextBoardIndex} of ${results.totalBoardsAvailable} boards. ${remaining} boards remaining. ${totalJobsDiscovered} jobs queued for scoring.`);
            // Persist scrape progress so the server-side cron can resume board searching
            // without needing the user to have the page open
            await writePipelineEvent('scrape_paused', JSON.stringify({
              nextBoardIndex: results.nextBoardIndex,
              totalBoardsAvailable: results.totalBoardsAvailable,
              pausedAt: new Date().toISOString(),
            }));
          } else if (stopRequested) {
            await writePipelineEvent('info', `Scrape stopped by user. Searched ${boardsProcessed} boards, discovered ${totalJobsDiscovered} jobs.`);
          } else {
            await writePipelineEvent('success', `Scrape complete. Searched ${boardsProcessed} boards, discovered ${totalJobsDiscovered} jobs.`);
          }
          
          // After scrape, check how many pending jobs exist for the frontend to trigger score phase
          // IMPORTANT: Check ALL pending jobs for this candidate, not just ones stored in this run
          const { count: pendingAfterScrape } = await supabaseAdmin
            .from('pipeline_pending_jobs')
            .select('id', { count: 'exact', head: true })
            .eq('candidate_id', candidateId)
            .eq('status', 'pending');
          
          const pendingCount = pendingAfterScrape || 0;
          results.hasPendingJobs = pendingCount > 0;
          console.log(`Scrape complete: ${pendingCount} pending jobs ready for scoring`);
          
          // Detailed scrape diagnostics
          const scrapeSearchProgress = results.searchProgress || {};
          await writePipelineEvent('diagnostics', JSON.stringify({
            type: 'scrape_summary',
            boards_searched: (scrapeSearchProgress as any).boardsSearched?.length || 0,
            boards_available: (scrapeSearchProgress as any).totalBoardsAvailable || 0,
            boards_detail: ((scrapeSearchProgress as any).boardsSearched || []).map((b: any) => ({
              name: b.name, jobs_found: b.jobsFound, status: b.status,
            })),
            total_pending: pendingCount,
            firecrawl_calls: firecrawlCallCount || 0,
            stopped_due_to_timeout: (scrapeSearchProgress as any).stoppedDueToTimeout || false,
          }));
          
          // If we found pending jobs (from this run or prior runs), signal that to frontend
          if (pendingCount > 0) {
            await writePipelineEvent('info', `${pendingCount} jobs queued for AI scoring...`);
          }
        }
      }
    }

    // ===============================================================
    // MODE: SCORE - Process pending jobs with AI scoring
    // No board searching - just scoring queued jobs
    // ===============================================================
    if ((mode === 'score' || mode === 'all') && !isCriticalTimeout()) {
      // Get current match count to check if we need more
      const { count: currentMatchCount } = await supabaseClient
        .from('matches')
        .select('id', { count: 'exact', head: true })
        .eq('candidate_id', candidateId);
      
        // Always score all pending jobs - target is informational, not a hard stop
      const needsMoreMatches = true;
      
      if (false) {
        // Never skip scoring based on target - exhausting all boards is the goal
        results.hasPendingJobs = false;
      } else {
        // Fetch pending jobs for this candidate — each batch uses a different offset
        // so parallel batches from the resume worker don't all score the same jobs
        const BATCH_JOB_LIMIT = 25;
        const batchOffset = (batchIndex ?? 0) * BATCH_JOB_LIMIT;
        const { data: pendingJobsRaw } = await supabaseAdmin
          .from('pipeline_pending_jobs')
          .select('*')
          .eq('candidate_id', candidateId)
          .eq('status', 'pending')
          .order('discovered_at', { ascending: true })
          .range(batchOffset, batchOffset + BATCH_JOB_LIMIT - 1);
        
        if (!pendingJobsRaw || pendingJobsRaw.length === 0) {
          console.log('No pending jobs to score');
          results.hasPendingJobs = false;
        } else {
          // ================================================================
          // PRE-FILTER: Remove jobs from known large companies BEFORE AI scoring
          // This saves API calls by rejecting obvious mismatches early
          // ================================================================
          
          // Uses KNOWN_LARGE_COMPANIES constant defined at module level
          
          // Get all companies marked as exceeds_size or with employee_count >= max from DB
          const { data: largeCompanies } = await supabaseAdmin
            .from('companies')
            .select('name, employee_count, enrichment_status')
            .or(`enrichment_status.eq.exceeds_size,employee_count.gte.${MAX_COMPANY_EMPLOYEES}`);
          
          // Combine DB companies with hardcoded enterprise list
          const largeCompanyNames = new Set([
            ...KNOWN_LARGE_COMPANIES,
            ...(largeCompanies || []).map(c => c.name.toLowerCase().trim())
          ]);
          
          // Filter pending jobs and reject those from known large companies
          // OPTIMIZATION: Collect rejection IDs and batch-update instead of individual DB calls
          const pendingJobs: typeof pendingJobsRaw = [];
          let preFilterRejected = 0;
          const preFilterRejectIds: { id: string; reason: string }[] = [];
          
          for (const job of pendingJobsRaw) {
            const titleLower = (job.job_title || '').toLowerCase();
            const companyNameFromPending = (job.company_name || '').toLowerCase().trim();
            
            // Direct company_name match (if stored during scrape)
            if (companyNameFromPending && largeCompanyNames.has(companyNameFromPending)) {
              console.log(`[Pre-filter] Rejecting job from known large company: ${job.company_name}`);
              preFilterRejectIds.push({ id: job.id, reason: `Pre-filter: Company exceeds max employees (${MAX_COMPANY_EMPLOYEES})` });
              preFilterRejected++;
              continue;
            }
            
            // Check if any large company name appears in the job title
            let matchedLargeCompany: string | null = null;
            for (const largeName of largeCompanyNames) {
              if (largeName.length > 3 && titleLower.includes(largeName)) {
                matchedLargeCompany = largeName;
                break;
              }
            }
            
            if (matchedLargeCompany) {
              console.log(`[Pre-filter] Rejecting job with large company in title: "${matchedLargeCompany}" from "${job.job_title}"`);
              preFilterRejectIds.push({ id: job.id, reason: `Pre-filter: Company "${matchedLargeCompany}" exceeds max employees` });
              preFilterRejected++;
              continue;
            }
            
            pendingJobs.push(job);
          }
          
          // Batch-update all pre-filter rejections in one call
          if (preFilterRejectIds.length > 0) {
            const rejectIdsOnly = preFilterRejectIds.map(r => r.id);
            await supabaseAdmin
              .from('pipeline_pending_jobs')
              .update({ status: 'rejected', rejection_reason: `Pre-filter: Company exceeds max employees (${MAX_COMPANY_EMPLOYEES})` })
              .in('id', rejectIdsOnly);
          }
          
          if (preFilterRejected > 0) {
            // Log each rejected company name for diagnostics
            const rejectedCompanyNames = preFilterRejectIds.map(r => {
              const job = pendingJobsRaw.find(j => j.id === r.id);
              return job?.company_name || job?.job_title || 'unknown';
            });
            console.log(`[Pre-filter] Rejected ${preFilterRejected} jobs from known large companies`);
            await writePipelineEvent('filter', JSON.stringify({
              type: 'pre_filter_large_company',
              rejected: preFilterRejected,
              remaining: pendingJobs.length,
              rejected_companies: rejectedCompanyNames.slice(0, 20),
              max_employees: MAX_COMPANY_EMPLOYEES,
            }));
          }
          
          // If all jobs were filtered out, we're done
          if (pendingJobs.length === 0) {
            console.log('All pending jobs filtered out (large companies)');
            results.hasPendingJobs = false;
          } else {
            // ================================================================
            // CROSS-BOARD DEDUPLICATION
            // Detect the same job appearing on multiple boards and keep only one
            // Uses URL canonicalization + title/company fingerprinting
            // ================================================================
            const seenCanonicalUrls = new Set<string>();
            const seenFingerprints = new Set<string>();
            const dedupedJobs: typeof pendingJobs = [];
            let dedupRejected = 0;
            const dedupRejectIds: string[] = [];

            for (const job of pendingJobs) {
              const canonical = canonicalizeJobUrl(job.job_url);
              if (seenCanonicalUrls.has(canonical)) {
                dedupRejectIds.push(job.id);
                dedupRejected++;
                continue;
              }
              seenCanonicalUrls.add(canonical);

              const fp = buildJobFingerprint(job.job_url, job.job_title || '');
              if (fp && seenFingerprints.has(fp)) {
                dedupRejectIds.push(job.id);
                dedupRejected++;
                continue;
              }
              if (fp) seenFingerprints.add(fp);

              dedupedJobs.push(job);
            }
            
            // Batch-update all dedup rejections in one call
            if (dedupRejectIds.length > 0) {
              await supabaseAdmin
                .from('pipeline_pending_jobs')
                .update({ status: 'rejected', rejection_reason: 'Duplicate: cross-board' })
                .in('id', dedupRejectIds);
            }

            if (dedupRejected > 0) {
              console.log(`[Dedup] Removed ${dedupRejected} cross-board duplicates (${dedupedJobs.length} remaining)`);
              await writePipelineEvent('filter', JSON.stringify({
                type: 'cross_board_dedup',
                rejected: dedupRejected,
                remaining: dedupedJobs.length,
              }));
            }

            // Replace pendingJobs with deduped list
            pendingJobs.length = 0;
            pendingJobs.push(...dedupedJobs);

            if (pendingJobs.length === 0) {
              console.log('All pending jobs removed by deduplication');
              results.hasPendingJobs = false;
            } else {

            console.log(`Scoring ${pendingJobs.length} pending jobs (after pre-filter + dedup)...`);
            results.hasPendingJobs = true;
            await writePipelineEvent('info', `Scoring ${pendingJobs.length} pending jobs with AI...`);
          
          // OPTIMIZATION: Pre-fetch all companies ONCE for the entire scoring loop
          // instead of querying per-job (was N queries, now 1)
          const { data: allCompaniesCache } = await supabaseClient
            .from('companies')
            .select('id, employee_count, enrichment_status, name');
          const companiesLookup = new Map<string, { id: string; employee_count: number | null; enrichment_status: string; name: string }>();
          for (const c of (allCompaniesCache || [])) {
            companiesLookup.set(normalizeCompanyName(c.name), c);
          }
          
          let matchesSaved = currentMatchCount || 0;
          // Process jobs SEQUENTIALLY (one at a time) to avoid hitting the AI gateway rate limit.
          // Concurrent requests (even 4) trigger 429s on GPT models. Sequential is slower but reliable.
          const jobsNeedingScrape = pendingJobs.filter(j => (j.job_content || '').length < 100).length;
          const AI_BATCH_SIZE = 1; // Sequential — prevents all 429 rate limit errors
          const AI_INTER_JOB_DELAY_MS = 200; // 200ms between jobs
          const AI_TIMEOUT_MS = 35000; // 35s timeout per AI call — gemini-2.5-flash is fast but need headroom
          console.log(`Scoring sequentially (${jobsNeedingScrape}/${pendingJobs.length} need scraping)`);
          
          // Helper function to extract location from content using pattern matching as fallback
          function extractLocationFallback(content: string): string | null {
            const text = content.toLowerCase();
            
            // Common location patterns
            const patterns = [
              // "Location: City, State" or "Location: Remote"
              /location[:\s]+([A-Za-z][A-Za-z\s,.-]+(?:,\s*[A-Z]{2})?(?:,\s*(?:USA|US|UK|Canada|Australia|Germany|France|India))?)/i,
              // "Based in City" or "Office in City"
              /(?:based|located|office|position|role|job|work)\s+in\s+([A-Z][a-z]+(?:[,\s]+[A-Z][a-z]+)*(?:,\s*[A-Z]{2})?)/i,
              // Remote patterns
              /\b(remote|work from home|wfh|fully remote|100% remote|remote-first)\b/i,
              // City, State format (US)
              /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?,\s*[A-Z]{2})\b/,
              // Major city names
              /\b(New York|Los Angeles|Chicago|Houston|Phoenix|San Francisco|Seattle|Denver|Austin|Dallas|Boston|Atlanta|Miami|Washington D\.?C\.?|London|Toronto|Vancouver|Sydney|Melbourne|Berlin|Munich|Paris|Dublin|Amsterdam|Singapore|Hong Kong|Tokyo|Bangalore|Hyderabad|Mumbai)\b/i,
              // Hybrid patterns
              /\b(hybrid)\s*[-–—]?\s*([A-Z][a-z]+(?:[,\s]+[A-Z][a-z]+)*)/i,
            ];
            
            for (const pattern of patterns) {
              const match = content.match(pattern);
              if (match) {
                const extracted = match[1] || match[0];
                // Clean up the extracted location
                const cleaned = extracted.trim()
                  .replace(/^[:\s]+/, '')
                  .replace(/[.\s]+$/, '')
                  .slice(0, 100); // Limit length
                if (cleaned.length >= 3) {
                  return cleaned;
                }
              }
            }
            return null;
          }

          // Helper function to validate extracted salary is actually a concrete salary figure
          function isValidSalary(value: string): boolean {
            if (!value || value.length < 3) return false;
            
            const lowerValue = value.toLowerCase().trim();

            // Reject vague/non-numeric salary descriptions - these should be left blank
            const vaguePatterns = [
              /^competitive$/i,
              /^competitive\s+(salary|pay|compensation|package)/i,
              /^negotiable$/i,
              /^doe$/i,
              /^depends?\s+on\s+experience/i,
              /^based\s+on\s+experience/i,
              /^market\s+rate/i,
              /^not\s+specified/i,
              /^not\s+disclosed/i,
              /^undisclosed/i,
              /^attractive/i,
              /^commensurate/i,
              /^tbd$/i,
              /^to\s+be\s+discussed/i,
              /^excellent\s+(salary|pay|compensation|package|benefits)/i,
              /^generous/i,
              /^above\s+average/i,
              /^industry[\s-]leading/i,
              /^highly\s+competitive/i,
            ];
            
            for (const pattern of vaguePatterns) {
              if (pattern.test(lowerValue)) {
                console.log(`Rejecting vague salary value: "${value}"`);
                return false;
              }
            }
            
            // Reject common date patterns
            const datePatterns = [
              /^\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}$/,  // MM/DD/YYYY, DD-MM-YYYY
              /^\d{4}[\/\-\.]\d{1,2}[\/\-\.]\d{1,2}$/,    // YYYY-MM-DD (ISO)
              /^\d{4}[\/\-]\d{1,2}$/,                       // YYYY-MM (e.g. "2023-10")
              /\d{4}-\d{2}-\d{2}/,                          // ISO date anywhere in string
              /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i, // Month names
              /^\d{1,2}\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i, // 15 January
              /^(monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i, // Day names
              /^\d{1,2}(st|nd|rd|th)\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i, // 15th January
              /posted|closing|deadline|starts?|application|apply by/i, // Date context words
            ];
            
            for (const pattern of datePatterns) {
              if (pattern.test(lowerValue)) {
                console.log(`Rejecting salary value as date: "${value}"`);
                return false;
              }
            }
            
            // Must contain actual numeric salary indicators - currency symbol with number, or numeric range
            const hasCurrency = /[\$£€¥]\s*\d/i.test(value);
            const hasNumericRange = /\d+\s*[-–—to]+\s*\d+/i.test(value);
            const isPlainNumber = /^\$?\d[\d,]*(?:k)?$/i.test(value.trim()); // $80,000 or 80k
            const hasRateWithNumber = /\d+.*(?:per\s*(?:hour|annum|year|month)|\/\s*(?:hr|hour|yr|year)|p\.?a\.?|ote)/i.test(value);
            
            const hasValidFormat = hasCurrency || hasNumericRange || isPlainNumber || hasRateWithNumber;
            if (!hasValidFormat) return false;
            
            // Extract all numbers and verify they are reasonable salary figures
            const numbers = value.match(/\d[\d,]*/g);
            if (numbers) {
              const parsedNums = numbers.map(n => parseInt(n.replace(/,/g, ''), 10));
              const maxNum = Math.max(...parsedNums);
              const minNum = Math.min(...parsedNums);
              const isRange = parsedNums.length >= 2;
              const hasHourlyContext = /\/\s*(?:hr|hour)|per\s*hour/i.test(value);
              
              // For bare single dollar amounts (no range, no hourly context):
              // must be at least $1,000 — catches truncated "$106", "$147" etc.
              if (!isRange && !hasHourlyContext && hasCurrency && maxNum < 1000) {
                console.log(`Rejecting bare low dollar amount (likely truncated): "${value}" (value: ${maxNum})`);
                return false;
              }
              
              // General minimum: $10 (could be hourly like $45/hr)
              if (maxNum < 10) {
                console.log(`Rejecting salary with unreasonably low values: "${value}" (max number: ${maxNum})`);
                return false;
              }
              
              // Maximum reasonable salary: $2,000,000 — anything above is likely a corrupted value
              // This catches values like "59982-1631921217897" where one side is absurd
              if (maxNum > 2000000) {
                console.log(`Rejecting salary with unreasonably high values: "${value}" (max number: ${maxNum})`);
                return false;
              }
              
              // If it's a range, the ratio between min and max should be reasonable (within 10x)
              // Catches corrupted ranges like "3-336" or "1-3802"
              if (isRange && minNum > 0) {
                const ratio = maxNum / minNum;
                if (ratio > 10) {
                  console.log(`Rejecting salary with suspicious range ratio: "${value}" (${minNum} to ${maxNum}, ratio: ${ratio.toFixed(1)})`);
                  return false;
                }
              }
            }
            
            return true;
          }

          // Helper function to extract salary from content using pattern matching as fallback
          function extractSalaryFallback(content: string): string | null {
            const patterns = [
              // Dollar amounts: $80,000 - $120,000 or $80k-$120k
              /\$[\d,]+(?:\.\d{2})?(?:\s*[-–—to]+\s*\$?[\d,]+(?:\.\d{2})?)?(?:\s*(?:k|K|per\s+(?:year|annum|hour|hr)))?/g,
              // Pound/Euro amounts
              /[£€][\d,]+(?:\.\d{2})?(?:\s*[-–—to]+\s*[£€]?[\d,]+(?:\.\d{2})?)?(?:\s*(?:k|K|pa|per\s+(?:year|annum|hour|hr)))?/g,
              // Salary: X or Compensation: X
              /(?:salary|compensation|pay|base|rate)[:\s]+\$?[£€]?[\d,]+(?:\s*[-–—to]+\s*\$?[£€]?[\d,]+)?(?:\s*(?:k|K))?/gi,
              // Range format: 80,000 - 120,000 with currency context
              /(?:USD|GBP|EUR|AUD|CAD)?\s*[\d,]+\s*[-–—to]+\s*[\d,]+(?:\s*(?:per\s+(?:year|annum|hour)|pa|p\.a\.))?/gi,
              // Hourly rates
              /[\$£€][\d]+(?:\.\d{2})?\s*(?:\/|\s+per\s+)(?:hr|hour)/gi,
              // OTE patterns
              /ote[:\s]+[\$£€]?[\d,]+k?/gi,
              // NOTE: Do NOT match vague terms like "competitive", "DOE", "negotiable" - leave salary blank for those
            ];
            
            for (const pattern of patterns) {
              const matches = content.match(pattern);
              if (matches && matches.length > 0) {
                // Return the first reasonable match that passes validation
                for (const match of matches) {
                  const cleaned = match.trim().slice(0, 100);
                  if (cleaned.length >= 3 && isValidSalary(cleaned)) {
                    return cleaned;
                  }
                }
              }
            }
            return null;
          }

          // Define the tool for structured output
          const jobMatchTool = {
            type: "function",
            function: {
              name: "analyze_job_match",
              description: "Analyze the job posting and extract all structured data. CRITICAL: Search the ENTIRE document thoroughly for company name, location and salary before returning Unknown. Look in headers, footers, sidebars, 'About' sections, and embedded in paragraph text.",
              parameters: {
                type: "object",
                properties: {
                  job_title: { type: "string", description: "The job title/position name" },
                  company_name: { 
                    type: "string", 
                    description: "CRITICAL - REQUIRED: The actual hiring company name. Search EXHAUSTIVELY: 1) Look for 'About [Company]' sections, 2) Check 'Company:', 'Employer:', 'Posted by:' fields, 3) Look for '[Company] is hiring/seeking', 4) Check 'Join [Company]', 'Work at [Company]' phrases, 5) Look at page header/logo area, 6) Check for 'position at [Company]' pattern in title, 7) Look for company name followed by ratings (★), 8) Find incorporated names (Inc, LLC, Ltd, Corp, GmbH, etc). NEVER return the job board name (LinkedIn, Indeed, Glassdoor, etc). NEVER return 'Unknown' or 'Confidential' without exhaustive search. This is the most important field." 
                  },
                  job_location: { type: "string", description: "REQUIRED: Search thoroughly - check headers, 'Location:' fields, 'based in', 'office in', footer addresses, embedded city names. Format as 'City, State/Country' or 'Remote'. Only return 'Unknown' after exhaustive search." },
                  job_type: { type: "string", description: "Full-time, Part-time, Contract, Temporary - look for FTE, W2, 1099 indicators too. Default to Full-time if not specified." },
                  industry: { type: "string", description: "Industry sector" },
                  experience_level: { type: "string", description: "Junior, Mid-level, Senior, Lead, Executive - infer from years required if not explicit" },
                  salary_range: { type: "string", description: "ACTUAL NUMERIC SALARY ONLY - NOT DATES. Search for: currency symbols ($, £, €), 'salary:', 'compensation:', 'pay:', 'rate:', hourly rates ($/hr), 'OTE', 'base salary', annual figures (e.g. $80,000-$120,000), or 'k' notation (80k-120k). NEVER return posting dates. If salary is described as 'Competitive', 'Negotiable', 'DOE', 'Based on experience', 'Market rate', or similar vague terms, return 'Not specified'. ONLY return concrete numeric values." },
                  posted_date: { type: "string", description: "Job posting date in YYYY-MM-DD format. Convert relative dates using today's date." },
                  match_score: { type: "number", description: "Match score 0-100 based on skill alignment" },
                  match_reason: { type: "string", description: "Brief explanation of match quality" },
                  skills_matched: { type: "array", items: { type: "string" }, description: "Skills candidate has that match job requirements" },
                  skills_missing: { type: "array", items: { type: "string" }, description: "Required skills candidate lacks" },
                  is_job_posting: { type: "boolean", description: "True if actual job posting, false if search page, profile, or unrelated content" },
                  is_complete_record: { type: "boolean", description: "True if location AND company are properly extracted (not 'Unknown' or 'Confidential')" },
                  is_recruitment_agency: { type: "boolean", description: "True if the hiring company is a recruitment agency, staffing firm, consulting/outsourcing company, or talent agency that places candidates at other companies. Examples: Robert Half, Hays, Randstad, Adecco, ManpowerGroup, TEKsystems, Kforce, Aston Carter, Insight Global, Apex Group. Also true if the posting says 'on behalf of our client' or 'for our client'. False if it's a direct employer." }
                },
                required: ["job_title", "company_name", "job_location", "job_type", "match_score", "match_reason", "skills_matched", "skills_missing", "is_job_posting", "is_complete_record", "is_recruitment_agency"]
              }
            }
          };
          
          // Accumulate all rejections across batches for diagnostics summary
          const batchRejections: { id: string; reason: string; score?: number; location?: string; company_name?: string }[] = [];
          
          for (let i = 0; i < pendingJobs.length && !shouldStopScoringForWrites(); i += AI_BATCH_SIZE) {
            const batch = pendingJobs.slice(i, i + AI_BATCH_SIZE);
            if (i > 0) await new Promise(r => setTimeout(r, AI_INTER_JOB_DELAY_MS)); // throttle between jobs
            console.log(`Scoring job ${i + 1}/${pendingJobs.length}: ${batch[0]?.job_url || ''}`);
            
            const batchResults = await Promise.all(batch.map(async (pending) => {
              try {
                // PRE-FILTER: Reject category/listing pages before AI processing
                if (isCategoryOrListingPage(pending.job_url)) {
                  console.log(`Rejecting category/listing page: ${pending.job_url}`);
                  return { pending, status: 'skipped', reason: 'category_listing_page' };
                }
                
                // Domains where live scraping consistently times out or is blocked.
                // NOTE: if the job already has stored content (job_content), it will still be scored by AI.
                // Only used to skip the live Firecrawl scrape attempt.
                const SCRAPE_BLOCKED_DOMAINS = [
                  'indeed.com',        // Blocks scrapers
                  'linkedin.com',      // Blocks scrapers
                  'dribbble.com',      // Design jobs — irrelevant + causes AI 500s
                  'careerbuilder.com', // Blocks scrapers consistently
                  // builtin.com REMOVED — jobs were being rejected with no content; allow Firecrawl scrape
                  'goinhouse.com',     // No content stored and scraping times out
                  'glassdoor.com',     // Blocks scrapers
                  'stackoverflow.com', // User profiles, not job postings
                  'stackexchange.com', // Not job postings
                  'meta.stackoverflow.com', // Discussion pages, not jobs
                  'blossombi.com',     // Internal portal — not a job board
                  'portal.blossombi.com', // Internal portal — not a job board
                ];
                const isScrapeBlocked = SCRAPE_BLOCKED_DOMAINS.some(d => pending.job_url.includes(d));

                // If content is missing (from native URL scraping), fetch it now
                let jobContent = pending.job_content || '';
                if (jobContent.length < 200 && FIRECRAWL_API_KEY && !isScrapeBlocked) {
                  const scrapeTimeoutMs = safeTimeoutMs(15000, 'scrape');
                  const doScrape = async (attempt: number): Promise<string> => {
                    try {
                      if (attempt > 1) console.log(`[Scrape] Retry attempt ${attempt} for ${pending.job_url}`);
                      else console.log(`[Scrape] Fetching content for ${pending.job_url}`);
                      const scrapeResp = await firecrawlFetch('https://api.firecrawl.dev/v1/scrape', {
                        method: 'POST',
                        headers: {
                          'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
                          'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                          url: pending.job_url,
                          formats: ['markdown'],
                          onlyMainContent: true,
                          waitFor: 1500,
                        }),
                      }, scrapeTimeoutMs, `scrape:${pending.job_url}`);
                      if (scrapeResp.ok) {
                        const scrapeData = await scrapeResp.json();
                        return scrapeData?.data?.markdown || scrapeData?.markdown || '';
                      } else if (scrapeResp.status === 402) {
                        results.firecrawl402Count++;
                        if (results.firecrawl402Count >= 3) {
                          results.firecrawlQuotaExceeded = true;
                          console.error('[Quota] Firecrawl API returned 402 during scrape - credits exhausted');
                        }
                      } else {
                        console.log(`[Scrape] Non-OK status ${scrapeResp.status} for ${pending.job_url}`);
                      }
                    } catch (scrapeErr) {
                      const errMsg = scrapeErr instanceof Error ? scrapeErr.message : String(scrapeErr);
                      console.log(`[Scrape] Failed for ${pending.job_url}: ${errMsg}`);
                      // Retry once on abort/timeout errors
                      if (attempt === 1 && (errMsg.includes('abort') || errMsg.includes('timeout') || errMsg.includes('Abort'))) {
                        console.log(`[Scrape] Retrying after ${errMsg} for ${pending.job_url}`);
                        await new Promise(r => setTimeout(r, 1000));
                        return doScrape(2);
                      }
                    }
                    return '';
                  };
                  try {
                    const scraped = await doScrape(1);
                    if (scraped.length >= 100) {
                      jobContent = scraped;
                      await supabaseAdmin
                        .from('pipeline_pending_jobs')
                        .update({ job_content: jobContent.slice(0, 15000) })
                        .eq('id', pending.id);
                    }
                  } catch (scrapeErr) {
                    console.log(`[Scrape] Outer catch for ${pending.job_url}: ${scrapeErr}`);
                  }
                }
                
                // Determine board-specific minimum content length (default 200)
                const boardProfile = boardProfiles.get(pending.source_board || '');
                const boardMinLen = boardProfile?.minContentLength ?? 200;
                // Use global minimum of 200 or board-specific, whichever is higher
                const effectiveMinLen = Math.max(200, boardMinLen);
                
                if (jobContent.length < effectiveMinLen) {
                  if (isScrapeBlocked) {
                    return { pending, status: 'skipped', reason: 'scrape_blocked_domain' };
                  }
                  return { pending, status: 'skipped', reason: 'content_too_short' };
                }
                
                // Strip HTML tags and collapse whitespace before sending to AI.
                // Raw HTML from some boards causes gateway 500s.
                const stripHtml = (text: string): string => {
                  return text
                    // Strip HTML script/style blocks
                    .replace(/<script[\s\S]*?<\/script>/gi, '')
                    .replace(/<style[\s\S]*?<\/style>/gi, '')
                    .replace(/<[^>]+>/g, ' ')
                    .replace(/&[a-z]+;/gi, ' ')
                    // Strip Markdown image syntax: [![alt](url)](link) or ![alt](url)
                    .replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1')
                    // Strip Markdown links: [text](url)
                    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
                    // Strip bare URLs that look like image CDN paths
                    .replace(/https?:\/\/cdn\.[^\s)>]+/g, '')
                    // Strip remaining bare URLs
                    .replace(/https?:\/\/\S+/g, '')
                    // Strip Markdown headers ##, ###
                    .replace(/^#{1,6}\s+/gm, '')
                    // Strip Markdown bold/italic **text** or *text*
                    .replace(/\*{1,2}([^*]+)\*{1,2}/g, '$1')
                    // Strip Markdown bold/italic __text__ or _text_
                    .replace(/_{1,2}([^_]+)_{1,2}/g, '$1')
                    .replace(/\s{3,}/g, '\n\n')
                    .trim();
                };
                const cleanContent = stripHtml(jobContent).slice(0, 2500);
                
                // After stripping HTML, if meaningful text is still too short, skip it.
                // This catches CareerBuilder/blocked domains that had minimal stored content.
                if (cleanContent.length < 80) {
                  return { pending, status: 'skipped', reason: 'content_too_short_after_strip' };
                }

                // ============================================================
                // PRE-SCORE CONTENT QUALITY GATE
                // Detect non-job-posting content BEFORE burning an AI API call.
                // This saves ~895 wasted AI calls per run (the #1 source of waste).
                // Patterns derived from empirical analysis of "not_job_posting" rejections.
                // ============================================================
                const contentLower = cleanContent.toLowerCase();
                
                // Signal 1: search results page indicators
                const isSearchResultsPage = (
                  (contentLower.includes('jobs found') && contentLower.includes('sort by')) ||
                  (contentLower.includes('search results') && contentLower.includes('filter')) ||
                  (contentLower.includes('showing') && contentLower.includes('results') && contentLower.includes('page')) ||
                  // Job listing aggregator pages often have "X jobs at Company"
                  (/\d+\s+jobs?\s+(at|in|for)\s+/i.test(cleanContent) && contentLower.includes('apply now') && contentLower.includes('sort'))
                );
                
                // Signal 2: company profile / "jobs at X" pages (not a single job)
                const isCompanyProfilePage = (
                  contentLower.includes('all jobs at') ||
                  contentLower.includes('jobs at this company') ||
                  contentLower.includes('view all openings') ||
                  (contentLower.includes('open positions') && !contentLower.includes('responsibilities') && !contentLower.includes('requirements'))
                );
                
                // Signal 3: clear single-job content markers (PASS signals)
                const hasSingleJobMarkers = (
                  contentLower.includes('responsibilities') ||
                  contentLower.includes('requirements') ||
                  contentLower.includes('qualifications') ||
                  contentLower.includes('what you\'ll do') ||
                  contentLower.includes('what you will do') ||
                  contentLower.includes('about the role') ||
                  contentLower.includes('about this role') ||
                  contentLower.includes('job description') ||
                  contentLower.includes('we are looking for') ||
                  contentLower.includes('we\'re looking for') ||
                  contentLower.includes('you will be') ||
                  contentLower.includes('the ideal candidate') ||
                  contentLower.includes('apply now') ||
                  contentLower.includes('apply for this')
                );
                
                // Only skip if search/profile page signals fire AND no single-job markers present
                if ((isSearchResultsPage || isCompanyProfilePage) && !hasSingleJobMarkers) {
                  console.log(`[PreScore] Skipping non-job content: ${pending.job_url}`);
                  batchEvents.push({ type: 'content_filter', message: JSON.stringify({
                    url: pending.job_url, reason: 'not_job_posting', title: pending.job_title,
                    signals: { isSearchResultsPage, isCompanyProfilePage, hasSingleJobMarkers },
                    content_length: cleanContent.length,
                  })});
                  return { pending, status: 'skipped', reason: 'not_job_posting_prefilter' };
                }
                
                // JSON-LD JobPosting detection: strong positive signal for content quality
                const hasJobPostingSchema = jobContent.includes('"JobPosting"') || 
                  jobContent.includes("'JobPosting'") || 
                  jobContent.includes('schema.org/JobPosting') ||
                  jobContent.includes('@type":"JobPosting');
                
                // Enhanced content quality gate: if content is very short AND has no JSON-LD signal,
                // reject as content_low_quality to avoid wasting AI calls on junk pages
                if (cleanContent.length < 500 && !hasJobPostingSchema && !hasSingleJobMarkers) {
                  console.log(`[PreScore] Low quality content (${cleanContent.length} chars, no JobPosting/markers): ${pending.job_url}`);
                  batchEvents.push({ type: 'content_filter', message: JSON.stringify({
                    url: pending.job_url, reason: 'content_too_short', title: pending.job_title,
                    content_length: cleanContent.length, has_schema: hasJobPostingSchema,
                  })});
                  return { pending, status: 'skipped', reason: 'content_low_quality' };
                }

                // AI call with retry on 429 (rate limit) and 500 (gateway error)
                const callAI = async (attempt: number): Promise<Response> => {
                  const aiController = new AbortController();
                  const aiTimeout = setTimeout(() => aiController.abort(), AI_TIMEOUT_MS);
                  try {
                    const resp = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
                      method: 'POST',
                      signal: aiController.signal,
                      headers: {
                        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
                        'Content-Type': 'application/json',
                      },
                      body: JSON.stringify({
                        model: 'google/gemini-2.5-flash',
                        messages: [
                          { role: 'system', content: buildMatchPrompt({
                            skills: candidate.skills || [],
                            current_title: candidate.current_title,
                            ideal_role: candidate.ideal_role,
                            career_goals: candidate.career_goals,
                            industries_of_interest: candidate.industries_of_interest,
                            ai_summary: candidate.ai_summary,
                            career_highlights: candidate.career_highlights,
                          }) },
                          { role: 'user', content: cleanContent }
                        ],
                        tools: [jobMatchTool],
                        tool_choice: { type: "function", function: { name: "analyze_job_match" } },
                        max_completion_tokens: 2500,
                      }),
                    });
                    return resp;
                  } finally {
                    clearTimeout(aiTimeout);
                  }
                };

                let response = await callAI(1);

                // Retry once on 429 (rate limit) or 500 (gateway error) with backoff
                if (response.status === 429) {
                  console.log(`[AI] 429 rate limit for ${pending.job_url}, retrying after 3s...`);
                  await new Promise(r => setTimeout(r, 3000));
                  response = await callAI(2);
                } else if (response.status === 500) {
                  console.log(`[AI] 500 gateway error for ${pending.job_url}, retrying after 2s...`);
                  await new Promise(r => setTimeout(r, 2000));
                  response = await callAI(2);
                }
                
                if (!response.ok) {
                  let errBody = '';
                  try { errBody = await response.text(); } catch (_) {}
                  console.log(`[AI] Non-OK response HTTP ${response.status} for ${pending.job_url}: ${errBody.slice(0, 300)}`);
                  return { pending, status: 'failed', reason: 'ai_error' };
                }
                
                const aiData = await response.json();
                const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
                if (!toolCall) {
                  // Log the actual AI response to diagnose why tool wasn't called
                  const finishReason = aiData.choices?.[0]?.finish_reason;
                  const msgContent = aiData.choices?.[0]?.message?.content;
                  console.log(`[AI] no_tool_call for ${pending.job_url} — finish_reason=${finishReason}, content_preview=${(msgContent || '').slice(0, 200)}`);
                  return { pending, status: 'failed', reason: 'no_tool_call' };
                }
                
                const parsed = JSON.parse(toolCall.function.arguments);
                const matchScore = Math.min(100, Math.max(0, parseInt(parsed.match_score) || 0));
                
                // FALLBACK: If AI returned Unknown for company, try multiple fallback methods
                let extractedCompany = parsed.company_name;
                const companyIsInvalid = !extractedCompany || 
                  extractedCompany.toLowerCase() === 'unknown' || 
                  extractedCompany.toLowerCase() === 'unknown company' ||
                  extractedCompany.toLowerCase() === 'confidential' ||
                  extractedCompany.toLowerCase() === 'company confidential' ||
                  extractedCompany.toLowerCase() === 'not specified' ||
                  isGenericJobBoardName(extractedCompany);
                
                if (companyIsInvalid) {
                  console.log(`AI returned invalid company "${extractedCompany}" for ${pending.job_url} - trying fallbacks...`);
                  
                  // Try URL-based extraction first (more reliable)
                  let fallbackCompany = guessCompanyNameFromUrl(pending.job_url);
                  if (!fallbackCompany) {
                    // Try title-based extraction
                    fallbackCompany = guessCompanyNameFromTitle(pending.job_title || '');
                  }
                  if (!fallbackCompany) {
                    // Try content-based extraction (most comprehensive)
                    fallbackCompany = extractCompanyNameFallback(jobContent);
                  }
                  
                  if (fallbackCompany) {
                    console.log(`Fallback company extraction for ${pending.job_url}: "${fallbackCompany}"`);
                    extractedCompany = fallbackCompany;
                    parsed.company_name = fallbackCompany;
                  }
                }
                
                // FALLBACK: If AI returned Unknown for location, try pattern matching
                let extractedLocation = parsed.job_location;
                if (!extractedLocation || extractedLocation.toLowerCase() === 'unknown' || extractedLocation.toLowerCase() === 'not specified') {
                  const fallbackLocation = extractLocationFallback(jobContent);
                  if (fallbackLocation) {
                    console.log(`Fallback location extraction for ${pending.job_url}: "${fallbackLocation}"`);
                    extractedLocation = fallbackLocation;
                    parsed.job_location = fallbackLocation;
                  }
                }
                
                // Update is_complete_record based on current values
                const hasValidLocation = extractedLocation && 
                  extractedLocation.toLowerCase() !== 'unknown' && 
                  extractedLocation.toLowerCase() !== 'not specified';
                const hasValidCompany = extractedCompany && 
                  extractedCompany.toLowerCase() !== 'unknown' && 
                  extractedCompany.toLowerCase() !== 'unknown company' &&
                  !isGenericJobBoardName(extractedCompany);
                parsed.is_complete_record = hasValidLocation && hasValidCompany;
                
                // VALIDATE: Check if AI returned a date instead of salary, then try fallback
                let extractedSalary = parsed.salary_range;
                if (extractedSalary && !isValidSalary(extractedSalary)) {
                  console.log(`AI returned invalid salary (likely date) for ${pending.job_url}: "${extractedSalary}" - trying fallback`);
                  extractedSalary = null;
                  parsed.salary_range = null;
                }
                
                // FALLBACK: If AI returned Not specified/Unknown or invalid, try pattern matching
                if (!extractedSalary || extractedSalary.toLowerCase() === 'not specified' || extractedSalary.toLowerCase() === 'unknown') {
                  const fallbackSalary = extractSalaryFallback(jobContent);
                  if (fallbackSalary) {
                    console.log(`Fallback salary extraction for ${pending.job_url}: "${fallbackSalary}"`);
                    extractedSalary = fallbackSalary;
                    parsed.salary_range = fallbackSalary;
                  }
                }
                
                return {
                  pending,
                  status: 'scored',
                  parsed,
                  matchScore,
                  isJobPosting: parsed.is_job_posting !== false,
                };
              } catch (err) {
                console.error(`Error scoring job ${pending.job_url}:`, err);
                return { pending, status: 'failed', reason: 'exception' };
              }
            }));
            
            // Process scored jobs — BATCHED for performance
            // Collect all DB operations and execute in parallel at end of batch
            // batchRejections is accumulated across all batches (declared above the loop)
            const batchEvents: { type: string; message: string }[] = [];
            const batchMatchOps: (() => Promise<void>)[] = [];
            
            for (const result of batchResults) {
              if (result.status !== 'scored' || !result.parsed) {
                batchRejections.push({ id: result.pending.id, reason: result.reason || 'unknown' });
                continue;
              }
              
              const { pending, parsed, matchScore: rawScore, isJobPosting } = result;
              const matchScore = rawScore ?? 0;
              results.pendingJobsScored++;
              
              // Check if this is an actual job posting
              if (!isJobPosting) {
                batchRejections.push({ id: pending.id, reason: 'not_job_posting', score: matchScore });
                continue;
              }
              
              // ============================================================
              // RECRUITMENT AGENCY FILTER — 3-layer detection strategy
              // ============================================================
              const companyNameForAgencyCheck = (parsed.company_name || '').toLowerCase().trim();
              
              const aiFlaggedAgency = parsed.is_recruitment_agency === true;
              
              const KNOWN_AGENCIES = [
                'robert half', 'hays', 'randstad', 'adecco', 'manpowergroup', 'manpower',
                'kelly services', 'kforce', 'teksystems', 'tek systems', 'aston carter',
                'insight global', 'apex group', 'apex systems', 'modis', 'aerotek',
                'staffing', 'recruiting', 'recruiters', 'talent solutions',
                'michael page', 'page personnel', 'pagegroup',
                'spencer ogden', 'harvey nash', 'nigel frank', 'frank recruitment',
                'hudson global', 'robert walters', 'morgan mckinley', 'reed',
                'antal international', 'spring professional', 'badenoch & clark',
                'sthree', 'computer futures', 'progressive recruitment', 'la fosse',
                'opus recruitment', 'lorien', 'experis', 'jefferson frank',
                'talent international', 'huxley', 'understanding recruitment',
                'tenth revolution', 'oscar technology', 'eliassen group',
                'corestaff', 'cybercoders', 'dice staffing', 'addison group',
                'motion recruitment', 'vaco', 'beacon hill staffing', 'yoh',
                'genesis10', 'brooksource', 'hirekeyz', 'procom', 'ettain group',
                'collabera', 'syntel', 'mastech', 'igate', 'mindlance',
              ];
              
              const isKnownAgency = KNOWN_AGENCIES.some(agency => {
                if (companyNameForAgencyCheck === agency) return true;
                if (companyNameForAgencyCheck.includes(agency)) return true;
                return false;
              });
              
              const agencyIndicators = [
                /\bstaffing\b/i, /\brecruit(ment|ing|ers?)?\b/i, /\btalent\s+(agency|solutions|partners?)\b/i,
                /\bplacement\b/i, /\bheadhunt/i, /\bexecutive\s+search\b/i,
                /\bcontract(ing)?\s+(agency|services?|solutions?)\b/i,
                /\bhr\s+consult/i, /\bpersonnel\s+(agency|services?)\b/i,
              ];
              const nameMatchesAgencyPattern = agencyIndicators.some(pattern => pattern.test(companyNameForAgencyCheck));
              
              if (aiFlaggedAgency || isKnownAgency || nameMatchesAgencyPattern) {
                const detectionMethod = aiFlaggedAgency ? 'ai_detected' : isKnownAgency ? 'known_agency' : 'name_pattern';
                console.log(`[Agency Filter] Rejecting job from recruitment agency: "${parsed.company_name}" (method: ${detectionMethod})`);
                batchRejections.push({ id: pending.id, reason: 'recruitment_agency', score: matchScore, company_name: parsed.company_name });
                batchEvents.push({ type: 'filter', message: JSON.stringify({
                  type: 'recruitment_agency', companyName: parsed.company_name, method: detectionMethod, jobUrl: pending.job_url,
                })});
                continue;
              }

              // Check if job record is complete
              const hasValidLocation = parsed.job_location && 
                parsed.job_location.trim() !== '' && 
                parsed.job_location.toLowerCase() !== 'unknown' &&
                parsed.job_location.toLowerCase() !== 'not specified';
              const hasValidCompany = parsed.company_name && 
                parsed.company_name.trim() !== '' && 
                parsed.company_name.toLowerCase() !== 'unknown' &&
                parsed.company_name.toLowerCase() !== 'unknown company' &&
                parsed.company_name.toLowerCase() !== 'confidential' &&
                !isGenericJobBoardName(parsed.company_name);
              const isCompleteRecord = parsed.is_complete_record !== false;
              
              if (!isCompleteRecord || !hasValidLocation || !hasValidCompany) {
                const rejectionReason = !hasValidCompany ? 'company_name_missing' : 
                                        !hasValidLocation ? 'location_missing' : 'incomplete_record';
                console.log(`Rejecting incomplete job record: location="${parsed.job_location}", company="${parsed.company_name}", reason=${rejectionReason}`);
                batchRejections.push({ id: pending.id, reason: rejectionReason, score: matchScore, location: parsed.job_location, company_name: parsed.company_name });
                batchEvents.push({ type: 'filter', message: JSON.stringify({
                  type: rejectionReason, jobLocation: parsed.job_location, companyName: parsed.company_name, jobUrl: pending.job_url,
                })});
                continue;
              }
              
              // Check score threshold
              if (matchScore < EXTERNAL_MATCH_THRESHOLD) {
                batchRejections.push({ id: pending.id, reason: 'low_score', score: matchScore });
                continue;
              }
              
              // Check job age — but be lenient for high-scoring matches
              const jobAgeCheck = isJobTooOld(parsed.posted_date);
              if (jobAgeCheck.tooOld) {
                // If date is unknown/unparseable AND job scored well, give benefit of doubt
                // (it was just found on a live search page, so it's likely still active)
                const isDateUnknown = jobAgeCheck.ageInDays === null;
                const isHighScore = matchScore >= EXTERNAL_MATCH_THRESHOLD;
                if (isDateUnknown && isHighScore) {
                  console.log(`[Age] Allowing high-scoring job (${matchScore}%) with unknown date: ${pending.job_url}`);
                } else {
                  batchRejections.push({ id: pending.id, reason: 'job_too_old', score: matchScore });
                  continue;
                }
              }
              
              // Check location match
              const locationCheck = isLocationMismatch(
                parsed.job_location,
                candidate.search_city,
                candidate.search_country,
                candidate.desired_location,
                candidate.is_remote_worker,
                candidate.address,
                candidate.search_distance_km
              );
              if (locationCheck.mismatch) {
                console.log(`Rejecting job due to location mismatch: ${parsed.job_location} vs target: ${candidate.search_city}, ${candidate.search_country}`);
                batchRejections.push({ id: pending.id, reason: 'location_mismatch', score: matchScore, location: parsed.job_location });
                batchEvents.push({ type: 'filter', message: JSON.stringify({
                  type: 'location_mismatch', jobLocation: parsed.job_location, candidateCity: candidate.search_city, candidateCountry: candidate.search_country,
                })});
                continue;
              }
              
              // ---- This job passes all filters — save it ----
              const jobTitle = parsed.job_title || pending.job_title || 'Unknown';
              const companyName = parsed.company_name!;
              
              // Queue the match save operation (runs in parallel later)
              batchMatchOps.push(async () => {
                // Check for existing job
                const { data: existingJob } = await supabaseClient
                  .from('jobs')
                  .select('id, company_id')
                  .eq('source_url', pending.job_url)
                  .maybeSingle();
                
                if (existingJob) {
                  // Check company size for existing jobs
                  if (existingJob.company_id) {
                    const { data: existingJobCompany } = await supabaseClient
                      .from('companies')
                      .select('employee_count, enrichment_status, name')
                      .eq('id', existingJob.company_id)
                      .maybeSingle();
                    
                    if (existingJobCompany) {
                      const exceedsByCount = existingJobCompany.employee_count && existingJobCompany.employee_count >= MAX_COMPANY_EMPLOYEES;
                      const exceedsByStatus = existingJobCompany.enrichment_status === 'exceeds_size';
                      if (exceedsByCount || exceedsByStatus) {
                        console.log(`Rejecting existing job from ${existingJobCompany.name}: company exceeds size limit`);
                        await supabaseAdmin.from('pipeline_pending_jobs')
                          .update({ status: 'rejected', rejection_reason: `Company exceeds max employees (${MAX_COMPANY_EMPLOYEES})`, score: matchScore, scored_at: new Date().toISOString() })
                          .eq('id', pending.id);
                        results.jobsRejected++;
                        return;
                      }
                    }
                  }
                  
                  // Check if match already exists
                  const { data: existingMatch } = await supabaseClient
                    .from('matches')
                    .select('id')
                    .eq('job_id', existingJob.id)
                    .eq('candidate_id', candidateId)
                    .maybeSingle();
                  
                  if (!existingMatch) {
                    await supabaseAdmin.from('matches').insert({
                      candidate_id: candidateId, job_id: existingJob.id,
                      match_score: matchScore, match_reason: parsed.match_reason || '',
                      skills_matched: parsed.skills_matched || [], skills_missing: parsed.skills_missing || [],
                      status: 'pending', created_by: user.id,
                      salary_benchmark: null, salary_percentile: null,
                    });
                    matchesSaved++;
                    results.matchesSaved++;
                  }
                  
                  await supabaseAdmin.from('pipeline_pending_jobs')
                    .update({ status: 'saved', score: matchScore, scored_at: new Date().toISOString() })
                    .eq('id', pending.id);
                  return;
                }
                
                // New job — resolve company
                let companyId: string | null = null;
                let companyExceedsSize = false;
                
                // Uses shared KNOWN_LARGE_COMPANIES from module level
                
                const isKnownLargeCompany = isKnownLargeCompanyMatch(companyName);
                
                if (isKnownLargeCompany) {
                  console.log(`[Pre-filter] Rejecting job from known large company: ${companyName}`);
                  companyExceedsSize = true;
                  await writePipelineEvent('filter', JSON.stringify({ type: 'known_large_company', companyName, jobUrl: pending.job_url }));
                }
                
                if (!companyExceedsSize) {
                  const normalizedCompanyName = normalizeCompanyName(companyName);
                  let existingCompany = companiesLookup.get(normalizedCompanyName) || null;
                  
                  if (existingCompany) {
                    if (existingCompany.employee_count && existingCompany.employee_count >= MAX_COMPANY_EMPLOYEES) {
                      companyExceedsSize = true;
                    } else if (existingCompany.enrichment_status === 'exceeds_size') {
                      companyExceedsSize = true;
                    } else {
                      companyId = existingCompany.id;
                    }
                  } else {
                    // Create new company
                    const { data: newCompany } = await supabaseAdmin
                      .from('companies')
                      .insert({ name: companyName, enrichment_status: 'pending', created_by: user.id })
                      .select('id')
                      .single();
                    
                    if (newCompany) {
                      companyId = newCompany.id;
                      companiesLookup.set(normalizeCompanyName(companyName), {
                        id: newCompany.id, employee_count: null, enrichment_status: 'pending', name: companyName
                      });
                      
                      // FIRE-AND-FORGET: Domain lookup + enrichment chain (no await)
                      const bgAuthHeader = `Bearer ${supabaseServiceRoleKey}`;
                      const runEnrichmentChain = async (cId: string, cName: string, cDomain: string) => {
                        try {
                          const enrichResp = await fetch(`${supabaseUrl}/functions/v1/enrich-company`, {
                            method: 'POST',
                            headers: { 'Authorization': bgAuthHeader, 'Content-Type': 'application/json' },
                            body: JSON.stringify({ domain: cDomain, companyId: cId }),
                          });
                          if (enrichResp.ok) {
                            await fetch(`${supabaseUrl}/functions/v1/enrich-stakeholders`, {
                              method: 'POST',
                              headers: { 'Authorization': bgAuthHeader, 'Content-Type': 'application/json' },
                              body: JSON.stringify({ companyId: cId, companyName: cName, domain: cDomain }),
                            });
                          }
                        } catch (err) {
                          console.error(`[Background] Enrichment chain error for ${cName}:`, err);
                        }
                      };
                      
                      // Fire-and-forget domain lookup (don't block scoring loop)
                      (async () => {
                        try {
                          const domainResponse = await fetch(`${supabaseUrl}/functions/v1/lookup-company-domain`, {
                            method: 'POST',
                            headers: { 'Authorization': bgAuthHeader, 'Content-Type': 'application/json' },
                            body: JSON.stringify({ companyName, companyId: newCompany.id, quickMode: true }),
                          });
                          if (domainResponse.ok) {
                            const domainData = await domainResponse.json();
                            const domain = domainData?.data?.domain || domainData?.domain;
                            const employeeCount = domainData?.data?.employee_count;
                            
                            if (employeeCount && employeeCount >= MAX_COMPANY_EMPLOYEES) {
                              await supabaseAdmin.from('companies').update({
                                employee_count: employeeCount, enrichment_status: 'exceeds_size',
                              }).eq('id', newCompany.id);
                            } else if (domain) {
                              await runEnrichmentChain(newCompany.id, companyName, domain);
                            } else {
                              // Full lookup then enrich
                              const lookupResp = await fetch(`${supabaseUrl}/functions/v1/lookup-company-domain`, {
                                method: 'POST',
                                headers: { 'Authorization': bgAuthHeader, 'Content-Type': 'application/json' },
                                body: JSON.stringify({ companyName, companyId: newCompany.id, quickMode: false }),
                              });
                              if (lookupResp.ok) {
                                const lookupData = await lookupResp.json();
                                const discoveredDomain = lookupData?.domain;
                                if (discoveredDomain) {
                                  await runEnrichmentChain(newCompany.id, companyName, discoveredDomain);
                                }
                              }
                            }
                          }
                        } catch (err) {
                          console.error(`[Background] Domain lookup error for ${companyName}:`, err);
                        }
                      })();
                    }
                  }
                }
                
                if (companyExceedsSize) {
                  await supabaseAdmin.from('pipeline_pending_jobs')
                    .update({ status: 'rejected', rejection_reason: `Company exceeds max employees (${MAX_COMPANY_EMPLOYEES})`, score: matchScore, scored_at: new Date().toISOString() })
                    .eq('id', pending.id);
                  results.jobsRejected++;
                  return;
                }
                
                if (!companyId) {
                  await supabaseAdmin.from('pipeline_pending_jobs')
                    .update({ status: 'rejected', rejection_reason: 'company_creation_failed', score: matchScore, scored_at: new Date().toISOString() })
                    .eq('id', pending.id);
                  results.jobsRejected++;
                  return;
                }
                
                // Insert job
                const { data: newJob } = await supabaseAdmin
                  .from('jobs')
                  .insert({
                    title: jobTitle, description: (pending.job_content || '').slice(0, 5000),
                    source_url: pending.job_url, location: parsed.job_location || null,
                    salary_range: parsed.salary_range || null, job_type: parsed.job_type || null,
                    experience_level: parsed.experience_level || null, status: 'active',
                    skills_required: parsed.skills_matched || [], company_id: companyId,
                    created_by: user.id, posted_at: parsed.posted_date || null,
                  })
                  .select('id')
                  .single();
                
                if (newJob) {
                  await supabaseAdmin.from('matches').insert({
                    candidate_id: candidateId, job_id: newJob.id,
                    match_score: matchScore, match_reason: parsed.match_reason || '',
                    skills_matched: parsed.skills_matched || [], skills_missing: parsed.skills_missing || [],
                    status: 'pending', created_by: user.id,
                    salary_benchmark: null, salary_percentile: null,
                  });
                  
                  matchesSaved++;
                  results.matchesSaved++;
                  
                  await writePipelineEvent('job_match', JSON.stringify({
                    id: newJob.id, title: jobTitle, url: pending.job_url,
                    match_score: matchScore, match_reason: parsed.match_reason || '',
                    skills_matched: parsed.skills_matched || [], skills_missing: parsed.skills_missing || [],
                    source: pending.source_board || 'Unknown', company_name: companyName,
                  }));
                  
                  console.log(`Saved match: ${jobTitle} (${matchScore}%)`);
                }
                
                await supabaseAdmin.from('pipeline_pending_jobs')
                  .update({ status: 'saved', score: matchScore, scored_at: new Date().toISOString() })
                  .eq('id', pending.id);
              });
            }
            
            // PARALLEL EXECUTION: Run all match save operations concurrently (up to 5 at a time)
            const MATCH_CONCURRENCY = 5;
            for (let m = 0; m < batchMatchOps.length; m += MATCH_CONCURRENCY) {
              await Promise.all(batchMatchOps.slice(m, m + MATCH_CONCURRENCY).map(op => op().catch(err => {
                console.error('[Match save error]:', err);
              })));
            }
            
            // BULK: Write all rejections in parallel batches
            if (batchRejections.length > 0) {
              const rejectionUpdates = batchRejections.map(r => 
                supabaseAdmin.from('pipeline_pending_jobs')
                  .update({ 
                    status: 'rejected', 
                    rejection_reason: r.reason,
                    score: r.score ?? null,
                    scored_at: new Date().toISOString(),
                    ...(r.location ? { location: r.location } : {}),
                    ...(r.company_name ? { company_name: r.company_name } : {}),
                  })
                  .eq('id', r.id)
              );
              // Execute all rejection updates in parallel
              await Promise.all(rejectionUpdates);
            }
            
            // BULK: Write all filter events in parallel
            if (batchEvents.length > 0) {
              await Promise.all(batchEvents.map(e => writePipelineEvent(e.type, e.message)));
            }
            
          }
          
          // Check if there are still pending jobs
          const { count: remainingPending } = await supabaseAdmin
            .from('pipeline_pending_jobs')
            .select('id', { count: 'exact', head: true })
            .eq('candidate_id', candidateId)
            .eq('status', 'pending');
          
          results.hasPendingJobs = (remainingPending || 0) > 0;
          
          // Build comprehensive scoring diagnostics
          const rejectionBreakdown: Record<string, number> = {};
          for (const r of batchRejections) {
            const key = r.reason || 'unknown';
            rejectionBreakdown[key] = (rejectionBreakdown[key] || 0) + 1;
          }
          
          const diagnostics = {
            type: 'scoring_summary',
            total_fetched: pendingJobsRaw.length,
            pre_filter_rejected: preFilterRejected,
            deduped_removed: pendingJobsRaw.length - preFilterRejected - pendingJobs.length,
            sent_to_ai: pendingJobs.length,
            scored: results.pendingJobsScored,
            matches_saved: results.matchesSaved,
            remaining_pending: remainingPending || 0,
            rejection_reasons: rejectionBreakdown,
          };
          await writePipelineEvent('diagnostics', JSON.stringify(diagnostics));
          
          if (shouldStopScoringForWrites() && results.hasPendingJobs) {
            await writePipelineEvent('warning', `Scoring paused - time limit reached. Scored ${results.pendingJobsScored} jobs, saved ${results.matchesSaved} matches. ${remainingPending} jobs still pending.`);
          } else {
            await writePipelineEvent('success', `Scoring complete. Saved ${results.matchesSaved} matches from ${results.pendingJobsScored} scored jobs.`);
          }
        }  // closes: if (pendingJobs.length > 0) after dedup
        }  // closes: if (pendingJobs.length > 0) after pre-filter
      }  // closes: if (pendingJobsRaw.length > 0)
    }  // closes: if (needsMoreMatches)
    
    // ================================================================
    // FEEDBACK AGGREGATION: Update keyword_performance and search_feedback
    // based on scoring outcomes from this run
    // ================================================================
    if (results.pendingJobsScored > 0) {
      try {
        console.log('[Feedback] Aggregating scoring outcomes...');
        
        // Get all scored/saved/rejected jobs from this run with their source queries
        const { data: scoredJobs } = await supabaseAdmin
          .from('pipeline_pending_jobs')
          .select('source_query, source_board, score, status')
          .eq('candidate_id', candidateId)
          .eq('run_id', runId)
          .in('status', ['saved', 'rejected', 'scored']);
        
        if (scoredJobs && scoredJobs.length > 0) {
          // Aggregate by source_query
          const queryStats = new Map<string, { found: number; scored: number; matched: number; scores: number[] }>();
          for (const job of scoredJobs) {
            const q = (job.source_query || 'unknown').toLowerCase().trim();
            if (!queryStats.has(q)) queryStats.set(q, { found: 0, scored: 0, matched: 0, scores: [] });
            const stat = queryStats.get(q)!;
            stat.found++;
            stat.scored++;
            if (job.score != null) stat.scores.push(job.score);
            if (job.status === 'saved') stat.matched++;
          }
          
          // Upsert keyword_performance — fetch all existing records in one query, then update/insert in parallel
          const cleanKeywordEntries = Array.from(queryStats.entries())
            .filter(([keyword]) => keyword !== 'unknown')
            .map(([keyword, stat]) => {
              const cleanKeyword = keyword.replace(new RegExp((searchLocation || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '').trim();
              const avgScore = stat.scores.length > 0 ? stat.scores.reduce((a, b) => a + b, 0) / stat.scores.length : null;
              const matchRate = stat.scored > 0 ? (stat.matched / stat.scored) * 100 : 0;
              const effectiveness = avgScore != null ? (matchRate * 0.6) + (avgScore * 0.4) : matchRate;
              return { cleanKeyword, stat, avgScore, effectiveness };
            })
            .filter(e => e.cleanKeyword.length >= 3);

          if (cleanKeywordEntries.length > 0) {
            // Single batch fetch for all existing keyword records
            const { data: existingKeywords } = await supabaseAdmin
              .from('keyword_performance')
              .select('id, keyword, times_used, jobs_found, matches_produced, avg_match_score')
              .eq('candidate_id', candidateId)
              .in('keyword', cleanKeywordEntries.map(e => e.cleanKeyword));

            const existingMap = new Map((existingKeywords || []).map(k => [k.keyword, k]));

            // Fire all updates/inserts in parallel
            await Promise.all(cleanKeywordEntries.map(({ cleanKeyword, stat, avgScore, effectiveness }) => {
              const existing = existingMap.get(cleanKeyword);
              if (existing) {
                const newTimesUsed = (existing.times_used || 0) + 1;
                const newJobsFound = (existing.jobs_found || 0) + stat.found;
                const newMatchesProduced = (existing.matches_produced || 0) + stat.matched;
                const prevAvg = existing.avg_match_score || 0;
                const newAvg = avgScore != null ? (prevAvg * 0.7) + (avgScore * 0.3) : prevAvg;
                const newEffectiveness = (existing.times_used >= 2) ? effectiveness : 50;
                return supabaseAdmin
                  .from('keyword_performance')
                  .update({
                    times_used: newTimesUsed,
                    jobs_found: newJobsFound,
                    matches_produced: newMatchesProduced,
                    avg_match_score: Math.round(newAvg * 100) / 100,
                    effectiveness_score: Math.round(newEffectiveness * 100) / 100,
                    last_used_at: new Date().toISOString(),
                    updated_at: new Date().toISOString(),
                  })
                  .eq('id', existing.id);
              } else {
                return supabaseAdmin
                  .from('keyword_performance')
                  .insert({
                    candidate_id: candidateId,
                    keyword: cleanKeyword,
                    times_used: 1,
                    jobs_found: stat.found,
                    matches_produced: stat.matched,
                    avg_match_score: avgScore != null ? Math.round(avgScore * 100) / 100 : null,
                    effectiveness_score: 50,
                    last_used_at: new Date().toISOString(),
                  });
              }
            }));
          }
          
          // Aggregate by source_board for search_feedback AND job_board_performance updates
          const boardStats = new Map<string, { query: string; found: number; scored: number; matched: number; saved: number; scores: number[]; rejectionReasons: Map<string, number> }>();
          for (const job of scoredJobs) {
            const key = `${job.source_board}::${job.source_query || 'unknown'}`;
            if (!boardStats.has(key)) boardStats.set(key, { query: job.source_query || 'unknown', found: 0, scored: 0, matched: 0, saved: 0, scores: [], rejectionReasons: new Map() });
            const stat = boardStats.get(key)!;
            stat.found++;
            stat.scored++;
            if (job.score != null) stat.scores.push(job.score);
            if (job.status === 'saved') { stat.matched++; stat.saved++; }
          }
          
          // Also aggregate rejection reasons from ALL pipeline_pending_jobs for this run
          const { data: rejectedJobs } = await supabaseAdmin
            .from('pipeline_pending_jobs')
            .select('source_board, rejection_reason')
            .eq('candidate_id', candidateId)
            .eq('run_id', runId)
            .eq('status', 'rejected');
          
          for (const rj of rejectedJobs || []) {
            const reason = rj.rejection_reason || 'unknown';
            const boardKey = `${rj.source_board}::unknown`;
            // Find matching board stat or create minimal entry
            for (const [key, stat] of boardStats) {
              if (key.startsWith(`${rj.source_board}::`)) {
                stat.rejectionReasons.set(reason, (stat.rejectionReasons.get(reason) || 0) + 1);
                break;
              }
            }
          }
          
          // Resolve board_id from board name for linking
          const boardNameToId = new Map<string, string>();
          const { data: allBoardsLookup } = await supabaseAdmin
            .from('job_boards')
            .select('id, name');
          for (const b of allBoardsLookup || []) {
            boardNameToId.set(b.name, b.id);
          }
          
          const feedbackRecords = Array.from(boardStats.entries()).map(([key, stat]) => {
            const boardName = key.split('::')[0];
            const boardId = boardNameToId.get(boardName) || null;
            const avgScore = stat.scores.length > 0 ? Math.round((stat.scores.reduce((a, b) => a + b, 0) / stat.scores.length) * 100) / 100 : null;
            const bestScore = stat.scores.length > 0 ? Math.max(...stat.scores) : null;
            return {
              candidate_id: candidateId,
              query_text: stat.query,
              board_name: boardName,
              board_id: boardId,
              jobs_discovered: stat.found,
              jobs_scored: stat.scored,
              jobs_matched: stat.matched,
              avg_score: avgScore,
              best_score: bestScore,
            };
          });
          
          if (feedbackRecords.length > 0) {
            await supabaseAdmin.from('search_feedback').insert(feedbackRecords);
          }
          
          // Update job_board_performance with scoring results and trigger lifetime stats recalc
          const boardScoringAgg = new Map<string, { scored: number; matched: number; saved: number; avgScore: number | null; highScoreCount: number }>();
          for (const [key, stat] of boardStats) {
            const boardName = key.split('::')[0];
            const boardId = boardNameToId.get(boardName);
            if (!boardId) continue;
            
            const existing = boardScoringAgg.get(boardId) || { scored: 0, matched: 0, saved: 0, avgScore: null, highScoreCount: 0 };
            existing.scored += stat.scored;
            existing.matched += stat.matched;
            existing.saved += stat.saved;
            existing.highScoreCount += stat.scores.filter(s => s >= 75).length;
            if (stat.scores.length > 0) {
              const avg = stat.scores.reduce((a, b) => a + b, 0) / stat.scores.length;
              existing.avgScore = existing.avgScore != null ? (existing.avgScore + avg) / 2 : avg;
            }
            boardScoringAgg.set(boardId, existing);
          }
          
          // Update job_board_performance rows with scoring results and trigger lifetime stats
          for (const [boardId, agg] of boardScoringAgg) {
            try {
              // Update the most recent performance record for this board+candidate
              await supabaseAdmin
                .from('job_board_performance')
                .update({
                  jobs_matched: agg.matched,
                  jobs_saved: agg.saved,
                  avg_match_score: agg.avgScore != null ? Math.round(agg.avgScore * 100) / 100 : null,
                  high_score_count: agg.highScoreCount,
                  updated_at: new Date().toISOString(),
                })
                .eq('job_board_id', boardId)
                .eq('candidate_id', candidateId)
                .order('created_at', { ascending: false })
                .limit(1);
              
              // Trigger lifetime stats recalculation
              await supabaseAdmin.rpc('update_job_board_lifetime_stats', { board_id: boardId });
            } catch (perfErr) {
              console.log(`[Perf] Failed to update board performance for ${boardId}: ${perfErr}`);
            }
          }
          
          console.log(`[Feedback] Updated ${queryStats.size} keyword records, ${boardStats.size} board feedback records`);
        }
      } catch (fbErr) {
        console.log(`[Feedback] Aggregation failed (non-critical): ${fbErr}`);
      }
    }
  }  // closes: if (mode === 'score')

    // ===============================================================
    // MODE: MATCH-EXISTING - Query existing jobs from DB and score them
    // This searches all jobs already in the database (not web scraping)
    // ===============================================================
    if (mode === 'match-existing' && !isCriticalTimeout()) {
      await writePipelineEvent('info', 'Searching existing jobs in database...');
      
      // Get current match count
      const { count: currentMatchCount } = await supabaseClient
        .from('matches')
        .select('id', { count: 'exact', head: true })
        .eq('candidate_id', candidateId);
      
      // Get all job IDs that already have matches for this candidate
      const { data: existingMatches } = await supabaseClient
        .from('matches')
        .select('job_id')
        .eq('candidate_id', candidateId);
      
      const matchedJobIds = new Set((existingMatches || []).map(m => m.job_id));
      
      // Fetch all jobs that don't already have matches
      const { data: existingJobs, error: jobsError } = await supabaseClient
        .from('jobs')
        .select(`
          id,
          title,
          description,
          location,
          job_type,
          salary_range,
          requirements,
          experience_level,
          skills_required,
          source_url,
          company_id,
          companies (
            id,
            name,
            employee_count,
            enrichment_status
          )
        `)
        .order('created_at', { ascending: false })
        .limit(200);
      
      if (jobsError) {
        console.error('Error fetching existing jobs:', jobsError);
        await writePipelineEvent('error', `Failed to fetch existing jobs: ${jobsError.message}`);
      } else {
        // Filter out jobs that already have matches
        const unmatchedJobs = (existingJobs || []).filter((job: any) => !matchedJobIds.has(job.id));
        
        console.log(`Found ${unmatchedJobs.length} unmatched jobs out of ${existingJobs?.length || 0} total`);
        await writePipelineEvent('info', `Found ${unmatchedJobs.length} jobs to evaluate...`);
        
        if (unmatchedJobs.length === 0) {
          await writePipelineEvent('success', 'No new jobs to match in database.');
        } else {
          // Filter out jobs from companies that exceed size limit
          const jobsToScore = unmatchedJobs.filter((job: any) => {
            if (!job.companies) return true; // No company info, allow scoring
            const company = job.companies;
            const exceedsByCount = company.employee_count && company.employee_count >= MAX_COMPANY_EMPLOYEES;
            const exceedsByStatus = company.enrichment_status === 'exceeds_size';
            if (exceedsByCount || exceedsByStatus) {
              console.log(`Skipping job from large company: ${company.name}`);
              return false;
            }
            return true;
          });
          
          console.log(`${jobsToScore.length} jobs pass size filter (excluded ${unmatchedJobs.length - jobsToScore.length} from large companies)`);
          
          let matchesSaved = 0;
          const AI_BATCH_SIZE = 20;
          const AI_TIMEOUT_MS = 8000;
          
          // Build candidate profile for scoring
          const candidateProfile = {
            skills: candidate.skills || [],
            current_title: candidate.current_title,
            ideal_role: candidate.ideal_role,
            career_goals: candidate.career_goals,
            industries_of_interest: candidate.industries_of_interest,
            ai_summary: candidate.ai_summary,
            career_highlights: candidate.career_highlights,
          };
          
          // Process jobs in batches
          for (let i = 0; i < jobsToScore.length && !shouldStopScoringForWrites() && !isCriticalTimeout(); i += AI_BATCH_SIZE) {
            if (await checkStopRequested()) break;
            
            const batch = jobsToScore.slice(i, i + AI_BATCH_SIZE);
            console.log(`Scoring batch ${Math.floor(i / AI_BATCH_SIZE) + 1}: ${batch.length} jobs`);
            
            const batchPromises = batch.map(async (job: any) => {
              try {
                // Build job content string from database fields
                const jobContent = [
                  `Job Title: ${job.title}`,
                  job.companies?.name ? `Company: ${job.companies.name}` : '',
                  job.location ? `Location: ${job.location}` : '',
                  job.job_type ? `Type: ${job.job_type}` : '',
                  job.salary_range ? `Salary: ${job.salary_range}` : '',
                  job.experience_level ? `Experience Level: ${job.experience_level}` : '',
                  job.skills_required?.length ? `Required Skills: ${job.skills_required.join(', ')}` : '',
                  job.description ? `\nDescription:\n${job.description}` : '',
                  job.requirements ? `\nRequirements:\n${job.requirements}` : '',
                ].filter(Boolean).join('\n');
                
                const controller = new AbortController();
                const timeout = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);
                
                try {
                  const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                      'Authorization': `Bearer ${LOVABLE_API_KEY}`,
                      'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                      model: 'openai/gpt-5-nano',
                      messages: [
                        { 
                          role: 'system', 
                          content: `You are evaluating a job for a candidate. Score 0-100 based on skill match (50%) and career fit (50%).
                          
Candidate Profile:
- Skills: ${candidateProfile.skills.join(', ') || 'Not specified'}
- Current Role: ${candidateProfile.current_title || 'Not specified'}
- Target Role: ${candidateProfile.ideal_role || 'Not specified'}
- Career Goals: ${candidateProfile.career_goals || 'Not specified'}
- Target Industries: ${candidateProfile.industries_of_interest?.join(', ') || 'Not specified'}

Respond ONLY with valid JSON:
{
  "match_score": <0-100>,
  "match_reason": "<brief explanation>",
  "skills_matched": ["skill1", "skill2"],
  "skills_missing": ["skill1", "skill2"]
}`
                        },
                        { role: 'user', content: jobContent.slice(0, 4000) }
                      ],
                      temperature: 0.1,
                      max_tokens: 500,
                    }),
                    signal: controller.signal,
                  });
                  
                  clearTimeout(timeout);
                  
                  if (!response.ok) {
                    console.error(`AI scoring failed for job ${job.id}`);
                    return null;
                  }
                  
                  const aiData = await response.json();
                  const content = aiData.choices?.[0]?.message?.content || '';
                  const parsed = safeParseFirstJsonObject(content);
                  
                  if (!parsed || typeof parsed.match_score !== 'number') {
                    console.error(`Invalid AI response for job ${job.id}`);
                    return null;
                  }
                  
                  const matchScore = Math.min(100, Math.max(0, parsed.match_score));
                  
                  return {
                    job,
                    matchScore,
                    matchReason: parsed.match_reason || '',
                    skillsMatched: parsed.skills_matched || [],
                    skillsMissing: parsed.skills_missing || [],
                  };
                } catch (err) {
                  clearTimeout(timeout);
                  console.error(`Error scoring job ${job.id}:`, err);
                  return null;
                }
              } catch (err) {
                console.error(`Error processing job ${job.id}:`, err);
                return null;
              }
            });
            
            const batchResults = await Promise.all(batchPromises);
            results.pendingJobsScored += batch.length;
            
            // Save matches for jobs above threshold
            for (const result of batchResults) {
              if (!result) continue;
              
              const { job, matchScore, matchReason, skillsMatched, skillsMissing } = result;
              
              if (matchScore < EXTERNAL_MATCH_THRESHOLD) {
                console.log(`Job ${job.title} scored ${matchScore}% - below threshold`);
                results.jobsRejected++;
                continue;
              }
              
              // Location mismatch check
              const locationCheck = isLocationMismatch(
                job.location,
                candidate.search_city,
                candidate.search_country,
                candidate.desired_location,
                candidate.is_remote_worker ?? false,
                candidate.address,
                candidate.search_distance_km
              );
              
              if (locationCheck.mismatch) {
                console.log(`Job ${job.title} rejected: ${locationCheck.reason}`);
                results.jobsRejected++;
                continue;
              }
              
              // Salary benchmarking deferred to background - save match immediately
              const { error: matchError } = await supabaseAdmin.from('matches').insert({
                candidate_id: candidateId,
                job_id: job.id,
                match_score: matchScore,
                match_reason: matchReason,
                skills_matched: skillsMatched,
                skills_missing: skillsMissing,
                status: 'pending',
                created_by: user.id,
                salary_benchmark: null,
                salary_percentile: null,
              });
              
              if (!matchError) {
                matchesSaved++;
                results.matchesSaved++;
                console.log(`Saved match: ${job.title} at ${job.companies?.name || 'Unknown'} (${matchScore}%)`);
                
                await writePipelineEvent('match', JSON.stringify({
                  job_title: job.title,
                  score: matchScore,
                  company_name: job.companies?.name || 'Unknown',
                }));
              }
            }
            
            // Progress update
            await writePipelineEvent('info', `Scored ${results.pendingJobsScored}/${jobsToScore.length} jobs, saved ${matchesSaved} matches...`);
          }
          
          await writePipelineEvent('success', `Database scan complete. Found ${matchesSaved} new matches from ${results.pendingJobsScored} jobs.`);
        }
      }
    }  // closes: if (mode === 'match-existing')

    // Final response
    const finalMatchCount = await supabaseClient
      .from('matches')
      .select('id', { count: 'exact', head: true })
      .eq('candidate_id', candidateId);

    console.log(`Pipeline ${mode} complete: ${results.pendingJobsStored} stored, ${results.pendingJobsScored} scored, ${results.matchesSaved} saved, total matches: ${finalMatchCount.count}`);

    // Emit credit usage summary to debug feed
    await writePipelineEvent('credit', JSON.stringify({
      firecrawl_calls: firecrawlCallCount,
      estimated_credits: firecrawlCallCount,
      failed_402s: results.firecrawl402Count,
      jobs_discovered: results.pendingJobsStored,
      jobs_scored: results.pendingJobsScored,
      matches_saved: results.matchesSaved,
      note: 'Each successful Firecrawl API call consumes ~1 credit',
    }));

    return new Response(
      JSON.stringify({
        success: true,
        runId,
        mode,
        pendingJobsStored: results.pendingJobsStored,
        pendingJobsScored: results.pendingJobsScored,
        matchesSaved: results.matchesSaved,
        totalMatches: finalMatchCount.count || 0,
        searchProgress: {
          boardsSearched: results.boardsSearched,
          totalBoardsAttempted: results.boardsSearched.length,
          stoppedDueToTimeout: results.stoppedDueToTimeout,
          nextBoardIndex: results.nextBoardIndex,
          totalBoardsAvailable: results.totalBoardsAvailable,
          hasPendingJobs: results.hasPendingJobs,
          firecrawlQuotaExceeded: results.firecrawlQuotaExceeded,
        },
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Pipeline error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Pipeline failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
