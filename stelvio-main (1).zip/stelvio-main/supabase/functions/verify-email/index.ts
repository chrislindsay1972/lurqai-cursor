import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface VerifyRequest {
  email?: string;
  stakeholder_id?: string;
  // Batch mode: verify all unverified emails for a company
  company_id?: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body: VerifyRequest & { batch_mode?: boolean; batch_size?: number; offset?: number } = await req.json();
    const HUNTER_API_KEY = Deno.env.get("HUNTER_API_KEY");
    if (!HUNTER_API_KEY) {
      return new Response(
        JSON.stringify({ error: "HUNTER_API_KEY not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Collect stakeholders to verify
    const targets: { id: string; email: string; currentStatus: string | null }[] = [];

    if (body.batch_mode) {
      // Batch mode: verify all unverified stakeholders with emails
      const batchSize = Math.min(body.batch_size || 50, 50);
      const offset = body.offset || 0;
      const { data: shs } = await supabase
        .from("stakeholders")
        .select("id, email, email_status, enrichment_source")
        .not("email", "is", null)
        .neq("enrichment_source", "bettercontact_pending")
        .or("email_status.is.null,email_status.in.(\"inferred\",\"extrapolated\",\"unknown\")")
        .range(offset, offset + batchSize - 1);
      if (shs) targets.push(...shs.filter(s => s.email).map(s => ({ id: s.id, email: s.email!, currentStatus: s.email_status })));
    } else if (body.stakeholder_id) {
      const { data: sh } = await supabase
        .from("stakeholders")
        .select("id, email, email_status")
        .eq("id", body.stakeholder_id)
        .single();
      if (sh?.email) targets.push({ id: sh.id, email: sh.email, currentStatus: sh.email_status });
    } else if (body.company_id) {
      const { data: shs } = await supabase
        .from("stakeholders")
        .select("id, email, email_status")
        .eq("company_id", body.company_id)
        .not("email", "is", null)
        .not("email_status", "in", '("verified","undeliverable","catch_all")');
      if (shs) targets.push(...shs.filter(s => s.email).map(s => ({ id: s.id, email: s.email!, currentStatus: s.email_status })));
    } else if (body.email) {
      targets.push({ id: "", email: body.email, currentStatus: null });
    }

    if (targets.length === 0) {
      return new Response(
        JSON.stringify({ error: "No emails to verify" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const results: any[] = [];

    for (const target of targets.slice(0, 20)) {
      try {
        console.log(`Verifying: ${target.email}`);

        const response = await fetch(
          `https://api.hunter.io/v2/email-verifier?email=${encodeURIComponent(target.email)}&api_key=${HUNTER_API_KEY}`,
          { method: "GET" }
        );

        const hunterData = await response.json();

        // Handle in-progress / rate-limited
        if (response.status === 202 || hunterData.meta?.message) {
          results.push({ email: target.email, status: "pending", details: "verification in progress" });
          continue;
        }

        if (hunterData.errors?.length > 0) {
          results.push({ email: target.email, status: "unknown", error: hunterData.errors[0]?.details });
          continue;
        }

        if (!hunterData.data) {
          results.push({ email: target.email, status: "unknown" });
          continue;
        }

        // Map Hunter result to our status
        let emailStatus: string;
        const result = hunterData.data.result || hunterData.data.status;

        switch (result) {
          case "deliverable":
          case "valid":
            emailStatus = "verified";
            break;
          case "undeliverable":
          case "invalid":
            emailStatus = "undeliverable";
            break;
          case "risky":
          case "accept_all":
            emailStatus = hunterData.data.accept_all ? "catch_all" : "unknown";
            break;
          default:
            emailStatus = "unknown";
        }

        const score = hunterData.data.score || 0;
        const details = {
          mxRecords: hunterData.data.mx_records,
          smtpServer: hunterData.data.smtp_server,
          smtpCheck: hunterData.data.smtp_check,
          acceptAll: hunterData.data.accept_all,
          disposable: hunterData.data.disposable,
          webmail: hunterData.data.webmail,
          hunterScore: score,
        };

        // Write back to stakeholders table if we have an ID
        // Monotonicity: never downgrade verified → lower status
        if (target.id) {
          const confidence = emailStatus === "verified" ? 1.0
            : emailStatus === "catch_all" ? 0.7
            : emailStatus === "undeliverable" ? 0.0
            : (score / 100);

          const statusRank: Record<string, number> = { verified: 3, catch_all: 2, undeliverable: 1, unknown: 0, inferred: 0, extrapolated: 0 };
          const currentRank = statusRank[target.currentStatus || ""] ?? 0;
          const newRank = statusRank[emailStatus] ?? 0;

          // Only write if upgrade OR if moving to undeliverable (explicit negative signal)
          if (newRank > currentRank || emailStatus === "undeliverable") {
            await supabase
              .from("stakeholders")
              .update({
                email_status: emailStatus,
                email_confidence: confidence,
              })
              .eq("id", target.id);
            console.log(`Updated stakeholder ${target.id}: ${target.currentStatus} → ${emailStatus}, confidence=${confidence}`);
          } else {
            console.log(`Skipped stakeholder ${target.id}: ${target.currentStatus} → ${emailStatus} (would be downgrade)`);
          }
        }

        results.push({
          email: target.email,
          stakeholder_id: target.id || undefined,
          status: emailStatus,
          score,
          details,
        });
      } catch (err) {
        console.error(`Error verifying ${target.email}:`, err);
        results.push({ email: target.email, status: "unknown", error: String(err) });
      }
    }

    return new Response(
      JSON.stringify({ results, verified: results.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Verification error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
