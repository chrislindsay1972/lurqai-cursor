import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY') ?? '';

function serviceClient() {
  return createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
}

// Call a sibling edge function using the service role key
async function callFunction(name: string, body: Record<string, unknown>): Promise<{ data?: unknown; error?: string }> {
  const url = `${SUPABASE_URL}/functions/v1/${name}`;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 55_000); // 55s timeout per sub-call
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SERVICE_ROLE_KEY}`,
        'Content-Type': 'application/json',
        'apikey': ANON_KEY,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    clearTimeout(timeout);
    const data = await res.json();
    if (!res.ok) return { error: data.error || `HTTP ${res.status}` };
    if (data.error) return { error: data.error };
    return { data };
  } catch (e) {
    return { error: e instanceof Error ? e.message : 'Unknown error' };
  }
}

async function updateItem(db: ReturnType<typeof serviceClient>, itemId: string, updates: Record<string, unknown>) {
  await db.from('bulk_enrichment_items').update(updates).eq('id', itemId);
}

async function updateRunCounts(db: ReturnType<typeof serviceClient>, runId: string) {
  const { data: items } = await db
    .from('bulk_enrichment_items')
    .select('domain_status, enrich_status, stakeholder_status')
    .eq('run_id', runId);

  if (!items) return;

  let completed = 0, succeeded = 0, failed = 0;
  for (const item of items) {
    const isDone = item.domain_status !== 'pending' && item.domain_status !== 'running'
      && item.enrich_status !== 'pending' && item.enrich_status !== 'running'
      && item.stakeholder_status !== 'pending' && item.stakeholder_status !== 'running';
    if (isDone) {
      completed++;
      if (item.domain_status === 'success' || item.enrich_status === 'success') {
        succeeded++;
      } else {
        failed++;
      }
    }
  }

  await db.from('bulk_enrichment_runs').update({ completed, succeeded, failed }).eq('id', runId);
}

async function processCompany(
  db: ReturnType<typeof serviceClient>,
  item: { id: string; company_id: string; company_name: string; domain: string | null },
  runId: string,
) {
  const alreadyHasDomain = item.domain && item.domain.trim() !== '';
  let domain = alreadyHasDomain ? item.domain! : undefined;

  // Step 1: Domain lookup (skip if already has domain)
  if (!alreadyHasDomain) {
    await updateItem(db, item.id, { domain_status: 'running' });
    const result = await callFunction('lookup-company-domain', {
      companyName: item.company_name,
      companyId: item.company_id,
    });
    if (result.error) {
      await updateItem(db, item.id, {
        domain_status: 'failed',
        enrich_status: 'skipped',
        stakeholder_status: 'skipped',
        error: result.error,
      });
      await updateRunCounts(db, runId);
      return;
    }
    const d = (result.data as Record<string, unknown>)?.data as Record<string, unknown> | undefined;
    domain = d?.domain as string | undefined;
    if (!domain) {
      await updateItem(db, item.id, {
        domain_status: 'failed',
        enrich_status: 'skipped',
        stakeholder_status: 'skipped',
        error: 'Domain not found',
      });
      await updateRunCounts(db, runId);
      return;
    }
    await updateItem(db, item.id, { domain_status: 'success', domain });
  }

  // Step 2: Enrich company
  await updateItem(db, item.id, { enrich_status: 'running' });
  const enrichResult = await callFunction('enrich-company', {
    domain,
    companyId: item.company_id,
  });
  if (enrichResult.error) {
    await updateItem(db, item.id, { enrich_status: 'failed' });
    console.error(`Enrich failed for ${item.company_name}: ${enrichResult.error}`);
  } else {
    await updateItem(db, item.id, { enrich_status: 'success' });
  }

  // Step 3: Discover stakeholders
  await updateItem(db, item.id, { stakeholder_status: 'running' });
  const stakeholderResult = await callFunction('enrich-stakeholders', {
    companyId: item.company_id,
    companyName: item.company_name,
    domain,
  });
  if (stakeholderResult.error) {
    await updateItem(db, item.id, { stakeholder_status: 'failed' });
    console.error(`Stakeholder discovery failed for ${item.company_name}: ${stakeholderResult.error}`);
  } else {
    const created = (stakeholderResult.data as Record<string, unknown>)?.stakeholdersCreated as number | undefined;
    await updateItem(db, item.id, { stakeholder_status: 'success', stakeholders_found: created || 0 });
  }

  await updateRunCounts(db, runId);
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Auth check - verify the calling user is recruiter/admin
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    const userClient = createClient(SUPABASE_URL, ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    const { data: roleData } = await userClient.from('user_roles').select('role').eq('user_id', user.id).single();
    if (!roleData || !['recruiter', 'admin'].includes(roleData.role)) {
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    const { runId } = await req.json();

    if (!runId) {
      return new Response(
        JSON.stringify({ error: 'runId is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

     const db = serviceClient();

     // Step 0: Delete orphan companies (those with no matched jobs)
     const { data: allItems } = await db
       .from('bulk_enrichment_items')
       .select('id, company_id')
       .eq('run_id', runId);

     if (allItems && allItems.length > 0) {
       const companyIds = allItems.map(i => i.company_id);
       
       // Find companies with no jobs
       const { data: companiesWithJobs } = await db
         .from('jobs')
         .select('company_id')
         .in('company_id', companyIds);
       
       const companiesWithJobsSet = new Set(companiesWithJobs?.map(j => j.company_id) || []);
       const orphanItems = allItems.filter(i => !companiesWithJobsSet.has(i.company_id));
       
       if (orphanItems.length > 0) {
         const orphanIds = orphanItems.map(i => i.id);
         
         // Delete orphan items from tracking
         await db.from('bulk_enrichment_items').delete().in('id', orphanIds);
         
         // Delete orphan companies from database
         const orphanCompanyIds = orphanItems.map(i => i.company_id);
         await db.from('companies').delete().in('id', orphanCompanyIds);
         
         console.log(`Deleted ${orphanItems.length} orphan companies with no jobs`);
       }
     }

     // Fetch all pending items for this run, ordered
     const { data: items, error: itemsError } = await db
       .from('bulk_enrichment_items')
       .select('id, company_id, company_name, domain, domain_status')
       .eq('run_id', runId)
       .in('domain_status', ['pending', 'success']) // pending = needs full processing, success = domain done, needs enrich
       .order('processing_order', { ascending: true });

    if (itemsError || !items || items.length === 0) {
      // Mark run as completed
      await db.from('bulk_enrichment_runs').update({ status: 'completed' }).eq('id', runId);
      return new Response(
        JSON.stringify({ success: true, message: 'No items to process' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // Filter to only items that still need work
    const toProcess = items.filter(i => {
      // If domain_status is pending, definitely needs processing
      if (i.domain_status === 'pending') return true;
      // If domain_status is success, check if enrich/stakeholder still pending
      // (we'll re-fetch to check)
      return true;
    });

    console.log(`Bulk enrich: processing ${toProcess.length} companies for run ${runId}`);

    // Process sequentially with 1s delay between companies
    for (let i = 0; i < toProcess.length; i++) {
      const item = toProcess[i];
      await processCompany(db, item, runId);

      // 1s delay between companies (skip on last)
      if (i < toProcess.length - 1) {
        await new Promise(r => setTimeout(r, 1000));
      }
    }

    // Mark run completed
    await db.from('bulk_enrichment_runs').update({ status: 'completed' }).eq('id', runId);

    return new Response(
      JSON.stringify({ success: true, processed: toProcess.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (error) {
    console.error('Bulk enrich error:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to process bulk enrichment' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
