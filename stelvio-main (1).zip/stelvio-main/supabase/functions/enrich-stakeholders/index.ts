// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Auth check - support both user JWT and service role key
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const token = authHeader.replace('Bearer ', '');
    const isServiceRole = token === serviceRoleKey;

    let supabaseClient;
    let userId: string | null = null;

    if (isServiceRole) {
      console.log('Authenticated via service role key (background task)');
      supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        serviceRoleKey
      );
    } else {
      const supabaseUserClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
        { global: { headers: { Authorization: authHeader } } }
      );

      const { data: { user }, error: userError } = await supabaseUserClient.auth.getUser();
      if (userError || !user) {
        console.error('Auth getUser error:', userError);
        return new Response(
          JSON.stringify({ error: 'Unauthorized' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      userId = user.id;
      console.log(`Authenticated user: ${user.id}`);

      supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        serviceRoleKey
      );

      const { data: userRole, error: roleError } = await supabaseClient
        .rpc('get_user_role', { _user_id: user.id });

      if (roleError) {
        console.error('Role check error:', roleError);
        return new Response(
          JSON.stringify({ error: 'Failed to verify permissions' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log(`User ${user.id} has role: ${userRole}`);

      if (!userRole || !['recruiter', 'admin'].includes(userRole)) {
        return new Response(
          JSON.stringify({ error: 'Insufficient permissions' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    const body = await req.json();
    const { companyId, companyName, domain, jobTitle, jobDescription } = body;
    
    console.log(`Received enrichment request body:`, JSON.stringify(body));
    console.log(`Parsed: companyId=${companyId}, companyName=${companyName}, domain=${domain}`);
    
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!companyId || !uuidRegex.test(companyId)) {
      return new Response(
        JSON.stringify({ error: 'Valid Company ID (UUID) is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    if (!domain) {
      return new Response(
        JSON.stringify({ error: 'Company domain is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Enriching stakeholders for company: ${companyName} (${domain})`);

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    let FIRECRAWL_API_KEY = Deno.env.get('FIRECRAWL_API_KEY');
    // Resolve Firecrawl API key: app_settings override first, then env var
    try {
      const { data: secretSetting } = await supabaseClient
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'secret_firecrawl_api_key')
        .single();
      if (secretSetting?.setting_value) {
        FIRECRAWL_API_KEY = secretSetting.setting_value;
        console.log('Using Firecrawl API key from app_settings');
      }
    } catch (_) { /* ignore, use env fallback */ }

    if (!LOVABLE_API_KEY) {
      return new Response(
        JSON.stringify({ error: 'AI service not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch company details
    const { data: companyData } = await supabaseClient
      .from('companies')
      .select('employee_count, industry, linkedin_url')
      .eq('id', companyId)
      .single();

    const APOLLO_API_KEY = Deno.env.get('APOLLO_API_KEY');
    let potentialContacts: Array<{ first_name: string; last_name: string; title: string; email?: string; linkedin_url?: string; reasoning?: string }> = [];
    let discoverySource = 'none';

    // ═══════════════════════════════════════════════════════════════════════
    // TIER 1: Apollo People Search — verified data, no hallucination risk
    // ═══════════════════════════════════════════════════════════════════════
    if (APOLLO_API_KEY) {
      console.log(`[TIER 1] Apollo People Search for ${companyName} (${domain})`);

      // Build title filters based on company size
      const employeeCount = companyData?.employee_count || 0;
      let targetTitles: string[] = [];
      if (employeeCount <= 50) {
        targetTitles = ['CEO', 'Founder', 'Co-Founder', 'Owner', 'Managing Director', 'Head of', 'Director'];
      } else if (employeeCount <= 200) {
        targetTitles = ['HR Manager', 'Talent Acquisition', 'Head of People', 'VP', 'Director', 'Head of HR', 'People Operations'];
      } else {
        targetTitles = ['Talent Acquisition Manager', 'HR Director', 'Head of Talent', 'Recruiting Lead', 'VP People', 'VP Human Resources'];
      }

      try {
        // Fetch custom targeting rules from app_settings
        const { data: targetingRules } = await supabaseClient
          .from('stakeholder_targeting_rules')
          .select('*')
          .order('display_order', { ascending: true });

        if (targetingRules && targetingRules.length > 0) {
          // Find the matching rule for this company size
          const matchingRule = targetingRules.find(rule => {
            const min = rule.min_employees || 0;
            const max = rule.max_employees;
            return employeeCount >= min && (max === null || employeeCount <= max);
          });
          if (matchingRule && matchingRule.target_titles.length > 0) {
            targetTitles = matchingRule.target_titles;
            console.log(`[TIER 1] Using custom targeting rule for ${employeeCount} employees: ${targetTitles.join(', ')}`);
          }
        }

        const apolloResponse = await fetch('https://api.apollo.io/api/v1/mixed_people/api_search', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Api-Key': APOLLO_API_KEY,
          },
          body: JSON.stringify({
            q_organization_domains_list: [domain],
            person_titles: targetTitles,
            page: 1,
            per_page: 5,
          }),
        });

        if (apolloResponse.ok) {
          const apolloData = await apolloResponse.json();
          const people = apolloData.people || [];

          console.log(`[TIER 1] Apollo api_search returned ${people.length} people for ${domain}`);

          if (people.length > 0) {
            // api_search returns obfuscated last names — enrich each person via /people/match to get full profiles
            const enrichPromises = people.slice(0, 5).map(async (person: any) => {
              try {
                const enrichResp = await fetch('https://api.apollo.io/api/v1/people/match', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'X-Api-Key': APOLLO_API_KEY },
                  body: JSON.stringify({ id: person.id }),
                });
                if (enrichResp.ok) {
                  const enrichData = await enrichResp.json();
                  const p = enrichData.person;
                  if (p?.first_name && p?.last_name) {
                    console.log(`[TIER 1] ✓ Enriched: ${p.first_name} ${p.last_name} (${p.title || 'N/A'}) | LinkedIn: ${p.linkedin_url || 'none'} | Email: ${p.email || 'none'}`);
                    return {
                      first_name: p.first_name,
                      last_name: p.last_name,
                      title: p.title || p.headline || 'Unknown',
                      email: p.email || null,
                      linkedin_url: p.linkedin_url || null,
                      reasoning: `Apollo verified record. Organization: ${p.organization?.name || domain}`,
                    };
                  }
                } else {
                  console.log(`[TIER 1] People match failed for ${person.id}: ${enrichResp.status}`);
                }
              } catch (e) {
                console.log(`[TIER 1] People match error for ${person.id}:`, e);
              }
              return null;
            });

            const enrichResults = await Promise.allSettled(enrichPromises);
            for (const result of enrichResults) {
              if (result.status === 'fulfilled' && result.value) {
                potentialContacts.push(result.value);
              }
            }
          }

          if (potentialContacts.length > 0) {
            discoverySource = 'apollo-people-search';
            console.log(`[TIER 1] ✓ Found ${potentialContacts.length} verified contacts via Apollo`);
          }
        } else {
          const errText = await apolloResponse.text();
          console.log(`[TIER 1] Apollo People Search failed (${apolloResponse.status}): ${errText.slice(0, 200)}`);
        }
      } catch (apolloErr) {
        console.log(`[TIER 1] Apollo People Search error:`, apolloErr);
      }
    } else {
      console.log('[TIER 1] Apollo API key not configured, skipping');
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TIER 2 FALLBACK: LinkedIn scrape + AI extraction (only if Apollo found nothing)
    // ═══════════════════════════════════════════════════════════════════════
    if (potentialContacts.length === 0) {
      console.log(`[TIER 2] Apollo returned no results, falling back to LinkedIn scrape + AI for ${companyName}`);

      let linkedInPeopleData = '';
      const linkedInCompanyUrl = companyData?.linkedin_url || `https://www.linkedin.com/company/${domain?.replace(/\./g, '')}`;

      if (FIRECRAWL_API_KEY) {
        console.log(`[TIER 2] Scraping LinkedIn page: ${linkedInCompanyUrl}`);
        try {
          const resp = await fetch('https://api.firecrawl.dev/v1/scrape', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              url: linkedInCompanyUrl,
              formats: ['markdown'],
              onlyMainContent: true,
              timeout: 15000,
            }),
          });
          if (resp.ok) {
            const data = await resp.json();
            if (data.success && data.data?.markdown) {
              linkedInPeopleData = data.data.markdown;
              console.log(`[TIER 2] Scraped LinkedIn (${linkedInPeopleData.length} chars)`);
            }
          } else {
            console.log(`[TIER 2] LinkedIn scrape failed: ${resp.status}`);
          }
        } catch (e) {
          console.log('[TIER 2] LinkedIn scrape error:', e);
        }
      }

      // ═══ HALLUCINATION GUARD: Skip AI entirely if no real scraped data ═══
      if (!linkedInPeopleData || linkedInPeopleData.trim().length < 200) {
        console.log(`[TIER 2] ✗ Insufficient scraped data (${linkedInPeopleData.length} chars) — skipping AI to prevent hallucination`);
        return new Response(
          JSON.stringify({ success: true, stakeholdersCreated: 0, message: 'No scraped data available for AI extraction' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Fetch the AI instruction prompt from database
      const { data: aiInstruction } = await supabaseClient
        .from('ai_instructions')
        .select('instruction_prompt')
        .eq('instruction_key', 'stakeholder_identification')
        .single();

      let promptTemplate = aiInstruction?.instruction_prompt || getDefaultStakeholderPrompt();
      
      promptTemplate = promptTemplate
        .replace(/\{\{company_name\}\}/g, companyName || 'Unknown')
        .replace(/\{\{company_domain\}\}/g, domain || 'Unknown')
        .replace(/\{\{employee_count\}\}/g, companyData?.employee_count?.toString() || 'Unknown')
        .replace(/\{\{industry\}\}/g, companyData?.industry || 'Unknown')
        .replace(/\{\{linkedin_url\}\}/g, companyData?.linkedin_url || 'Not available')
        .replace(/\{\{job_title\}\}/g, jobTitle || 'General hiring')
        .replace(/\{\{job_description\}\}/g, jobDescription || 'No specific job description provided');

      if (linkedInPeopleData) {
        promptTemplate += `\n\n--- SCRAPED DATA FROM LINKEDIN & COMPANY WEBSITE ---\n${linkedInPeopleData.slice(0, 8000)}`;
      }

      console.log(`[TIER 2] Using AI to identify decision-makers for ${companyName} (${companyData?.employee_count || 'unknown'} employees)${linkedInPeopleData ? ' with scraped data' : ''}`);

      const stakeholderSearchResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${LOVABLE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'google/gemini-2.5-pro',
          messages: [
          {
              role: 'system',
              content: `You are a recruitment researcher. Your ONLY job is to extract REAL people from the SCRAPED DATA provided below.

## ABSOLUTE RULES — VIOLATION MEANS FAILURE

1. **DO NOT INVENT, FABRICATE, OR HALLUCINATE** any person, name, title, email, or LinkedIn URL.
2. **ONLY return people whose names appear VERBATIM in the scraped data.** If a name is not explicitly written in the data, do NOT include that person.
3. **LinkedIn URLs**: Only include a LinkedIn URL if it appears VERBATIM in the scraped data. If you cannot copy-paste the exact URL from the data, set linkedin_url to null. NEVER construct or guess a LinkedIn URL.
4. **Emails**: Only include an email if it appears VERBATIM in the scraped data. If not found, set email to null. NEVER guess or construct emails.
5. **If the scraped data contains ZERO identifiable people, return an empty contacts array.** Returning zero results is ALWAYS better than fabricating results.
6. **Titles**: Only use the exact title shown in the data. Do not infer or upgrade titles.

## WHAT TO EXTRACT

From the scraped data, find people who are decision-makers relevant to hiring:
- Hiring Managers, Department Heads, HR/Talent Acquisition, C-Suite (for smaller companies)
- Return ALL relevant contacts found (typically 2-5), quality over quantity
- For each person, explain WHERE in the scraped data you found them

## REMEMBER
It is better to return 0 contacts than to return 1 fabricated contact. Accuracy is everything. If you are not 100% certain a person works at this company based on the scraped data, do NOT include them.`
            },
            { role: 'user', content: promptTemplate }
          ],
          tools: [
            {
              type: "function",
              function: {
                name: "identify_stakeholders",
                description: "Return ONLY people whose names appear verbatim in the scraped data. Return empty array if no real people found. NEVER fabricate.",
                parameters: {
                  type: "object",
                  properties: {
                    contacts: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          first_name: { type: "string", description: "First name — must appear verbatim in scraped data" },
                          last_name: { type: "string", description: "Last name — must appear verbatim in scraped data" },
                          title: { type: "string", description: "Exact job title from scraped data" },
                          email: { type: "string", description: "Email ONLY if found verbatim in scraped data. null otherwise. NEVER guess." },
                          linkedin_url: { type: "string", description: "LinkedIn URL ONLY if found verbatim in scraped data. null otherwise. NEVER construct URLs." },
                          reasoning: { type: "string", description: "Quote the exact text from the scraped data where you found this person" }
                        },
                        required: ["first_name", "last_name", "title", "reasoning"],
                        additionalProperties: false
                      }
                    }
                  },
                  required: ["contacts"],
                  additionalProperties: false
                }
              }
            }
          ],
          tool_choice: { type: "function", function: { name: "identify_stakeholders" } }
        }),
      });

      if (stakeholderSearchResponse.ok) {
        const searchData = await stakeholderSearchResponse.json();
        const toolCall = searchData.choices?.[0]?.message?.tool_calls?.[0];
        if (toolCall?.function?.arguments) {
          try {
            const parsed = JSON.parse(toolCall.function.arguments);
            potentialContacts = parsed.contacts || [];
            if (potentialContacts.length > 0) {
              discoverySource = 'ai-linkedin-scrape';
            }
          } catch {
            console.log('[TIER 2] Could not parse tool call response');
          }
        }

        // ═══ POST-EXTRACTION HALLUCINATION FILTER ═══
        // Verify each AI-returned name actually appears in the scraped text
        // This filter runs on ALL AI-extracted contacts regardless of parse path
        const applyHallucinationFilter = (contacts: typeof potentialContacts, sourceData: string): typeof potentialContacts => {
          if (contacts.length === 0 || !sourceData || sourceData.trim().length < 100) return contacts;
          const scrapedLower = sourceData.toLowerCase();
          const beforeCount = contacts.length;
          const filtered = contacts.filter(contact => {
            const firstName = (contact.first_name || '').toLowerCase().trim();
            const lastName = (contact.last_name || '').toLowerCase().trim();
            if (!firstName || !lastName) return false;
            
            // STRICT CHECK: The full name "FirstName LastName" must appear as a 
            // contiguous phrase in the scraped data, not just individual words scattered anywhere.
            const fullName = `${firstName} ${lastName}`;
            const nameInData = scrapedLower.includes(fullName);
            
            if (!nameInData) {
              console.log(`[HALLUCINATION FILTER] ✗ BLOCKED: "${contact.first_name} ${contact.last_name}" — full name not found as contiguous phrase in scraped data`);
            }
            return nameInData;
          });
          if (beforeCount !== filtered.length) {
            console.log(`[HALLUCINATION FILTER] ${beforeCount} → ${filtered.length} contacts survived verbatim check`);
          }
          return filtered;
        };

        // Apply filter to tool_call results
        potentialContacts = applyHallucinationFilter(potentialContacts, linkedInPeopleData);

        // Fallback: try parsing from message.content if tool_call returned nothing
        if (potentialContacts.length === 0) {
          const searchContent = searchData.choices?.[0]?.message?.content;
          if (searchContent) {
            try {
              const parsed = JSON.parse(searchContent.replace(/```json\n?|\n?```/g, '').trim());
              let fallbackContacts = Array.isArray(parsed) ? parsed : [];
              // CRITICAL: Apply the SAME hallucination filter to fallback-parsed contacts
              fallbackContacts = applyHallucinationFilter(fallbackContacts, linkedInPeopleData);
              if (fallbackContacts.length > 0) {
                potentialContacts = fallbackContacts;
                discoverySource = 'ai-linkedin-scrape';
              }
            } catch {
              console.log('[TIER 2] Could not parse AI response');
            }
          }
        }
      } else {
        console.log(`[TIER 2] AI request failed: ${stakeholderSearchResponse.status}`);
      }
    }

    if (potentialContacts.length === 0) {
      console.log(`No potential contacts found for ${companyName} (tried Apollo + AI fallback)`);
      return new Response(
        JSON.stringify({ success: true, stakeholdersCreated: 0, message: 'No contacts identified' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`[Discovery] Source: ${discoverySource}, contacts: ${potentialContacts.length}`);

    // Log findings
    potentialContacts.forEach((contact, i) => {
      const emailStatus = contact.email ? `✓ Email: ${contact.email}` : '✗ No email found';
      console.log(`[${discoverySource}] Contact ${i + 1}: ${contact.first_name} ${contact.last_name} (${contact.title}) - ${emailStatus}${contact.linkedin_url ? ` | LinkedIn: ${contact.linkedin_url}` : ''}`);
      if (contact.reasoning) console.log(`  Reasoning: ${contact.reasoning}`);
    });

    // LinkedIn profile URL search skipped in auto-enrich path to preserve Firecrawl credits
    // BetterContact enrichment (triggered below) will resolve emails without needing LinkedIn URLs

    // Create stakeholder records and trigger enrichment IN PARALLEL
    let stakeholdersCreated = 0;
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';

    // Step 1: Insert all stakeholders in parallel
    const insertPromises = potentialContacts.map(async (contact) => {
      const name = `${contact.first_name} ${contact.last_name}`.trim();
      if (!name || name === ' ') return null;

      // Check if stakeholder already exists
      const { data: existing } = await supabaseClient
        .from('stakeholders')
        .select('id')
        .eq('company_id', companyId)
        .ilike('name', name)
        .maybeSingle();

      if (existing) {
        console.log(`Stakeholder ${name} already exists, skipping`);
        return null;
      }
      
      let discoveredEmail = contact.email || null;
      if (discoveredEmail) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(discoveredEmail)) {
          console.log(`Invalid email format detected: ${discoveredEmail}, discarding`);
          discoveredEmail = null;
        }
      }
      
      let linkedinUrl = contact.linkedin_url || null;
      if (linkedinUrl && !linkedinUrl.includes('linkedin.com/in/')) {
        console.log(`Invalid LinkedIn URL format: ${linkedinUrl}, discarding`);
        linkedinUrl = null;
      }

      // ─── Validate AI-generated LinkedIn URL via Firecrawl ────────────────
      if (linkedinUrl && FIRECRAWL_API_KEY) {
        try {
          console.log(`[LinkedIn Verify] Checking ${linkedinUrl} for ${contact.first_name} ${contact.last_name}`);
          const verifyResp = await fetch('https://api.firecrawl.dev/v1/scrape', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              url: linkedinUrl,
              formats: ['markdown'],
              onlyMainContent: true,
              timeout: 10000,
            }),
          });

          if (!verifyResp.ok) {
            console.log(`[LinkedIn Verify] Scrape failed (${verifyResp.status}), discarding URL`);
            linkedinUrl = null;
          } else {
            const verifyData = await verifyResp.json();
            const pageText = (verifyData?.data?.markdown || verifyData?.markdown || '').toLowerCase();

            // Check if the page actually contains the person's name (fuzzy match)
            const firstName = contact.first_name.toLowerCase();
            const lastName = contact.last_name.toLowerCase();
            const hasName = pageText.includes(firstName) && pageText.includes(lastName);
            const isErrorPage = pageText.includes('page not found') || pageText.includes('this page doesn') || pageText.includes('profile not found') || pageText.length < 100;

            if (isErrorPage || !hasName) {
              console.log(`[LinkedIn Verify] ✗ Profile mismatch or not found for ${contact.first_name} ${contact.last_name} — discarding`);
              linkedinUrl = null;
            } else {
              console.log(`[LinkedIn Verify] ✓ Confirmed profile for ${contact.first_name} ${contact.last_name}`);
            }
          }
        } catch (e) {
          console.log(`[LinkedIn Verify] Error checking URL, discarding:`, e);
          linkedinUrl = null;
        }
      }
      
      const safeCompanyId = String(companyId).trim();
      
      let notes = contact.reasoning || '';
      if (discoverySource === 'apollo-people-search') notes += ' | Verified via Apollo People Search.';
      if (discoveredEmail) notes += ` | Email: ${discoveredEmail}`;
      if (linkedinUrl) notes += ' | LinkedIn profile verified.';
      else notes += ' | LinkedIn profile not found.';
      
      const insertPayload = {
        name,
        title: contact.title || null,
        linkedin_url: linkedinUrl,
        email: discoveredEmail,
        phone: null,
        company_id: safeCompanyId,
        source: discoverySource === 'apollo-people-search' ? 'apollo' : 'ai-research',
        notes: notes.trim(),
        contacted: false,
        created_by: userId,
      };
      
      console.log(`[STAKEHOLDER INSERT] company_id="${safeCompanyId}" linkedin="${linkedinUrl || 'NONE'}" payload:`, JSON.stringify(insertPayload));
      
      const { data: insertedData, error: insertError } = await supabaseClient
        .from('stakeholders')
        .insert(insertPayload)
        .select('id, company_id, name, linkedin_url');

      if (insertError || !insertedData?.[0]) {
        console.error(`[STAKEHOLDER INSERT FAILED] ${name}:`, JSON.stringify(insertError));
        return null;
      }

      const linkedinStatus = insertedData[0].linkedin_url ? '✓ LinkedIn' : '✗ No LinkedIn';
      console.log(`[STAKEHOLDER CREATED] ${name} (${contact.title}) | id=${insertedData[0].id} | ${linkedinStatus}`);
      
      if (!insertedData[0].company_id) {
        console.error(`[WARNING] Stakeholder ${name} created but company_id is NULL despite passing "${safeCompanyId}"`);
      }

      return { insertedData: insertedData[0], contact, discoveredEmail };
    });

    const insertResults = await Promise.allSettled(insertPromises);

    // Step 2: Trigger Apollo enrichment for ALL inserted stakeholders IN PARALLEL
    const enrichPromises: Promise<void>[] = [];
    const createdStakeholders: Array<{ id: string; name: string; contact: typeof potentialContacts[0] }> = [];

    for (const result of insertResults) {
      if (result.status === 'fulfilled' && result.value) {
        stakeholdersCreated++;
        createdStakeholders.push({
          id: result.value.insertedData.id,
          name: result.value.insertedData.name,
          contact: result.value.contact,
        });
      }
    }

    // Only trigger enrichment for contacts that DON'T already have verified emails (Apollo contacts often do)
    const needsEnrichment = createdStakeholders.filter(sh => !sh.contact.email);
    if (APOLLO_API_KEY && needsEnrichment.length > 0) {
      console.log(`[ENRICH] Triggering enrichment for ${needsEnrichment.length}/${createdStakeholders.length} stakeholders (${createdStakeholders.length - needsEnrichment.length} already have emails from Apollo)...`);
      
      for (const sh of needsEnrichment) {
        const enrichPromise = (async () => {
          try {
            const aiEmail = sh.contact.email || null;
            console.log(`[APOLLO ENRICH] Enriching ${sh.name}${aiEmail ? ` (AI found email: ${aiEmail}, verifying...)` : ''}...`);
            
            const enrichResponse = await fetch(
              `${supabaseUrl}/functions/v1/enrich-contact-bettercontact`,
              {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${serviceRoleKey}`,
                },
                body: JSON.stringify({
                  stakeholder_id: sh.id,
                  first_name: sh.contact.first_name,
                  last_name: sh.contact.last_name,
                  company_name: companyName,
                  company_domain: domain,
                  linkedin_url: sh.contact.linkedin_url || null,
                  title: sh.contact.title || null,
                }),
              }
            );

            if (enrichResponse.ok) {
              const enrichResult = await enrichResponse.json();
              if (enrichResult.email) {
                console.log(`[APOLLO ENRICH] ${sh.name}: ✓ Apollo verified email: ${enrichResult.email} (status: ${enrichResult.email_status || 'unknown'})`);
              } else {
                // Only remove if no LinkedIn either — a stakeholder with LinkedIn is still contactable
                const hasLinkedIn = !!sh.contact.linkedin_url;
                if (hasLinkedIn) {
                  console.log(`[APOLLO ENRICH] ${sh.name}: ✗ No verified email found, but keeping record (has LinkedIn)`);
                } else {
                  console.log(`[APOLLO ENRICH] ${sh.name}: ✗ No verified email and no LinkedIn — removing stakeholder record`);
                  const { error: deleteError } = await supabaseClient.from('stakeholders').delete().eq('id', sh.id);
                  if (deleteError) {
                    console.error(`[APOLLO ENRICH] ${sh.name}: Failed to delete record:`, deleteError);
                  } else {
                    stakeholdersCreated--;
                    console.log(`[APOLLO ENRICH] ${sh.name}: Record deleted successfully`);
                  }
                }
              }
            } else {
              console.log(`[APOLLO ENRICH] ${sh.name}: Failed (${enrichResponse.status})`);
            }
          } catch (enrichError) {
            console.log(`[APOLLO ENRICH] ${sh.name}: Error -`, enrichError);
          }
        })();

        enrichPromises.push(enrichPromise);
      }

      await Promise.allSettled(enrichPromises);
    }

    // ── Build company_email_intel cache from discovered emails ──
    if (companyId && domain) {
      try {
        const { data: emailStakeholders } = await supabaseClient
          .from('stakeholders')
          .select('email, name')
          .eq('company_id', companyId)
          .not('email', 'is', null);

        if (emailStakeholders && emailStakeholders.length >= 1) {
          // Extract pattern from emails matching this domain
          const domainEmails = emailStakeholders
            .filter(s => s.email?.endsWith(`@${domain}`))
            .map(s => ({ email: s.email!, name: s.name }));

          if (domainEmails.length > 0) {
            // Detect pattern from first email
            const firstEmail = domainEmails[0];
            const localPart = firstEmail.email.split('@')[0];
            const nameParts = firstEmail.name.toLowerCase().split(/\s+/);
            let pattern: string | null = null;

            if (nameParts.length >= 2) {
              const [first, last] = [nameParts[0], nameParts[nameParts.length - 1]];
              if (localPart === `${first}.${last}`) pattern = '{first}.{last}';
              else if (localPart === `${first[0]}.${last}`) pattern = '{f}.{last}';
              else if (localPart === `${first[0]}${last}`) pattern = '{f}{last}';
              else if (localPart === `${first}${last[0]}`) pattern = '{first}{l}';
              else if (localPart === `${first}`) pattern = '{first}';
              else if (localPart === `${last}`) pattern = '{last}';
              else if (localPart === `${first}_${last}`) pattern = '{first}_{last}';
              else if (localPart === `${first}-${last}`) pattern = '{first}-{last}';
            }

            const confidence = domainEmails.length >= 3 ? 0.9 : domainEmails.length >= 2 ? 0.7 : 0.5;

            const intel = {
              company_id: companyId,
              domain: domain,
              pattern: pattern,
              pattern_confidence: confidence,
              examples: domainEmails.slice(0, 5).map(e => ({ email: e.email, name: e.name })),
              sources: [{ source: 'enrich-stakeholders', count: domainEmails.length }],
            };

            await supabaseClient.from('company_email_intel').upsert(intel, { onConflict: 'company_id' });
            console.log(`[Cache] ✓ Built email intel for company ${companyId}: pattern=${pattern}, confidence=${confidence}, examples=${domainEmails.length}`);
          }
        }
      } catch (cacheErr) {
        console.warn('[Cache] Failed to build email intel:', cacheErr);
      }
    }

    // Update company enrichment status
    await supabaseClient
      .from('companies')
      .update({
        enrichment_status: stakeholdersCreated > 0 ? 'enriched' : 'pending',
        enriched_at: stakeholdersCreated > 0 ? new Date().toISOString() : null,
        enrichment_source: discoverySource,
      })
      .eq('id', companyId);

    console.log(`Stakeholder discovery complete: ${stakeholdersCreated} created for ${companyName} via ${discoverySource}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        stakeholdersCreated,
        source: discoverySource,
        message: stakeholdersCreated > 0 
          ? `Found ${stakeholdersCreated} decision maker(s) via ${discoverySource}` 
          : 'No decision makers could be identified'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in enrich-stakeholders function:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to enrich stakeholders' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Default prompt if not found in database
function getDefaultStakeholderPrompt(): string {
  return `Analyze this company to identify the 2 best decision-makers to contact regarding the job role.

COMPANY INFORMATION:
- Name: {{company_name}}
- Domain: {{company_domain}}
- Employee Count: {{employee_count}}
- Industry: {{industry}}
- LinkedIn URL: {{linkedin_url}}

JOB CONTEXT:
- Job Title: {{job_title}}
- Job Description: {{job_description}}

ANALYSIS CRITERIA:
1. Company Size Assessment:
   - Small (1-50 employees): Target Owner, CEO, Founder, or direct department head
   - Medium (51-200 employees): Target HR Manager, Department Director, or VP
   - Large (200+ employees): Target Talent Acquisition Manager, HR Director, or Recruiting Lead

2. Role Relevance:
   - Consider who would be the hiring manager for this specific role
   - Technical roles: May need Engineering Manager or CTO alongside HR
   - Sales roles: Sales Director or VP Sales alongside HR
   - General roles: HR Director or People Operations

3. Decision-Making Authority:
   - Prioritize those with hiring authority for the specific role
   - Consider budget holders and final decision makers

Return JSON array of exactly 2 contacts with format:
[
  {
    "first_name": "likely first name or common name for title",
    "last_name": "likely last name based on research",
    "title": "Job Title",
    "reasoning": "Why this person is ideal to contact"
  }
]

If company is very small (<10 employees), only return 1 contact (the founder/CEO).
Only return valid JSON array, no other text.`;
}
