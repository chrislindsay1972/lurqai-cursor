import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface RequestBody {
  candidateName: string;
  candidateTitle: string | null;
  candidateEmail: string | null;
  goal: string;
  dayOffsets: number[];
  voice: string;
  languageStyle: string;
  toneChips: string[];
  primaryCta: string;
  secondaryCta: string;
  neverMentionSalary: boolean;
  respectOptOut: boolean;
  linkedinBrevity: boolean;
  singleStepIndex?: number;
}

const GOAL_DESCRIPTIONS: Record<string, string> = {
  prospect_candidate: "Introduce a strong candidate to a stakeholder/hiring manager and generate interest in meeting or hiring them",
  warm_intro: "Make a warm introduction of the candidate and schedule a call to discuss them",
  role_pitch: "Pitch a specific candidate for a role the stakeholder's company is hiring for",
  relationship_build: "Build an ongoing relationship with the stakeholder by staying top-of-mind with relevant candidate talent",
  custom: "General engagement with stakeholders about candidate talent",
};

const INTENT_SEQUENCE = [
  "intro",
  "nudge",
  "value_add",
  "social_proof",
  "check_in",
  "follow_up",
  "soft_close",
];

const FALLBACK_SYSTEM_PROMPT = `You are an expert recruitment copywriter. You are writing an email sequence FROM a recruitment consultant TO a stakeholder (hiring manager / decision-maker) ABOUT a candidate.

The RECIPIENT of these emails is a stakeholder. The SUBJECT being discussed is a candidate.

Candidate context (for YOUR reference only — do NOT reveal the candidate's name to the recipient):
- Title: {{candidate_current_title}}

CRITICAL RULE: NEVER mention the candidate's name in any email. Instead, refer to them generically as "a strong candidate", "an experienced professional", "a talented {{candidate_current_title}}", etc. The candidate's identity must remain confidential until the stakeholder expresses interest.

Rules:
- Voice: {{voice}}
- Language style: {{language_style}} English spelling and phrasing
- Tone: {{tone_chips}}
- Primary CTA: "{{primary_cta}}"
- Secondary CTA: "{{secondary_cta}}"
{{#never_mention_salary}}- NEVER mention salary, compensation, or pay{{/never_mention_salary}}
{{#linkedin_brevity}}- Keep emails very short, like LinkedIn DMs — 3-5 sentences max{{/linkedin_brevity}}
{{^linkedin_brevity}}- Keep emails concise but professional — 4-8 sentences{{/linkedin_brevity}}
- Address the stakeholder using {{stakeholder_first_name}} or {{stakeholder_name}}
- NEVER use {{candidate_name}} or {{candidate_first_name}} — the candidate's name must stay confidential
- You may use {{candidate_current_title}} to describe the candidate's role/seniority
- Use {{consultant_name}} for the sender's name
- Use {{stakeholder_company}} for the stakeholder's company name
- Do NOT fabricate specific job details, salary figures, or company-specific facts
- Each email must have ONE clear primary call-to-action
- Write the body as PLAIN TEXT only — no HTML tags. Use blank lines to separate paragraphs.
- The emails should position the candidate as a strong talent the stakeholder should consider, without revealing their identity`;

function buildSystemPrompt(template: string, params: Record<string, string>): string {
  let result = template;
  for (const [key, value] of Object.entries(params)) {
    result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value);
  }
  result = result.replace(/\{\{#(\w+)\}\}([\s\S]*?)\{\{\/\1\}\}/g, (_, key, content) => {
    return params[key] && params[key] !== 'false' ? content : '';
  });
  result = result.replace(/\{\{\^(\w+)\}\}([\s\S]*?)\{\{\/\1\}\}/g, (_, key, content) => {
    return !params[key] || params[key] === 'false' ? content : '';
  });
  result = result.replace(/\n{3,}/g, '\n\n');
  return result.trim();
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body: RequestBody = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAdmin = createClient(supabaseUrl, supabaseKey);

    const {
      candidateName,
      candidateTitle,
      goal,
      dayOffsets,
      voice,
      languageStyle,
      toneChips,
      primaryCta,
      secondaryCta,
      neverMentionSalary,
      respectOptOut,
      linkedinBrevity,
    } = body;

    const candidateFirstName = candidateName.split(" ")[0];
    const goalDesc = GOAL_DESCRIPTIONS[goal] || GOAL_DESCRIPTIONS.custom;

    const stepsToGenerate = dayOffsets.map((dayOffset, i) => {
      const intent = INTENT_SEQUENCE[i % INTENT_SEQUENCE.length];
      if (i === dayOffsets.length - 1 && dayOffsets.length > 1) {
        return { dayOffset, intent: "soft_close" };
      }
      return { dayOffset, intent };
    });

    // Fetch configurable prompt from ai_instructions
    let promptTemplate = FALLBACK_SYSTEM_PROMPT;
    try {
      const { data } = await supabaseAdmin
        .from("ai_instructions")
        .select("instruction_prompt")
        .eq("instruction_key", "engagement_email_generation")
        .single();
      if (data?.instruction_prompt) {
        promptTemplate = data.instruction_prompt;
      }
    } catch (e) {
      console.log("Using fallback prompt – ai_instructions lookup failed:", e);
    }

    const systemPrompt = buildSystemPrompt(promptTemplate, {
      candidate_current_title: candidateTitle || "professional",
      voice,
      language_style: languageStyle,
      tone_chips: toneChips.join(", "),
      primary_cta: primaryCta,
      secondary_cta: secondaryCta || "",
      never_mention_salary: neverMentionSalary ? "true" : "false",
      respect_opt_out: respectOptOut ? "true" : "false",
      linkedin_brevity: linkedinBrevity ? "true" : "false",
    });

    const userPrompt = `Generate ${stepsToGenerate.length} email(s) for a ${dayOffsets[dayOffsets.length - 1]}-day prospect campaign.

These emails are sent TO stakeholders (hiring managers) ABOUT a candidate (${candidateTitle || "role unspecified"}). Do NOT reveal the candidate's name.

Goal: ${goalDesc}

Steps to generate:
${stepsToGenerate.map((s) => `- Day ${s.dayOffset}: Intent = "${s.intent}"`).join("\n")}

IMPORTANT: For each step, generate THREE body text variants tailored to different stakeholder roles:
1. "bodyText" — the GENERAL version for any manager or decision-maker
2. "bodyText_csuite" — tailored for C-suite executives (CEO, CTO, CFO, COO, MD, Managing Director, Founder). Focus on strategic value, business impact, competitive advantage, and leadership-level language. Keep it high-level and outcome-oriented.
3. "bodyText_hr" — tailored for HR/Talent professionals (VP Talent, Head of People, HR Director, Talent Acquisition, Recruiter). Focus on candidate quality, cultural fit, hiring pipeline efficiency, and recruitment-specific language.

All three variants must use the same subject line and keep the same intent, but the WORDING and ANGLE should be different to resonate with each audience.

Return a JSON object with a "steps" array. Each step must have:
- dayOffset (number)
- intent (string)
- subject (string — the email subject line, same for all variants)
- bodyText (string — general version, plain text, no HTML)
- bodyText_csuite (string — C-suite version, plain text, no HTML)
- bodyText_hr (string — HR/Talent version, plain text, no HTML)
- status: "planned"`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "generate_email_steps",
              description: "Generate email steps with role-based variants for the prospect campaign",
              parameters: {
                type: "object",
                properties: {
                  steps: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        dayOffset: { type: "number" },
                        intent: { type: "string" },
                        subject: { type: "string" },
                        bodyText: { type: "string", description: "General version for any manager" },
                        bodyText_csuite: { type: "string", description: "Version tailored for C-suite executives" },
                        bodyText_hr: { type: "string", description: "Version tailored for HR/Talent professionals" },
                        status: { type: "string", enum: ["planned"] },
                      },
                      required: ["dayOffset", "intent", "subject", "bodyText", "bodyText_csuite", "bodyText_hr", "status"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["steps"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "generate_email_steps" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits required. Please add funds." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const aiResponse = await response.json();
    const toolCall = aiResponse.choices?.[0]?.message?.tool_calls?.[0];

    if (!toolCall?.function?.arguments) {
      throw new Error("No tool call response from AI");
    }

    const result = JSON.parse(toolCall.function.arguments);

    // Transform the flat structure into nested roleVariants for the frontend
    if (result.steps) {
      result.steps = result.steps.map((step: any) => ({
        dayOffset: step.dayOffset,
        intent: step.intent,
        subject: step.subject,
        bodyText: step.bodyText,
        status: step.status,
        roleVariants: {
          c_suite: step.bodyText_csuite || step.bodyText,
          hr_talent: step.bodyText_hr || step.bodyText,
        },
      }));
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("generate-engagement-emails error:", err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
