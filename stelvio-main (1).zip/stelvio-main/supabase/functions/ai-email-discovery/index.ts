const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface DiscoveryRequest {
  type: "analyze_patterns" | "generate_queries" | "predict_email";
  data: {
    firstName?: string;
    lastName?: string;
    companyName?: string;
    domain?: string;
    jobTitle?: string;
    scrapedContent?: string;
    linkedInTitle?: string;
    linkedInDescription?: string;
    existingEmails?: string[];
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { type, data }: DiscoveryRequest = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY not configured");
      return new Response(
        JSON.stringify({ success: false, error: "AI service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let systemPrompt = "";
    let userPrompt = "";
    let tools: any[] = [];
    let toolChoice: any = undefined;

    if (type === "analyze_patterns") {
      systemPrompt = `You are an expert at analyzing email patterns from scraped website content. Your job is to:
1. Find any email addresses in the provided content
2. Identify the naming pattern used (e.g., first.last, firstlast, flast, first_last, etc.)
3. Assess confidence in the detected pattern
Be precise and analytical. Only report emails that are clearly visible in the content.`;

      userPrompt = `Analyze this content for email patterns for the company domain "${data.domain}":

Content:
${data.scrapedContent?.substring(0, 4000) || "No content provided"}

${data.linkedInTitle ? `LinkedIn Title: ${data.linkedInTitle}` : ""}
${data.linkedInDescription ? `LinkedIn Description: ${data.linkedInDescription}` : ""}

Find all email addresses, identify the naming pattern, and assess confidence.`;

      tools = [{
        type: "function",
        function: {
          name: "report_pattern_analysis",
          description: "Report the email pattern analysis results",
          parameters: {
            type: "object",
            properties: {
              detectedPattern: { 
                type: "string", 
                enum: ["first.last", "firstlast", "flast", "first_last", "last.first", "lastf", "first", "last", "unknown"],
                description: "The detected email naming pattern"
              },
              confidence: { type: "number", description: "Confidence score 0-100" },
              emails: { type: "array", items: { type: "string" }, description: "All email addresses found" },
              reasoning: { type: "string", description: "Brief explanation" }
            },
            required: ["detectedPattern", "confidence", "emails", "reasoning"],
            additionalProperties: false
          }
        }
      }];
      toolChoice = { type: "function", function: { name: "report_pattern_analysis" } };

    } else if (type === "generate_queries") {
      systemPrompt = `You are an expert at finding professional email addresses through web search. Generate highly effective search queries to find someone's email address.`;

      userPrompt = `Generate search queries to find the email address for:

Name: ${data.firstName || "Unknown"} ${data.lastName || "Unknown"}
Company: ${data.companyName || "Unknown"}
Domain: ${data.domain || "Unknown"}
Job Title: ${data.jobTitle || "Unknown"}

Generate 3-5 targeted search queries.`;

      tools = [{
        type: "function",
        function: {
          name: "suggest_queries",
          description: "Suggest search queries to find email addresses",
          parameters: {
            type: "object",
            properties: {
              queries: { type: "array", items: { type: "string" }, description: "List of search queries" },
              reasoning: { type: "string", description: "Brief explanation" }
            },
            required: ["queries", "reasoning"],
            additionalProperties: false
          }
        }
      }];
      toolChoice = { type: "function", function: { name: "suggest_queries" } };

    } else if (type === "predict_email") {
      systemPrompt = `You are an expert at predicting professional email addresses based on company naming conventions and industry patterns.`;

      userPrompt = `Predict the most likely email address for:

Name: ${data.firstName || "Unknown"} ${data.lastName || "Unknown"}
Company: ${data.companyName || "Unknown"}
Domain: ${data.domain || "Unknown"}
Job Title: ${data.jobTitle || "Unknown"}

${data.existingEmails && data.existingEmails.length > 0 ? 
  `Existing emails found at this company: ${data.existingEmails.join(", ")}` : 
  "No existing emails found for reference."}

Predict the top 3 most likely email formats.`;

      tools = [{
        type: "function",
        function: {
          name: "predict_emails",
          description: "Predict the most likely email addresses",
          parameters: {
            type: "object",
            properties: {
              predictions: { 
                type: "array", 
                items: {
                  type: "object",
                  properties: {
                    email: { type: "string" },
                    confidence: { type: "number" },
                    reasoning: { type: "string" }
                  },
                  required: ["email", "confidence", "reasoning"],
                  additionalProperties: false
                }
              }
            },
            required: ["predictions"],
            additionalProperties: false
          }
        }
      }];
      toolChoice = { type: "function", function: { name: "predict_emails" } };
    } else {
      return new Response(
        JSON.stringify({ success: false, error: "Invalid type parameter" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`AI Email Discovery: ${type} for ${data.firstName} ${data.lastName} @ ${data.domain}`);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools,
        tool_choice: toolChoice,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ success: false, error: "Rate limit exceeded" }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ success: false, error: "AI service error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiResponse = await response.json();
    const toolCall = aiResponse.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      return new Response(
        JSON.stringify({ success: false, error: "AI did not return structured data" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let result;
    try {
      result = JSON.parse(toolCall.function.arguments);
    } catch (e) {
      return new Response(
        JSON.stringify({ success: false, error: "Failed to parse AI response" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`AI ${type} result:`, JSON.stringify(result).substring(0, 200));

    return new Response(
      JSON.stringify({ success: true, type, result }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("AI Email Discovery error:", error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
