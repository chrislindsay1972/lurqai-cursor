const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface LeadInput {
  firstName: string;
  lastName: string;
  fullName: string;
  jobTitle: string;
  companyName: string;
  location?: string;
  linkedinUrl?: string;
  companyWebsite?: string;
  /** If the company already has a resolved domain, pass it here to enforce it for email construction */
  resolvedDomain?: string;
}

type DomainClassification = 
  | "official_candidate" 
  | "third_party_directory" 
  | "social_platform" 
  | "authoritative_registry" 
  | "blocked_or_botwall";

interface WebsiteCandidate {
  url: string;
  domain: string;
  classification: DomainClassification;
  accepted: boolean;
  rejectionReason: string;
  score: number;
}

interface PhoneCandidate {
  phone: string;
  sourceUrl: string;
  sourceDomain: string;
  accepted: boolean;
  reason: string;
}

interface DomainCandidate {
  domain: string;
  sourceUrl: string;
  sourceType: "official_site_email" | "official_pdf_email" | "third_party" | "registry" | "inferred_from_website";
  mxValid: boolean;
  accepted: boolean;
  reason: string;
}

interface DebugInfo {
  websiteCandidates: WebsiteCandidate[];
  phoneCandidates: PhoneCandidate[];
  domainCandidates: DomainCandidate[];
  callCounts: {
    firecrawlSearch: number;
    firecrawlScrape: number;
    firecrawlCrawl: number;
    firecrawlMap: number;
    mxLookups: number;
    verifierCalls: number;
  };
}

interface DiscoveryResult {
  resolvedCompanyWebsite: string | null;
  resolvedCompanyDomain: string | null;
  emailDomainsFound: string[];
  selectedEmailDomain: string | null;
  domainMxValid: boolean;
  domainStatus: "verified" | "candidate" | "not_found" | "not_email_enabled";
  officePhone: string | null;
  phoneStatus: "verified" | "candidate" | "not_found";
  phoneEvidenceUrl: string | null;
  explicitEmailFound: boolean;
  foundEmail: string | null;
  foundEmailEvidenceUrl: string | null;
  emailPattern: string | null;
  patternStatus: "verified" | "not_determined";
  patternEvidenceCount: number;
  patternExamples: string[];
  candidateEmail: string | null;
  candidateEmailStatus: "verified_person_email" | "inferred" | "not_found" | "ambiguous";
  verification: {
    attempted: boolean;
    result: "deliverable" | "undeliverable" | "risky" | "unknown" | "not_checked";
    isCatchAll: boolean | null;
    provider: string | null;
  };
  confidenceScore: number;
  confidenceReason: string;
  sources: string[];
  searchedQueries: string[];
  blockedSources: string[];
  notes: string;
  debug: DebugInfo;
  // Resolved name when input surname was incomplete (e.g., "N." -> "Nazir")
  resolvedFullName: string | null;
  resolvedLastName: string | null;
}

const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY");

// ========================================
// DOMAIN CLASSIFICATION
// ========================================

const THIRD_PARTY_DENYLIST = new Set([
  "zoominfo.com", "apollo.io", "rocketreach.co", "theorg.com", "signalhire.com",
  "lusha.com", "adapt.io", "lead411.com", "dnb.com", "crunchbase.com",
  "pitchbook.com", "owler.com", "glassdoor.com", "indeed.com", "yelp.com",
  "yell.com", "192.com", "thomasnet.com", "manta.com", "yellowpages.com",
  "trustpilot.com", "bbb.org", "g2.com", "capterra.com",
  // Company/business data directories
  "endole.co.uk", "duedil.com", "companiesintheuk.co.uk", "companycheck.co.uk",
  "checkacompany.co.uk", "bizdb.co.uk", "findthecompany.co.uk", "ukcompany.org"
]);

const SOCIAL_DENYLIST = new Set([
  "linkedin.com", "facebook.com", "instagram.com", "x.com", "twitter.com",
  "youtube.com", "tiktok.com", "pinterest.com", "threads.net"
]);

const AUTHORITATIVE_REGISTRY = new Set([
  "companieshouse.gov.uk", "gov.uk", "sec.gov", "opencorporates.com"
]);

function getHostname(url: string): string | null {
  try {
    return new URL(url.startsWith("http") ? url : `https://${url}`).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

function classifyDomain(domain: string): { classification: DomainClassification; reason: string } {
  if (!domain) return { classification: "blocked_or_botwall", reason: "Invalid domain" };
  
  const lowerDomain = domain.toLowerCase();
  
  for (const denied of THIRD_PARTY_DENYLIST) {
    if (lowerDomain === denied || lowerDomain.endsWith(`.${denied}`)) {
      return { classification: "third_party_directory", reason: `Known third-party directory (${denied})` };
    }
  }
  
  for (const social of SOCIAL_DENYLIST) {
    if (lowerDomain === social || lowerDomain.endsWith(`.${social}`)) {
      return { classification: "social_platform", reason: `Social platform (${social})` };
    }
  }
  
  for (const registry of AUTHORITATIVE_REGISTRY) {
    if (lowerDomain === registry || lowerDomain.endsWith(`.${registry}`)) {
      return { classification: "authoritative_registry", reason: `Registry (${registry})` };
    }
  }
  
  return { classification: "official_candidate", reason: "" };
}

const ROLE_PREFIXES = [
  "info", "hello", "sales", "support", "contact", "admin", "help", "team",
  "hr", "careers", "jobs", "press", "media", "marketing", "office", "enquiries",
  "enquiry", "noreply", "no-reply", "newsletter", "notifications", "accounts"
];

const BOT_BLOCK_PHRASES = [
  "pardon our interruption", "please verify you are human", "checking your browser before",
  "ray id:", "cf-browser-verification", "why do i have to complete a captcha"
];

function isBlockedContent(content: string): boolean {
  if (!content || content.length < 100) return true;
  const lower = content.toLowerCase();
  if (BOT_BLOCK_PHRASES.some(phrase => lower.includes(phrase))) return true;
  if (content.length < 500 && (lower.includes("javascript") || lower.includes("enable"))) return true;
  return false;
}

function createCallCounter() {
  return { firecrawlSearch: 0, firecrawlScrape: 0, firecrawlCrawl: 0, firecrawlMap: 0, mxLookups: 0, verifierCalls: 0 };
}

async function firecrawlMap(url: string, callCounts: DebugInfo["callCounts"], search?: string): Promise<string[]> {
  if (!FIRECRAWL_API_KEY) return [];
  callCounts.firecrawlMap++;
  
  try {
    const response = await fetch("https://api.firecrawl.dev/v1/map", {
      method: "POST",
      headers: { "Authorization": `Bearer ${FIRECRAWL_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ 
        url, 
        search, // Filter URLs by keyword
        limit: 100, // Get up to 100 URLs
        includeSubdomains: false 
      }),
    });
    if (!response.ok) return [];
    const data = await response.json();
    return data.links || data.data?.links || [];
  } catch (e) {
    console.error("Firecrawl map error:", e);
    return [];
  }
}

async function firecrawlSearch(query: string, callCounts: DebugInfo["callCounts"], limit = 5): Promise<any[]> {
  if (!FIRECRAWL_API_KEY) return [];
  callCounts.firecrawlSearch++;
  
  try {
    const response = await fetch("https://api.firecrawl.dev/v1/search", {
      method: "POST",
      headers: { "Authorization": `Bearer ${FIRECRAWL_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ query, limit }),
    });
    if (!response.ok) return [];
    const data = await response.json();
    return data.data || [];
  } catch (e) {
    console.error("Firecrawl search error:", e);
    return [];
  }
}

async function firecrawlScrape(url: string, callCounts: DebugInfo["callCounts"]): Promise<{ content: string | null; html: string | null; blocked: boolean }> {
  if (!FIRECRAWL_API_KEY) return { content: null, html: null, blocked: false };
  callCounts.firecrawlScrape++;
  
  try {
    const response = await fetch("https://api.firecrawl.dev/v1/scrape", {
      method: "POST",
      headers: { "Authorization": `Bearer ${FIRECRAWL_API_KEY}`, "Content-Type": "application/json" },
      // Request both markdown and HTML to find anti-spam encoded emails
      body: JSON.stringify({ url, formats: ["markdown", "html"], onlyMainContent: false }),
    });
    if (!response.ok) return { content: null, html: null, blocked: response.status === 403 };
    const data = await response.json();
    const content = data.data?.markdown || data.markdown || null;
    const html = data.data?.html || data.html || null;
    if (content && isBlockedContent(content)) return { content: null, html: null, blocked: true };
    return { content, html, blocked: false };
  } catch (e) {
    console.error("Firecrawl scrape error:", e);
    return { content: null, html: null, blocked: false };
  }
}

async function checkMxRecords(domain: string, callCounts: DebugInfo["callCounts"]): Promise<{ valid: boolean; hosts: string[] }> {
  callCounts.mxLookups++;
  try {
    const response = await fetch(`https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=MX`);
    if (!response.ok) return { valid: false, hosts: [] };
    const data = await response.json();
    if (data.Status !== 0) return { valid: false, hosts: [] };
    const answers = Array.isArray(data.Answer) ? data.Answer : [];
    const mxRecords = answers.filter((a: { type: number }) => a.type === 15);
    const hosts = mxRecords.map((record: { data: string }) => {
      const parts = record.data?.split(" ");
      return parts && parts.length >= 2 ? parts.slice(1).join(" ").replace(/\.$/, "") : record.data?.replace(/\.$/, "");
    }).filter(Boolean);
    return { valid: hosts.length > 0, hosts };
  } catch (e) {
    return { valid: false, hosts: [] };
  }
}

// Decode Cloudflare email protection (data-cfemail attribute)
function decodeCloudflareEmail(encoded: string): string | null {
  try {
    const r = parseInt(encoded.substr(0, 2), 16);
    let email = "";
    for (let i = 2; i < encoded.length; i += 2) {
      email += String.fromCharCode(parseInt(encoded.substr(i, 2), 16) ^ r);
    }
    return email.includes("@") ? email : null;
  } catch {
    return null;
  }
}

// Extract emails from HTML anti-spam patterns
function extractEmailsFromHtml(html: string, filterDomain?: string): string[] {
  const emails: string[] = [];
  
  // 1. Cloudflare email protection: data-cfemail="encoded"
  const cfEmailRegex = /data-cfemail="([a-f0-9]+)"/gi;
  let match;
  while ((match = cfEmailRegex.exec(html)) !== null) {
    const decoded = decodeCloudflareEmail(match[1]);
    if (decoded) {
      console.log(`  Decoded Cloudflare email: ${decoded}`);
      emails.push(decoded);
    }
  }
  
  // 2. data-email, data-mailto, data-mail attributes
  const dataEmailRegex = /data-(?:email|mailto|mail)=["']([^"']+)["']/gi;
  while ((match = dataEmailRegex.exec(html)) !== null) {
    const value = match[1];
    // Could be plain email or base64 encoded
    if (value.includes("@")) {
      emails.push(value);
    } else {
      // Try base64 decode
      try {
        const decoded = atob(value);
        if (decoded.includes("@")) {
          console.log(`  Decoded base64 email: ${decoded}`);
          emails.push(decoded);
        }
      } catch { /* not base64 */ }
    }
  }
  
  // 3. href="mailto:" with encoded characters
  const mailtoRegex = /href=["']mailto:([^"'?\s]+)/gi;
  while ((match = mailtoRegex.exec(html)) !== null) {
    try {
      const decoded = decodeURIComponent(match[1]);
      if (decoded.includes("@")) {
        emails.push(decoded);
      }
    } catch {
      if (match[1].includes("@")) {
        emails.push(match[1]);
      }
    }
  }
  
  // 4. onclick handlers with email (common anti-spam pattern)
  // e.g., onclick="location.href='mailto:' + 'john' + '@' + 'domain.com'"
  const onclickEmailRegex = /['"]mailto:\s*['"]\s*\+\s*['"]([^'"]+)['"]\s*\+\s*['"]@['"]\s*\+\s*['"]([^'"]+)['"]/gi;
  while ((match = onclickEmailRegex.exec(html)) !== null) {
    const email = `${match[1]}@${match[2]}`;
    console.log(`  Decoded onclick email: ${email}`);
    emails.push(email);
  }
  
  // 5. JavaScript string concatenation patterns
  // e.g., var email = "john" + "@" + "domain.com"
  const jsEmailRegex = /["']([a-z0-9._%+-]+)["']\s*\+\s*["']@["']\s*\+\s*["']([a-z0-9.-]+\.[a-z]{2,})["']/gi;
  while ((match = jsEmailRegex.exec(html)) !== null) {
    const email = `${match[1]}@${match[2]}`;
    console.log(`  Decoded JS concat email: ${email}`);
    emails.push(email);
  }
  
  // Filter by domain if specified
  return emails.filter(email => {
    const lower = email.toLowerCase();
    const localPart = lower.split("@")[0];
    const isRole = ROLE_PREFIXES.some(role => localPart === role);
    const matchesDomain = filterDomain ? lower.endsWith(`@${filterDomain.toLowerCase()}`) : true;
    return !isRole && matchesDomain;
  });
}

function extractEmails(text: string, filterDomain?: string): string[] {
  // Standard email regex
  const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const standardEmails = text.match(emailRegex) || [];
  
  // Also try to de-obfuscate common patterns:
  // - [at] or (at) or {at} or " at " -> @
  // - [dot] or (dot) or {dot} or " dot " -> .
  // - &#64; or &#x40; -> @
  const deobfuscated = text
    .replace(/\s*[\[\(\{]\s*at\s*[\]\)\}]\s*/gi, "@")
    .replace(/\s+at\s+/gi, "@")
    .replace(/\s*[\[\(\{]\s*dot\s*[\]\)\}]\s*/gi, ".")
    .replace(/\s+dot\s+/gi, ".")
    .replace(/&#64;|&#x40;/gi, "@")
    .replace(/&#46;|&#x2e;/gi, ".");
  
  const deobfuscatedEmails = deobfuscated.match(emailRegex) || [];
  const allEmails = [...new Set([...standardEmails, ...deobfuscatedEmails])];
  
  return allEmails.filter(email => {
    const lower = email.toLowerCase();
    const localPart = lower.split("@")[0];
    const isRole = ROLE_PREFIXES.some(role => localPart === role);
    const matchesDomain = filterDomain ? lower.endsWith(`@${filterDomain.toLowerCase()}`) : true;
    return !isRole && matchesDomain;
  });
}

function extractAllEmailDomains(text: string): string[] {
  const emailRegex = /[a-zA-Z0-9._%+-]+@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g;
  const domains = new Set<string>();
  let match;
  while ((match = emailRegex.exec(text)) !== null) {
    domains.add(match[1].toLowerCase());
  }
  return Array.from(domains);
}

function extractPhones(text: string): string[] {
  const phoneRegex = /(?:\+44|0)[\s.-]?(?:\d[\s.-]?){9,10}|\+1[\s.-]?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/g;
  return text.match(phoneRegex) || [];
}

// ========================================
// NAME RESOLUTION (for incomplete surnames like "N.")
// ========================================

function isIncompleteSurname(lastName: string | undefined | null): boolean {
  if (!lastName) return false;
  // Detect initials like "N.", "A", "S." etc
  const trimmed = lastName.trim();
  return /^[A-Za-z]\.?$/.test(trimmed);
}

function extractFullNameFromContent(
  firstName: string, 
  content: string,
  html?: string
): { resolvedLastName: string | null; resolvedFullName: string | null } {
  if (!content && !html) return { resolvedLastName: null, resolvedFullName: null };
  
  const firstLower = firstName.toLowerCase().replace(/[^a-z]/g, "");
  if (firstLower.length < 2) return { resolvedLastName: null, resolvedFullName: null };
  
  // Search patterns for full name near first name
  // Look for "FirstName LastName" patterns in the text
  const combinedContent = `${content || ""} ${html || ""}`;
  
  // Match "FirstName LastName" where last name is 2+ chars
  // Also handle "First Last" with possible middle initial
  const namePatterns = [
    // FirstName LastName (case insensitive first name)
    new RegExp(`\\b${firstName}\\s+([A-Z][a-z]{2,15})\\b`, "gi"),
    // FirstName M. LastName (with middle initial)
    new RegExp(`\\b${firstName}\\s+[A-Z]\\.?\\s+([A-Z][a-z]{2,15})\\b`, "gi"),
    // In HTML: often names are in headers or bold - look for name patterns
    new RegExp(`(?:>|^|\\n)\\s*${firstName}\\s+([A-Z][a-z]{2,15})(?:<|$|\\n)`, "gi"),
  ];
  
  const candidates: Map<string, number> = new Map();
  
  for (const pattern of namePatterns) {
    let match;
    while ((match = pattern.exec(combinedContent)) !== null) {
      const potentialLast = match[1];
      // Basic validation: not a common word, at least 2 chars
      const lower = potentialLast.toLowerCase();
      const commonWords = new Set([
        "the", "and", "for", "our", "has", "was", "are", "will", "can", 
        "team", "staff", "member", "partner", "director", "manager",
        "senior", "junior", "associate", "assistant", "head", "lead"
      ]);
      
      if (potentialLast.length >= 2 && !commonWords.has(lower)) {
        const count = candidates.get(potentialLast) || 0;
        candidates.set(potentialLast, count + 1);
      }
    }
  }
  
  if (candidates.size === 0) return { resolvedLastName: null, resolvedFullName: null };
  
  // Return most frequent match
  const sorted = [...candidates.entries()].sort((a, b) => b[1] - a[1]);
  const bestMatch = sorted[0][0];
  
  console.log(`  Resolved name: ${firstName} ${bestMatch} (from ${sorted[0][1]} occurrences)`);
  
  return { 
    resolvedLastName: bestMatch, 
    resolvedFullName: `${firstName} ${bestMatch}` 
  };
}

function detectEmailPattern(emails: string[], domain: string): { pattern: string; examples: string[] } | null {
  if (emails.length < 2) return null;
  
  const patterns: Record<string, number> = {
    "first": 0,        // phil@, john@, sarah@ (less common professionally)
    "first.last": 0,   // john.smith@ (MOST COMMON professionally)
    "firstlast": 0,    // johnsmith@
    "f.last": 0,       // j.smith@
    "first.l": 0,      // john.s@
    "flast": 0,        // jsmith@
    "firstl": 0,       // johns@
    "last.first": 0,   // smith.john@
    "lfirst": 0,       // sjohn@
  };
  const examples: string[] = [];
  
  for (const email of emails.slice(0, 15)) {
    const local = email.split("@")[0].toLowerCase();
    examples.push(email);
    
    // Order matters - check most specific patterns first (structured patterns before ambiguous ones)
    if (/^[a-z]+\.[a-z]+$/.test(local)) {
      // Contains a dot - structured pattern
      const parts = local.split(".");
      if (parts[1].length === 1) patterns["first.l"]++;
      else if (parts[0].length === 1) patterns["f.last"]++;
      else patterns["first.last"]++;  // Most professional: first.last
    }
    else if (/^[a-z]+[a-z]+$/.test(local) && local.length > 10) {
      // Long concatenation (>10 chars) - likely firstlast
      patterns["firstlast"]++;
    }
    else if (/^[a-z][a-z]{3,7}$/.test(local)) {
      // Short 4-8 chars like "jsmith" - could be flast pattern
      // Only count if looks like initial+name format
      const firstChar = local[0];
      const rest = local.slice(1);
      // Check if rest could be a last name (3+ chars)
      if (rest.length >= 3) {
        patterns["flast"]++;
      } else {
        // Very short - ambiguous, skip or count as first with low weight
        patterns["first"] += 0.5;
      }
    }
    else if (/^[a-z]{2,8}$/.test(local)) {
      // Single word 2-8 chars - could be first name only
      // But be conservative - this is less common professionally
      patterns["first"] += 0.5;  // Half weight for ambiguous single words
    }
  }
  
  // Log pattern counts for debugging
  const nonZero = Object.entries(patterns).filter(([_, v]) => v > 0);
  if (nonZero.length > 0) {
    console.log(`Pattern counts: ${nonZero.map(([k, v]) => `${k}:${v.toFixed(1)}`).join(", ")}`);
  }
  
  // Sort by count, but prefer structured patterns (with dots) when counts are close
  const sorted = Object.entries(patterns).sort((a, b) => {
    const diff = b[1] - a[1];
    if (Math.abs(diff) < 1.5) {
      // Counts are close - prefer structured patterns
      const structuredPatterns = ["first.last", "f.last", "first.l", "last.first"];
      const aStructured = structuredPatterns.includes(a[0]) ? 1 : 0;
      const bStructured = structuredPatterns.includes(b[0]) ? 1 : 0;
      return bStructured - aStructured;
    }
    return diff;
  });
  
  const bestPattern = sorted[0];
  // Require at least 2 full examples (accounting for half-weights)
  if (bestPattern && bestPattern[1] >= 1.5) {
    console.log(`PATTERN: ${bestPattern[0]} (${Math.floor(bestPattern[1])} examples)`);
    return { pattern: bestPattern[0], examples: examples.slice(0, 5) };
  }
  return null;
}

function generateCandidateEmail(firstName: string, lastName: string, pattern: string, domain: string): string {
  const first = firstName.toLowerCase().replace(/[^a-z]/g, "");
  const last = lastName.toLowerCase().replace(/[^a-z]/g, "");
  
  switch (pattern) {
    case "first": return `${first}@${domain}`;  // NEW: first name only
    case "first.last": return `${first}.${last}@${domain}`;
    case "firstlast": return `${first}${last}@${domain}`;
    case "f.last": return `${first[0]}.${last}@${domain}`;
    case "first.l": return `${first}.${last[0]}@${domain}`;
    case "flast": return `${first[0]}${last}@${domain}`;
    case "firstl": return `${first}${last[0]}@${domain}`;
    case "last.first": return `${last}.${first}@${domain}`;
    case "lfirst": return `${last[0]}${first}@${domain}`;
    default: return `${first}.${last}@${domain}`;
  }
}

// ========================================
// MAIN DISCOVERY FUNCTION - OPTIMIZED v2.3
// ========================================

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const lead: LeadInput = await req.json();
    console.log(`\n========================================`);
    console.log(`Deep discovery v2.3 for: ${lead.fullName} at ${lead.companyName}`);
    console.log(`========================================`);
    
    const callCounts = createCallCounter();
    const debug: DebugInfo = { websiteCandidates: [], phoneCandidates: [], domainCandidates: [], callCounts };
    
    const result: DiscoveryResult = {
      resolvedCompanyWebsite: null, resolvedCompanyDomain: null,
      emailDomainsFound: [], selectedEmailDomain: null, domainMxValid: false, domainStatus: "not_found",
      officePhone: null, phoneStatus: "not_found", phoneEvidenceUrl: null,
      explicitEmailFound: false, foundEmail: null, foundEmailEvidenceUrl: null,
      emailPattern: null, patternStatus: "not_determined", patternEvidenceCount: 0, patternExamples: [],
      candidateEmail: null, candidateEmailStatus: "not_found",
      verification: { attempted: false, result: "not_checked", isCatchAll: null, provider: null },
      confidenceScore: 0, confidenceReason: "",
      sources: [], searchedQueries: [], blockedSources: [], notes: "", debug,
      resolvedFullName: null, resolvedLastName: null,
    };
    
    // Track working name - may be resolved if input has incomplete surname
    let workingFirstName = lead.firstName || "";
    let workingLastName = lead.lastName || "";
    
    const websiteCandidates: WebsiteCandidate[] = [];
    
    // Helper to add website candidate - search results get higher score than inferred
    const addWebsiteCandidate = (url: string, fromSearch: boolean = true) => {
      const domain = getHostname(url);
      if (!domain || websiteCandidates.some(c => c.domain === domain)) return;
      
      const { classification, reason } = classifyDomain(domain);
      const accepted = classification === "official_candidate";
      // Search results score 5, inferred domains score based on match quality (set later)
      const score = accepted ? (fromSearch ? 5 : 1) : 0;
      websiteCandidates.push({ url, domain, classification, accepted, rejectionReason: accepted ? "" : reason, score });
      console.log(`  ${accepted ? "✓" : "✗"} ${domain} [${classification}] (score: ${score})`);
    };
    
    // ========================================
    // STEP 1: Find official website - ENHANCED APPROACH
    // Uses person name + job title to disambiguate same-named companies
    // IMPORTANT: Run job-title search FIRST to get correct industry context
    // ========================================
    console.log("\n--- STEP 1: Find official website ---");
    
    // 1a: User-provided website first (highest priority)
    if (lead.companyWebsite) {
      console.log(`Using provided website: ${lead.companyWebsite}`);
      addWebsiteCandidate(lead.companyWebsite);
    }
    
    // Detect industry from job title BEFORE searching
    let industryHint: string | null = null;
    if (lead.jobTitle) {
      const jobWords = lead.jobTitle.toLowerCase();
      if (jobWords.includes("account") || jobWords.includes("finance") || jobWords.includes("tax") || 
          jobWords.includes("audit") || jobWords.includes("cashier") || jobWords.includes("bookkeeper") ||
          jobWords.includes("payroll") || jobWords.includes("controller")) {
        industryHint = "accountants";
      } else if (jobWords.includes("lawyer") || jobWords.includes("legal") || jobWords.includes("solicitor") || 
                 jobWords.includes("barrister") || jobWords.includes("convey")) {
        industryHint = "solicitors";
      } else if (jobWords.includes("architect") || jobWords.includes("design") || jobWords.includes("plann")) {
        industryHint = "architects";
      } else if (jobWords.includes("estate") || jobWords.includes("property") || jobWords.includes("lettings") ||
                 jobWords.includes("realtor")) {
        industryHint = "estate agents";
      } else if (jobWords.includes("insur") || jobWords.includes("broker")) {
        industryHint = "insurance brokers";
      } else if (jobWords.includes("mort") || jobWords.includes("financ")) {
        industryHint = "financial advisers";
      }
      
      if (industryHint) {
        console.log(`  Detected industry hint from job title: ${industryHint}`);
      }
    }
    
    // 1b: Person + Company search FIRST - this is the most disambiguating
    // "Nicola Edwards" "Dunhams" finds the right Dunhams, not Dunham's Sports
    if (lead.companyName && lead.fullName) {
      const personCompanyQuery = `"${lead.fullName}" "${lead.companyName}"`;
      console.log(`Searching person+company: ${personCompanyQuery}`);
      result.searchedQueries.push(personCompanyQuery);
      
      const results = await firecrawlSearch(personCompanyQuery, callCounts, 8);
      for (const r of results) {
        if (r.url) {
          // Person+company matches get highest score (8) - most reliable disambiguation
          const domain = getHostname(r.url);
          if (domain && !websiteCandidates.some(c => c.domain === domain)) {
            const { classification, reason } = classifyDomain(domain);
            const accepted = classification === "official_candidate";
            const score = accepted ? 8 : 0;
            websiteCandidates.push({ url: r.url, domain, classification, accepted, rejectionReason: accepted ? "" : reason, score });
            console.log(`  ${accepted ? "✓" : "✗"} ${domain} [${classification}] (score: ${score}, person+company match)`);
          }
        }
      }
    }
    
    // 1c: Search with job title industry context (second priority)
    // This finds "Dunhams accountants" instead of "Dunhams sports"
    if (industryHint && lead.companyName && !websiteCandidates.some(c => c.accepted)) {
      const industryQuery = `"${lead.companyName}" ${industryHint} ${lead.location || "UK"}`.trim();
      console.log(`Searching with industry context: ${industryQuery}`);
      result.searchedQueries.push(industryQuery);
      
      const results = await firecrawlSearch(industryQuery, callCounts, 8);
      for (const r of results) {
        if (r.url) {
          // Give industry-matched results a higher score
          const domain = getHostname(r.url);
          if (domain && !websiteCandidates.some(c => c.domain === domain)) {
            const { classification, reason } = classifyDomain(domain);
            const accepted = classification === "official_candidate";
            // Industry-matched search results get score 7
            const score = accepted ? 7 : 0;
            websiteCandidates.push({ url: r.url, domain, classification, accepted, rejectionReason: accepted ? "" : reason, score });
            console.log(`  ${accepted ? "✓" : "✗"} ${domain} [${classification}] (score: ${score}, industry-matched)`);
          }
        }
      }
    }
    
    // 1d: Simple company search (fallback if no person or industry results)
    if (!websiteCandidates.some(c => c.accepted) && lead.companyName) {
      const simpleQuery = `"${lead.companyName}" official website`;
      console.log(`Searching: ${simpleQuery}`);
      result.searchedQueries.push(simpleQuery);
      
      const results = await firecrawlSearch(simpleQuery, callCounts, 8);
      for (const r of results) {
        if (r.url) addWebsiteCandidate(r.url);
      }
    }
    
    // 1e: Location-based search
    if (!websiteCandidates.some(c => c.accepted) && lead.companyName) {
      const locQuery = `"${lead.companyName}" ${lead.location || ""} contact`.trim();
      console.log(`Searching with location: ${locQuery}`);
      result.searchedQueries.push(locQuery);
      
      const results = await firecrawlSearch(locQuery, callCounts, 8);
      for (const r of results) {
        if (r.url) addWebsiteCandidate(r.url);
      }
    }
    
    // 1e: Quick UK TLD check - ALWAYS try brand.co.uk for UK leads even if other candidates found
    // This prevents selecting .com.au when .co.uk exists (e.g. Seftons)
    const locationLowerPre = (lead.location || "").toLowerCase();
    const hasExplicitNonUKPre = locationLowerPre.includes("australia") || locationLowerPre.includes("usa") || 
                                locationLowerPre.includes("canada") || locationLowerPre.includes("india");
    const isUKPre = !hasExplicitNonUKPre; // Default to UK when no explicit non-UK location
    
    if (isUKPre && lead.companyName) {
      const brandSlug = lead.companyName.toLowerCase()
        .replace(/\s+(and|&)\s+(company|co\.?|associates?|partners?)\s*$/i, "")
        .replace(/\s+(ltd|llp|plc|inc|llc|limited)\s*$/i, "")
        .replace(/\s+(chartered|certified|accountants?)\s*$/i, "")
        .split(/\s+/)[0]
        .replace(/[^a-z0-9]/g, "");
      
      if (brandSlug.length >= 4) {
        const ukDomain = `${brandSlug}.co.uk`;
        if (!websiteCandidates.some(c => c.domain === ukDomain)) {
          console.log(`Quick UK TLD check: ${ukDomain}`);
          const mxResult = await checkMxRecords(ukDomain, callCounts);
          if (mxResult.valid) {
            console.log(`  ✓ UK domain valid: ${ukDomain}`);
            websiteCandidates.push({
              url: `https://${ukDomain}`,
              domain: ukDomain,
              classification: "official_candidate",
              accepted: true,
              rejectionReason: "",
              score: 6, // High score - UK TLD match for UK lead
            });
          }
        }
      }
    }
    
    // 1f: Domain inference fallback - try common domain patterns
    if (!websiteCandidates.some(c => c.accepted) && lead.companyName) {
      console.log("Trying domain inference fallback...");
      
      // Generate multiple slug variations
      const base = lead.companyName.toLowerCase();
      const slugs = new Set<string>();
      
      // Remove common suffixes: "and Company", "& Co", "Ltd", "LLP", etc
      const cleaned = base
        .replace(/\s+(and|&)\s+(company|co\.?|associates?|partners?)\s*$/i, "")
        .replace(/\s+(ltd|llp|plc|inc|llc|limited)\s*$/i, "")
        .replace(/\s+(chartered|certified|accountants?)\s*$/i, "")
        .trim();
      
      // Basic: remove all non-alphanumeric
      slugs.add(base.replace(/[^a-z0-9]/g, ""));
      slugs.add(cleaned.replace(/[^a-z0-9]/g, ""));
      
      // With numbers converted: "4" → "for", "2" → "to", etc
      const numToWord = cleaned.replace(/4/g, "for").replace(/2/g, "to").replace(/[^a-z0-9]/g, "");
      slugs.add(numToWord);
      
      // Numbers kept as-is with common separators removed
      slugs.add(cleaned.replace(/\s+/g, "").replace(/[^a-z0-9]/g, ""));
      
      // Hyphens instead of spaces
      const withHyphens = cleaned.replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, "-");
      slugs.add(withHyphens);
      
      // First word only (common for established firms like "Cowgill")
      const firstWord = cleaned.split(/\s+/)[0].replace(/[^a-z0-9]/g, "");
      if (firstWord.length >= 4) {
        slugs.add(firstWord);
        // Also try a pluralized brand variant (e.g. cowgill -> cowgills)
        if (!firstWord.endsWith("s")) slugs.add(`${firstWord}s`);
      }
      
      // First two words (e.g., "cowgillholloway")
      const words = cleaned.split(/\s+/).filter(w => w.length > 0);
      if (words.length >= 2) {
        slugs.add((words[0] + words[1]).replace(/[^a-z0-9]/g, ""));
      }
      
      // Prioritize UK TLDs if location suggests UK
      const locationLower = (lead.location || "").toLowerCase();
      const isUK = locationLower.includes("uk") || locationLower.includes("kingdom") || 
                   locationLower.includes("england") || locationLower.includes("london") ||
                   locationLower.includes("manchester") || locationLower.includes("birmingham") ||
                   locationLower.includes("leeds") || locationLower.includes("liverpool");
      
      const tlds = isUK ? [".co.uk", ".com", ".uk"] : [".com", ".co.uk", ".uk"];
      
      const domains: string[] = [];
      for (const slug of slugs) {
        if (!slug || slug.length < 3) continue;
        for (const tld of tlds) {
          domains.push(`${slug}${tld}`);
        }
      }
      
      console.log(`  Trying ${[...new Set(domains)].length} domain variations`);
      
      // Optimization: stop early once we find a strong MX-valid candidate to avoid timeouts
      // (e.g. cowgillholloway.co.uk is a much better match than cowgill.com)
      let bestMxMatchScore = 0;

      for (const domain of [...new Set(domains)].slice(0, 12)) {
        // If we already found a strong match (>=3), stop trying more inferred domains.
        if (bestMxMatchScore >= 3) {
          console.log(`  Early stop domain inference (best match score: ${bestMxMatchScore})`);
          break;
        }

        console.log(`  Checking: ${domain}`);
        const mxResult = await checkMxRecords(domain, callCounts);

        if (!mxResult.valid) continue;

        console.log(`  ✓ MX valid: ${domain}`);
        const { content, html, blocked } = await firecrawlScrape(`https://${domain}`, callCounts);

        // Score based on domain length match to company name - longer = better match
        // cowgillholloway.co.uk should score higher than cowgill.com
        const domainBase = domain.split(".")[0];
        const nameWords = cleaned.split(/\s+/).filter(w => w.length > 0);
        const fullMatch = nameWords.slice(0, 2).join("").replace(/[^a-z0-9]/g, "");

        // Better match = higher score: full name match (4), long domain (3), short (2)
        // MX-only (no scrape content) gets -1 penalty
        let matchScore = domainBase === fullMatch ? 4 : domainBase.length >= 10 ? 3 : 2;

        if (content && !blocked) {
          websiteCandidates.push({
            url: `https://${domain}`,
            domain,
            classification: "official_candidate",
            accepted: true,
            rejectionReason: "",
            score: matchScore,
          });
          console.log(`  ✓ Domain verified: ${domain} (score: ${matchScore})`);
        } else {
          // Still add MX-valid domain but with lower score (can receive email even if site doesn't load)
          matchScore = Math.max(1, matchScore - 1);
          websiteCandidates.push({
            url: `https://${domain}`,
            domain,
            classification: "official_candidate",
            accepted: true,
            rejectionReason: "scrape_failed",
            score: matchScore, // Mark as scrape failed
          });
          console.log(`  ✓ MX-only domain: ${domain} (score: ${matchScore}, scrape failed)`);
        }

        bestMxMatchScore = Math.max(bestMxMatchScore, matchScore);
      }
    }
    
    debug.websiteCandidates = websiteCandidates;
    
    // Select best candidate - prioritize score (domain name match quality) over scrape success
    // A domain like cowgillholloway.co.uk is better than cowgill.com even if scrape failed
    
    // Determine preferred TLD based on location
    // Default to UK preference when no location is specified (common use case for UK leads)
    const locationLower = (lead.location || "").toLowerCase();
    const hasExplicitNonUKLocation = locationLower.includes("australia") || locationLower.includes("usa") || 
                                      locationLower.includes("canada") || locationLower.includes("india") ||
                                      locationLower.includes("new zealand");
    const isUK = !hasExplicitNonUKLocation && (
                 locationLower === "" || // Default to UK when no location
                 locationLower.includes("uk") || locationLower.includes("kingdom") || 
                 locationLower.includes("england") || locationLower.includes("london") ||
                 locationLower.includes("manchester") || locationLower.includes("birmingham") ||
                 locationLower.includes("leeds") || locationLower.includes("liverpool") ||
                 locationLower.includes("scotland") || locationLower.includes("wales") ||
                 locationLower.includes("edinburgh") || locationLower.includes("cardiff") ||
                 locationLower.includes("glasgow") || locationLower.includes("bristol"));
    const preferredTlds = isUK ? [".co.uk", ".uk", ".org.uk"] : [];
    const penalizedTlds = isUK ? [".com.au", ".au", ".nz", ".ca", ".us", ".in"] : [];
    
    const acceptedSites = websiteCandidates
      .filter(c => c.accepted)
      .sort((a, b) => {
        // FIRST: Penalize wrong-country TLDs heavily (e.g. .com.au when UK expected)
        // This should override other factors to prevent geographic mismatches
        const aPenalized = penalizedTlds.some(tld => a.domain.endsWith(tld));
        const bPenalized = penalizedTlds.some(tld => b.domain.endsWith(tld));
        if (aPenalized !== bPenalized) return aPenalized ? 1 : -1;
        
        // Secondary: Apply geographic TLD preference (boost .co.uk over .com)
        const aPreferred = preferredTlds.some(tld => a.domain.endsWith(tld));
        const bPreferred = preferredTlds.some(tld => b.domain.endsWith(tld));
        if (aPreferred !== bPreferred) return aPreferred ? -1 : 1;
        
        // Tertiary: sort by score (domain name match quality)
        if (a.score !== b.score) return b.score - a.score;
        
        // Quaternary: prefer scraped sites (can help with pattern discovery)
        const aScrapedOk = a.rejectionReason === "";
        const bScrapedOk = b.rejectionReason === "";
        if (aScrapedOk !== bScrapedOk) return bScrapedOk ? 1 : -1;
        
        // Quinary: prefer longer domain names (more specific)
        return b.domain.length - a.domain.length;
      });
    
    // Track if selected domain had scrape issues
    let selectedDomainScrapeFailed = false;
    
    if (acceptedSites.length > 0) {
      result.resolvedCompanyWebsite = acceptedSites[0].url;
      result.resolvedCompanyDomain = acceptedSites[0].domain;
      result.domainStatus = "candidate";
      selectedDomainScrapeFailed = acceptedSites[0].rejectionReason !== "";
      console.log(`Selected: ${acceptedSites[0].domain} (score: ${acceptedSites[0].score}${selectedDomainScrapeFailed ? ", scrape failed" : ""})`);
    } else {
      console.log("No official website found");
      result.notes += "Could not find official company website. ";
    }
    
    // ========================================
    // STEP 2: Scrape official site for emails & phones
    // ========================================
    console.log("\n--- STEP 2: Scrape official site ---");
    
    const allScrapedContent: string[] = [];
    const allFoundEmails: string[] = [];
    const officialDomain = result.resolvedCompanyDomain;
    
    // Skip scraping if domain already failed scrape (MX-only domain)
    if (officialDomain && !selectedDomainScrapeFailed) {
      // Expanded list of common team/staff page paths (includes /about/people-staff for Seftons-style sites)
      const paths = [
        "/contact", "/contact-us", "/about", "/about-us", 
        "/team", "/our-team", "/meet-the-team", "/the-team",
        "/people", "/our-people", "/staff", "/our-staff",
        "/meet-us", "/who-we-are", "/leadership",
        "/about/people", "/about/team", "/about/staff", "/about/people-staff"
      ];
      let pagesScraped = 0;
      let consecutiveFailures = 0;
      
      for (const path of paths) {
        if (pagesScraped >= 5) break;
        if (consecutiveFailures >= 2) {
          console.log("Stopping scrape - too many failures");
          break;
        }
        
        const pageUrl = `https://${officialDomain}${path}`;
        console.log(`Scraping: ${pageUrl}`);
        const { content, html, blocked } = await firecrawlScrape(pageUrl, callCounts);
        
        if (blocked) { result.blockedSources.push(pageUrl); consecutiveFailures++; continue; }
        
        if (!content) { consecutiveFailures++; continue; }
        consecutiveFailures = 0;
        
        pagesScraped++;
        allScrapedContent.push(content);
        result.sources.push(pageUrl);
        
        // Extract phones
        for (const phone of extractPhones(content)) {
          debug.phoneCandidates.push({ phone, sourceUrl: pageUrl, sourceDomain: officialDomain, accepted: true, reason: "Official site" });
          if (!result.officePhone) {
            result.officePhone = phone;
            result.phoneStatus = "verified";
            result.phoneEvidenceUrl = pageUrl;
            console.log(`Found phone: ${phone}`);
          }
        }
        
        // Extract emails from markdown
        const emails = extractEmails(content);
        allFoundEmails.push(...emails);
        
        // Also extract anti-spam protected emails from HTML
        if (html) {
          const htmlEmails = extractEmailsFromHtml(html, officialDomain);
          if (htmlEmails.length > 0) {
            console.log(`Found ${htmlEmails.length} anti-spam protected emails on ${pageUrl}`);
            allFoundEmails.push(...htmlEmails);
          }
        }
        
        // NAME RESOLUTION: If surname is incomplete (e.g., "N."), try to find full name
        if (isIncompleteSurname(workingLastName) && !result.resolvedLastName) {
          console.log(`Attempting name resolution for "${workingFirstName} ${workingLastName}" from ${pageUrl}`);
          const nameResult = extractFullNameFromContent(workingFirstName, content, html || undefined);
          if (nameResult.resolvedLastName) {
            result.resolvedLastName = nameResult.resolvedLastName;
            result.resolvedFullName = nameResult.resolvedFullName;
            workingLastName = nameResult.resolvedLastName;
            result.notes += `Resolved incomplete surname "${lead.lastName}" to "${workingLastName}". `;
            console.log(`  ✓ Resolved: ${result.resolvedFullName}`);
          }
        }
        
        // Track email domains
        for (const d of extractAllEmailDomains(content)) {
          if (!result.emailDomainsFound.includes(d)) result.emailDomainsFound.push(d);
        }
        
        // If domain emails found, mark verified
        if (extractEmails(content, officialDomain).length > 0 || 
            (html && extractEmailsFromHtml(html, officialDomain).length > 0)) {
          result.domainStatus = "verified";
          console.log(`Domain verified via emails`);
        }
      }
    } else if (officialDomain && selectedDomainScrapeFailed) {
      console.log(`Skipping page scrapes - domain ${officialDomain} already failed initial scrape`);
    }
    
    console.log(`Scraped ${result.sources.length} pages, found ${allFoundEmails.length} emails`);
    
    // ========================================
    // STEP 2b: Dynamic page discovery fallback (if no emails found)
    // Use Firecrawl Map to find team/staff pages dynamically
    // ========================================
    if (allFoundEmails.length === 0 && officialDomain && !selectedDomainScrapeFailed) {
      console.log("\n--- STEP 2b: Dynamic page discovery via sitemap ---");
      
      const siteUrl = `https://${officialDomain}`;
      const allSiteUrls = await firecrawlMap(siteUrl, callCounts);
      
      if (allSiteUrls.length > 0) {
        console.log(`Found ${allSiteUrls.length} URLs on site`);
        
        // Filter for team/staff/people pages
        const teamPageKeywords = [
          "team", "staff", "people", "about", "meet", "who-we-are", "our-", 
          "leadership", "partners", "directors", "professionals", "attorneys",
          "solicitors", "accountants", "advisors", "consultants", "experts"
        ];
        
        const teamPages = allSiteUrls.filter(url => {
          const urlLower = url.toLowerCase();
          return teamPageKeywords.some(kw => urlLower.includes(kw));
        }).slice(0, 8); // Limit to 8 pages
        
        if (teamPages.length > 0) {
          console.log(`Found ${teamPages.length} potential team pages: ${teamPages.slice(0, 3).join(", ")}...`);
          
          for (const pageUrl of teamPages) {
            // Skip if already scraped
            if (result.sources.includes(pageUrl)) continue;
            
            console.log(`Scraping discovered page: ${pageUrl}`);
            const { content, html, blocked } = await firecrawlScrape(pageUrl, callCounts);
            
            if (blocked || !content) continue;
            
            result.sources.push(pageUrl);
            allScrapedContent.push(content);
            
            // Extract emails from markdown
            const emails = extractEmails(content);
            
            // Also extract anti-spam protected emails from HTML
            const htmlEmails = html ? extractEmailsFromHtml(html, officialDomain) : [];
            const allEmails = [...emails, ...htmlEmails];
            
            if (allEmails.length > 0) {
              console.log(`Found ${allEmails.length} emails on ${pageUrl}${htmlEmails.length > 0 ? ` (${htmlEmails.length} from anti-spam)` : ""}`);
              allFoundEmails.push(...allEmails);
              
              // Track email domains
              for (const d of extractAllEmailDomains(content)) {
                if (!result.emailDomainsFound.includes(d)) result.emailDomainsFound.push(d);
              }
              
              // If domain emails found, mark verified
              if (extractEmails(content, officialDomain).length > 0 || htmlEmails.length > 0) {
                result.domainStatus = "verified";
                console.log(`Domain verified via emails`);
              }
            }
            
            // Extract phones
            for (const phone of extractPhones(content)) {
              debug.phoneCandidates.push({ phone, sourceUrl: pageUrl, sourceDomain: officialDomain, accepted: true, reason: "Dynamic discovery" });
              if (!result.officePhone) {
                result.officePhone = phone;
                result.phoneStatus = "verified";
                result.phoneEvidenceUrl = pageUrl;
                console.log(`Found phone: ${phone}`);
              }
            }
            
            // Stop if we found enough emails
            if (allFoundEmails.length >= 3) break;
          }
          
          console.log(`Dynamic discovery complete: found ${allFoundEmails.length} total emails`);
        } else {
          console.log("No team/staff pages found in sitemap");
        }
      } else {
        console.log("Sitemap discovery returned no URLs");
      }
    }
    
    // ========================================
    // STEP 2c: External directory search (if no emails found on website)
    // Professional registries often list staff emails (e.g., Law Society, Equity Release Council)
    // ========================================
    if (allFoundEmails.length === 0 && lead.companyName) {
      console.log("\n--- STEP 2c: External directory search for email patterns ---");
      
      const externalQueries = [
        `"${lead.companyName}" "@${officialDomain || lead.companyName.toLowerCase().replace(/[^a-z0-9]/g, "")}.com" email`,
        `"${lead.companyName}" staff email site:equityreleasecouncil.com OR site:lawsociety.org.uk OR site:reviewsolicitors.co.uk`,
        `"${lead.companyName}" team email contact directory`,
      ];
      
      for (const query of externalQueries.slice(0, 2)) {
        result.searchedQueries.push(query);
        console.log(`External search: ${query}`);
        const results = await firecrawlSearch(query, callCounts, 5);
        
        for (const r of results) {
          const content = r.markdown || r.description || "";
          const sourceDomain = getHostname(r.url);
          
          // Extract any emails that match the official domain
          if (officialDomain) {
            const domainMatches = extractEmails(content, officialDomain);
            if (domainMatches.length > 0) {
              console.log(`Found ${domainMatches.length} emails from external source: ${sourceDomain}`);
              allFoundEmails.push(...domainMatches);
              result.sources.push(r.url);
              
              // Track email domains
              for (const d of extractAllEmailDomains(content)) {
                if (!result.emailDomainsFound.includes(d)) result.emailDomainsFound.push(d);
              }
            }
          }
          
          // Also extract any company-domain emails (might be different from website domain)
          const allEmailsInContent = extractEmails(content);
          for (const email of allEmailsInContent) {
            const emailDomain = email.split("@")[1]?.toLowerCase();
            // Accept if domain looks like company name (basic heuristic)
            const companyNorm = lead.companyName.toLowerCase().replace(/[^a-z0-9]/g, "");
            if (emailDomain && emailDomain.includes(companyNorm.slice(0, 6))) {
              console.log(`Found potential company email: ${email} from ${sourceDomain}`);
              allFoundEmails.push(email);
              if (!result.emailDomainsFound.includes(emailDomain)) {
                result.emailDomainsFound.push(emailDomain);
              }
            }
          }
        }
        
        // Stop if we found enough
        if (allFoundEmails.length >= 2) break;
      }
      
      console.log(`External directory search complete: found ${allFoundEmails.length} emails`);
    }
    
    // ========================================
    // STEP 3: Get MX-valid email domain
    // PRIORITY: Website domain > extracted email domains
    // (website domain is more authoritative for email inference)
    // ========================================
    console.log("\n--- STEP 3: Validate email domain ---");
    
    let mxValidDomain: string | null = null;
    let alternateEmailDomain: string | null = null; // Track if emails use different domain
    
    // FIRST: Try the official website domain (most authoritative)
    if (officialDomain) {
      console.log(`MX checking website domain: ${officialDomain}`);
      const mxResult = await checkMxRecords(officialDomain, callCounts);
      
      if (mxResult.valid) {
        mxValidDomain = officialDomain;
        result.domainMxValid = true;
        result.selectedEmailDomain = officialDomain;
        console.log(`✓ MX valid (website): ${officialDomain}`);
      }
    }
    
    // SECOND: Check email domains found on site
    // These might differ from website domain (e.g., site is dunhamsaccountants.co.uk but emails use dunhams.co.uk)
    const officialEmailDomains = [...new Set(allFoundEmails.map(e => e.split("@")[1]?.toLowerCase()).filter(Boolean))];
    
    for (const d of officialEmailDomains) {
      const { classification } = classifyDomain(d);
      if (classification !== "official_candidate") continue;
      
      // Skip if same as website domain (already checked)
      if (d === officialDomain) continue;
      
      console.log(`MX checking extracted email domain: ${d}`);
      const mxResult = await checkMxRecords(d, callCounts);
      
      if (mxResult.valid) {
        // If we already have website domain, track this as alternate
        if (mxValidDomain) {
          alternateEmailDomain = d;
          console.log(`✓ MX valid (alternate): ${d} - will try both domains`);
        } else {
          // No website domain worked, use this
          mxValidDomain = d;
          result.domainMxValid = true;
          result.selectedEmailDomain = d;
          console.log(`✓ MX valid (fallback): ${d}`);
        }
        break;
      }
    }
    
    // Store alternate domain for pattern discovery
    if (alternateEmailDomain) {
      result.notes += `Also found emails using ${alternateEmailDomain}. `;
    }
    
    // THIRD: Try known institutional domains based on company name/type
    if (!mxValidDomain) {
      const companyLower = lead.companyName.toLowerCase();
      const knownInstitutionalDomains: { patterns: string[]; domain: string | null }[] = [
        { patterns: ["nhs", "national health service", "integrated care", "health trust", "clinical commissioning", "primary care trust"], domain: "nhs.net" },
        { patterns: ["university", "uni "], domain: null }, // Universities vary, skip auto-assignment
        { patterns: ["council", "borough", "county council"], domain: "gov.uk" },
      ];
      
      for (const inst of knownInstitutionalDomains) {
        if (!inst.domain) continue;
        const matches = inst.patterns.some(p => companyLower.includes(p));
        if (matches) {
          console.log(`Trying institutional domain: ${inst.domain} (matched patterns for ${lead.companyName})`);
          const mxResult = await checkMxRecords(inst.domain, callCounts);
          if (mxResult.valid) {
            mxValidDomain = inst.domain;
            result.domainMxValid = true;
            result.selectedEmailDomain = inst.domain;
            result.notes += `Using institutional domain ${inst.domain}. `;
            console.log(`✓ MX valid (institutional): ${inst.domain}`);
            break;
          }
        }
      }
    }
    
    if (!mxValidDomain) {
      result.domainStatus = "not_email_enabled";
      result.notes += "No MX-valid domain found. ";
      console.log("STOPPING: No MX-valid domain");
      return new Response(JSON.stringify({ success: true, data: result }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    // ========================================
    // STEP 4: Search for person's explicit email
    // ========================================
    console.log("\n--- STEP 4: Search for explicit email ---");
    
    const personQueries = [
      `site:${mxValidDomain} "${lead.fullName}"`,
      `"${lead.fullName}" "${lead.companyName}" email`,
      `"${lead.fullName}" @${mxValidDomain}`,
    ].filter(q => q.length < 200);
    
    for (const query of personQueries) {
      result.searchedQueries.push(query);
      console.log(`Searching: ${query}`);
      const results = await firecrawlSearch(query, callCounts, 5);
      
      for (const r of results) {
        const sourceDomain = getHostname(r.url);
        if (sourceDomain) {
          const { classification } = classifyDomain(sourceDomain);
          if (classification !== "official_candidate") {
            console.log(`  Skip ${sourceDomain} (${classification})`);
            continue;
          }
        }
        
        const content = r.markdown || r.description || "";
        if (!content.toLowerCase().includes(lead.fullName.toLowerCase())) continue;
        
        const emails = extractEmails(content, mxValidDomain);
        for (const email of emails) {
          const local = email.split("@")[0].toLowerCase();
          const firstLower = lead.firstName.toLowerCase();
          const lastLower = lead.lastName.toLowerCase();
          
          if (local.includes(firstLower) || local.includes(lastLower)) {
            result.explicitEmailFound = true;
            result.foundEmail = email;
            result.foundEmailEvidenceUrl = r.url;
            result.candidateEmail = email;
            result.candidateEmailStatus = "verified_person_email";
            result.confidenceScore = 1.0;
            result.confidenceReason = "Email found with person's name on official source.";
            
            console.log(`FOUND EXPLICIT EMAIL: ${email}`);
            return new Response(JSON.stringify({ success: true, data: result }), {
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }
        }
      }
    }
    
    // ========================================
    // STEP 5: Pattern discovery
    // Prioritize website domain patterns over alternate email domains
    // ========================================
    console.log("\n--- STEP 5: Pattern discovery ---");

    // If the official website couldn't be scraped, pattern discovery + deep scraping is very slow
    // and commonly leads to client-side connection drops. In that case, skip to inference.
    if (selectedDomainScrapeFailed) {
      result.patternStatus = "not_determined";
      result.notes += `Website scrape failed for ${officialDomain}; skipping pattern discovery to avoid timeout. `;
      console.log("Skipping pattern discovery because website scrape failed");
    }

    // Collect emails matching our primary domain (website domain)
    const domainEmails = allFoundEmails.filter(e => e.toLowerCase().endsWith(`@${mxValidDomain}`));
    
    // Also collect emails from alternate domain if different (for comparison)
    const alternateEmails = alternateEmailDomain 
      ? allFoundEmails.filter(e => e.toLowerCase().endsWith(`@${alternateEmailDomain}`))
      : [];
    
    if (alternateEmails.length > 0) {
      console.log(`Note: Found ${alternateEmails.length} emails using alternate domain @${alternateEmailDomain}`);
    }
    
    // Check if we're using an institutional domain (different from website)
    const isInstitutionalDomain = mxValidDomain !== officialDomain && 
      ["nhs.net", "gov.uk", "police.uk", "mod.uk", "nhs.uk", "nhs.scot"].includes(mxValidDomain);

    // Initialize pattern variables (used even if we skip searches)
    let uniqueEmails: string[] = [...new Set(domainEmails)];
    let patternResult = detectEmailPattern(uniqueEmails, mxValidDomain);

    if (!selectedDomainScrapeFailed) {
      // Search for more colleague emails on the PRIMARY domain (website domain)
      const patternQueries: string[] = [];

      if (isInstitutionalDomain) {
        // For institutional domains, search for email patterns on that domain specifically
        patternQueries.push(
          `"${lead.companyName}" "@${mxValidDomain}"`,                    // Company + institutional domain
          `"${lead.fullName}" "@${mxValidDomain}"`,                       // Person + institutional domain
          `"${mxValidDomain}" email format pattern`,                      // General pattern for the domain
        );
      } else {
        patternQueries.push(
          `site:${mxValidDomain} "@${mxValidDomain}"`,
          `"${lead.companyName}" team email`,
          `"${lead.companyName}" staff contact`,
        );
      }

      for (const query of patternQueries.slice(0, 3)) {
        result.searchedQueries.push(query);
        console.log(`Pattern search: ${query}`);
        const results = await firecrawlSearch(query, callCounts, 5);

        for (const r of results) {
          const sourceDomain = getHostname(r.url);
          if (sourceDomain) {
            const { classification } = classifyDomain(sourceDomain);
            // For institutional domains, allow broader sources (directories may have valid patterns)
            if (classification !== "official_candidate" && !isInstitutionalDomain) continue;
          }

          const content = r.markdown || r.description || "";
          domainEmails.push(...extractEmails(content, mxValidDomain));
        }
      }

      uniqueEmails = [...new Set(domainEmails)];
      console.log(`Found ${uniqueEmails.length} colleague emails for @${mxValidDomain}`);

      // Detect pattern from primary domain emails
      patternResult = detectEmailPattern(uniqueEmails, mxValidDomain);
    
    // SECOND-TIER: If no pattern found, try explicit "email pattern" search
    if (!patternResult || uniqueEmails.length < 2) {
      console.log("\n--- STEP 5b: Email pattern discovery search ---");
      
      const patternDiscoveryQueries = [
        `"${lead.companyName}" email pattern`,
        `"${lead.companyName}" "${lead.fullName}" email`,
        `what is the email format for "${lead.companyName}"`,
      ];
      
      for (const query of patternDiscoveryQueries.slice(0, 2)) {
        result.searchedQueries.push(query);
        console.log(`Pattern discovery: ${query}`);
        const results = await firecrawlSearch(query, callCounts, 5);
        
        for (const r of results) {
          const content = r.markdown || r.description || "";
          const foundEmails = extractEmails(content, mxValidDomain);
          if (foundEmails.length > 0) {
            console.log(`  Found ${foundEmails.length} emails from pattern search`);
            domainEmails.push(...foundEmails);
          }
        }
      }
      
      // Re-dedupe and re-detect pattern
      uniqueEmails = [...new Set(domainEmails)];
      if (uniqueEmails.length > 0) {
        console.log(`After pattern search: ${uniqueEmails.length} total colleague emails`);
        patternResult = detectEmailPattern(uniqueEmails, mxValidDomain);
      }
    }
    
    // THIRD-TIER: Deep scrape of top search results for @ mentions
    // Sometimes email patterns are hidden in articles, PDFs, or news mentions (e.g., Insider Media)
    if (!patternResult || uniqueEmails.length < 2) {
      console.log("\n--- STEP 5c: Deep scrape of search results for hidden emails ---");
      
      // Search broadly for company mentions - news articles often contain email addresses
      const deepSearchQueries = [
        `"${lead.companyName}" contact email`,
        `"${lead.companyName}" appoints OR joins OR announces`, // News articles often have contact emails
      ];
      
      for (const query of deepSearchQueries) {
        result.searchedQueries.push(query);
        console.log(`Deep search: ${query}`);
        const results = await firecrawlSearch(query, callCounts, 8); // Get more results
        
        // Check top 3 results by scraping their full content
        let scrapedCount = 0;
        for (const r of results) {
          if (scrapedCount >= 3) break;
          
          const sourceDomain = getHostname(r.url);
          if (!sourceDomain) continue;
          
          // Skip social platforms and known bad sources
          const { classification } = classifyDomain(sourceDomain);
          if (classification === "social_platform") continue;
          
          // Don't re-scrape the official site
          if (sourceDomain === officialDomain) continue;
          
          // Quick check: does the snippet/description contain @ symbol?
          const snippetContent = r.markdown || r.description || "";
          const hasAtSymbol = snippetContent.includes("@");
          
          // Check if snippet already has useful emails
          const snippetEmails = extractEmails(snippetContent, mxValidDomain);
          if (snippetEmails.length > 0) {
            console.log(`  Found ${snippetEmails.length} emails in snippet from ${sourceDomain}`);
            domainEmails.push(...snippetEmails);
            result.sources.push(r.url);
            continue; // No need to deep scrape
          }
          
          // If no MX domain yet, look for any company-related emails
          if (!mxValidDomain) {
            const anyEmails = extractEmails(snippetContent);
            const companyNorm = lead.companyName.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8);
            for (const email of anyEmails) {
              const emailDomain = email.split("@")[1]?.toLowerCase();
              if (emailDomain && emailDomain.includes(companyNorm)) {
                console.log(`  Found company email in snippet: ${email}`);
                domainEmails.push(email);
                if (!result.emailDomainsFound.includes(emailDomain)) {
                  result.emailDomainsFound.push(emailDomain);
                }
              }
            }
          }
          
          // Deep scrape if snippet hints at email content OR it's a news/directory site
          const isLikelyEmailSource = hasAtSymbol || 
            sourceDomain.includes("insider") || 
            sourceDomain.includes("news") ||
            sourceDomain.includes("business") ||
            r.url.includes(".pdf");
          
          if (isLikelyEmailSource) {
            console.log(`  Deep scraping: ${r.url} (${hasAtSymbol ? "has @" : "likely source"})`);
            const { content, html, blocked } = await firecrawlScrape(r.url, callCounts);
            scrapedCount++;
            
            if (blocked || !content) {
              console.log(`    Blocked or empty`);
              continue;
            }
            
            // Extract all emails and look for company domain matches
            if (mxValidDomain) {
              const deepEmails = extractEmails(content, mxValidDomain);
              const htmlEmails = html ? extractEmailsFromHtml(html, mxValidDomain) : [];
              const allDeepEmails = [...deepEmails, ...htmlEmails];
              
              if (allDeepEmails.length > 0) {
                console.log(`    Found ${allDeepEmails.length} emails matching @${mxValidDomain}${htmlEmails.length > 0 ? ` (${htmlEmails.length} from anti-spam)` : ""}`);
                domainEmails.push(...allDeepEmails);
                result.sources.push(r.url);
              }
            }
            
            // Also look for any company-domain emails we haven't found yet
            const allDeepEmails = extractEmails(content);
            const htmlDeepEmails = html ? extractEmailsFromHtml(html) : [];
            const companyNorm = lead.companyName.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8);
            for (const email of [...allDeepEmails, ...htmlDeepEmails]) {
              const emailDomain = email.split("@")[1]?.toLowerCase();
              if (emailDomain && emailDomain.includes(companyNorm)) {
                if (!mxValidDomain || emailDomain === mxValidDomain) {
                  console.log(`    Found company email: ${email}`);
                  domainEmails.push(email);
                  result.sources.push(r.url);
                }
                if (!result.emailDomainsFound.includes(emailDomain)) {
                  result.emailDomainsFound.push(emailDomain);
                }
              }
            }
          }
        }
        
        // Stop if we found enough
        if (domainEmails.length >= 3) break;
      }
      
      // Re-dedupe and re-detect pattern after deep scrape
      uniqueEmails = [...new Set(domainEmails)];
      if (uniqueEmails.length > 0) {
        console.log(`After deep scrape: ${uniqueEmails.length} total colleague emails`);
        patternResult = detectEmailPattern(uniqueEmails, mxValidDomain);
      }
    }

    } // end if (!selectedDomainScrapeFailed)

    // If no pattern found on website domain but we have alternate domain emails, analyze those too
    if (!patternResult && alternateEmails.length >= 2 && alternateEmailDomain) {
      console.log(`Checking alternate domain pattern from ${alternateEmails.length} emails...`);
      const altPattern = detectEmailPattern(alternateEmails, alternateEmailDomain);
      if (altPattern) {
        // Apply the pattern to our primary website domain instead
        console.log(`Found pattern '${altPattern.pattern}' from @${alternateEmailDomain}, applying to @${mxValidDomain}`);
        patternResult = { ...altPattern };
        result.notes += `Pattern detected from @${alternateEmailDomain} emails, applied to @${mxValidDomain}. `;
      }
    }
    
    if (patternResult) {
      result.emailPattern = patternResult.pattern;
      result.patternStatus = "verified";
      result.patternEvidenceCount = patternResult.examples.length;
      result.patternExamples = patternResult.examples;
      console.log(`PATTERN: ${patternResult.pattern} (${patternResult.examples.length} examples)`);
    } else {
      console.log("Pattern not determined from examples");
    }
    
    // ========================================
    // STEP 6: Infer email (with multi-pattern Hunter verification)
    // Uses resolved name if available (for incomplete surnames like "N.")
    // If resolvedDomain was provided by caller, enforce it for email construction
    // ========================================
    console.log("\n--- STEP 6: Infer email ---");
    
    // CRITICAL: If caller provided a resolvedDomain, override discovered domain
    // This prevents cross-domain pollution (e.g., prophecy.co.uk vs prophecy.io)
    const emailDomain = lead.resolvedDomain || mxValidDomain;
    if (lead.resolvedDomain && lead.resolvedDomain !== mxValidDomain) {
      console.log(`DOMAIN OVERRIDE: Using caller-provided ${lead.resolvedDomain} instead of discovered ${mxValidDomain}`);
      // Verify MX for the overridden domain if not already checked
      const overrideMx = await checkMxRecords(lead.resolvedDomain, callCounts);
      if (!overrideMx.valid) {
        console.log(`WARNING: Caller domain ${lead.resolvedDomain} has no MX records, falling back to ${mxValidDomain}`);
      }
    }
    
    // Log if using resolved name
    if (result.resolvedLastName) {
      console.log(`Using resolved name: ${workingFirstName} ${workingLastName}`);
    }
    
    const HUNTER_API_KEY = Deno.env.get("HUNTER_API_KEY");
    
    // If pattern verified, use it — but still verify through Hunter
    if (result.patternStatus === "verified" && result.emailPattern) {
      result.candidateEmail = generateCandidateEmail(workingFirstName, workingLastName, result.emailPattern, emailDomain);
      result.candidateEmailStatus = "inferred";
      
      let confidence = 0;
      const reasons: string[] = [];
      
      if (result.domainStatus === "verified" && result.domainMxValid) {
        confidence += 0.30;
        reasons.push("verified domain");
      } else if (result.domainMxValid) {
        confidence += 0.15;
        reasons.push("MX valid");
      }
      
      if (result.patternEvidenceCount >= 2) {
        confidence += 0.25;
        reasons.push(`${result.patternEvidenceCount} pattern examples`);
      }
      
      if (result.patternEvidenceCount >= 5) {
        confidence += 0.10;
        reasons.push("strong evidence");
      }
      
      if (result.phoneStatus === "verified") {
        confidence += 0.10;
        reasons.push("phone verified");
      }
      
      if (result.resolvedLastName) {
        confidence += 0.10;
        reasons.push("name resolved from website");
      }
      
      // Verify the pattern-based email through Hunter
      if (HUNTER_API_KEY && result.candidateEmail) {
        console.log(`Verifying pattern email via Hunter: ${result.candidateEmail}`);
        callCounts.verifierCalls++;
        try {
          const vResp = await fetch(
            `https://api.hunter.io/v2/email-verifier?email=${encodeURIComponent(result.candidateEmail)}&api_key=${HUNTER_API_KEY}`
          );
          if (vResp.ok) {
            const vData = await vResp.json();
            const vResult = vData.data?.result || vData.data?.status;
            result.verification.attempted = true;
            result.verification.provider = "hunter";
            result.verification.isCatchAll = vData.data?.accept_all || false;
            
            if (vResult === "deliverable" || vResult === "valid") {
              result.verification.result = "deliverable";
              confidence = Math.max(confidence, 0.85);
              reasons.push("Hunter verified");
              console.log(`  ✓ Hunter: deliverable`);
            } else if (vResult === "risky" || vData.data?.accept_all) {
              result.verification.result = "risky";
              confidence = Math.max(confidence, 0.70);
              reasons.push("Hunter risky/catch-all");
              console.log(`  ~ Hunter: risky/catch-all`);
            } else if (vResult === "undeliverable" || vResult === "invalid") {
              result.verification.result = "undeliverable";
              confidence = 0.0;
              reasons.push("Hunter undeliverable");
              console.log(`  ✗ Hunter: undeliverable`);
            } else {
              result.verification.result = "unknown";
              console.log(`  ? Hunter: ${vResult}`);
            }
          }
        } catch (e) {
          console.error("Hunter verification error:", e);
        }
      }
      
      result.confidenceScore = Math.min(confidence, 1);
      result.confidenceReason = reasons.join(", ");
      
      console.log(`INFERRED: ${result.candidateEmail} (confidence: ${result.confidenceScore.toFixed(2)})`);
    }
    // FALLBACK: Generate 5 common patterns and verify each through Hunter
    else if (result.domainMxValid && emailDomain) {
      console.log("No pattern - trying 5 common email formats with Hunter verification...");
      
      // 5 most common B2B email patterns, ordered by frequency
      const patternsToTry = ["first.last", "firstlast", "f.last", "flast", "first"];
      const candidates = patternsToTry.map(p => ({
        pattern: p,
        email: generateCandidateEmail(workingFirstName, workingLastName, p, emailDomain),
      }));
      
      console.log(`Generated ${candidates.length} candidates: ${candidates.map(c => c.email).join(", ")}`);
      
      if (HUNTER_API_KEY) {
        let bestCandidate: { email: string; pattern: string; status: string; score: number } | null = null;
        
        for (const candidate of candidates) {
          callCounts.verifierCalls++;
          console.log(`  Verifying: ${candidate.email}`);
          
          try {
            const vResp = await fetch(
              `https://api.hunter.io/v2/email-verifier?email=${encodeURIComponent(candidate.email)}&api_key=${HUNTER_API_KEY}`
            );
            
            if (!vResp.ok) {
              console.log(`    Hunter API error: ${vResp.status}`);
              continue;
            }
            
            const vData = await vResp.json();
            
            if (vData.errors?.length > 0) {
              console.log(`    Hunter error: ${vData.errors[0]?.details}`);
              continue;
            }
            
            const vResult = vData.data?.result || vData.data?.status;
            const vScore = vData.data?.score || 0;
            const isCatchAll = vData.data?.accept_all || false;
            
            console.log(`    Result: ${vResult}, score: ${vScore}, catch-all: ${isCatchAll}`);
            
            // Deliverable = immediate win, stop checking
            if (vResult === "deliverable" || vResult === "valid") {
              bestCandidate = { email: candidate.email, pattern: candidate.pattern, status: "deliverable", score: vScore };
              console.log(`  ✓ VERIFIED: ${candidate.email}`);
              break; // Stop at first verified hit
            }
            
            // Risky/catch-all = acceptable but keep looking for better
            if ((vResult === "risky" || isCatchAll) && !bestCandidate) {
              bestCandidate = { email: candidate.email, pattern: candidate.pattern, status: "risky", score: vScore };
              console.log(`  ~ Acceptable (risky): ${candidate.email}`);
              // Don't break - keep trying for a deliverable
            }
            
            // Undeliverable = skip
            if (vResult === "undeliverable" || vResult === "invalid") {
              console.log(`  ✗ Undeliverable: ${candidate.email}`);
            }
          } catch (e) {
            console.error(`    Verification error for ${candidate.email}:`, e);
          }
        }
        
        if (bestCandidate) {
          result.candidateEmail = bestCandidate.email;
          result.candidateEmailStatus = "inferred";
          result.emailPattern = bestCandidate.pattern;
          result.verification.attempted = true;
          result.verification.provider = "hunter";
          result.verification.result = bestCandidate.status === "deliverable" ? "deliverable" : "risky";
          
          if (bestCandidate.status === "deliverable") {
            result.confidenceScore = 0.90;
            result.confidenceReason = `Multi-pattern verification: ${bestCandidate.pattern} verified deliverable by Hunter`;
          } else {
            result.confidenceScore = 0.60;
            result.confidenceReason = `Multi-pattern verification: ${bestCandidate.pattern} risky/catch-all by Hunter`;
          }
          result.notes += `Tried ${candidates.length} patterns, ${bestCandidate.pattern} passed Hunter verification. `;
          console.log(`MULTI-PATTERN WINNER: ${bestCandidate.email} (${bestCandidate.status}, confidence: ${result.confidenceScore})`);
        } else {
          // All 5 patterns failed Hunter - use first.last as weak fallback
          result.candidateEmail = candidates[0].email;
          result.candidateEmailStatus = "inferred";
          result.emailPattern = "first.last";
          result.verification.attempted = true;
          result.verification.provider = "hunter";
          result.verification.result = "undeliverable";
          result.confidenceScore = 0.10;
          result.confidenceReason = "All 5 patterns failed Hunter verification";
          result.notes += `All ${candidates.length} patterns failed Hunter verification. `;
          console.log(`ALL PATTERNS FAILED - weak fallback: ${candidates[0].email}`);
        }
      } else {
        // No Hunter key - fall back to first.last without verification
        result.candidateEmail = candidates[0].email;
        result.candidateEmailStatus = "inferred";
        result.emailPattern = "first.last";
        result.confidenceScore = result.resolvedLastName ? 0.45 : 0.35;
        result.confidenceReason = result.resolvedLastName 
          ? "Common pattern fallback (first.last), MX valid, name resolved, no Hunter key" 
          : "Common pattern fallback (first.last), MX valid, no Hunter key";
        result.notes += "Used common pattern fallback without verification (no Hunter key). ";
        console.log(`FALLBACK (no Hunter): ${candidates[0].email} (confidence: ${result.confidenceScore})`);
      }
    }
    
    if (!result.candidateEmail) {
      result.candidateEmailStatus = "not_found";
      result.notes += "Could not infer email. ";
      console.log("Could not infer email");
    }
    
    // Trim arrays
    result.sources = result.sources.slice(0, 8);
    result.searchedQueries = result.searchedQueries.slice(0, 12);
    result.blockedSources = result.blockedSources.slice(0, 5);
    
    console.log(`\n--- COMPLETE: ${result.candidateEmailStatus} ---`);
    console.log(`API calls - Search: ${callCounts.firecrawlSearch}, Scrape: ${callCounts.firecrawlScrape}, MX: ${callCounts.mxLookups}`);
    
    return new Response(JSON.stringify({ success: true, data: result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
    
  } catch (error: unknown) {
    console.error("Deep discovery error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
