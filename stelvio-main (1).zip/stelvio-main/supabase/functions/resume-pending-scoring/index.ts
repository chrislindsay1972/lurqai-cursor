/**
 * resume-pending-scoring
 *
 * Called by pg_cron every 5 minutes.
 * Phase 1: Resumes stalled SCORING queues (fires parallel scoring batches).
 * Phase 2: Resumes stalled SCRAPING (fires scrape continuation from next board index).
 */
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const BATCH_SIZE = 25;
const MAX_PARALLEL_BATCHES = 4; // Cap parallel invocations to avoid timeout stampede

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

  const supabase = createClient(supabaseUrl, serviceKey);

  try {
    const fired: Array<{ candidateId: string; type: 'score' | 'scrape'; detail: string }> = [];

    // ================================================================
    // PHASE 1: Resume stalled SCORING queues
    // ================================================================
    const cutoff = new Date(Date.now() - 2 * 60 * 1000).toISOString();

    const { data: pendingGroups, error } = await supabase
      .from('pipeline_pending_jobs')
      .select('candidate_id')
      .eq('status', 'pending')
      .lt('discovered_at', cutoff)
      .limit(100);

    if (error) {
      console.error('Error fetching pending jobs:', error);
    } else if (pendingGroups && pendingGroups.length > 0) {
      const uniqueCandidateIds = [...new Set(pendingGroups.map(r => r.candidate_id))];
      console.log(`[Scoring] Found ${uniqueCandidateIds.length} candidate(s) with stuck pending jobs`);

      for (const candidateId of uniqueCandidateIds) {
        const { count } = await supabase
          .from('pipeline_pending_jobs')
          .select('id', { count: 'exact', head: true })
          .eq('candidate_id', candidateId)
          .eq('status', 'pending');

        const totalPending = count ?? 0;
        if (totalPending === 0) continue;

        const rawBatchCount = Math.ceil(totalPending / BATCH_SIZE);
        const batchCount = Math.min(rawBatchCount, MAX_PARALLEL_BATCHES);
        console.log(`[Scoring] Firing ${batchCount} parallel scoring batches for ${candidateId} (${totalPending} pending jobs, capped from ${rawBatchCount})`);

        await supabase.from('pipeline_events').insert({
          candidate_id: candidateId,
          created_by: 'system',
          event_type: 'info',
          message: `Auto-resume: firing ${batchCount} parallel scoring batches for ${totalPending} pending jobs...`,
        });

        const firePromises = Array.from({ length: batchCount }, (_, i) =>
          fetch(`${supabaseUrl}/functions/v1/run-candidate-pipeline`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${serviceKey}`,
              'apikey': serviceKey,
            },
            body: JSON.stringify({ candidateId, mode: 'score', batchIndex: i }),
          }).catch(err => console.warn(`Score batch ${i} fire error for ${candidateId}:`, err?.message ?? err))
        );

        try {
          // @ts-ignore
          if (typeof EdgeRuntime !== 'undefined' && EdgeRuntime.waitUntil) {
            // @ts-ignore
            EdgeRuntime.waitUntil(Promise.all(firePromises));
          } else {
            Promise.all(firePromises);
          }
        } catch {
          Promise.all(firePromises);
        }

        fired.push({ candidateId, type: 'score', detail: `${batchCount} batches for ${totalPending} pending jobs` });
      }
    }

    // ================================================================
    // PHASE 2: Resume stalled SCRAPING (board search continuation)
    //
    // Finds candidates with a 'scrape_paused' event (at least 3 min old)
    // that has NOT been followed by any newer 'scrape_paused', 'success',
    // or 'stop_requested' event — meaning the search has genuinely stalled.
    //
    // IMPORTANT: Skip scrape resume if the candidate already has >100 pending
    // jobs — scoring must drain the queue first to avoid scrape/score contention
    // which causes both phases to timeout with almost no progress.
    // ================================================================
    const PENDING_THRESHOLD_FOR_SCRAPE_SKIP = 100;
    const scrapePausedCutoff = new Date(Date.now() - 3 * 60 * 1000).toISOString();

    const { data: pausedScrapes } = await supabase
      .from('pipeline_events')
      .select('candidate_id, message, created_at')
      .eq('event_type', 'scrape_paused')
      .lt('created_at', scrapePausedCutoff)
      .order('created_at', { ascending: false })
      .limit(50);

    if (pausedScrapes && pausedScrapes.length > 0) {
      // Deduplicate to most recent scrape_paused per candidate
      const latestPausePerCandidate = new Map<string, { message: string; created_at: string }>();
      for (const row of pausedScrapes) {
        if (!latestPausePerCandidate.has(row.candidate_id)) {
          latestPausePerCandidate.set(row.candidate_id, { message: row.message, created_at: row.created_at });
        }
      }

      for (const [candidateId, pauseRow] of latestPausePerCandidate) {
        // Check if there's already a newer event showing the scrape resumed or completed
        const { data: newerEvents } = await supabase
          .from('pipeline_events')
          .select('event_type, created_at')
          .eq('candidate_id', candidateId)
          .in('event_type', ['scrape_paused', 'success', 'stop_requested'])
          .gt('created_at', pauseRow.created_at)
          .limit(1);

        if (newerEvents && newerEvents.length > 0) {
          console.log(`[Scrape] Candidate ${candidateId}: newer event found (${newerEvents[0].event_type}), skipping resume`);
          continue;
        }

        // IMPORTANT: Skip scrape if too many pending jobs — scoring must drain queue first
        // to avoid both phases competing for execution budget and both timing out
        const { count: pendingCount } = await supabase
          .from('pipeline_pending_jobs')
          .select('id', { count: 'exact', head: true })
          .eq('candidate_id', candidateId)
          .eq('status', 'pending');

        if ((pendingCount ?? 0) >= PENDING_THRESHOLD_FOR_SCRAPE_SKIP) {
          console.log(`[Scrape] Candidate ${candidateId}: ${pendingCount} pending jobs queued — deferring scrape resume until scoring drains queue`);
          continue;
        }

        // Parse nextBoardIndex from stored event message
        let nextBoardIndex = 0;
        let totalBoardsAvailable = 0;
        try {
          const parsed = JSON.parse(pauseRow.message);
          nextBoardIndex = parsed.nextBoardIndex ?? 0;
          totalBoardsAvailable = parsed.totalBoardsAvailable ?? 0;
        } catch {
          console.warn(`[Scrape] Could not parse scrape_paused message for ${candidateId}`);
          continue;
        }

        if (nextBoardIndex >= totalBoardsAvailable) {
          console.log(`[Scrape] Candidate ${candidateId}: already at end of boards (${nextBoardIndex}/${totalBoardsAvailable}), skipping`);
          continue;
        }

        console.log(`[Scrape] Resuming board search for ${candidateId} from board ${nextBoardIndex}/${totalBoardsAvailable}`);

        await supabase.from('pipeline_events').insert({
          candidate_id: candidateId,
          created_by: 'system',
          event_type: 'info',
          message: `Auto-resume: continuing board search from board ${nextBoardIndex} of ${totalBoardsAvailable}...`,
        });

        // Fire scrape continuation — fire-and-forget
        const scrapePromise = fetch(`${supabaseUrl}/functions/v1/run-candidate-pipeline`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${serviceKey}`,
            'apikey': serviceKey,
          },
          body: JSON.stringify({
            candidateId,
            mode: 'scrape',
            continueFromBoard: nextBoardIndex,
          }),
        }).catch(err => console.warn(`Scrape resume fire error for ${candidateId}:`, err?.message ?? err));

        try {
          // @ts-ignore
          if (typeof EdgeRuntime !== 'undefined' && EdgeRuntime.waitUntil) {
            // @ts-ignore
            EdgeRuntime.waitUntil(scrapePromise);
          } else {
            scrapePromise;
          }
        } catch {
          scrapePromise;
        }

        fired.push({ candidateId, type: 'scrape', detail: `Resuming from board ${nextBoardIndex}/${totalBoardsAvailable}` });
      }
    }

    console.log(`Resume run complete. Fired: ${fired.length} operations`);

    return new Response(JSON.stringify({ fired, message: `Fired ${fired.length} resume operation(s)` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (err) {
    console.error('resume-pending-scoring error:', err);
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
