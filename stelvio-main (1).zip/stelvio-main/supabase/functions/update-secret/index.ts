import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify the user is authenticated and is an admin
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Not authenticated" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Create client with user's token to check role
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check admin role
    const { data: roleData } = await userClient.rpc("get_user_role", { _user_id: user.id });
    if (roleData !== "admin") {
      return new Response(
        JSON.stringify({ error: "Admin access required" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { secretName, secretValue } = await req.json();

    // Whitelist of allowed secret names that can be updated
    const allowedSecrets = [
      "FIRECRAWL_API_KEY",
      "MS365_SMTP_HOST",
      "MS365_SMTP_USER", 
      "MS365_SMTP_PASSWORD",
      "APOLLO_API_KEY",
      "BETTERCONTACT_API_KEY",
      "CLAY_API_KEY",
      "OPENAI_API_KEY",
      "VIRUSTOTAL_API_KEY",
    ];

    if (!allowedSecrets.includes(secretName)) {
      return new Response(
        JSON.stringify({ error: "Secret not allowed to be updated" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Use the Management API to update the secret
    const projectId = Deno.env.get("SUPABASE_PROJECT_ID") || supabaseUrl.match(/https:\/\/(.+?)\.supabase/)?.[1];
    
    const mgmtResponse = await fetch(
      `https://api.supabase.com/v1/projects/${projectId}/secrets`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${supabaseServiceKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify([
          { name: secretName, value: secretValue },
        ]),
      }
    );

    if (!mgmtResponse.ok) {
      const errText = await mgmtResponse.text();
      console.error("Failed to update secret:", errText);
      
      // Fallback: Store in app_settings table as encrypted reference
      // The edge functions can check app_settings as fallback
      const adminClient = createClient(supabaseUrl, supabaseServiceKey);
      await adminClient
        .from("app_settings")
        .upsert(
          {
            setting_key: `secret_${secretName.toLowerCase()}`,
            setting_value: secretValue,
            setting_type: "secret",
            description: `Override for ${secretName}`,
          },
          { onConflict: "setting_key" }
        );

      return new Response(
        JSON.stringify({ success: true, method: "app_settings" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, method: "secrets" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error updating secret:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
