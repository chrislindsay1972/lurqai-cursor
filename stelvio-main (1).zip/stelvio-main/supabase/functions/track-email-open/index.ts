import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 1x1 transparent GIF (43 bytes)
const TRACKING_PIXEL = Uint8Array.from(atob(
  "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
), c => c.charCodeAt(0));

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

Deno.serve(async (req) => {
  const pixelHeaders = {
    "Content-Type": "image/gif",
    "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
    "Pragma": "no-cache",
    "Expires": "0",
    "Access-Control-Allow-Origin": "*",
  };

  try {
    const url = new URL(req.url);
    const campaignId = url.searchParams.get("c");
    const stakeholderId = url.searchParams.get("s");
    const stepId = url.searchParams.get("st");
    const email = url.searchParams.get("e");

    if (!campaignId || !stakeholderId || !email) {
      return new Response(TRACKING_PIXEL, { headers: pixelHeaders });
    }

    // Validate parameter formats
    if (!UUID_REGEX.test(campaignId) || !UUID_REGEX.test(stakeholderId)) {
      return new Response(TRACKING_PIXEL, { headers: pixelHeaders });
    }
    if (stepId && !UUID_REGEX.test(stepId)) {
      return new Response(TRACKING_PIXEL, { headers: pixelHeaders });
    }
    if (!EMAIL_REGEX.test(email) || email.length > 255) {
      return new Response(TRACKING_PIXEL, { headers: pixelHeaders });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check for duplicate opens — only record the first one per step
    const { data: existing } = await supabase
      .from("campaign_metrics")
      .select("id")
      .eq("campaign_id", campaignId)
      .eq("stakeholder_id", stakeholderId)
      .eq("email_address", email)
      .eq("event_type", "opened")
      .eq("step_id", stepId || "")
      .limit(1);

    if (!existing || existing.length === 0) {
      await supabase.from("campaign_metrics").insert({
        campaign_id: campaignId,
        stakeholder_id: stakeholderId,
        step_id: stepId || null,
        email_address: email,
        event_type: "opened",
        event_data: {
          user_agent: req.headers.get("user-agent") || "unknown",
          ip: req.headers.get("x-forwarded-for") || req.headers.get("cf-connecting-ip") || "unknown",
        },
      });
    }
  } catch (err) {
    console.error("Open tracking error:", err);
  }

  return new Response(TRACKING_PIXEL, { headers: pixelHeaders });
});
