// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CachedJob {
  title: string;
  url: string;
  content: string;
  score: number;
  parsedData: {
    match_reason?: string;
    skills_matched?: string[];
    skills_missing?: string[];
    job_location?: string;
    job_type?: string;
    industry?: string;
    experience_level?: string;
    salary_range?: string;
    posted_date?: string;
  };
  source: string;
  boardId?: string;
}

interface RejectionStats {
  total: number;
  byReason: Record<string, number>;
  examples: Array<{
    title: string;
    url: string;
    reason: string;
    score?: number;
    details?: string;
  }>;
  lowScoreCache?: CachedJob[];
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    
    if (!LOVABLE_API_KEY) {
      return new Response(
        JSON.stringify({ error: 'AI service not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);

    // Helper function to extract company name from job content using AI
    async function extractCompanyFromJob(content: string, url: string): Promise<string | null> {
      try {
        const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              {
                role: 'system',
                content: `Extract the company name from this job posting. Return ONLY the company name, nothing else. If you cannot determine the company name, return "Unknown Company".`,
              },
              { role: 'user', content: `URL: ${url}\n\nContent:\n${content.slice(0, 2000)}` }
            ],
            temperature: 0.1,
            max_tokens: 50,
          }),
        });
        
        if (!response.ok) return null;
        const data = await response.json();
        const companyName = data.choices?.[0]?.message?.content?.trim();
        return companyName && companyName !== 'Unknown Company' ? companyName : null;
      } catch {
        return null;
      }
    }

    // Helper function to get or create company
    async function getOrCreateCompany(companyName: string, userId: string): Promise<string | null> {
      if (!companyName || companyName === 'Unknown Company') return null;

      // Check if company exists
      const { data: existingCompany } = await supabaseAdmin
        .from('companies')
        .select('id')
        .ilike('name', companyName)
        .maybeSingle();

      if (existingCompany) {
        console.log(`Found existing company: ${companyName}`);
        return existingCompany.id;
      }

      // Create new company
      const { data: newCompany, error } = await supabaseAdmin
        .from('companies')
        .insert({
          name: companyName,
          enrichment_status: 'pending',
          created_by: userId,
        })
        .select('id')
        .single();

      if (error) {
        console.error('Failed to create company:', error);
        return null;
      }

      console.log(`Created new company: ${companyName}`);
      return newCompany.id;
    }

    const { 
      rejectionStats, 
      candidateId, 
      savedMatchesCount, 
      candidateSkills, 
      candidateTitle,
      matchThreshold,
      userId,
    } = await req.json() as {
      rejectionStats: RejectionStats;
      candidateId: string;
      savedMatchesCount: number;
      candidateSkills?: string[];
      candidateTitle?: string;
      matchThreshold?: number;
      userId?: string;
    };

    const threshold = matchThreshold || 50;

    if (!rejectionStats || rejectionStats.total === 0) {
      console.log('No rejection data to analyze');
      return new Response(
        JSON.stringify({ success: true, message: 'No rejections to analyze', updated: false, jobsAdded: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Analyzing ${rejectionStats.total} rejections for candidate ${candidateId}`);
    console.log(`Cached jobs for re-evaluation: ${rejectionStats.lowScoreCache?.length || 0}`);

    // Calculate rejection percentages
    const rejectionBreakdown = Object.entries(rejectionStats.byReason)
      .filter(([_, count]) => count > 0)
      .map(([reason, count]) => ({
        reason,
        count,
        percentage: Math.round((count / rejectionStats.total) * 100),
      }))
      .sort((a, b) => b.count - a.count);

    // Get current matching instruction
    const { data: currentInstruction } = await supabaseAdmin
      .from('ai_instructions')
      .select('id, instruction_prompt, instruction_key')
      .eq('instruction_key', 'job_match_scoring')
      .single();

    if (!currentInstruction) {
      console.log('No job_match_scoring instruction found - creating default');
      await supabaseAdmin.from('ai_instructions').insert({
        instruction_key: 'job_match_scoring',
        instruction_name: 'Job Match Scoring',
        instruction_prompt: getDefaultPrompt(),
      });
      
      return new Response(
        JSON.stringify({ success: true, message: 'Created default instruction', updated: true, jobsAdded: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build analysis context with examples
    const examplesByReason: Record<string, string[]> = {};
    for (const example of rejectionStats.examples) {
      if (!examplesByReason[example.reason]) {
        examplesByReason[example.reason] = [];
      }
      examplesByReason[example.reason].push(
        `"${example.title}" (${example.score !== undefined ? `score: ${example.score}%` : 'no score'})${example.details ? ` - ${example.details}` : ''}`
      );
    }

    const analysisPrompt = `You are an AI recruitment matching system optimizer. Analyze rejection patterns from a job search pipeline and refine the matching criteria to improve future results.

## CURRENT MATCHING INSTRUCTION:
${currentInstruction.instruction_prompt}

## CANDIDATE CONTEXT:
- Skills: ${candidateSkills?.join(', ') || 'Not specified'}
- Current/Target Role: ${candidateTitle || 'Not specified'}

## SEARCH RESULTS:
- Jobs saved as matches: ${savedMatchesCount}
- Jobs rejected: ${rejectionStats.total}
- Save rate: ${savedMatchesCount > 0 ? Math.round((savedMatchesCount / (savedMatchesCount + rejectionStats.total)) * 100) : 0}%
- Match threshold: ${threshold}%

## REJECTION BREAKDOWN:
${rejectionBreakdown.map(r => `- ${r.reason}: ${r.count} (${r.percentage}%)`).join('\n')}

## REJECTION EXAMPLES BY REASON:
${Object.entries(examplesByReason).map(([reason, examples]) => `### ${reason}:\n${examples.map(e => `  - ${e}`).join('\n')}`).join('\n\n')}

## YOUR TASK:
Analyze this data and determine if the matching instruction needs refinement. Consider:

1. **If low_score rejections are high (>40%)**: Are we being too strict? Should scoring criteria be adjusted to value transferable skills more?
2. **If scrape_failed is high (>30%)**: This is a technical issue, not a matching criteria issue - ignore.
3. **If location_mismatch is high (>20%)**: Consider if remote/hybrid options should score higher.
4. **If company_too_large is high (>20%)**: This is a setting issue, not matching criteria.
5. **If content_too_short or blocked_url are high**: Technical issues - ignore.
6. **Look at low_score examples**: Are these legitimately bad matches, or could they be reconsidered with more weight on transferable skills?

## OUTPUT FORMAT:
Return a JSON object with:
{
  "should_update": boolean,
  "analysis": "Brief explanation of your analysis (2-3 sentences)",
  "changes_made": ["list of specific changes if any"],
  "updated_prompt": "The complete new matching instruction prompt if should_update is true, otherwise null",
  "new_threshold_suggestion": number or null (suggest a new threshold if current one is too strict/lenient)
}

IMPORTANT GUIDELINES FOR UPDATED PROMPT:
- Keep the same JSON output structure (job_title, match_score, match_reason, skills_matched, skills_missing, is_job_posting)
- Include the {{candidate_skills}} and {{candidate_title}} template variables
- Make scoring criteria more precise based on what we learned
- Add specific guidance based on rejection patterns (e.g., "Consider transferable skills more generously")
- Keep the prompt under 800 words
- If save rate is >15% and we have decent matches, be conservative with changes
- If save rate is <5%, consider being more lenient with scoring
- Consider adding specific examples of what SHOULD match based on the rejected examples

Return ONLY valid JSON.`;

    console.log('Sending rejection analysis to AI...');
    
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'user', content: analysisPrompt }
        ],
        temperature: 0.3,
        max_tokens: 2000,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const aiData = await response.json();
    const aiContent = aiData.choices?.[0]?.message?.content;
    
    if (!aiContent) {
      throw new Error('Empty AI response');
    }

    console.log('AI analysis received, parsing...');

    // Extract JSON from response
    let analysis;
    try {
      const jsonMatch = aiContent.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in response');
      }
      analysis = JSON.parse(jsonMatch[0]);
    } catch (parseError) {
      console.error('Failed to parse AI response:', aiContent);
      throw new Error('Failed to parse AI analysis');
    }

    console.log(`Analysis result: should_update=${analysis.should_update}, analysis="${analysis.analysis}"`);

    let jobsAdded = 0;
    const newJobs: any[] = [];

    // Update instruction if needed
    if (analysis.should_update && analysis.updated_prompt) {
      const { error: updateError } = await supabaseAdmin
        .from('ai_instructions')
        .update({
          instruction_prompt: analysis.updated_prompt,
          updated_at: new Date().toISOString(),
        })
        .eq('id', currentInstruction.id);

      if (updateError) {
        console.error('Failed to update instruction:', updateError);
        throw new Error('Failed to update matching instruction');
      }

      console.log('Matching instruction updated successfully');
      console.log('Changes made:', analysis.changes_made?.join('; ') || 'None specified');

      // Log the update to pipeline_events for transparency
      await supabaseAdmin.from('pipeline_events').insert({
        candidate_id: candidateId,
        event_type: 'criteria_refinement',
        message: `AI refined matching criteria: ${analysis.analysis}. Changes: ${analysis.changes_made?.join(', ') || 'Adjustments made'}`,
        created_by: userId || '00000000-0000-0000-0000-000000000000',
      });

      // Re-evaluate cached low_score jobs with the new criteria
      if (rejectionStats.lowScoreCache && rejectionStats.lowScoreCache.length > 0 && userId) {
        console.log(`Re-evaluating ${rejectionStats.lowScoreCache.length} cached jobs with refined criteria...`);

        for (const cachedJob of rejectionStats.lowScoreCache) {
          try {
            // Re-score the job with the new prompt
            const rescoreResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${LOVABLE_API_KEY}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                model: 'google/gemini-2.5-flash',
                messages: [
                  {
                    role: 'system',
                    content: buildMatchPrompt(analysis.updated_prompt, candidateSkills || [], candidateTitle),
                  },
                  { role: 'user', content: cachedJob.content.slice(0, 4000) }
                ],
                temperature: 0.2,
                max_tokens: 500,
              }),
            });

            if (!rescoreResponse.ok) {
              console.log(`Re-score failed for ${cachedJob.title}`);
              continue;
            }

            const rescoreData = await rescoreResponse.json();
            const rescoreContent = rescoreData.choices?.[0]?.message?.content;
            
            if (!rescoreContent) continue;

            // Parse the new score
            let jsonStr = rescoreContent.trim();
            if (jsonStr.startsWith('```json')) jsonStr = jsonStr.slice(7);
            else if (jsonStr.startsWith('```')) jsonStr = jsonStr.slice(3);
            if (jsonStr.endsWith('```')) jsonStr = jsonStr.slice(0, -3);

            const parsed = safeParseFirstJsonObject(jsonStr.trim());
            if (!parsed) continue;

            const newScore = Math.min(100, Math.max(0, Number(parsed.match_score) || 0));
            
            console.log(`Re-scored "${cachedJob.title}": ${cachedJob.score}% -> ${newScore}%`);

            // If the new score meets the threshold, save the job
            if (newScore >= threshold) {
              console.log(`Job now qualifies! Saving: ${cachedJob.title} (${newScore}%)`);

              // Check if job already exists
              const { data: existingJob } = await supabaseAdmin
                .from('jobs')
                .select('id')
                .eq('source_url', cachedJob.url)
                .maybeSingle();

              if (existingJob) {
                console.log(`Job already exists, creating match only`);
                // Just create the match
                await supabaseAdmin.from('matches').upsert({
                  candidate_id: candidateId,
                  job_id: existingJob.id,
                  match_score: newScore,
                  match_reason: parsed.match_reason || 'Re-evaluated with refined criteria',
                  skills_matched: parsed.skills_matched || [],
                  skills_missing: parsed.skills_missing || [],
                  status: 'pending',
                  created_by: userId,
                }, { onConflict: 'candidate_id,job_id' });

                jobsAdded++;
                newJobs.push({
                  title: cachedJob.title,
                  url: cachedJob.url,
                  matchScore: newScore,
                  matchReason: parsed.match_reason || 'Re-evaluated with refined criteria',
                  skillsMatched: parsed.skills_matched || [],
                  skillsMissing: parsed.skills_missing || [],
                  source: cachedJob.source,
                  jobId: existingJob.id,
                  companyName: 'Unknown Company',
                  stakeholders: [],
                });
              } else {
                // Extract company name and create/lookup company
                const companyName = await extractCompanyFromJob(cachedJob.content, cachedJob.url);
                const companyId = companyName ? await getOrCreateCompany(companyName, userId) : null;
                
                if (!companyId) {
                  console.log(`Skipping job "${cachedJob.title}" - could not resolve company`);
                  continue;
                }

                // Create new job and match
                const { data: insertedJob, error: jobError } = await supabaseAdmin
                  .from('jobs')
                  .insert({
                    title: cachedJob.title,
                    description: cachedJob.content.slice(0, 5000),
                    source_url: cachedJob.url,
                    location: cachedJob.parsedData.job_location || null,
                    salary_range: cachedJob.parsedData.salary_range || null,
                    job_type: cachedJob.parsedData.job_type || null,
                    experience_level: cachedJob.parsedData.experience_level || null,
                    status: 'active',
                    skills_required: parsed.skills_matched || [],
                    company_id: companyId,
                    created_by: userId,
                    posted_at: cachedJob.parsedData.posted_date || null,
                  })
                  .select()
                  .single();

                if (!jobError && insertedJob) {
                  await supabaseAdmin.from('matches').insert({
                    candidate_id: candidateId,
                    job_id: insertedJob.id,
                    match_score: newScore,
                    match_reason: parsed.match_reason || 'Re-evaluated with refined criteria',
                    skills_matched: parsed.skills_matched || [],
                    skills_missing: parsed.skills_missing || [],
                    status: 'pending',
                    created_by: userId,
                  });

                  jobsAdded++;
                  newJobs.push({
                    id: insertedJob.id,
                    matchId: `refined-${Date.now()}`,
                    title: cachedJob.title,
                    url: cachedJob.url,
                    match_score: newScore,
                    match_reason: parsed.match_reason || 'Re-evaluated with refined criteria',
                    skills_matched: parsed.skills_matched || [],
                    skills_missing: parsed.skills_missing || [],
                    source: cachedJob.source,
                    company_name: companyName,
                  });
                }
              }
            }
          } catch (rescoreError) {
            console.error(`Error re-scoring job ${cachedJob.title}:`, rescoreError);
          }
        }

        console.log(`Re-evaluation complete: ${jobsAdded} jobs added from previously rejected candidates`);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        updated: analysis.should_update,
        analysis: analysis.analysis,
        changes: analysis.changes_made || [],
        rejectionBreakdown,
        saveRate: savedMatchesCount > 0 ? Math.round((savedMatchesCount / (savedMatchesCount + rejectionStats.total)) * 100) : 0,
        jobsAdded,
        newJobs,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in refine-match-criteria:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Failed to refine criteria' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function buildMatchPrompt(updatedPrompt: string, skills: string[], title?: string): string {
  let prompt = updatedPrompt;
  prompt = prompt.replace(/\{\{candidate_skills\}\}/g, skills.join(', ') || 'Not specified');
  prompt = prompt.replace(/\{\{#candidate_title\}\}.*?\{\{\/candidate_title\}\}/gs, title ? `Role: ${title}` : '');
  prompt = prompt.replace(/\{\{candidate_title\}\}/g, title || 'Not specified');
  return prompt;
}

function safeParseFirstJsonObject(text: string): any | null {
  try {
    // Try direct parse first
    return JSON.parse(text);
  } catch {
    // Try to find JSON object in text
    const match = text.match(/\{[\s\S]*?\}/);
    if (match) {
      try {
        return JSON.parse(match[0]);
      } catch {
        return null;
      }
    }
    return null;
  }
}

function getDefaultPrompt(): string {
  return `Analyze job posting for candidate with skills: {{candidate_skills}}
{{#candidate_title}}Role: {{candidate_title}}{{/candidate_title}}

SCORING CRITERIA:
- 90-100%: Perfect match - all required skills present, matching seniority level, same job family
- 70-89%: Strong match - most skills present (80%+), related job title, minor gaps
- 50-69%: Moderate match - core skills present (60%+), transferable experience
- 30-49%: Weak match - some relevant skills, significant gaps
- 0-29%: Poor match - minimal skill overlap, different specialization

Consider:
1. Direct skill matches (exact technology/tool)
2. Related skills (e.g., React experience counts for JavaScript roles)
3. Seniority alignment (Senior vs Junior roles)
4. Domain relevance (e.g., Healthcare IT experience for Healthcare jobs)

Return JSON:
- job_title: string
- match_score: number 0-100
- match_reason: string (explain the score with specific skill analysis)
- skills_matched: string[]
- skills_missing: string[]
- is_job_posting: boolean

Only valid JSON.`;
}
