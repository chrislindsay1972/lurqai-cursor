// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Auth check
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // User client for auth verification
    const supabaseUserClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabaseUserClient.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Admin client for database operations
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Check user role
    const { data: userRole, error: roleError } = await supabaseClient
      .rpc("get_user_role", { _user_id: user.id });

    if (roleError || !userRole || !["recruiter", "admin"].includes(userRole)) {
      return new Response(
        JSON.stringify({ error: "Insufficient permissions" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    const { connectionName } = body;

    if (!connectionName) {
      return new Response(
        JSON.stringify({ error: "Connection name required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create a pending connection record
    const { data: connection, error: insertError } = await supabaseClient
      .from("email_connections")
      .insert({
        connection_name: connectionName,
        email_address: "pending@oauth",
        use_oauth: true,
        is_active: false,
        created_by: user.id,
      })
      .select()
      .single();

    if (insertError) {
      console.error("Failed to create connection:", insertError);
      return new Response(
        JSON.stringify({ error: "Failed to create connection" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const MS365_CLIENT_ID = Deno.env.get("MS365_CLIENT_ID");
    const MS365_TENANT_ID = Deno.env.get("MS365_TENANT_ID");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");

    if (!MS365_CLIENT_ID || !MS365_TENANT_ID) {
      return new Response(
        JSON.stringify({ error: "MS365 not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build OAuth URL
    const redirectUri = `${SUPABASE_URL}/functions/v1/ms365-oauth-callback`;
    const state = btoa(JSON.stringify({ connectionId: connection.id }));
    
    const authUrl = new URL(`https://login.microsoftonline.com/${MS365_TENANT_ID}/oauth2/v2.0/authorize`);
    authUrl.searchParams.set("client_id", MS365_CLIENT_ID);
    authUrl.searchParams.set("response_type", "code");
    authUrl.searchParams.set("redirect_uri", redirectUri);
    authUrl.searchParams.set("scope", "https://graph.microsoft.com/Mail.Read https://graph.microsoft.com/Mail.ReadWrite https://graph.microsoft.com/Mail.Send https://graph.microsoft.com/User.Read offline_access");
    authUrl.searchParams.set("state", state);
    authUrl.searchParams.set("response_mode", "query");
    authUrl.searchParams.set("prompt", "consent");

    return new Response(
      JSON.stringify({
        authUrl: authUrl.toString(),
        connectionId: connection.id,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: any) {
    console.error("OAuth start error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
