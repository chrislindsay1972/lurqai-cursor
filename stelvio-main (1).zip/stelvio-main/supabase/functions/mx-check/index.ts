const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface MxCheckRequest {
  domain: string;
}

interface MxCheckResponse {
  domain: string;
  mxValid: boolean;
  mxHosts: string[];
  error?: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { domain }: MxCheckRequest = await req.json();

    if (!domain) {
      return new Response(
        JSON.stringify({ domain: "", mxValid: false, mxHosts: [], error: "Domain is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const cleanDomain = domain.toLowerCase().trim().replace(/^www\./, "");
    console.log(`MX check for domain: ${cleanDomain}`);

    const dnsUrl = `https://dns.google/resolve?name=${encodeURIComponent(cleanDomain)}&type=MX`;
    
    const response = await fetch(dnsUrl, {
      method: "GET",
      headers: { "Accept": "application/dns-json" },
    });

    if (!response.ok) {
      console.error(`DNS query failed: ${response.status}`);
      return new Response(
        JSON.stringify({ 
          domain: cleanDomain, 
          mxValid: false, 
          mxHosts: [], 
          error: `DNS query failed: ${response.status}` 
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    console.log(`DNS response:`, JSON.stringify(data));

    if (data.Status !== 0) {
      const statusMessages: Record<number, string> = {
        1: "Format error",
        2: "Server failure", 
        3: "Domain does not exist (NXDOMAIN)",
        4: "Not implemented",
        5: "Query refused",
      };
      const errorMsg = statusMessages[data.Status] || `DNS error code: ${data.Status}`;
      console.log(`DNS status: ${errorMsg}`);
      
      return new Response(
        JSON.stringify({ 
          domain: cleanDomain, 
          mxValid: false, 
          mxHosts: [], 
          error: errorMsg 
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const answers = Array.isArray(data.Answer) ? data.Answer : [];
    const mxRecords = answers.filter((a: { type: number }) => a.type === 15);
    
    const mxHosts = mxRecords
      .map((record: { data: string }) => {
        const parts = record.data?.split(" ");
        if (parts && parts.length >= 2) {
          return parts.slice(1).join(" ").replace(/\.$/, "");
        }
        return record.data?.replace(/\.$/, "");
      })
      .filter(Boolean);

    const mxValid = mxHosts.length > 0;
    
    console.log(`MX check result: ${mxValid ? "VALID" : "NO MX"}, hosts: ${mxHosts.join(", ")}`);

    const result: MxCheckResponse = {
      domain: cleanDomain,
      mxValid,
      mxHosts,
    };

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("MX check error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ 
        domain: "", 
        mxValid: false, 
        mxHosts: [], 
        error: errorMessage 
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
