import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

// ── Denylist: domains that are never a company's official site ──
const DENYLIST_EXACT = new Set([
  'epdf.pub','pdfhost.io','docplayer.net','slideshare.net','issuu.com','scribd.com',
  'linkedin.com','facebook.com','instagram.com','twitter.com','x.com','tiktok.com',
  'crunchbase.com','zoominfo.com','rocketreach.co','theorg.com','apollo.io','lusha.com',
  'glassdoor.com','glassdoor.co.uk','indeed.com','ziprecruiter.com','monster.com',
  'salary.com','comparably.com','trustpilot.com','yelp.com','bbb.org',
  'wikipedia.org','bloomberg.com','pitchbook.com','owler.com','craft.co',
  'dnb.com','builtwith.com','datanyze.com','leadiq.com','wayup.com',
  'manta.com','clearbit.com','google.com','youtube.com','github.com',
]);

// ATS subdomains – accept only if branded (jobs.company.com pattern handled separately)
const ATS_HOSTS = ['greenhouse.io','lever.co','workable.com','breezy.hr','recruitee.com','ashbyhq.com','jobs.lever.co'];

function isDenied(hostname: string): boolean {
  const h = hostname.replace(/^www\./, '').toLowerCase();
  if (DENYLIST_EXACT.has(h)) return true;
  // deny any subdomain of a denied host
  for (const d of DENYLIST_EXACT) {
    if (h.endsWith(`.${d}`)) return true;
  }
  // ATS hosts (but allow branded subdomains like jobs.company.greenhouse.io -> still deny)
  for (const a of ATS_HOSTS) {
    if (h === a || h.endsWith(`.${a}`)) return true;
  }
  return false;
}

// ── Normalise company name for alias matching ──
function normaliseName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[''`]/g, '')
    .replace(/\b(inc|ltd|llc|gmbh|plc|limited|corp|co|corporation|company|group|holdings|sa|ag|bv|nv|pty|srl|spa)\b\.?/gi, '')
    .replace(/[^a-z0-9 ]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// ── Tokenise name for matching ──
function nameTokens(name: string): string[] {
  return normaliseName(name).split(' ').filter(t => t.length > 1);
}

// ── Extract domain from URL ──
function extractDomain(url: string): string | null {
  try {
    return new URL(url).hostname.replace(/^www\./, '').toLowerCase();
  } catch { return null; }
}

// ── Score a candidate domain against company name ──
interface CandidateScore {
  domain: string;
  source: string;
  score: number;
  reasons: Record<string, boolean | string>;
  title?: string;
  metaDescription?: string;
}

function scoreCandidateFromContent(
  domain: string,
  tokens: string[],
  companyName: string,
  title: string,
  metaDesc: string,
  bodySnippet: string,
  hasAboutNav: boolean,
  schemaOrgName: string | null,
  jobCorroboration: boolean,
  linkedInCorroboration: boolean,
): number {
  let score = 0;
  const lower = (s: string) => s.toLowerCase();
  const titleLower = lower(title);
  const metaLower = lower(metaDesc);
  const bodyLower = lower(bodySnippet);

  // title contains name tokens (0.35)
  const titleHits = tokens.filter(t => titleLower.includes(t));
  if (titleHits.length > 0) score += 0.35 * (titleHits.length / tokens.length);

  // meta description contains tokens (0.15)
  const metaHits = tokens.filter(t => metaLower.includes(t));
  if (metaHits.length > 0) score += 0.15 * (metaHits.length / tokens.length);

  // schema.org org name match (0.25)
  if (schemaOrgName) {
    const schemaTokens = nameTokens(schemaOrgName);
    const overlap = tokens.filter(t => schemaTokens.includes(t));
    if (overlap.length > 0) score += 0.25 * (overlap.length / Math.max(tokens.length, 1));
  }

  // footer / body mention (0.10)
  const bodyHits = tokens.filter(t => bodyLower.includes(t));
  if (bodyHits.length > 0) score += 0.10 * (bodyHits.length / tokens.length);

  // has about/contact nav (0.05)
  if (hasAboutNav) score += 0.05;

  // job context corroboration (0.10)
  if (jobCorroboration) score += 0.10;

  // ── Acronym match bonus (+0.15) ──
  // If company name looks like an acronym (e.g. "TCS", "IBM", "SAP")
  const nameUpper = companyName.trim();
  const isAcronym = nameUpper.length <= 5 && nameUpper === nameUpper.toUpperCase() && /^[A-Z]{2,5}$/.test(nameUpper);
  if (isAcronym) {
    const acronymLower = nameUpper.toLowerCase();
    // Check og:site_name, schema org name, logo alt text, title
    const ogSiteMatch = bodyLower.includes(`"og:site_name"`) && bodyLower.includes(acronymLower);
    const schemaMatch = schemaOrgName && schemaOrgName.toLowerCase().includes(acronymLower);
    const titleMatch = titleLower.includes(acronymLower);
    if (ogSiteMatch || schemaMatch || titleMatch) {
      score += 0.15;
    }
  }

  // ── LinkedIn corroboration bonus (+0.15) ──
  // If the page links to the same LinkedIn company page or mentions a matching org name
  if (linkedInCorroboration) {
    score += 0.15;
  }

  return Math.min(score, 1.0);
}

// ── Firecrawl search returning candidates (not a single domain) ──
interface RawCandidate {
  domain: string;
  url: string;
  source: string;
  title?: string;
  description?: string;
  markdown?: string;
}

async function harvestCandidatesFirecrawl(companyName: string, apiKey: string): Promise<{ candidates: RawCandidate[]; linkedInUrl?: string }> {
  const candidates: RawCandidate[] = [];
  let linkedInUrl: string | undefined;

  const queries = [
    `"${companyName}" official website`,
    `"${companyName}" careers about`,
  ];

  for (const query of queries) {
    try {
      const resp = await fetch('https://api.firecrawl.dev/v1/search', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, limit: 5 }),
      });
      if (!resp.ok) { console.warn(`[Firecrawl] search ${resp.status}`); continue; }
      const data = await resp.json();
      for (const r of (data.data || [])) {
        const url = r.url || '';
        if (url.includes('linkedin.com/company') && !linkedInUrl) { linkedInUrl = url; continue; }
        const domain = extractDomain(url);
        if (!domain || isDenied(domain)) continue;
        // dedupe
        if (candidates.some(c => c.domain === domain)) continue;
        candidates.push({ domain, url, source: 'firecrawl', title: r.title, description: r.description, markdown: r.markdown?.slice(0, 1500) });
      }
    } catch (e) { console.warn('[Firecrawl] error', e); }
  }

  return { candidates, linkedInUrl };
}

// ── Extract domains from job context ──
function extractDomainsFromJobContext(jobDescription?: string, jobUrl?: string): RawCandidate[] {
  if (!jobDescription && !jobUrl) return [];
  const candidates: RawCandidate[] = [];
  const text = (jobDescription || '') + ' ' + (jobUrl || '');
  
  // Extract URLs
  const urlRegex = /https?:\/\/[^\s"'<>]+/gi;
  const matches = text.match(urlRegex) || [];
  for (const m of matches) {
    const domain = extractDomain(m);
    if (domain && !isDenied(domain) && !candidates.some(c => c.domain === domain)) {
      candidates.push({ domain, url: m, source: 'job_context' });
    }
  }
  
  // Extract email domains
  const emailRegex = /[\w.-]+@([\w.-]+\.\w+)/gi;
  let em;
  while ((em = emailRegex.exec(text)) !== null) {
    const domain = em[1].toLowerCase();
    if (!isDenied(domain) && !candidates.some(c => c.domain === domain)) {
      candidates.push({ domain, url: `https://${domain}`, source: 'job_email' });
    }
  }

  return candidates;
}

// ── Lightweight page fetch for validation ──
async function lightFetch(domain: string, linkedInUrl?: string): Promise<{ title: string; metaDesc: string; bodySnippet: string; hasAboutNav: boolean; schemaOrgName: string | null; finalDomain: string; ok: boolean; linkedInCorroboration: boolean }> {
  const empty = { title: '', metaDesc: '', bodySnippet: '', hasAboutNav: false, schemaOrgName: null as string | null, finalDomain: domain, ok: false, linkedInCorroboration: false };
  try {
    const resp = await fetch(`https://${domain}`, { redirect: 'follow', signal: AbortSignal.timeout(6000) });
    if (!resp.ok) return { ...empty, finalDomain: extractDomain(resp.url) || domain };
    const finalDomain = extractDomain(resp.url) || domain;
    const html = await resp.text();
    const first5k = html.slice(0, 8000);

    const titleMatch = first5k.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const title = titleMatch?.[1]?.trim() || '';

    const metaMatch = first5k.match(/<meta[^>]*name=["']description["'][^>]*content=["']([\s\S]*?)["']/i);
    const metaDesc = metaMatch?.[1]?.trim() || '';

    const hasAboutNav = /href=["'][^"']*\/(about|company|who-we-are|over-ons)[/"']/i.test(first5k);

    let schemaOrgName: string | null = null;
    const schemaMatch = first5k.match(/"@type"\s*:\s*"Organization"[\s\S]*?"name"\s*:\s*"([^"]+)"/i);
    if (schemaMatch) schemaOrgName = schemaMatch[1];

    // LinkedIn corroboration: check if page links to the same LinkedIn company page
    let linkedInCorroboration = false;
    if (linkedInUrl) {
      const linkedInSlug = linkedInUrl.replace(/^https?:\/\/(www\.)?linkedin\.com\/company\//i, '').replace(/\/$/, '').toLowerCase();
      if (linkedInSlug && first5k.toLowerCase().includes(linkedInSlug)) {
        linkedInCorroboration = true;
      }
    }

    // body text snippet (strip tags, take first 500 chars)
    const bodySnippet = first5k.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 500);

    return { title, metaDesc, bodySnippet, hasAboutNav, schemaOrgName, finalDomain, ok: true, linkedInCorroboration };
  } catch {
    return empty;
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // ── Auth ──
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authentication required' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const isSystemCaller = authHeader === `Bearer ${supabaseServiceRoleKey}`;

    let supabaseClient;
    if (isSystemCaller) {
      console.log('System caller detected');
      supabaseClient = createClient(Deno.env.get('SUPABASE_URL') ?? '', supabaseServiceRoleKey);
    } else {
      supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
        { global: { headers: { Authorization: authHeader } } }
      );
      const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
      if (userError || !user) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }
      const { data: role } = await supabaseClient.rpc('get_user_role', { _user_id: user.id });
      if (!role || !['recruiter', 'admin'].includes(String(role))) {
        return new Response(JSON.stringify({ error: 'Insufficient permissions' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }
    }

    const { companyName, jobDescription, companyId, quickMode, force } = await req.json();
    if (!companyName) {
      return new Response(JSON.stringify({ error: 'Company name is required' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const isQuickMode = quickMode === true;
    const isForce = force === true;
    console.log(`[lookup-domain-v2] company="${companyName}" id=${companyId} quick=${isQuickMode} force=${isForce}`);

    const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
    let FIRECRAWL_API_KEY = Deno.env.get('FIRECRAWL_API_KEY');
    try {
      const { data: secretSetting } = await supabaseClient
        .from('app_settings').select('setting_value').eq('setting_key', 'secret_firecrawl_api_key').single();
      if (secretSetting?.setting_value) { FIRECRAWL_API_KEY = secretSetting.setting_value; }
    } catch {}

    if (!OPENAI_API_KEY) {
      return new Response(JSON.stringify({ error: 'OpenAI API key not configured' }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // ── Step 0: Check locked alias or already resolved ──
    const normName = normaliseName(companyName);
    const tokens = nameTokens(companyName);

    // 0a) Alias lookup
    const { data: alias } = await supabaseClient
      .from('company_domain_aliases')
      .select('domain, locked, confidence')
      .ilike('company_name_alias', normName)
      .order('confidence', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (alias?.domain) {
      console.log(`[alias] Found alias: ${normName} → ${alias.domain} (locked=${alias.locked})`);
      if (companyId) {
        await supabaseClient.from('companies').update({
          domain: alias.domain,
          website_url: `https://${alias.domain}`,
          domain_status: 'resolved',
          domain_quality_score: alias.confidence || 1.0,
          domain_quality_reasons: { source: 'alias', locked: alias.locked },
        }).eq('id', companyId);
      }
      return new Response(JSON.stringify({
        success: true,
        data: { domain: alias.domain, confidence: 'high', source: 'alias' },
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // 0b) Already resolved? (skip if force)
    if (companyId && !isForce) {
      const { data: existing } = await supabaseClient
        .from('companies')
        .select('domain, domain_status, domain_quality_score')
        .eq('id', companyId)
        .single();
      if (existing?.domain && existing.domain_status === 'resolved') {
        console.log(`[skip] Already resolved: ${existing.domain}`);
        return new Response(JSON.stringify({
          success: true,
          data: { domain: existing.domain, confidence: 'high', source: 'cached' },
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }
    }

    // ── Step 1: Harvest candidates ──
    const allCandidates: RawCandidate[] = [];

    // 1a) Firecrawl (skip in quickMode)
    let linkedInUrl: string | undefined;
    if (FIRECRAWL_API_KEY && !isQuickMode) {
      const fc = await harvestCandidatesFirecrawl(companyName, FIRECRAWL_API_KEY);
      allCandidates.push(...fc.candidates);
      linkedInUrl = fc.linkedInUrl;
    }

    // 1b) Job context
    allCandidates.push(...extractDomainsFromJobContext(jobDescription));

    // Dedupe
    const seen = new Set<string>();
    const uniqueCandidates = allCandidates.filter(c => {
      if (seen.has(c.domain)) return false;
      seen.add(c.domain);
      return true;
    });

    console.log(`[candidates] ${uniqueCandidates.length} unique candidates: ${uniqueCandidates.map(c => c.domain).join(', ')}`);

    // ── Step 2: Validate & score candidates (cap at 6) ──
    const toValidate = uniqueCandidates.slice(0, 6);
    const scored: CandidateScore[] = [];

    // Check if domain appears in job context for corroboration
    const jobText = (jobDescription || '').toLowerCase();

    await Promise.all(toValidate.map(async (cand) => {
      if (isQuickMode) {
        // In quick mode, score purely from search result metadata
        const titleHits = tokens.filter(t => (cand.title || '').toLowerCase().includes(t));
        const descHits = tokens.filter(t => (cand.description || '').toLowerCase().includes(t));
        const jobCorr = jobText.includes(cand.domain);
        let score = 0;
        if (titleHits.length > 0) score += 0.35 * (titleHits.length / tokens.length);
        if (descHits.length > 0) score += 0.25 * (descHits.length / tokens.length);
        if (jobCorr) score += 0.10;
        // Bonus for source diversity
        if (cand.source === 'job_context' || cand.source === 'job_email') score += 0.15;
        scored.push({
          domain: cand.domain,
          source: cand.source,
          score: Math.min(score, 1.0),
          reasons: { titleHits: titleHits.length > 0, descHits: descHits.length > 0, jobCorr, quickMode: true },
          title: cand.title,
        });
        return;
      }

      // Full validation: light fetch
      const page = await lightFetch(cand.domain, linkedInUrl);
      const jobCorr = jobText.includes(cand.domain);

      // If redirected to a denied domain, skip
      if (page.finalDomain !== cand.domain && isDenied(page.finalDomain)) {
        console.log(`[validate] ${cand.domain} redirected to denied ${page.finalDomain}`);
        return;
      }

      const score = page.ok
        ? scoreCandidateFromContent(cand.domain, tokens, companyName, page.title, page.metaDesc, page.bodySnippet, page.hasAboutNav, page.schemaOrgName, jobCorr, page.linkedInCorroboration)
        : 0.05; // unreachable domain gets minimal score

      scored.push({
        domain: page.finalDomain !== cand.domain ? page.finalDomain : cand.domain,
        source: cand.source,
        score,
        reasons: {
          title_match: page.title,
          meta_match: page.metaDesc.slice(0, 100),
          schema_org: page.schemaOrgName || false,
          about_nav: page.hasAboutNav,
          job_corr: jobCorr,
          linkedin_corr: page.linkedInCorroboration,
          redirected: page.finalDomain !== cand.domain ? page.finalDomain : false,
          reachable: page.ok,
        },
        title: page.title,
      });
    }));

    // Sort by score desc
    scored.sort((a, b) => b.score - a.score);
    console.log(`[scored] ${scored.map(s => `${s.domain}=${s.score.toFixed(2)}`).join(', ')}`);

    // ── Step 3: AI tie-breaker (only from shortlist) ──
    let chosenDomain: string | null = null;
    let chosenScore = 0;
    let chosenSource = 'none';
    let aiUsed = false;

    if (scored.length === 0) {
      // No candidates at all — let AI try (constrained)
      console.log('[ai-fallback] No candidates found, asking AI for domain guess');
      // We'll still ask AI but it will be stored as low_confidence
    } else if (scored[0].score >= 0.70) {
      // Clear winner
      chosenDomain = scored[0].domain;
      chosenScore = scored[0].score;
      chosenSource = scored[0].source;
    } else if (scored.length >= 2 && scored[0].score - scored[1].score < 0.05 && scored[0].score >= 0.30) {
      // Tie — use AI to break
      aiUsed = true;
      console.log('[ai-tiebreaker] Top candidates too close, asking AI');
    } else if (scored[0].score >= 0.40) {
      // Moderate confidence — accept but mark low_confidence
      chosenDomain = scored[0].domain;
      chosenScore = scored[0].score;
      chosenSource = scored[0].source;
    } else {
      // Below threshold — try AI
      aiUsed = true;
      console.log('[ai-fallback] Top score too low, asking AI');
    }

    // AI call (tie-breaker or fallback)
    if (aiUsed || (!chosenDomain && scored.length > 0)) {
      const candidateList = scored.slice(0, 5).map(s => ({
        domain: s.domain,
        score: s.score.toFixed(2),
        title: s.title || '',
        source: s.source,
      }));

      const aiPrompt = `You are selecting the OFFICIAL corporate website domain for "${companyName}".

Here are the candidate domains found from web search, with their validation scores:
${JSON.stringify(candidateList, null, 2)}

${jobDescription ? `Job context (use to corroborate): ${jobDescription.slice(0, 500)}` : ''}

RULES:
- You MUST choose one domain FROM THIS LIST. Do NOT invent or guess a domain.
- If none seem correct, respond with {"domain": null, "reason": "none match"}.
- Prefer higher-scored candidates unless you have strong evidence another is better.

Respond ONLY with JSON: {"domain": "chosen.com", "reason": "explanation"}`;

      try {
        const aiResp = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
              { role: 'system', content: 'You select official company domains from a provided list. Never invent domains.' },
              { role: 'user', content: aiPrompt },
            ],
            temperature: 0.1,
            max_tokens: 150,
          }),
        });

        if (aiResp.ok) {
          const aiData = await aiResp.json();
          const content = aiData.choices?.[0]?.message?.content || '';
          const jsonMatch = content.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[0]);
            if (parsed.domain && scored.some(s => s.domain === parsed.domain)) {
              chosenDomain = parsed.domain;
              chosenScore = scored.find(s => s.domain === parsed.domain)!.score;
              chosenSource = 'ai_tiebreaker';
              console.log(`[ai] Chose: ${chosenDomain} reason: ${parsed.reason}`);
            } else if (parsed.domain) {
              console.log(`[ai] Returned domain not in list: ${parsed.domain} — ignoring`);
            }
          }
        }
      } catch (e) {
        console.warn('[ai] tie-breaker failed', e);
      }
    }

    // If still no domain and we have NO candidates, do a last-resort AI lookup
    // but constrain it to produce metadata without inventing a domain
    let aiMetadata: Record<string, unknown> = {};
    if (!chosenDomain && scored.length === 0) {
      console.log('[ai-metadata] No candidates, asking AI for company metadata only');
      try {
        const metaResp = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
              { role: 'system', content: 'You are a business research assistant. Provide company metadata.' },
              { role: 'user', content: `Provide metadata for "${companyName}". Return JSON: {"industry":"...","employee_count":N,"address":"City, Country","linkedin_url":"...","description":"..."}. If unsure, use null. Do NOT guess a domain.` },
            ],
            temperature: 0.3,
            max_tokens: 200,
          }),
        });
        if (metaResp.ok) {
          const d = await metaResp.json();
          const c = d.choices?.[0]?.message?.content || '';
          const m = c.match(/\{[\s\S]*\}/);
          if (m) aiMetadata = JSON.parse(m[0]);
        }
      } catch {}
    }

    // ── Step 4: Post-processing — wipe any denylisted domain ──
    if (chosenDomain && isDenied(chosenDomain)) {
      console.log(`[denylist] Chosen domain ${chosenDomain} is denylisted — forcing unresolved`);
      chosenDomain = null;
      chosenScore = 0;
      chosenSource = 'denied';
    }

    // ── Step 5: Determine status & write results ──
    let domainStatus: string;
    if (!chosenDomain) {
      domainStatus = 'unresolved';
    } else if (chosenScore >= 0.70) {
      domainStatus = 'resolved';
    } else if (chosenScore >= 0.40) {
      domainStatus = 'low_confidence';
    } else {
      domainStatus = 'unresolved';
    }

    const candidatesJson = scored.slice(0, 8).map(s => ({
      domain: s.domain,
      score: parseFloat(s.score.toFixed(3)),
      source: s.source,
      title: s.title || null,
    }));

    const qualityReasons: Record<string, unknown> = {};
    if (chosenDomain) {
      const chosen = scored.find(s => s.domain === chosenDomain);
      if (chosen) qualityReasons.reasons = chosen.reasons;
      qualityReasons.ai_used = aiUsed;
      qualityReasons.source = chosenSource;
    }

    console.log(`[result] domain=${chosenDomain} status=${domainStatus} score=${chosenScore.toFixed(2)}`);

    if (companyId) {
      // Fetch max company employees setting
      let maxCompanyEmployees = 500;
      try {
        const { data: settings } = await supabaseClient
          .from('app_settings').select('setting_value').eq('setting_key', 'max_company_employees').single();
        if (settings?.setting_value) {
          const parsed = parseInt(settings.setting_value, 10);
          if (!isNaN(parsed)) maxCompanyEmployees = parsed;
        }
      } catch {}

      const updateData: Record<string, unknown> = {
        domain_status: domainStatus,
        domain_quality_score: parseFloat(chosenScore.toFixed(3)),
        domain_candidates: candidatesJson,
        domain_quality_reasons: qualityReasons,
      };

      // Only set domain if resolved or low_confidence (not unresolved)
      if (chosenDomain && domainStatus !== 'unresolved') {
        // Check for duplicate domain
        const { data: existingCompany } = await supabaseClient
          .from('companies').select('id, name').eq('domain', chosenDomain).neq('id', companyId).maybeSingle();

        if (existingCompany) {
          console.log(`[duplicate] Domain ${chosenDomain} already belongs to ${existingCompany.name}`);
          updateData.domain_quality_reasons = { ...qualityReasons as Record<string, unknown>, duplicate_of: existingCompany.id };
          // Don't set domain — leave it for the duplicate company
        } else {
          updateData.domain = chosenDomain;
          updateData.website_url = `https://${chosenDomain}`;
          updateData.enrichment_status = 'pending';
        }
      }

      if (linkedInUrl) updateData.linkedin_url = linkedInUrl;

      // Apply AI metadata if we got it (no-domain fallback)
      if (aiMetadata.industry) updateData.industry = aiMetadata.industry;
      if (aiMetadata.description) updateData.description = aiMetadata.description;
      if (aiMetadata.address) updateData.address = aiMetadata.address;
      if (aiMetadata.linkedin_url && !linkedInUrl) updateData.linkedin_url = aiMetadata.linkedin_url;
      if (typeof aiMetadata.employee_count === 'number') {
        if ((aiMetadata.employee_count as number) > maxCompanyEmployees) {
          updateData.employee_count = maxCompanyEmployees;
          updateData.enrichment_status = 'exceeds_size';
        } else {
          updateData.employee_count = aiMetadata.employee_count;
        }
      }

      // If domain unresolved, don't set enrichment_status to pending (it would trigger enrichment with no domain)
      if (domainStatus === 'unresolved' && !updateData.enrichment_status) {
        updateData.enrichment_status = 'domain_unresolved';
      }

      const { error: updateError } = await supabaseClient.from('companies').update(updateData).eq('id', companyId);
      if (updateError) {
        console.error('Error updating company:', updateError);
      } else {
        console.log(`[updated] company ${companyId}`);
      }
    }

    return new Response(JSON.stringify({
      success: true,
      data: {
        domain: chosenDomain,
        domain_status: domainStatus,
        domain_quality_score: parseFloat(chosenScore.toFixed(3)),
        candidates: candidatesJson,
        linkedin_url: linkedInUrl || (aiMetadata.linkedin_url as string) || null,
        confidence: domainStatus === 'resolved' ? 'high' : domainStatus === 'low_confidence' ? 'medium' : 'low',
        ai_used: aiUsed,
        ...aiMetadata,
      },
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

  } catch (error) {
    console.error('Error in lookup-company-domain:', error);
    return new Response(JSON.stringify({
      error: 'An error occurred while looking up company domain.',
      details: error instanceof Error ? error.message : String(error),
    }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
