import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url, name } = await req.json();

    if (!url) {
      return new Response(
        JSON.stringify({ success: false, error: 'URL is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const FIRECRAWL_API_KEY = Deno.env.get('FIRECRAWL_API_KEY');
    if (!FIRECRAWL_API_KEY) {
      return new Response(
        JSON.stringify({ success: false, error: 'Firecrawl connector not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      return new Response(
        JSON.stringify({ success: false, error: 'AI gateway not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Format URL
    let formattedUrl = url.trim();
    if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
      formattedUrl = `https://${formattedUrl}`;
    }

    console.log('Detecting search template for:', formattedUrl);

    // Step 1: Use Firecrawl map to discover URLs on the site
    const mapResponse = await fetch('https://api.firecrawl.dev/v1/map', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url: formattedUrl,
        search: 'jobs search careers',
        limit: 50,
        includeSubdomains: true,
      }),
    });

    let siteUrls: string[] = [];
    if (mapResponse.ok) {
      const mapData = await mapResponse.json();
      siteUrls = mapData.links || [];
      console.log(`Map found ${siteUrls.length} URLs`);
    } else {
      console.warn('Map failed, continuing with scrape only');
    }

    // Step 2: Scrape the homepage + any jobs/search page we found
    const scrapeResponse = await fetch('https://api.firecrawl.dev/v1/scrape', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url: formattedUrl,
        formats: ['links', 'markdown'],
        onlyMainContent: false,
      }),
    });

    let pageContent = '';
    let pageLinks: string[] = [];
    if (scrapeResponse.ok) {
      const scrapeData = await scrapeResponse.json();
      pageContent = scrapeData.data?.markdown || scrapeData.markdown || '';
      pageLinks = scrapeData.data?.links || scrapeData.links || [];
      console.log(`Scrape found ${pageLinks.length} links`);
    }

    // Combine all discovered URLs
    const allUrls = [...new Set([...siteUrls, ...pageLinks])];
    
    // Filter to job/search related URLs
    const jobRelatedUrls = allUrls.filter(u => 
      /job|career|search|vacanc|position|opening|listing|find|work|employ|hire/i.test(u)
    ).slice(0, 30);

    console.log(`Found ${jobRelatedUrls.length} job-related URLs`);

    // Step 3: Use AI to analyze and determine the search URL template
    const domain = new URL(formattedUrl).hostname;
    
    const aiPrompt = `You are an expert at analyzing job board websites. Given the following information about the job board "${name || domain}", determine the search URL template pattern.

SITE URL: ${formattedUrl}
DOMAIN: ${domain}

JOB-RELATED URLS FOUND ON THE SITE:
${jobRelatedUrls.join('\n')}

HOMEPAGE CONTENT (first 2000 chars):
${pageContent.substring(0, 2000)}

YOUR TASK:
Analyze the URLs and page content to determine the search URL template for this job board. The template should use these placeholders:
- {keywords} - for search terms/job title keywords
- {location} - for location/city
- {city} - for city specifically
- {state} - for state/province
- {radius_mi} - for search radius in miles

Look for patterns in the URLs that suggest search parameters (like ?q=, ?search=, ?keywords=, ?title=, ?location=, ?l=, etc.).

RULES:
1. Return ONLY the URL template string, nothing else
2. Use the most specific/useful URL pattern you can find
3. If you find a jobs search page with query parameters, use that pattern
4. Make sure the base URL is correct (https, correct domain, correct path)
5. Include {keywords} and {location} at minimum
6. If you cannot determine a reliable template, return "UNKNOWN"

Example outputs:
- https://www.indeed.com/jobs?q={keywords}&l={location}
- https://builtin.com/jobs?search={keywords}&location={location}
- https://www.linkedin.com/jobs/search/?keywords={keywords}&location={location}

SEARCH URL TEMPLATE:`;

    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash-lite',
        messages: [
          { role: 'user', content: aiPrompt },
        ],
        temperature: 0.1,
      }),
    });

    if (!aiResponse.ok) {
      const errText = await aiResponse.text();
      console.error('AI gateway error:', aiResponse.status, errText);
      return new Response(
        JSON.stringify({ success: false, error: 'AI analysis failed' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const aiData = await aiResponse.json();
    const template = (aiData.choices?.[0]?.message?.content || '').trim();

    console.log('AI detected template:', template);

    if (!template || template === 'UNKNOWN' || !template.startsWith('http')) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Could not automatically detect search URL pattern. Please enter it manually.',
          urls_found: jobRelatedUrls.slice(0, 10),
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        template,
        urls_analyzed: jobRelatedUrls.length,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error detecting template:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
