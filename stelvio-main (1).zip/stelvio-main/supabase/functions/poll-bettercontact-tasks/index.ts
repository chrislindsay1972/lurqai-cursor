// Polls pending BetterContact tasks and updates stakeholder emails when complete
// Uses explicit columns (bettercontact_task_id, bettercontact_status) instead of notes parsing
// Includes watchdog TTL: re-poll aggressively after 30min, mark error after 24h
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  // Hoist body parsing to top to prevent "body already consumed" errors
  let bodyText = "";
  try { bodyText = await req.text(); } catch { /* no body is fine for cron */ }

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const BETTERCONTACT_API_KEY = Deno.env.get("BETTERCONTACT_API_KEY");
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  if (!BETTERCONTACT_API_KEY) {
    return new Response(JSON.stringify({ error: "BetterContact API key not configured" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // ─── PHASE 1: Poll pending tasks using explicit columns ───────────────────
  const { data: stakeholders, error } = await supabase
    .from("stakeholders")
    .select("id, name, notes, email, bettercontact_task_id, bettercontact_submitted_at, bettercontact_last_polled_at, bettercontact_status, company_id")
    .eq("bettercontact_status", "pending")
    .not("bettercontact_task_id", "is", null)
    .is("email", null)
    .limit(50);

  if (error) {
    console.error("DB query error:", error);
    return new Response(JSON.stringify({ error: "DB error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  console.log(`[BC Poller] Found ${stakeholders?.length || 0} pending stakeholders`);

  let resolved = 0;
  let stillPending = 0;
  let expired = 0;
  let errors = 0;

  for (const sh of stakeholders || []) {
    const taskId = sh.bettercontact_task_id;
    if (!taskId) continue;

    const submittedAt = sh.bettercontact_submitted_at ? new Date(sh.bettercontact_submitted_at) : null;
    const now = new Date();
    const ageMinutes = submittedAt ? (now.getTime() - submittedAt.getTime()) / 60000 : 0;

    // ─── WATCHDOG: Mark as error if pending > 24 hours ──────────────────
    if (ageMinutes > 1440) {
      console.log(`[BC Poller] Task ${taskId} for ${sh.name} expired (${Math.round(ageMinutes)}min old) — marking error`);
      await supabase.from("stakeholders").update({
        bettercontact_status: "error",
        bettercontact_last_polled_at: now.toISOString(),
        enrichment_source: "bettercontact_expired",
      }).eq("id", sh.id);

      // Log to attempts table
      await supabase.from("stakeholder_enrichment_attempts").insert({
        stakeholder_id: sh.id,
        company_id: sh.company_id || null,
        status: "failed",
        final_source: "bettercontact",
        error: `Task ${taskId} expired after ${Math.round(ageMinutes)} minutes without resolution`,
        trace: [{ tier: "bettercontact_watchdog", action: "expired", age_minutes: Math.round(ageMinutes), task_id: taskId }],
        finished_at: now.toISOString(),
      });

      expired++;
      continue;
    }

    // ─── Backoff: skip if polled recently (< 3 min) unless > 30 min old ─
    const lastPolled = sh.bettercontact_last_polled_at ? new Date(sh.bettercontact_last_polled_at) : null;
    const sincePollMinutes = lastPolled ? (now.getTime() - lastPolled.getTime()) / 60000 : Infinity;
    const isAggressive = ageMinutes > 30;

    if (!isAggressive && sincePollMinutes < 3) {
      console.log(`[BC Poller] Skipping ${sh.name} — polled ${Math.round(sincePollMinutes)}min ago (not yet aggressive)`);
      stillPending++;
      continue;
    }

    console.log(`[BC Poller] Checking task ${taskId} for ${sh.name} (age=${Math.round(ageMinutes)}min, aggressive=${isAggressive})...`);

    try {
      const pollResponse = await fetch(`https://app.bettercontact.rocks/api/v2/async/${taskId}`, {
        headers: { "X-API-Key": BETTERCONTACT_API_KEY },
      });

      // Always update last polled time
      await supabase.from("stakeholders").update({
        bettercontact_last_polled_at: now.toISOString(),
      }).eq("id", sh.id);

      if (!pollResponse.ok) {
        console.log(`[BC Poller] Poll failed for task ${taskId}: ${pollResponse.status}`);
        errors++;
        continue;
      }

      const pollResult = await pollResponse.json();
      console.log(`[BC Poller] Task ${taskId} status: ${pollResult.status}`);

      if (pollResult.status === "terminated" || pollResult.status === "completed") {
        const resultData = pollResult.data?.[0] || pollResult.results?.[0];
        console.log(`[BC Poller] Result data keys: ${resultData ? Object.keys(resultData).join(', ') : 'NO DATA'}`);

        const foundEmail = resultData?.contact_email_address || resultData?.email_address || resultData?.email || null;
        const emailStatus = resultData?.contact_email_address_status || resultData?.email_status || null;

        // Clean legacy bc_task tag from notes if present
        const cleanedNotes = sh.notes?.replace(/\s*\[bc_task:[a-zA-Z0-9]+\]/g, "").trim() || null;

        if (foundEmail) {
          const provider = resultData?.email_provider || null;
          console.log(`[BC Poller] ✓ Email found for ${sh.name}: ${foundEmail} (status=${emailStatus}, provider=${provider})`);
          await supabase.from("stakeholders").update({
            email: foundEmail,
            email_status: emailStatus || "verified",
            email_provider: provider,
            enrichment_source: "bettercontact",
            notes: cleanedNotes,
            bettercontact_data: pollResult,
            bettercontact_status: "done",
            bettercontact_last_polled_at: now.toISOString(),
            email_confidence: emailStatus === "verified" || emailStatus === "valid" ? 0.95 : 0.7,
          }).eq("id", sh.id);

          // Update attempt record if one exists
          await supabase.from("stakeholder_enrichment_attempts")
            .update({
              status: "succeeded",
              final_email: foundEmail,
              final_email_status: emailStatus || "verified",
              final_source: "bettercontact",
              finished_at: now.toISOString(),
              trace: supabase.rpc ? undefined : undefined, // trace already written at submission
            })
            .eq("stakeholder_id", sh.id)
            .eq("status", "pending_async");

          resolved++;
        } else {
          console.log(`[BC Poller] No email for ${sh.name} — task ${pollResult.status}`);
          await supabase.from("stakeholders").update({
            notes: cleanedNotes,
            enrichment_source: "bettercontact_not_found",
            bettercontact_status: "not_found",
            bettercontact_last_polled_at: now.toISOString(),
          }).eq("id", sh.id);

          await supabase.from("stakeholder_enrichment_attempts")
            .update({
              status: "failed",
              final_source: "bettercontact",
              error: "BetterContact completed but no email found",
              finished_at: now.toISOString(),
            })
            .eq("stakeholder_id", sh.id)
            .eq("status", "pending_async");
        }
      } else {
        stillPending++;
        console.log(`[BC Poller] Task ${taskId} still in progress`);
      }
    } catch (e) {
      console.error(`[BC Poller] Error for task ${taskId}:`, e);
      errors++;
    }
  }

  // ─── PHASE 2: Reconcile stuck/orphaned records ────────────────────────────
  // Find stakeholders with bettercontact_pending but no task_id (submission failed)
  const { data: orphaned } = await supabase
    .from("stakeholders")
    .select("id, name, company_id")
    .eq("enrichment_source", "bettercontact_pending")
    .is("bettercontact_task_id", null)
    .is("email", null)
    .limit(20);

  let reconciled = 0;
  for (const orphan of orphaned || []) {
    console.log(`[BC Poller] Reconciling orphan: ${orphan.name} (no task_id but bettercontact_pending)`);

    // Also check legacy notes for task_id
    const { data: full } = await supabase
      .from("stakeholders")
      .select("notes")
      .eq("id", orphan.id)
      .single();

    const legacyMatch = full?.notes?.match(/\[bc_task:([a-zA-Z0-9]+)\]/);
    if (legacyMatch) {
      // Migrate legacy task_id to explicit column
      console.log(`[BC Poller] Migrating legacy task_id ${legacyMatch[1]} for ${orphan.name}`);
      await supabase.from("stakeholders").update({
        bettercontact_task_id: legacyMatch[1],
        bettercontact_status: "pending",
        bettercontact_submitted_at: new Date().toISOString(), // approximate
      }).eq("id", orphan.id);
    } else {
      // Truly orphaned — mark needs_review
      await supabase.from("stakeholders").update({
        enrichment_source: "bettercontact_failed",
        bettercontact_status: "error",
      }).eq("id", orphan.id);

      await supabase.from("stakeholder_enrichment_attempts").insert({
        stakeholder_id: orphan.id,
        company_id: orphan.company_id || null,
        status: "needs_review",
        error: "BetterContact submission likely failed — no task_id found",
        trace: [{ tier: "bettercontact_reconcile", action: "orphan_detected" }],
        finished_at: new Date().toISOString(),
      });
    }
    reconciled++;
  }

  // ─── PHASE 3: Legacy migration — pick up old notes-based tasks ────────────
  const { data: legacyStakeholders } = await supabase
    .from("stakeholders")
    .select("id, name, notes")
    .ilike("notes", "%[bc_task:%]%")
    .is("bettercontact_task_id", null)
    .is("email", null)
    .limit(50);

  let migrated = 0;
  for (const ls of legacyStakeholders || []) {
    const match = ls.notes?.match(/\[bc_task:([a-zA-Z0-9]+)\]/);
    if (match) {
      console.log(`[BC Poller] Legacy migration: ${ls.name} → task_id=${match[1]}`);
      await supabase.from("stakeholders").update({
        bettercontact_task_id: match[1],
        bettercontact_status: "pending",
        bettercontact_submitted_at: new Date().toISOString(),
      }).eq("id", ls.id);
      migrated++;
    }
  }

  console.log(`[BC Poller] Done: ${resolved} resolved, ${stillPending} pending, ${expired} expired, ${errors} errors, ${reconciled} reconciled, ${migrated} legacy migrated`);

  return new Response(
    JSON.stringify({
      success: true,
      resolved,
      stillPending,
      expired,
      errors,
      reconciled,
      migrated,
      checked: stakeholders?.length || 0,
    }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
});
