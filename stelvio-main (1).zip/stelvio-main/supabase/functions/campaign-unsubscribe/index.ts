import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const email = url.searchParams.get("email");
    const campaignId = url.searchParams.get("campaign_id");

    if (!email) {
      return new Response(renderPage("Missing email parameter.", false), {
        status: 400,
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Record opt-out
    const { error } = await supabase.from("opt_out_records").insert({
      email_address: email,
      campaign_id: campaignId || null,
      opt_out_reason: "unsubscribe_link",
    });

    if (error) {
      // Duplicate or other — still show success to the user
      console.log("Opt-out insert result:", error.message);
    }

    // Also pause the stakeholder in the campaign if possible
    if (campaignId) {
      // Find stakeholder by email
      const { data: stakeholder } = await supabase
        .from("stakeholders")
        .select("id")
        .eq("email", email)
        .limit(1)
        .maybeSingle();

      if (stakeholder) {
        await supabase
          .from("stakeholder_campaign_states")
          .update({ status: "opted_out", completed_at: new Date().toISOString() })
          .eq("campaign_id", campaignId)
          .eq("stakeholder_id", stakeholder.id);
      }
    }

    return new Response(renderPage("You have been successfully unsubscribed.", true), {
      status: 200,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  } catch (err) {
    console.error("Unsubscribe error:", err);
    return new Response(renderPage("An error occurred. Please try again.", false), {
      status: 500,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }
});

function renderPage(message: string, success: boolean): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Unsubscribe</title>
  <style>
    body { font-family: Arial, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f9fafb; color: #1f2937; }
    .card { background: #fff; border-radius: 12px; padding: 48px; text-align: center; max-width: 440px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
    .icon { font-size: 48px; margin-bottom: 16px; }
    h1 { font-size: 22px; margin: 0 0 12px; }
    p { font-size: 15px; color: #6b7280; margin: 0; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">${success ? "✅" : "⚠️"}</div>
    <h1>${success ? "Unsubscribed" : "Error"}</h1>
    <p>${message}</p>
  </div>
</body>
</html>`;
}
