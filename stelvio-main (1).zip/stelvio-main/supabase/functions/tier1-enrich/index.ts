/**
 * Tier 1 Enrichment Sweep
 * 
 * High-ROI, low-cost waterfall for NO_EMAIL stakeholders:
 * 1. Hunter Email Finder + multi-pattern verify (cheapest, highest precision)
 * 2. Apollo LinkedIn (person match with full context)
 * 3. BetterContact async (broad coverage fallback)
 * 4. Pattern leverage (1 verified → many, via company_email_intel)
 * 5. Deep Discovery (last resort, company-level)
 *
 * Eligibility: email IS NULL, domain resolved (≥0.70), LinkedIn present
 */
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface Tier1Request {
  batch_size?: number;
  stakeholder_ids?: string[]; // Optional: specific IDs instead of auto-select
  dry_run?: boolean;
}

interface StakeholderTarget {
  id: string;
  name: string;
  title: string | null;
  linkedin_url: string;
  company_id: string;
  company_name: string;
  company_domain: string;
}

interface Tier1Result {
  stakeholder_id: string;
  stakeholder_name: string;
  outcome: "email_found" | "bc_pending" | "pattern_generated" | "not_found" | "error";
  email?: string;
  email_status?: string;
  source?: string;
  error?: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const APOLLO_API_KEY = Deno.env.get("APOLLO_API_KEY");
  const BETTERCONTACT_API_KEY = Deno.env.get("BETTERCONTACT_API_KEY");
  const HUNTER_API_KEY = Deno.env.get("HUNTER_API_KEY");
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  try {
    const body: Tier1Request = await req.json();
    const batchSize = Math.min(body.batch_size || 25, 50);
    const dryRun = body.dry_run || false;

    // ─── SELECT TIER 1 ELIGIBLE STAKEHOLDERS ─────────────────────────────────
    let targets: StakeholderTarget[] = [];

    if (body.stakeholder_ids?.length) {
      // Specific IDs provided
      const { data } = await supabase
        .from("stakeholders")
        .select("id, name, title, linkedin_url, company_id")
        .in("id", body.stakeholder_ids)
        .is("email", null)
        .not("linkedin_url", "is", null)
        .limit(batchSize);

      if (data?.length) {
        const companyIds = [...new Set(data.map(s => s.company_id).filter(Boolean))] as string[];
        const { data: companies } = await supabase
          .from("companies")
          .select("id, name, domain, domain_status, domain_quality_score")
          .in("id", companyIds)
          .eq("domain_status", "resolved")
          .gte("domain_quality_score", 0.7);

        const companyMap = new Map(companies?.map(c => [c.id, c]) || []);
        targets = data
          .filter(s => s.company_id && companyMap.has(s.company_id))
          .map(s => {
            const c = companyMap.get(s.company_id!)!;
            return {
              id: s.id,
              name: s.name,
              title: s.title,
              linkedin_url: s.linkedin_url!,
              company_id: c.id,
              company_name: c.name,
              company_domain: c.domain!,
            };
          });
      }
    } else {
      // Auto-select: NO_EMAIL + resolved domain + LinkedIn present
      const { data: stakeholders } = await supabase
        .from("stakeholders")
        .select("id, name, title, linkedin_url, company_id, enrichment_source, bettercontact_status")
        .is("email", null)
        .not("linkedin_url", "is", null)
        .neq("enrichment_source", "bettercontact_pending")
        .or("bettercontact_status.is.null,bettercontact_status.neq.pending")
        .limit(200);

      if (stakeholders?.length) {
        const companyIds = [...new Set(stakeholders.map(s => s.company_id).filter(Boolean))] as string[];
        const { data: companies } = await supabase
          .from("companies")
          .select("id, name, domain, domain_status, domain_quality_score")
          .in("id", companyIds)
          .eq("domain_status", "resolved")
          .gte("domain_quality_score", 0.7)
          .not("domain", "is", null);

        const companyMap = new Map(companies?.map(c => [c.id, c]) || []);

        // Check opt-outs
        const { data: optOuts } = await supabase
          .from("opt_out_records")
          .select("stakeholder_id")
          .not("stakeholder_id", "is", null);
        const optOutSet = new Set(optOuts?.map(o => o.stakeholder_id) || []);

        targets = stakeholders
          .filter(s => s.company_id && companyMap.has(s.company_id) && !optOutSet.has(s.id))
          .map(s => {
            const c = companyMap.get(s.company_id!)!;
            return {
              id: s.id,
              name: s.name,
              title: s.title,
              linkedin_url: s.linkedin_url!,
              company_id: c.id,
              company_name: c.name,
              company_domain: c.domain!,
            };
          })
          .slice(0, batchSize);
      }
    }

    if (dryRun) {
      return new Response(
        JSON.stringify({ eligible: targets.length, targets: targets.map(t => ({ id: t.id, name: t.name, company: t.company_name })) }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (targets.length === 0) {
      return new Response(
        JSON.stringify({ success: true, processed: 0, results: [], message: "No Tier 1 eligible stakeholders found" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[Tier1] Processing ${targets.length} stakeholders`);

    // ─── PROCESS EACH STAKEHOLDER ────────────────────────────────────────────
    const results: Tier1Result[] = [];
    const CONCURRENCY = 5;

    for (let i = 0; i < targets.length; i += CONCURRENCY) {
      const batch = targets.slice(i, i + CONCURRENCY);
      const batchResults = await Promise.allSettled(
        batch.map(target => processStakeholder(target, supabase, {
          APOLLO_API_KEY,
          BETTERCONTACT_API_KEY,
          HUNTER_API_KEY,
          SUPABASE_URL,
          SUPABASE_SERVICE_ROLE_KEY,
        }))
      );

      for (let j = 0; j < batchResults.length; j++) {
        const r = batchResults[j];
        if (r.status === "fulfilled") {
          results.push(r.value);
        } else {
          results.push({
            stakeholder_id: batch[j].id,
            stakeholder_name: batch[j].name,
            outcome: "error",
            error: r.reason?.message || "Unknown error",
          });
        }
      }
    }

    const summary = {
      processed: results.length,
      email_found: results.filter(r => r.outcome === "email_found").length,
      pattern_generated: results.filter(r => r.outcome === "pattern_generated").length,
      bc_pending: results.filter(r => r.outcome === "bc_pending").length,
      not_found: results.filter(r => r.outcome === "not_found").length,
      errors: results.filter(r => r.outcome === "error").length,
    };

    console.log(`[Tier1] Complete: ${JSON.stringify(summary)}`);

    return new Response(
      JSON.stringify({ success: true, ...summary, results }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[Tier1] Fatal error:", error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// ─── PER-STAKEHOLDER WATERFALL ───────────────────────────────────────────────

interface ApiKeys {
  APOLLO_API_KEY: string | undefined;
  BETTERCONTACT_API_KEY: string | undefined;
  HUNTER_API_KEY: string | undefined;
  SUPABASE_URL: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
}

async function processStakeholder(
  target: StakeholderTarget,
  supabase: ReturnType<typeof createClient>,
  keys: ApiKeys,
): Promise<Tier1Result> {
  const nameParts = target.name.split(/\s+/);
  const firstName = nameParts[0] || "";
  const lastName = nameParts.slice(1).join(" ") || "";

  console.log(`[Tier1:${target.name}] Starting waterfall (${target.company_domain})`);

  // Create attempt row
  const traceSteps: Array<Record<string, unknown>> = [];
  const { data: attemptRow } = await supabase
    .from("stakeholder_enrichment_attempts")
    .insert({
      stakeholder_id: target.id,
      company_id: target.company_id,
      status: "running",
      trace: [],
    })
    .select("id")
    .single();
  const attemptId = attemptRow?.id;

  function addTrace(tier: string, data: Record<string, unknown>) {
    traceSteps.push({ tier, ...data, timestamp: new Date().toISOString() });
  }

  let finalEmail: string | null = null;
  let finalEmailStatus: string | null = null;
  let finalSource: string | null = null;
  let bcTaskId: string | null = null;
  let pipelineError: string | null = null;

  try {
    // ─── STEP 1: Hunter Email Finder (multi-pattern) ──────────────────────
    if (keys.HUNTER_API_KEY) {
      console.log(`[Tier1:${target.name}] Step 1: Hunter multi-pattern finder (${target.company_domain})`);
      try {
        // Try Hunter's email-finder endpoint first (it picks the best pattern)
        const finderUrl = `https://api.hunter.io/v2/email-finder?domain=${encodeURIComponent(target.company_domain)}&first_name=${encodeURIComponent(firstName)}&last_name=${encodeURIComponent(lastName)}&api_key=${keys.HUNTER_API_KEY}`;
        const finderResp = await fetch(finderUrl, { method: "GET" });

        if (finderResp.ok) {
          const finderData = await finderResp.json();
          console.log(`[Tier1:${target.name}] Hunter finder response: score=${finderData.data?.score}, email=${finderData.data?.email || 'null'}, verification=${finderData.data?.verification?.status || 'null'}`);

          if (finderData.data?.email) {
            const hunterEmail = finderData.data.email as string;
            const hunterScore = finderData.data.score || 0;
            const verificationStatus = finderData.data.verification?.status;

            // Accept if score >= 50 OR verification says valid/accept_all
            if (hunterScore >= 50 || verificationStatus === "valid" || verificationStatus === "accept_all") {
              finalEmail = hunterEmail;
              finalEmailStatus = verificationStatus === "valid" ? "verified"
                : verificationStatus === "accept_all" ? "catch_all"
                : "guessed";
              finalSource = "hunter_finder";
              addTrace("hunter_finder", { email: hunterEmail, score: hunterScore, verification: verificationStatus, accepted: true });
              console.log(`[Tier1:${target.name}] ✓ Hunter finder hit: ${hunterEmail} (score=${hunterScore}, status=${verificationStatus})`);
            } else {
              addTrace("hunter_finder", { email: hunterEmail, score: hunterScore, verification: verificationStatus, rejected: true, reason: "low_score_and_unverified" });
              console.log(`[Tier1:${target.name}] Hunter finder low confidence: ${hunterEmail} (score=${hunterScore})`);
            }
          } else {
            addTrace("hunter_finder", { found: false });
            console.log(`[Tier1:${target.name}] Hunter finder: no email found`);
          }
        } else {
          const errText = await finderResp.text();
          addTrace("hunter_finder", { http_status: finderResp.status, error: errText.slice(0, 200) });
          console.error(`[Tier1:${target.name}] Hunter finder HTTP error ${finderResp.status}`);
        }

        // If Hunter finder didn't work, try manual pattern combinations
        if (!finalEmail) {
          console.log(`[Tier1:${target.name}] Trying manual pattern verification...`);
          const patterns = ["first.last", "firstlast", "f.last", "first_last", "flast"];
          for (const pattern of patterns) {
            const candidate = applyPattern(pattern, firstName, lastName, target.company_domain);
            if (!candidate) continue;

            const verifyResult = await verifyEmail(candidate, keys.HUNTER_API_KEY);
            console.log(`[Tier1:${target.name}] Pattern ${pattern} → ${candidate} → ${verifyResult}`);

            if (verifyResult === "verified" || verifyResult === "catch_all") {
              finalEmail = candidate;
              finalEmailStatus = verifyResult;
              finalSource = "hunter_pattern_verified";
              addTrace("hunter_pattern", { email: candidate, pattern, verify_result: verifyResult, accepted: true });
              console.log(`[Tier1:${target.name}] ✓ Pattern verified: ${candidate}`);

              // Cache pattern in company_email_intel
              await supabase.from("company_email_intel").upsert({
                company_id: target.company_id,
                domain: target.company_domain,
                pattern,
                pattern_confidence: verifyResult === "verified" ? 0.95 : 0.70,
                mx_valid: true,
                examples: [{ email: candidate, name: target.name, verified: verifyResult }],
                sources: [{ source: "hunter_pattern_verify", date: new Date().toISOString() }],
              }, { onConflict: "company_id" });

              break;
            } else {
              addTrace("hunter_pattern", { email: candidate, pattern, verify_result: verifyResult, rejected: true });
            }
          }
        }
      } catch (e) {
        addTrace("hunter_finder", { error: (e as Error).message });
        console.error(`[Tier1:${target.name}] Hunter finder error:`, e);
      }
    }

    // ─── STEP 2: Apollo LinkedIn ──────────────────────────────────────────
    if (!finalEmail && keys.APOLLO_API_KEY && target.linkedin_url) {
      console.log(`[Tier1:${target.name}] Step 2: Apollo LinkedIn`);
      try {
        const resp = await fetch("https://api.apollo.io/api/v1/people/match", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Api-Key": keys.APOLLO_API_KEY,
            "Cache-Control": "no-cache",
          },
          body: JSON.stringify({
            first_name: firstName,
            last_name: lastName,
            linkedin_url: target.linkedin_url,
            domain: target.company_domain,
            organization_name: target.company_name,
            reveal_personal_emails: false,
            reveal_phone_number: false,
          }),
        });

        const respBody = await resp.text();
        console.log(`[Tier1:${target.name}] Apollo response status=${resp.status} body=${respBody.slice(0, 500)}`);
        if (resp.ok) {
          const result = JSON.parse(respBody);
          if (result.person) {
            console.log(`[Tier1:${target.name}] Apollo person: name=${result.person.first_name} ${result.person.last_name}, email=${result.person.email || 'null'}, email_status=${result.person.email_status || 'null'}, org=${result.person.organization?.name || 'null'}`);
          } else {
            console.log(`[Tier1:${target.name}] Apollo: person=null, keys=${Object.keys(result).join(',')}`);
          }
          if (result.person?.email) {
            const email = result.person.email as string;
            const emailDomain = email.split("@")[1]?.toLowerCase();
            const domainMatch = emailDomain === target.company_domain.toLowerCase() ||
              emailDomain?.includes(target.company_domain.toLowerCase()) ||
              target.company_domain.toLowerCase().includes(emailDomain || "");

            if (domainMatch) {
              finalEmail = email;
              finalEmailStatus = result.person.email_status || "guessed";
              finalSource = "apollo_linkedin";
              addTrace("apollo_linkedin", { email, status: finalEmailStatus, accepted: true });
              console.log(`[Tier1:${target.name}] ✓ Apollo hit: ${email}`);
            } else {
              addTrace("apollo_linkedin", { email, rejected: true, reason: `domain mismatch: ${emailDomain} vs ${target.company_domain}` });
              console.log(`[Tier1:${target.name}] Apollo domain mismatch: ${emailDomain}`);
            }
          } else {
            addTrace("apollo_linkedin", { found: false });
            console.log(`[Tier1:${target.name}] Apollo: no match`);
          }
        } else {
          addTrace("apollo_linkedin", { http_status: resp.status, body_preview: respBody.slice(0, 200) });
          console.error(`[Tier1:${target.name}] Apollo HTTP error ${resp.status}: ${respBody.slice(0, 300)}`);
        }
      } catch (e) {
        addTrace("apollo_linkedin", { error: (e as Error).message });
      }
    }

    // ─── STEP 3: BetterContact Async ──────────────────────────────────────
    if (!finalEmail && keys.BETTERCONTACT_API_KEY) {
      console.log(`[Tier1:${target.name}] Step 3: BetterContact async`);
      try {
        const bcContact: Record<string, string> = { first_name: firstName, last_name: lastName };
        if (target.linkedin_url) bcContact.linkedin_url = target.linkedin_url;
        if (target.company_name) bcContact.company = target.company_name;
        if (target.company_domain) bcContact.company_domain = target.company_domain;

        const bcResp = await fetch("https://app.bettercontact.rocks/api/v2/async", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-API-Key": keys.BETTERCONTACT_API_KEY,
          },
          body: JSON.stringify({
            data: [bcContact],
            enrich_email_address: true,
            enrich_phone_number: false,
          }),
        });

        if (bcResp.ok || bcResp.status === 201) {
          const bcResult = await bcResp.json();
          bcTaskId = bcResult.id || bcResult.task_id || bcResult.taskId || null;
          if (bcTaskId) {
            addTrace("bettercontact", { submitted: true, task_id: bcTaskId });
            console.log(`[Tier1:${target.name}] BC task submitted: ${bcTaskId}`);
          }
        } else {
          addTrace("bettercontact", { http_status: bcResp.status });
        }
      } catch (e) {
        addTrace("bettercontact", { error: (e as Error).message });
      }
    }

    // ─── STEP 3: Pattern Leverage ─────────────────────────────────────────
    if (!finalEmail && !bcTaskId) {
      console.log(`[Tier1:${target.name}] Step 4: Pattern leverage`);
      const { data: intel } = await supabase
        .from("company_email_intel")
        .select("*")
        .eq("company_id", target.company_id)
        .single();

      if (intel?.pattern && intel.mx_valid && intel.pattern_confidence && intel.pattern_confidence >= 0.6) {
        const generated = applyPattern(intel.pattern, firstName, lastName, target.company_domain);
        if (generated) {
          console.log(`[Tier1:${target.name}] Pattern candidate: ${generated} (confidence=${intel.pattern_confidence})`);

          // Verify immediately
          if (keys.HUNTER_API_KEY) {
            const verifyResult = await verifyEmail(generated, keys.HUNTER_API_KEY);
            addTrace("pattern_verify", { email: generated, pattern: intel.pattern, verify_result: verifyResult });

            if (verifyResult === "verified" || verifyResult === "catch_all") {
              finalEmail = generated;
              finalEmailStatus = verifyResult;
              finalSource = "pattern_verified";
              console.log(`[Tier1:${target.name}] ✓ Pattern verified: ${generated}`);
            } else {
              console.log(`[Tier1:${target.name}] Pattern failed verification: ${verifyResult}`);
            }
          } else {
            // No Hunter key — accept with lower confidence
            finalEmail = generated;
            finalEmailStatus = "pattern_generated";
            finalSource = "cached_pattern";
            addTrace("pattern_leverage", { email: generated, pattern: intel.pattern, no_verification: true });
          }
        }
      } else {
        addTrace("pattern_leverage", { skipped: true, reason: !intel ? "no_intel" : "low_confidence" });
      }
    }

    // ─── STEP 4: Deep Discovery (last resort) ────────────────────────────
    if (!finalEmail && !bcTaskId) {
      // Only if no company_email_intel exists yet (run once per company)
      const { data: existingIntel } = await supabase
        .from("company_email_intel")
        .select("company_id")
        .eq("company_id", target.company_id)
        .maybeSingle();

      if (!existingIntel) {
        console.log(`[Tier1:${target.name}] Step 5: Deep Discovery (company-level)`);
        try {
          const deepResp = await fetch(`${keys.SUPABASE_URL}/functions/v1/deep-email-discovery`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${keys.SUPABASE_SERVICE_ROLE_KEY}`,
            },
            body: JSON.stringify({
              firstName,
              lastName,
              fullName: target.name,
              jobTitle: target.title || "",
              companyName: target.company_name,
              companyWebsite: `https://${target.company_domain}`,
              resolvedDomain: target.company_domain,
              linkedinUrl: target.linkedin_url,
            }),
          });

          if (deepResp.ok) {
            const deepResult = await deepResp.json();
            if (deepResult.success && deepResult.data) {
              const dd = deepResult.data;
              addTrace("deep_discovery", {
                email: dd.candidateEmail,
                confidence: dd.confidenceScore,
                pattern: dd.emailPattern,
                status: dd.candidateEmailStatus,
              });

              if (dd.candidateEmail && dd.confidenceScore >= 0.4) {
                // Verify before accepting
                if (keys.HUNTER_API_KEY) {
                  const verifyResult = await verifyEmail(dd.candidateEmail, keys.HUNTER_API_KEY);
                  if (verifyResult === "verified" || verifyResult === "catch_all") {
                    finalEmail = dd.candidateEmail;
                    finalEmailStatus = verifyResult;
                    finalSource = "deep_discovery_verified";
                    console.log(`[Tier1:${target.name}] ✓ Deep Discovery verified: ${dd.candidateEmail}`);
                  } else {
                    console.log(`[Tier1:${target.name}] Deep Discovery failed verification: ${verifyResult}`);
                  }
                }
              }
            }
          } else {
            addTrace("deep_discovery", { http_status: deepResp.status });
          }
        } catch (e) {
          addTrace("deep_discovery", { error: (e as Error).message });
        }
      } else {
        addTrace("deep_discovery", { skipped: true, reason: "intel_exists" });
      }
    }

  } catch (error) {
    pipelineError = (error as Error).message;
    console.error(`[Tier1:${target.name}] Error:`, error);
  } finally {
    // ─── PERSIST RESULTS ──────────────────────────────────────────────────
    const updates: Record<string, unknown> = {
      enriched_at: new Date().toISOString(),
    };

    if (finalEmail) {
      updates.email = finalEmail;
      updates.email_status = finalEmailStatus;
      updates.email_confidence = finalEmailStatus === "verified" ? 1.0
        : finalEmailStatus === "catch_all" ? 0.7
        : finalEmailStatus === "pattern_generated" ? 0.5
        : 0.6;
      updates.enrichment_source = finalSource;
    } else if (bcTaskId) {
      updates.enrichment_source = "bettercontact_pending";
      updates.bettercontact_task_id = bcTaskId;
      updates.bettercontact_submitted_at = new Date().toISOString();
      updates.bettercontact_status = "pending";
    }

    if (Object.keys(updates).length > 1) { // more than just enriched_at
      await supabase.from("stakeholders").update(updates).eq("id", target.id);
    }

    // Update attempt
    const attemptStatus = finalEmail ? "succeeded"
      : bcTaskId ? "pending_async"
      : pipelineError ? "failed"
      : "failed";

    if (attemptId) {
      await supabase.from("stakeholder_enrichment_attempts").update({
        status: attemptStatus,
        final_email: finalEmail,
        final_email_status: finalEmailStatus,
        final_source: finalSource,
        trace: traceSteps,
        error: pipelineError,
        finished_at: new Date().toISOString(),
      }).eq("id", attemptId);
    }
  }

  return {
    stakeholder_id: target.id,
    stakeholder_name: target.name,
    outcome: finalEmail ? (finalSource?.includes("pattern") ? "pattern_generated" : "email_found")
      : bcTaskId ? "bc_pending"
      : pipelineError ? "error"
      : "not_found",
    email: finalEmail || undefined,
    email_status: finalEmailStatus || undefined,
    source: finalSource || undefined,
    error: pipelineError || undefined,
  };
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function applyPattern(pattern: string, firstName: string, lastName: string, domain: string): string | null {
  const f = firstName.toLowerCase().replace(/[^a-z]/g, "");
  const l = lastName.toLowerCase().replace(/[^a-z]/g, "");
  if (!f || !l) return null;

  const patternMap: Record<string, string> = {
    "first.last": `${f}.${l}`,
    "f.last": `${f[0]}.${l}`,
    "first.l": `${f}.${l[0]}`,
    "flast": `${f[0]}${l}`,
    "firstlast": `${f}${l}`,
    "last.first": `${l}.${f}`,
    "lfirst": `${l[0]}${f}`,
    "first": f,
    "last": l,
    "first_last": `${f}_${l}`,
    "f_last": `${f[0]}_${l}`,
  };

  const local = patternMap[pattern];
  return local ? `${local}@${domain}` : null;
}

async function verifyEmail(email: string, hunterApiKey: string): Promise<string> {
  try {
    const resp = await fetch(
      `https://api.hunter.io/v2/email-verifier?email=${encodeURIComponent(email)}&api_key=${hunterApiKey}`,
      { method: "GET" }
    );

    if (resp.status === 202) return "pending";
    if (!resp.ok) return "unknown";

    const data = await resp.json();
    if (data.errors?.length) return "unknown";

    const result = data.data?.result || data.data?.status;
    switch (result) {
      case "deliverable":
      case "valid":
        return "verified";
      case "undeliverable":
      case "invalid":
        return "undeliverable";
      case "risky":
      case "accept_all":
        return data.data?.accept_all ? "catch_all" : "unknown";
      default:
        return "unknown";
    }
  } catch {
    return "unknown";
  }
}
