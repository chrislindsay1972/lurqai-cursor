import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

/**
 * Sanitize CV text by removing personal identifying information:
 * - Name (first line or lines matching common name patterns)
 * - Email addresses
 * - Phone numbers (international formats)
 * - Physical addresses
 * - LinkedIn, GitHub, portfolio, and social media URLs
 * - Personal websites
 */
function sanitizeCvText(rawText: string, candidateName: string | null): string {
  let text = rawText;

  // 1. Remove candidate name (all occurrences, case-insensitive)
  if (candidateName) {
    const nameParts = candidateName.trim().split(/\s+/);
    // Remove full name
    text = text.replace(new RegExp(escapeRegex(candidateName), "gi"), "[CANDIDATE]");
    // Remove individual name parts (first name, last name) that are 3+ chars
    for (const part of nameParts) {
      if (part.length >= 3) {
        // Only replace standalone words to avoid false positives
        text = text.replace(new RegExp(`\\b${escapeRegex(part)}\\b`, "gi"), "[CANDIDATE]");
      }
    }
  }

  // 2. Remove email addresses
  text = text.replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, "[EMAIL REDACTED]");

  // 3. Remove phone numbers (various international formats)
  // Matches: +44 7911 123456, (555) 123-4567, 07911123456, +1-555-123-4567, etc.
  text = text.replace(/(?:\+?\d{1,3}[\s-.]?)?\(?\d{2,4}\)?[\s-.]?\d{3,4}[\s-.]?\d{3,4}/g, (match) => {
    // Only redact if it looks like a phone number (7+ digits)
    const digits = match.replace(/\D/g, "");
    if (digits.length >= 7 && digits.length <= 15) {
      return "[PHONE REDACTED]";
    }
    return match;
  });

  // 4. Remove URLs (LinkedIn, GitHub, social media, personal websites)
  // Full URLs
  text = text.replace(/https?:\/\/[^\s<>"{}|\\^`\[\]]+/gi, (url) => {
    const lower = url.toLowerCase();
    if (
      lower.includes("linkedin.com") ||
      lower.includes("github.com") ||
      lower.includes("twitter.com") ||
      lower.includes("x.com") ||
      lower.includes("facebook.com") ||
      lower.includes("instagram.com") ||
      lower.includes("stackoverflow.com") ||
      lower.includes("gitlab.com") ||
      lower.includes("bitbucket.org") ||
      lower.includes("behance.net") ||
      lower.includes("dribbble.com") ||
      lower.includes("medium.com")
    ) {
      return "[SOCIAL LINK REDACTED]";
    }
    // Other URLs could be personal sites
    return "[URL REDACTED]";
  });

  // 5. Remove linkedin.com/in/... without https prefix
  text = text.replace(/linkedin\.com\/in\/[^\s,)]+/gi, "[SOCIAL LINK REDACTED]");
  text = text.replace(/github\.com\/[^\s,)]+/gi, "[SOCIAL LINK REDACTED]");

  // 6. Remove physical address patterns (basic - lines with postal/zip codes)
  // UK postcodes
  text = text.replace(/\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b/gi, "[POSTCODE REDACTED]");
  // US zip codes (standalone 5 or 5+4 digit)
  text = text.replace(/\b\d{5}(-\d{4})?\b/g, (match, _, offset) => {
    // Avoid redacting years (1990-2025 range)
    const num = parseInt(match);
    if (num >= 1950 && num <= 2030) return match;
    return "[ZIP REDACTED]";
  });

  // 7. Clean up excessive redaction markers
  text = text.replace(/(\[CANDIDATE\]\s*){2,}/g, "[CANDIDATE] ");
  text = text.replace(/\n{4,}/g, "\n\n\n");

  return text.trim();
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Generate a simple text-based PDF from sanitized CV content.
 * Uses a minimal PDF structure (no external libraries needed).
 */
function generateSimplePdf(text: string, title: string): Uint8Array {
  // Encode text for PDF (escape special chars)
  const escPdf = (s: string) =>
    s
      .replace(/\\/g, "\\\\")
      .replace(/\(/g, "\\(")
      .replace(/\)/g, "\\)")
      .replace(/\r\n/g, "\n")
      .replace(/\r/g, "\n");

  // Split into lines, word-wrap at ~85 chars
  const rawLines = text.split("\n");
  const lines: string[] = [];
  for (const raw of rawLines) {
    if (raw.length === 0) {
      lines.push("");
      continue;
    }
    const words = raw.split(" ");
    let current = "";
    for (const word of words) {
      if (current.length + word.length + 1 > 85 && current.length > 0) {
        lines.push(current);
        current = word;
      } else {
        current = current ? current + " " + word : word;
      }
    }
    if (current) lines.push(current);
  }

  // PDF page dimensions (A4)
  const pageWidth = 595;
  const pageHeight = 842;
  const margin = 50;
  const fontSize = 10;
  const titleFontSize = 14;
  const lineHeight = 14;
  const usableHeight = pageHeight - 2 * margin - 30; // leave room for title on first page
  const linesPerPage = Math.floor(usableHeight / lineHeight);

  // Split lines into pages
  const pages: string[][] = [];
  for (let i = 0; i < lines.length; i += linesPerPage) {
    pages.push(lines.slice(i, i + linesPerPage));
  }
  if (pages.length === 0) pages.push([""]);

  // Build PDF objects
  const objects: string[] = [];
  let objectCount = 0;

  const addObject = (content: string): number => {
    objectCount++;
    objects.push(content);
    return objectCount;
  };

  // Object 1: Catalog
  addObject("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj");

  // Object 2: Pages (placeholder, will be rebuilt)
  const pagesObjIndex = 1; // index in objects array
  addObject(""); // placeholder

  // Object 3: Font
  addObject("3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj");

  // Object 4: Bold Font
  addObject("4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj");

  // Create page objects
  const pageObjIds: number[] = [];
  for (let p = 0; p < pages.length; p++) {
    const pageLines = pages[p];
    let stream = "";

    // Title on first page
    let yStart = pageHeight - margin;
    if (p === 0) {
      stream += `BT\n/F2 ${titleFontSize} Tf\n${margin} ${yStart} Td\n(${escPdf(title)}) Tj\nET\n`;
      yStart -= 25;
    }

    // Body text
    stream += `BT\n/F1 ${fontSize} Tf\n${margin} ${yStart} Td\n${lineHeight} TL\n`;
    for (const line of pageLines) {
      stream += `(${escPdf(line)}) '\n`;
    }
    stream += "ET\n";

    // Content stream object
    const streamObjId = addObject(
      `${objectCount + 1} 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}endstream\nendobj`
    );

    // Page object
    const pageObjId = addObject(
      `${objectCount + 1} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Contents ${streamObjId} 0 R /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>\nendobj`
    );
    pageObjIds.push(pageObjId);
  }

  // Rebuild Pages object
  const kidsStr = pageObjIds.map((id) => `${id} 0 R`).join(" ");
  objects[pagesObjIndex] = `2 0 obj\n<< /Type /Pages /Kids [${kidsStr}] /Count ${pages.length} >>\nendobj`;

  // Build final PDF
  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];
  for (const obj of objects) {
    offsets.push(pdf.length);
    pdf += obj + "\n";
  }

  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objectCount + 1}\n0000000000 65535 f \n`;
  for (const offset of offsets) {
    pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
  }

  pdf += `trailer\n<< /Size ${objectCount + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  return new TextEncoder().encode(pdf);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { candidateId } = await req.json();

    if (!candidateId) {
      return new Response(
        JSON.stringify({ error: "candidateId is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch candidate data
    const { data: candidate, error } = await supabase
      .from("candidates")
      .select("name, cv_raw_text, current_title")
      .eq("id", candidateId)
      .single();

    if (error || !candidate) {
      return new Response(
        JSON.stringify({ error: "Candidate not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!candidate.cv_raw_text) {
      return new Response(
        JSON.stringify({ error: "No CV text available for this candidate" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Sanitize the CV text
    const sanitizedText = sanitizeCvText(candidate.cv_raw_text, candidate.name);

    // Generate PDF
    const title = `Candidate Profile — ${candidate.current_title || "Professional"}`;
    const pdfBytes = generateSimplePdf(sanitizedText, title);

    // Return base64-encoded PDF
    let binary = "";
    for (let i = 0; i < pdfBytes.length; i++) {
      binary += String.fromCharCode(pdfBytes[i]);
    }
    const base64Pdf = btoa(binary);

    return new Response(
      JSON.stringify({
        success: true,
        pdf: base64Pdf,
        filename: `candidate-profile-${candidate.current_title?.replace(/\s+/g, "-").toLowerCase() || "cv"}.pdf`,
        contentType: "application/pdf",
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("sanitize-cv error:", err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
