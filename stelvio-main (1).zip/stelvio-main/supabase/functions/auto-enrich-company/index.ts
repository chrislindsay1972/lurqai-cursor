import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

async function callFunction(name: string, body: Record<string, unknown>): Promise<{ data?: unknown; error?: string }> {
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

  const response = await fetch(`${supabaseUrl}/functions/v1/${name}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${serviceKey}`,
      'apikey': serviceKey,
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(55000),
  });

  if (!response.ok) {
    const text = await response.text().catch(() => 'Unknown error');
    return { error: `${name} failed: ${text}` };
  }

  const data = await response.json().catch(() => ({}));
  return { data };
}

/**
 * Cascade-delete a company that exceeds the employee size cap:
 * matches → stakeholders → jobs → company record itself.
 */
async function purgeOversizedCompany(
  supabase: ReturnType<typeof createClient>,
  companyId: string,
  companyName: string,
) {
  console.log(`[PURGE] Company "${companyName}" exceeds size cap — removing matches, stakeholders, jobs, and company record`);

  // 1. Delete matches linked to this company's jobs
  const { data: companyJobs } = await supabase
    .from('jobs')
    .select('id')
    .eq('company_id', companyId);

  if (companyJobs && companyJobs.length > 0) {
    const jobIds = companyJobs.map((j: { id: string }) => j.id);
    const { error: matchDelErr, count: matchDelCount } = await supabase
      .from('matches')
      .delete({ count: 'exact' })
      .in('job_id', jobIds);
    if (matchDelErr) console.warn('[PURGE] Failed to delete matches:', matchDelErr);
    else console.log(`[PURGE] Deleted ${matchDelCount} matches`);
  }

  // 2. Delete stakeholders
  const { error: shDelErr, count: shDelCount } = await supabase
    .from('stakeholders')
    .delete({ count: 'exact' })
    .eq('company_id', companyId);
  if (shDelErr) console.warn('[PURGE] Failed to delete stakeholders:', shDelErr);
  else console.log(`[PURGE] Deleted ${shDelCount} stakeholders`);

  // 3. Delete jobs
  if (companyJobs && companyJobs.length > 0) {
    const jobIds = companyJobs.map((j: { id: string }) => j.id);
    const { error: jobDelErr, count: jobDelCount } = await supabase
      .from('jobs')
      .delete({ count: 'exact' })
      .in('id', jobIds);
    if (jobDelErr) console.warn('[PURGE] Failed to delete jobs:', jobDelErr);
    else console.log(`[PURGE] Deleted ${jobDelCount} jobs`);
  }

  // 4. Delete the company record itself
  const { error: coDelErr } = await supabase
    .from('companies')
    .delete()
    .eq('id', companyId);
  if (coDelErr) console.warn('[PURGE] Failed to delete company:', coDelErr);
  else console.log(`[PURGE] Deleted company "${companyName}" (${companyId})`);
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { company_id, candidate_id } = await req.json();

    if (!company_id) {
      return new Response(JSON.stringify({ error: 'company_id is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );

    // ===== Fetch max company employee setting =====
    let maxCompanyEmployees = 500;
    const { data: settings } = await supabase
      .from('app_settings')
      .select('setting_value')
      .eq('setting_key', 'max_company_employees')
      .single();
    if (settings?.setting_value) {
      const parsed = parseInt(settings.setting_value, 10);
      if (!isNaN(parsed)) maxCompanyEmployees = parsed;
    }
    console.log(`Max company employees setting: ${maxCompanyEmployees}`);

    // Check current enrichment status — skip if already done or in progress
    const { data: company, error: companyError } = await supabase
      .from('companies')
      .select('id, name, domain, enrichment_status, employee_count')
      .eq('id', company_id)
      .single();

    if (companyError || !company) {
      console.error('Company not found:', company_id);
      return new Response(JSON.stringify({ error: 'Company not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // ===== EARLY SIZE GATE: purge immediately if employee_count already known and oversized =====
    if (company.employee_count && company.employee_count > maxCompanyEmployees) {
      console.log(`[EARLY GATE] ${company.name} has ${company.employee_count} employees (max ${maxCompanyEmployees}) — skipping enrichment and purging`);
      await supabase.from('companies').update({
        enrichment_status: 'exceeds_size',
        enriched_at: new Date().toISOString(),
      }).eq('id', company_id);
      await purgeOversizedCompany(supabase, company_id, company.name);
      return new Response(JSON.stringify({
        success: false,
        exceeds_size: true,
        employee_count: company.employee_count,
        max_allowed: maxCompanyEmployees,
        company_id,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (company.enrichment_status === 'enriched' || company.enrichment_status === 'processing') {
      console.log(`Skipping ${company.name} — status: ${company.enrichment_status}`);
      return new Response(JSON.stringify({ skipped: true, status: company.enrichment_status }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // ===== DOMAIN/NAME-LEVEL CACHE CHECK =====
    let domain = company.domain;

    const cacheFields = 'id, enrichment_status, employee_count, linkedin_url, description, industry, industries, city, country, founded_year, logo_url, enrichment_source, apollo_data, quality_signals, funding_status, recent_news, glassdoor_rating, short_description, seo_description, keywords, technology_names, annual_revenue, annual_revenue_printed, total_funding, total_funding_printed, latest_funding_stage, latest_funding_round_date, domain';

    /**
     * Helper: apply cached enrichment data, but FIRST check employee count against the max.
     * If oversized, mark as exceeds_size and purge the company + related records.
     * Returns a Response to send back to the caller.
     */
    const applyCacheHitWithSizeCheck = async (
      cachedCompany: Record<string, unknown>,
      reason: string,
    ): Promise<Response> => {
      const empCount = cachedCompany.employee_count as number | null;

      // ===== SIZE CHECK: reject oversized companies even from cache =====
      if (empCount && empCount > maxCompanyEmployees) {
        console.log(`[CACHE HIT → OVERSIZED] ${reason} — cached company has ${empCount} employees (max ${maxCompanyEmployees}). Marking exceeds_size and purging.`);
        await supabase.from('companies').update({
          enrichment_status: 'exceeds_size',
          employee_count: empCount,
          enriched_at: new Date().toISOString(),
        }).eq('id', company_id);

        await purgeOversizedCompany(supabase, company_id, company.name);

        return new Response(JSON.stringify({
          success: false,
          exceeds_size: true,
          cached: true,
          employee_count: empCount,
          max_allowed: maxCompanyEmployees,
          company_id,
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Normal cache hit — copy data
      console.log(`[CACHE HIT] ${reason} — copying data from ${cachedCompany.id} to ${company.name} (${company_id})`);
      const { employee_count, linkedin_url, description, industry, industries, city, country, founded_year, logo_url, enrichment_source, apollo_data, quality_signals, funding_status, recent_news, short_description, seo_description, keywords, technology_names, annual_revenue, annual_revenue_printed, total_funding, total_funding_printed, latest_funding_stage, latest_funding_round_date } = cachedCompany as Record<string, unknown>;
      const { error: updateError } = await supabase.from('companies').update({
        enrichment_status: 'enriched',
        enrichment_source: enrichment_source ? `${enrichment_source} (cached)` : 'cached',
        enriched_at: new Date().toISOString(),
        employee_count, linkedin_url, description, industry, industries, city, country, founded_year, logo_url,
        apollo_data, quality_signals, funding_status, recent_news, short_description, seo_description,
        keywords, technology_names, annual_revenue, annual_revenue_printed, total_funding, total_funding_printed,
        latest_funding_stage, latest_funding_round_date,
      }).eq('id', company_id);
      if (updateError) console.error('[CACHE] Update failed:', updateError);

      return new Response(JSON.stringify({ success: true, cached: true, company_id, source_company_id: cachedCompany.id }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    };

    // Check by domain first (exact match)
    if (domain) {
      const { data: cachedByDomain } = await supabase
        .from('companies')
        .select(cacheFields)
        .eq('domain', domain)
        .eq('enrichment_status', 'enriched')
        .neq('id', company_id)
        .limit(1)
        .maybeSingle();

      if (cachedByDomain) {
        return await applyCacheHitWithSizeCheck(cachedByDomain, `Domain "${domain}" already enriched`);
      }
      console.log(`[CACHE MISS] No enriched company for domain "${domain}"`);
    }

    // If no domain, check by exact company name
    if (!domain) {
      const { data: cachedByName } = await supabase
        .from('companies')
        .select(cacheFields)
        .ilike('name', company.name)
        .eq('enrichment_status', 'enriched')
        .neq('id', company_id)
        .limit(1)
        .maybeSingle();

      if (cachedByName) {
        return await applyCacheHitWithSizeCheck(cachedByName, `Company name "${company.name}" already enriched`);
      }
      console.log(`[CACHE MISS] No enriched company for name "${company.name}"`);
    }

    // Mark as processing to prevent duplicate enrichment from concurrent triggers
    await supabase
      .from('companies')
      .update({ enrichment_status: 'processing' })
      .eq('id', company_id)
      .eq('enrichment_status', 'pending');

    console.log(`Auto-enriching company: ${company.name} (${company_id})`);

    // Step 1: Domain lookup — use job description + company name as per spec
    if (!domain) {
      console.log(`Looking up domain for ${company.name}...`);

      // Fetch job description from the matched job to aid domain resolution
      let jobDescription: string | null = null;
      if (candidate_id) {
        const { data: matchedJob } = await supabase
          .from('matches')
          .select('job_id, jobs(description, title, source_url)')
          .eq('candidate_id', candidate_id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (matchedJob?.jobs) {
          const job = matchedJob.jobs as unknown as { description?: string; title?: string; source_url?: string };
          jobDescription = [job.description, job.title, job.source_url].filter(Boolean).join('\n');
          console.log(`[domain-lookup] Using job context (${jobDescription?.length} chars) for ${company.name}`);
        }
      }

      // Also check jobs directly linked to this company
      if (!jobDescription) {
        const { data: companyJob } = await supabase
          .from('jobs')
          .select('description, title, source_url')
          .eq('company_id', company_id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (companyJob) {
          jobDescription = [companyJob.description, companyJob.title, companyJob.source_url].filter(Boolean).join('\n');
          console.log(`[domain-lookup] Using company job context (${jobDescription?.length} chars) for ${company.name}`);
        }
      }

      const domainResult = await callFunction('lookup-company-domain', {
        companyId: company_id,
        companyName: company.name,
        jobDescription,
      });
      if (domainResult.error) {
        console.warn('Domain lookup failed:', domainResult.error);
      } else {
        const { data: refreshed } = await supabase
          .from('companies')
          .select('domain')
          .eq('id', company_id)
          .single();
        domain = refreshed?.domain ?? null;
      }
    }

    if (!domain) {
      console.warn(`No domain found for ${company.name}, skipping enrich-company step`);
      await supabase.from('companies').update({ enrichment_status: 'failed' }).eq('id', company_id);
      return new Response(JSON.stringify({ error: 'No domain available for enrichment' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // ===== SECOND CACHE CHECK (post domain-lookup) =====
    {
      const { data: cachedCompany2 } = await supabase
        .from('companies')
        .select(cacheFields)
        .eq('domain', domain)
        .eq('enrichment_status', 'enriched')
        .neq('id', company_id)
        .limit(1)
        .maybeSingle();

      if (cachedCompany2) {
        return await applyCacheHitWithSizeCheck(cachedCompany2, `Post-domain-lookup cache hit for "${domain}"`);
      }
    }

    // Steps 2 & 3: Run enrich-company and enrich-stakeholders in PARALLEL
    console.log(`Enriching company data and discovering stakeholders in parallel for ${company.name} (domain: ${domain})...`);
    const [enrichResult, stakeholderResult] = await Promise.all([
      callFunction('enrich-company', { companyId: company_id, domain }),
      callFunction('enrich-stakeholders', { companyId: company_id, companyName: company.name, domain }),
    ]);

    if (enrichResult.error) {
      console.warn('Enrich company failed:', enrichResult.error);
      await supabase
        .from('companies')
        .update({ enrichment_status: 'failed' })
        .eq('id', company_id);
      return new Response(JSON.stringify({ error: enrichResult.error }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (stakeholderResult.error) {
      console.warn('Stakeholder enrichment failed (non-fatal):', stakeholderResult.error);
    }

    // Safety net: ensure status is never left as 'pending' or 'processing' after a successful run.
    const { data: finalStatus } = await supabase
      .from('companies')
      .select('enrichment_status, employee_count')
      .eq('id', company_id)
      .single();

    if (finalStatus && (finalStatus.enrichment_status === 'pending' || finalStatus.enrichment_status === 'processing')) {
      console.warn(`Company ${company.name} still had status "${finalStatus.enrichment_status}" after enrichment — forcing to "enriched"`);
      await supabase
        .from('companies')
        .update({ enrichment_status: 'enriched', enriched_at: new Date().toISOString() })
        .eq('id', company_id);
    }

    // ===== CLEANUP: Remove matches & stakeholders for companies that exceed size cap =====
    const shouldPurge = finalStatus && (
      finalStatus.enrichment_status === 'exceeds_size' ||
      (finalStatus.employee_count && finalStatus.employee_count > maxCompanyEmployees)
    );

    if (shouldPurge) {
      // Ensure the status is set to exceeds_size if it wasn't already
      if (finalStatus.enrichment_status !== 'exceeds_size') {
        console.log(`Company ${company.name} has ${finalStatus.employee_count} employees (max ${maxCompanyEmployees}) — correcting status to exceeds_size`);
        await supabase.from('companies').update({
          enrichment_status: 'exceeds_size',
        }).eq('id', company_id);
      }

      await purgeOversizedCompany(supabase, company_id, company.name);

      return new Response(JSON.stringify({
        success: false,
        exceeds_size: true,
        employee_count: finalStatus.employee_count,
        max_allowed: maxCompanyEmployees,
        company_id,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Auto-enrichment complete for ${company.name}`);
    return new Response(JSON.stringify({ success: true, company_id, company_name: company.name }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (err) {
    console.error('auto-enrich-company error:', err);
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
