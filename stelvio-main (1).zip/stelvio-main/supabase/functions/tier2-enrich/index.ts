/**
 * Tier 2 Enrichment Sweep
 *
 * Medium-ROI waterfall for NO_EMAIL stakeholders who are NOT Tier 1 eligible
 * (no LinkedIn) or who failed Tier 1.
 *
 * Waterfall:
 *  1. Apollo (name + domain + title)         – no LinkedIn required
 *  2. Hunter Email Finder (person-level)     – cheap per-person lookup
 *  3. Hunter Domain Search (pattern seeding) – once per company, ≥2 examples
 *  4. Verification (mandatory for every candidate email)
 *  5. Pattern Leverage from company_email_intel
 *  6. Deep Discovery (last resort, company-level, max 5 companies/run)
 *
 * Cross-domain guardrail enforced at every step.
 */
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ─── TYPES ───────────────────────────────────────────────────────────────────

interface Tier2Request {
  mode?: "dry_run" | "execute";
  limit?: number;
  company_id?: string;
  stakeholder_ids?: string[];
  force?: boolean;
}

interface StakeholderTarget {
  id: string;
  name: string;
  first_name: string;
  last_name: string;
  title: string | null;
  linkedin_url: string | null;
  company_id: string;
  company_name: string;
  company_domain: string;
}

interface Tier2Result {
  stakeholder_id: string;
  stakeholder_name: string;
  outcome: "verified" | "catch_all_safe" | "catch_all_not_safe" | "undeliverable" | "not_found" | "needs_review" | "skipped" | "error";
  email?: string;
  email_status?: string;
  source?: string;
  error?: string;
}

interface RunStats {
  apollo_calls: number;
  hunter_finder_calls: number;
  hunter_domain_search_calls: number;
  pattern_generated: number;
  deep_discovery_companies: number;
  verify_calls: number;
}

interface ApiKeys {
  APOLLO_API_KEY: string | undefined;
  HUNTER_API_KEY: string | undefined;
  SUPABASE_URL: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
}

// ─── BUDGET CAPS ─────────────────────────────────────────────────────────────

const MAX_DEEP_DISCOVERY_COMPANIES = 5;
const MAX_HUNTER_FINDER = 25;
const MAX_HUNTER_DOMAIN_SEARCH = 10;
const COOLDOWN_HOURS = 24;

// ─── MAIN HANDLER ────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  const keys: ApiKeys = {
    APOLLO_API_KEY: Deno.env.get("APOLLO_API_KEY"),
    HUNTER_API_KEY: Deno.env.get("HUNTER_API_KEY"),
    SUPABASE_URL,
    SUPABASE_SERVICE_ROLE_KEY,
  };

  try {
    const body: Tier2Request = await req.json();
    const mode = body.mode || "execute";
    const limit = Math.min(body.limit || 25, 50);
    const force = body.force || false;

    // ─── SELECT TIER 2 ELIGIBLE ──────────────────────────────────────────
    const targets = await selectTier2Eligible(supabase, { limit, company_id: body.company_id, stakeholder_ids: body.stakeholder_ids, force });

    if (mode === "dry_run") {
      return json({
        mode: "dry_run",
        eligible: targets.length,
        targets: targets.map(t => ({
          id: t.id,
          name: t.name,
          company: t.company_name,
          domain: t.company_domain,
          has_linkedin: !!t.linkedin_url,
        })),
      });
    }

    if (targets.length === 0) {
      return json({ success: true, processed: 0, message: "No Tier 2 eligible stakeholders found", results: [] });
    }

    console.log(`[Tier2] Processing ${targets.length} stakeholders across ${new Set(targets.map(t => t.company_id)).size} companies`);

    // ─── SHARED STATE ────────────────────────────────────────────────────
    const stats: RunStats = {
      apollo_calls: 0,
      hunter_finder_calls: 0,
      hunter_domain_search_calls: 0,
      pattern_generated: 0,
      deep_discovery_companies: 0,
      verify_calls: 0,
    };
    const deepDiscoveryCompanies = new Set<string>();
    const hunterDomainSearchCompanies = new Set<string>();

    // Load domain aliases for cross-domain guardrail
    const { data: aliases } = await supabase.from("company_domain_aliases").select("company_name_alias, domain, locked");
    const aliasMap = new Map<string, string[]>();
    for (const a of aliases || []) {
      const key = a.domain.toLowerCase();
      if (!aliasMap.has(key)) aliasMap.set(key, []);
      aliasMap.get(key)!.push(a.company_name_alias.toLowerCase());
    }

    // ─── PROCESS IN BATCHES OF 5 ─────────────────────────────────────────
    const results: Tier2Result[] = [];
    const CONCURRENCY = 5;

    for (let i = 0; i < targets.length; i += CONCURRENCY) {
      const batch = targets.slice(i, i + CONCURRENCY);
      const batchResults = await Promise.allSettled(
        batch.map(target =>
          processStakeholder(target, supabase, keys, stats, deepDiscoveryCompanies, hunterDomainSearchCompanies, aliasMap)
        )
      );

      for (let j = 0; j < batchResults.length; j++) {
        const r = batchResults[j];
        if (r.status === "fulfilled") {
          results.push(r.value);
        } else {
          results.push({
            stakeholder_id: batch[j].id,
            stakeholder_name: batch[j].name,
            outcome: "error",
            error: r.reason?.message || "Unknown error",
          });
        }
      }
    }

    // ─── SUMMARY ─────────────────────────────────────────────────────────
    const counts = {
      processed: results.length,
      verified: results.filter(r => r.outcome === "verified").length,
      catch_all_safe: results.filter(r => r.outcome === "catch_all_safe").length,
      catch_all_not_safe: results.filter(r => r.outcome === "catch_all_not_safe").length,
      undeliverable: results.filter(r => r.outcome === "undeliverable").length,
      not_found: results.filter(r => r.outcome === "not_found").length,
      needs_review: results.filter(r => r.outcome === "needs_review").length,
      skipped: results.filter(r => r.outcome === "skipped").length,
      errors: results.filter(r => r.outcome === "error").length,
    };

    console.log(`[Tier2] Complete: ${JSON.stringify(counts)}`);
    console.log(`[Tier2] Stats: ${JSON.stringify(stats)}`);

    return json({
      success: true,
      counts,
      per_tier_stats: stats,
      cost_proxy: {
        apollo_calls: stats.apollo_calls,
        hunter_finder_calls: stats.hunter_finder_calls,
        hunter_domain_search_calls: stats.hunter_domain_search_calls,
        deep_discovery_companies: stats.deep_discovery_companies,
        verify_calls: stats.verify_calls,
      },
      updated_stakeholder_ids: results.filter(r => r.email).map(r => r.stakeholder_id),
      results,
    });

  } catch (error) {
    console.error("[Tier2] Fatal error:", error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// ─── ELIGIBILITY SELECTION ───────────────────────────────────────────────────

async function selectTier2Eligible(
  supabase: ReturnType<typeof createClient>,
  opts: { limit: number; company_id?: string; stakeholder_ids?: string[]; force?: boolean },
): Promise<StakeholderTarget[]> {
  // Fetch candidates: email IS NULL, not BC pending, not already verified
  let query = supabase
    .from("stakeholders")
    .select("id, name, title, linkedin_url, company_id, bettercontact_status, email_status, enrichment_source")
    .is("email", null)
    .or("bettercontact_status.is.null,bettercontact_status.neq.pending")
    .limit(500);

  if (opts.stakeholder_ids?.length) {
    query = query.in("id", opts.stakeholder_ids);
  }
  if (opts.company_id) {
    query = query.eq("company_id", opts.company_id);
  }

  const { data: stakeholders } = await query;
  if (!stakeholders?.length) return [];

  // Filter out already-good statuses
  const candidates = stakeholders.filter(s =>
    !s.email_status || !["verified", "catch_all_safe"].includes(s.email_status)
  );

  // Get companies with resolved domains
  const companyIds = [...new Set(candidates.map(s => s.company_id).filter(Boolean))] as string[];
  if (!companyIds.length) return [];

  const { data: companies } = await supabase
    .from("companies")
    .select("id, name, domain, domain_status, domain_quality_score, employee_count")
    .in("id", companyIds)
    .eq("domain_status", "resolved")
    .gte("domain_quality_score", 0.7)
    .not("domain", "is", null);

  const companyMap = new Map(companies?.map(c => [c.id, c]) || []);

  // Load app_settings for max_company_size
  const { data: maxSizeSetting } = await supabase
    .from("app_settings")
    .select("setting_value")
    .eq("setting_key", "max_company_size")
    .maybeSingle();
  const maxCompanySize = maxSizeSetting ? parseInt(maxSizeSetting.setting_value, 10) : 10000;

  // Check opt-outs
  const { data: optOuts } = await supabase
    .from("opt_out_records")
    .select("stakeholder_id")
    .not("stakeholder_id", "is", null);
  const optOutSet = new Set(optOuts?.map(o => o.stakeholder_id) || []);

  // Check cooldown: recent attempts in last 24h
  let recentAttemptSet = new Set<string>();
  if (!opts.force) {
    const cutoff = new Date(Date.now() - COOLDOWN_HOURS * 3600 * 1000).toISOString();
    const { data: recentAttempts } = await supabase
      .from("stakeholder_enrichment_attempts")
      .select("stakeholder_id")
      .gte("started_at", cutoff)
      .in("stakeholder_id", candidates.map(c => c.id));
    recentAttemptSet = new Set(recentAttempts?.map(a => a.stakeholder_id) || []);
  }

  // Check Tier 1 attempt history for tier2 eligibility
  const { data: tier1Attempts } = await supabase
    .from("stakeholder_enrichment_attempts")
    .select("stakeholder_id, status, attempt_type")
    .eq("attempt_type", "tier1")
    .in("stakeholder_id", candidates.map(c => c.id));

  const tier1FailedSet = new Set(
    tier1Attempts
      ?.filter(a => ["not_found", "failed", "needs_review"].includes(a.status))
      .map(a => a.stakeholder_id) || []
  );

  // Build targets
  const targets: StakeholderTarget[] = [];

  for (const s of candidates) {
    if (!s.company_id || !companyMap.has(s.company_id)) continue;
    if (optOutSet.has(s.id)) continue;
    if (recentAttemptSet.has(s.id)) continue;

    const c = companyMap.get(s.company_id)!;

    // Exceeds size check
    if (c.employee_count && c.employee_count > maxCompanySize) continue;

    // Name resolution
    const nameParts = s.name.trim().split(/\s+/);
    const firstName = nameParts[0] || "";
    const lastName = nameParts.length > 1 ? nameParts.slice(1).join(" ") : "";
    if (!firstName || !lastName) continue; // Must have usable first + last name

    // Tier 2 eligibility: no LinkedIn OR Tier 1 failed
    const noLinkedIn = !s.linkedin_url;
    const tier1Failed = tier1FailedSet.has(s.id);

    if (!noLinkedIn && !tier1Failed) continue; // Has LinkedIn and Tier 1 didn't fail → still Tier 1

    targets.push({
      id: s.id,
      name: s.name,
      first_name: firstName,
      last_name: lastName,
      title: s.title,
      linkedin_url: s.linkedin_url,
      company_id: c.id,
      company_name: c.name,
      company_domain: c.domain!,
    });

    if (targets.length >= opts.limit) break;
  }

  return targets;
}

// ─── PER-STAKEHOLDER WATERFALL ───────────────────────────────────────────────

async function processStakeholder(
  target: StakeholderTarget,
  supabase: ReturnType<typeof createClient>,
  keys: ApiKeys,
  stats: RunStats,
  deepDiscoveryCompanies: Set<string>,
  hunterDomainSearchCompanies: Set<string>,
  aliasMap: Map<string, string[]>,
): Promise<Tier2Result> {
  console.log(`[Tier2:${target.name}] Starting waterfall (${target.company_domain})`);

  // Step 0: Create attempt row
  const traceSteps: Array<Record<string, unknown>> = [];
  const { data: attemptRow } = await supabase
    .from("stakeholder_enrichment_attempts")
    .insert({
      stakeholder_id: target.id,
      company_id: target.company_id,
      status: "running",
      attempt_type: "tier2",
      trace: [],
    })
    .select("id")
    .single();
  const attemptId = attemptRow?.id;

  function addTrace(tier: string, data: Record<string, unknown>) {
    traceSteps.push({ tier, ...data, timestamp: new Date().toISOString() });
  }

  let finalEmail: string | null = null;
  let finalEmailStatus: string | null = null;
  let finalSource: string | null = null;
  let pipelineError: string | null = null;
  let domainMismatch = false;

  try {
    // ─── STEP 1: Apollo (Name + Domain + Title) ────────────────────────
    if (keys.APOLLO_API_KEY && stats.apollo_calls < 50) {
      const start = Date.now();
      stats.apollo_calls++;
      console.log(`[Tier2:${target.name}] Step 1: Apollo name+domain`);

      try {
        const apolloBody: Record<string, unknown> = {
          first_name: target.first_name,
          last_name: target.last_name,
          organization_name: target.company_name,
          domain: target.company_domain,
          reveal_personal_emails: false,
          reveal_phone_number: false,
        };
        if (target.title) apolloBody.title = target.title;

        const resp = await fetch("https://api.apollo.io/api/v1/people/match", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Api-Key": keys.APOLLO_API_KEY,
            "Cache-Control": "no-cache",
          },
          body: JSON.stringify(apolloBody),
        });

        const respBody = await resp.text();
        console.log(`[Tier2:${target.name}] Apollo response status=${resp.status} body=${respBody.slice(0, 500)}`);
        if (resp.ok) {
          const result = JSON.parse(respBody);
          if (result.person) {
            console.log(`[Tier2:${target.name}] Apollo person: name=${result.person.first_name} ${result.person.last_name}, email=${result.person.email || 'null'}, email_status=${result.person.email_status || 'null'}, org=${result.person.organization?.name || 'null'}`);
          } else {
            console.log(`[Tier2:${target.name}] Apollo: person=null, keys=${Object.keys(result).join(',')}`);
          }
          if (result.person?.email) {
            const email = result.person.email as string;
            const domainCheck = checkDomainGuardrail(email, target.company_domain, aliasMap);

            if (domainCheck.accepted) {
              // Verify immediately
              const verifyResult = await verifyEmail(email, keys.HUNTER_API_KEY);
              stats.verify_calls++;
              addTrace("apollo_name_domain", { email, verify_result: verifyResult, duration_ms: Date.now() - start });

              if (verifyResult === "verified" || verifyResult === "catch_all") {
                finalEmail = email;
                finalEmailStatus = verifyResult === "verified" ? "deliverable" : verifyResult;
                finalSource = "apollo_name_domain";
                console.log(`[Tier2:${target.name}] ✓ Apollo verified: ${email}`);
              } else {
                addTrace("apollo_name_domain_verify_fail", { email, verify_result: verifyResult });
              }
            } else {
              domainMismatch = true;
              addTrace("apollo_name_domain", { email, rejected: true, reason: domainCheck.reason, duration_ms: Date.now() - start });
              console.log(`[Tier2:${target.name}] Apollo domain mismatch: ${domainCheck.reason}`);
            }
          } else {
            addTrace("apollo_name_domain", { found: false, duration_ms: Date.now() - start });
          }
        } else {
          addTrace("apollo_name_domain", { http_status: resp.status, body_preview: respBody.slice(0, 200), duration_ms: Date.now() - start });
          console.error(`[Tier2:${target.name}] Apollo HTTP error ${resp.status}: ${respBody.slice(0, 300)}`);
        }
      } catch (e) {
        addTrace("apollo_name_domain", { error: (e as Error).message, duration_ms: Date.now() - start });
      }
    }

    // ─── STEP 2: Hunter Email Finder ───────────────────────────────────
    if (!finalEmail && keys.HUNTER_API_KEY && stats.hunter_finder_calls < MAX_HUNTER_FINDER) {
      const start = Date.now();
      stats.hunter_finder_calls++;
      console.log(`[Tier2:${target.name}] Step 2: Hunter Email Finder`);

      try {
        const url = `https://api.hunter.io/v2/email-finder?domain=${encodeURIComponent(target.company_domain)}&first_name=${encodeURIComponent(target.first_name)}&last_name=${encodeURIComponent(target.last_name)}&api_key=${keys.HUNTER_API_KEY}`;
        const resp = await fetch(url, { method: "GET" });

        if (resp.ok) {
          const hunterData = await resp.json();
          if (hunterData.data?.email) {
            const email = hunterData.data.email as string;
            const score = hunterData.data.score || 0;
            const verification = hunterData.data.verification?.status;
            const acceptAll = hunterData.data.accept_all;

            // Accept if valid/accept_all OR score >= 70
            const accepted = verification === "valid" || verification === "accept_all" || score >= 70;

            if (accepted) {
              const domainCheck = checkDomainGuardrail(email, target.company_domain, aliasMap);
              if (domainCheck.accepted) {
                // Verify via our standard verification
                const verifyResult = await verifyEmail(email, keys.HUNTER_API_KEY);
                stats.verify_calls++;
                addTrace("hunter_finder", { email, score, verification, verify_result: verifyResult, duration_ms: Date.now() - start });

                if (verifyResult === "verified" || verifyResult === "catch_all") {
                  finalEmail = email;
                  finalEmailStatus = verifyResult === "verified" ? "deliverable" : verifyResult;
                  finalSource = "hunter_finder";
                  console.log(`[Tier2:${target.name}] ✓ Hunter Finder verified: ${email}`);
                }
              } else {
                domainMismatch = true;
                addTrace("hunter_finder", { email, rejected: true, reason: domainCheck.reason, duration_ms: Date.now() - start });
              }
            } else {
              addTrace("hunter_finder", { email, score, verification, rejected: true, reason: "low_score_or_invalid", duration_ms: Date.now() - start });
            }
          } else {
            addTrace("hunter_finder", { found: false, duration_ms: Date.now() - start });
          }
        } else {
          addTrace("hunter_finder", { http_status: resp.status, duration_ms: Date.now() - start });
        }
      } catch (e) {
        addTrace("hunter_finder", { error: (e as Error).message, duration_ms: Date.now() - start });
      }
    }

    // ─── STEP 5 (before 3): Pattern Leverage if intel exists ───────────
    if (!finalEmail) {
      const { data: intel } = await supabase
        .from("company_email_intel")
        .select("*")
        .eq("company_id", target.company_id)
        .maybeSingle();

      if (intel?.pattern && intel.mx_valid && (intel.pattern_confidence ?? 0) >= 0.6) {
        const generated = applyPattern(intel.pattern, target.first_name, target.last_name, target.company_domain);
        if (generated) {
          stats.pattern_generated++;
          console.log(`[Tier2:${target.name}] Step 5: Pattern leverage: ${generated}`);

          if (keys.HUNTER_API_KEY) {
            const verifyResult = await verifyEmail(generated, keys.HUNTER_API_KEY);
            stats.verify_calls++;
            addTrace("pattern_leverage", { email: generated, pattern: intel.pattern, verify_result: verifyResult });

            if (verifyResult === "verified" || verifyResult === "catch_all") {
              finalEmail = generated;
              finalEmailStatus = verifyResult === "verified" ? "deliverable" : verifyResult;
              finalSource = "pattern_verified";
              console.log(`[Tier2:${target.name}] ✓ Pattern verified: ${generated}`);
            }
          }
        }
      }

      // ─── STEP 3: Hunter Domain Search (pattern seeding) ──────────────
      if (!finalEmail && keys.HUNTER_API_KEY && !intel?.pattern &&
          !hunterDomainSearchCompanies.has(target.company_id) &&
          stats.hunter_domain_search_calls < MAX_HUNTER_DOMAIN_SEARCH) {

        // Check if at least 2 stakeholders at this company lack email
        const { count } = await supabase
          .from("stakeholders")
          .select("id", { count: "exact", head: true })
          .eq("company_id", target.company_id)
          .is("email", null);

        if ((count ?? 0) >= 2) {
          const start = Date.now();
          stats.hunter_domain_search_calls++;
          hunterDomainSearchCompanies.add(target.company_id);
          console.log(`[Tier2:${target.name}] Step 3: Hunter Domain Search`);

          try {
            const url = `https://api.hunter.io/v2/domain-search?domain=${encodeURIComponent(target.company_domain)}&api_key=${keys.HUNTER_API_KEY}&limit=20`;
            const resp = await fetch(url, { method: "GET" });

            if (resp.ok) {
              const data = await resp.json();
              const emails: Array<{ value: string; first_name: string; last_name: string; confidence: number }> = data.data?.emails || [];

              // Filter to only emails matching company domain
              const domainEmails = emails.filter(e => {
                const d = e.value.split("@")[1]?.toLowerCase();
                return d === target.company_domain.toLowerCase();
              });

              if (domainEmails.length >= 2) {
                // Detect pattern from examples
                const pattern = detectPatternFromExamples(domainEmails);
                if (pattern) {
                  // Write company_email_intel
                  await supabase.from("company_email_intel").upsert({
                    company_id: target.company_id,
                    domain: target.company_domain,
                    pattern: pattern.pattern,
                    pattern_confidence: pattern.confidence,
                    mx_valid: true,
                    examples: domainEmails.slice(0, 5).map(e => ({ email: e.value, name: `${e.first_name} ${e.last_name}` })),
                    sources: [{ type: "hunter_domain_search", date: new Date().toISOString() }],
                  }, { onConflict: "company_id" });

                  addTrace("hunter_domain_search", {
                    emails_found: domainEmails.length,
                    pattern: pattern.pattern,
                    confidence: pattern.confidence,
                    duration_ms: Date.now() - start,
                  });

                  // Generate candidate email for this stakeholder
                  const generated = applyPattern(pattern.pattern, target.first_name, target.last_name, target.company_domain);
                  if (generated) {
                    stats.pattern_generated++;
                    const verifyResult = await verifyEmail(generated, keys.HUNTER_API_KEY);
                    stats.verify_calls++;
                    addTrace("hunter_domain_pattern_verify", { email: generated, verify_result: verifyResult });

                    if (verifyResult === "verified" || verifyResult === "catch_all") {
                      finalEmail = generated;
                      finalEmailStatus = verifyResult === "verified" ? "deliverable" : verifyResult;
                      finalSource = "hunter_domain_pattern";
                      console.log(`[Tier2:${target.name}] ✓ Domain pattern verified: ${generated}`);
                    }
                  }
                } else {
                  addTrace("hunter_domain_search", { emails_found: domainEmails.length, pattern_detected: false, duration_ms: Date.now() - start });
                }
              } else {
                addTrace("hunter_domain_search", { emails_found: domainEmails.length, reason: "insufficient_examples", duration_ms: Date.now() - start });
              }
            } else {
              addTrace("hunter_domain_search", { http_status: resp.status, duration_ms: Date.now() - start });
            }
          } catch (e) {
            addTrace("hunter_domain_search", { error: (e as Error).message, duration_ms: Date.now() - start });
          }
        }
      }
    }

    // ─── STEP 6: Deep Discovery (last resort) ─────────────────────────
    if (!finalEmail && !deepDiscoveryCompanies.has(target.company_id) && stats.deep_discovery_companies < MAX_DEEP_DISCOVERY_COMPANIES) {
      // Check if Deep Discovery has run for this company in last 7 days
      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString();
      const { data: recentDD } = await supabase
        .from("stakeholder_enrichment_attempts")
        .select("id")
        .eq("company_id", target.company_id)
        .gte("started_at", sevenDaysAgo)
        .limit(1);

      // Check if trace contains deep_discovery (approximation via final_source)
      const hasRecentDD = recentDD?.some(() => true); // If any attempt exists, check traces
      // More precise: check if company_email_intel was updated recently
      const { data: recentIntel } = await supabase
        .from("company_email_intel")
        .select("updated_at")
        .eq("company_id", target.company_id)
        .gte("updated_at", sevenDaysAgo)
        .maybeSingle();

      if (!recentIntel) {
        const start = Date.now();
        deepDiscoveryCompanies.add(target.company_id);
        stats.deep_discovery_companies++;
        console.log(`[Tier2:${target.name}] Step 6: Deep Discovery (company-level)`);

        try {
          const deepResp = await fetch(`${keys.SUPABASE_URL}/functions/v1/deep-email-discovery`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${keys.SUPABASE_SERVICE_ROLE_KEY}`,
            },
            body: JSON.stringify({
              firstName: target.first_name,
              lastName: target.last_name,
              fullName: target.name,
              jobTitle: target.title || "",
              companyName: target.company_name,
              companyWebsite: `https://${target.company_domain}`,
              resolvedDomain: target.company_domain,
              linkedinUrl: target.linkedin_url || "",
            }),
          });

          if (deepResp.ok) {
            const deepResult = await deepResp.json();
            if (deepResult.success && deepResult.data) {
              const dd = deepResult.data;
              addTrace("deep_discovery", {
                email: dd.candidateEmail,
                confidence: dd.confidenceScore,
                pattern: dd.emailPattern,
                status: dd.candidateEmailStatus,
                duration_ms: Date.now() - start,
              });

              if (dd.candidateEmail && dd.confidenceScore >= 0.4) {
                const domainCheck = checkDomainGuardrail(dd.candidateEmail, target.company_domain, aliasMap);
                if (domainCheck.accepted) {
                  if (keys.HUNTER_API_KEY) {
                    const verifyResult = await verifyEmail(dd.candidateEmail, keys.HUNTER_API_KEY);
                    stats.verify_calls++;
                    if (verifyResult === "verified" || verifyResult === "catch_all") {
                      finalEmail = dd.candidateEmail;
                      finalEmailStatus = verifyResult === "verified" ? "deliverable" : verifyResult;
                      finalSource = "deep_discovery_verified";
                      console.log(`[Tier2:${target.name}] ✓ Deep Discovery verified: ${dd.candidateEmail}`);

                      // Update company_email_intel if pattern found
                      if (dd.emailPattern) {
                        await supabase.from("company_email_intel").upsert({
                          company_id: target.company_id,
                          domain: target.company_domain,
                          pattern: dd.emailPattern,
                          pattern_confidence: dd.confidenceScore,
                          mx_valid: true,
                          examples: [{ email: dd.candidateEmail, name: target.name, verified: true }],
                          sources: [{ type: "deep_discovery", date: new Date().toISOString() }],
                        }, { onConflict: "company_id" });
                      }
                    } else {
                      addTrace("deep_discovery_verify_fail", { email: dd.candidateEmail, verify_result: verifyResult });
                    }
                  }
                } else {
                  domainMismatch = true;
                  addTrace("deep_discovery", { rejected: true, reason: domainCheck.reason });
                }
              }
            } else {
              addTrace("deep_discovery", { found: false, duration_ms: Date.now() - start });
            }
          } else {
            addTrace("deep_discovery", { http_status: deepResp.status, duration_ms: Date.now() - start });
          }
        } catch (e) {
          addTrace("deep_discovery", { error: (e as Error).message, duration_ms: Date.now() - start });
        }
      } else {
        addTrace("deep_discovery", { skipped: true, reason: "recent_run_exists" });
      }
    }

  } catch (error) {
    pipelineError = (error as Error).message;
    console.error(`[Tier2:${target.name}] Error:`, error);
  } finally {
    // ─── PERSIST RESULTS ─────────────────────────────────────────────
    const updates: Record<string, unknown> = {
      enriched_at: new Date().toISOString(),
    };

    let outcome: Tier2Result["outcome"] = "not_found";

    if (finalEmail) {
      updates.email = finalEmail;
      updates.enrichment_source = `tier2_${finalSource}`;

      // Map to safe statuses
      if (finalEmailStatus === "deliverable" || finalEmailStatus === "verified") {
        updates.email_status = "verified";
        updates.email_confidence = 1.0;
        outcome = "verified";
      } else if (finalEmailStatus === "catch_all") {
        // Determine safe vs not safe based on domain quality
        updates.email_status = "catch_all";
        updates.email_confidence = 0.7;
        outcome = "catch_all_safe"; // Tier 2 only persists if verification passed
      }
    } else if (domainMismatch) {
      outcome = "needs_review";
    } else if (pipelineError) {
      outcome = "error";
    }

    if (finalEmail) {
      await supabase.from("stakeholders").update(updates).eq("id", target.id);
    }

    // Update attempt row
    const attemptStatus = finalEmail ? "succeeded"
      : domainMismatch ? "needs_review"
      : pipelineError ? "failed"
      : "not_found";

    if (attemptId) {
      await supabase.from("stakeholder_enrichment_attempts").update({
        status: attemptStatus,
        final_email: finalEmail,
        final_email_status: finalEmailStatus,
        final_source: finalSource ? `tier2_${finalSource}` : null,
        trace: traceSteps,
        error: pipelineError,
        finished_at: new Date().toISOString(),
      }).eq("id", attemptId);
    }
  }

  return {
    stakeholder_id: target.id,
    stakeholder_name: target.name,
    outcome: finalEmail
      ? (finalEmailStatus === "deliverable" || finalEmailStatus === "verified" ? "verified" : "catch_all_safe")
      : domainMismatch ? "needs_review"
      : pipelineError ? "error"
      : "not_found",
    email: finalEmail || undefined,
    email_status: finalEmailStatus || undefined,
    source: finalSource ? `tier2_${finalSource}` : undefined,
    error: pipelineError || undefined,
  };
}

// ─── CROSS-DOMAIN GUARDRAIL ─────────────────────────────────────────────────

function checkDomainGuardrail(
  email: string,
  companyDomain: string,
  aliasMap: Map<string, string[]>,
): { accepted: boolean; reason: string } {
  const emailDomain = email.split("@")[1]?.toLowerCase();
  const expected = companyDomain.toLowerCase();

  if (!emailDomain) return { accepted: false, reason: "no_email_domain" };
  if (emailDomain === expected) return { accepted: true, reason: "exact_match" };

  // Check domain aliases
  if (aliasMap.has(emailDomain) || aliasMap.has(expected)) {
    // Check if either domain lists the other as an alias
    const emailAliases = aliasMap.get(emailDomain) || [];
    const companyAliases = aliasMap.get(expected) || [];
    if (emailAliases.length || companyAliases.length) {
      return { accepted: true, reason: "domain_alias_match" };
    }
  }

  // Check parent/subdomain
  if (emailDomain.endsWith(`.${expected}`) || expected.endsWith(`.${emailDomain}`)) {
    return { accepted: true, reason: "subdomain_match" };
  }

  return { accepted: false, reason: `domain_mismatch: ${emailDomain} vs ${expected}` };
}

// ─── PATTERN DETECTION FROM EXAMPLES ─────────────────────────────────────────

function detectPatternFromExamples(
  emails: Array<{ value: string; first_name: string; last_name: string }>,
): { pattern: string; confidence: number } | null {
  const patternCounts: Record<string, number> = {};

  for (const e of emails) {
    const local = e.value.split("@")[0]?.toLowerCase();
    const f = e.first_name?.toLowerCase().replace(/[^a-z]/g, "") || "";
    const l = e.last_name?.toLowerCase().replace(/[^a-z]/g, "") || "";
    if (!local || !f || !l) continue;

    if (local === `${f}.${l}`) patternCounts["first.last"] = (patternCounts["first.last"] || 0) + 1;
    else if (local === `${f[0]}.${l}`) patternCounts["f.last"] = (patternCounts["f.last"] || 0) + 1;
    else if (local === `${f}${l}`) patternCounts["firstlast"] = (patternCounts["firstlast"] || 0) + 1;
    else if (local === `${f[0]}${l}`) patternCounts["flast"] = (patternCounts["flast"] || 0) + 1;
    else if (local === `${f}.${l[0]}`) patternCounts["first.l"] = (patternCounts["first.l"] || 0) + 1;
    else if (local === `${l}.${f}`) patternCounts["last.first"] = (patternCounts["last.first"] || 0) + 1;
    else if (local === f) patternCounts["first"] = (patternCounts["first"] || 0) + 1;
  }

  const entries = Object.entries(patternCounts).sort((a, b) => b[1] - a[1]);
  if (!entries.length || entries[0][1] < 2) return null;

  return {
    pattern: entries[0][0],
    confidence: Math.min(entries[0][1] / emails.length, 1.0),
  };
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function applyPattern(pattern: string, firstName: string, lastName: string, domain: string): string | null {
  const f = firstName.toLowerCase().replace(/[^a-z]/g, "");
  const l = lastName.toLowerCase().replace(/[^a-z]/g, "");
  if (!f || !l) return null;

  const patternMap: Record<string, string> = {
    "first.last": `${f}.${l}`,
    "f.last": `${f[0]}.${l}`,
    "first.l": `${f}.${l[0]}`,
    "flast": `${f[0]}${l}`,
    "firstlast": `${f}${l}`,
    "last.first": `${l}.${f}`,
    "lfirst": `${l[0]}${f}`,
    "first": f,
    "last": l,
    "first_last": `${f}_${l}`,
    "f_last": `${f[0]}_${l}`,
  };

  const local = patternMap[pattern];
  return local ? `${local}@${domain}` : null;
}

async function verifyEmail(email: string, hunterApiKey: string | undefined): Promise<string> {
  if (!hunterApiKey) return "unknown";
  try {
    const resp = await fetch(
      `https://api.hunter.io/v2/email-verifier?email=${encodeURIComponent(email)}&api_key=${hunterApiKey}`,
      { method: "GET" }
    );

    if (resp.status === 202) return "pending";
    if (!resp.ok) return "unknown";

    const data = await resp.json();
    if (data.errors?.length) return "unknown";

    const result = data.data?.result || data.data?.status;
    switch (result) {
      case "deliverable":
      case "valid":
        return "verified";
      case "undeliverable":
      case "invalid":
        return "undeliverable";
      case "risky":
      case "accept_all":
        return data.data?.accept_all ? "catch_all" : "unknown";
      default:
        return "unknown";
    }
  } catch {
    return "unknown";
  }
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
