import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface StakeholderState {
  id: string;
  campaign_id: string;
  stakeholder_id: string;
  current_step_order: number;
  status: string;
  last_action_at: string | null;
  next_step_scheduled_at: string | null;
}

interface CampaignStep {
  id: string;
  campaign_id: string;
  step_order: number;
  step_type: string;
  template_id: string | null;
  delay_minutes: number;
}

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body_html: string;
  include_unsubscribe_link: boolean;
  include_cv_attachment: boolean;
}

interface Stakeholder {
  id: string;
  name: string;
  email: string | null;
  title: string | null;
  phone: string | null;
  location: string | null;
  linkedin_url: string | null;
  gender: string | null;
  company: {
    id: string;
    name: string;
    domain: string | null;
    website_url: string | null;
    industry: string | null;
    employee_count: number | null;
    city: string | null;
    country: string | null;
    description: string | null;
    linkedin_url: string | null;
  } | null;
}

interface Job {
  id: string;
  title: string;
  description: string | null;
  location: string | null;
  salary_range: string | null;
  job_type: string | null;
  experience_level: string | null;
  requirements: string | null;
  skills_required: string[] | null;
  source_url: string | null;
}

/**
 * Add business days to a date (skipping weekends)
 */
function addBusinessDays(date: Date, businessDays: number): Date {
  const result = new Date(date);
  let daysAdded = 0;
  while (daysAdded < businessDays) {
    result.setDate(result.getDate() + 1);
    const dayOfWeek = result.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      daysAdded++;
    }
  }
  return result;
}

/**
 * Classify a stakeholder's title into a role category for variant selection
 */
function classifyStakeholderRole(title: string | null): "c_suite" | "hr_talent" | "general" {
  if (!title) return "general";
  const t = title.toLowerCase();
  
  // C-suite patterns
  const cSuitePatterns = [
    "ceo", "cto", "cfo", "coo", "cmo", "cio", "cpo", "cdo",
    "chief ", "c-level",
    "managing director", "founder", "co-founder", "cofounder",
    "president", "vice president", "vp ", "svp ", "evp ",
    "partner", "principal", "owner", "director general",
    "board member", "chairman", "chairwoman", "chairperson",
  ];
  
  // HR/Talent patterns
  const hrPatterns = [
    "talent", "recruit", "people", "human resource", "hr ",
    " hr", "hiring", "staffing", "workforce",
    "people & culture", "people and culture", "people ops",
    "head of people", "vp people", "vp talent", "vp hr",
    "director of people", "director of talent", "director of hr",
  ];
  
  for (const p of cSuitePatterns) {
    if (t.includes(p)) return "c_suite";
  }
  for (const p of hrPatterns) {
    if (t.includes(p)) return "hr_talent";
  }
  return "general";
}

/**
 * Strip HTML tags to produce a plain-text fallback
 */
function htmlToPlainText(html: string): string {
  return html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/div>/gi, "\n")
    .replace(/<\/tr>/gi, "\n")
    .replace(/<\/li>/gi, "\n")
    .replace(/<li[^>]*>/gi, "  • ")
    .replace(/<a[^>]*href="([^"]*)"[^>]*>([^<]*)<\/a>/gi, "$2 ($1)")
    .replace(/<hr[^>]*>/gi, "\n---\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/**
 * Wrap HTML body content in a proper email document structure
 */
function wrapInHtmlDocument(bodyContent: string, fontFamily = "Arial, sans-serif"): string {
  return `<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="format-detection" content="telephone=no, date=no, address=no, email=no" />
  <!--[if mso]><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml><![endif]-->
  <style>
    body { margin: 0; padding: 0; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: ${fontFamily}; }
    table { border-spacing: 0; border-collapse: collapse; }
    img { border: 0; line-height: 100%; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#ffffff;font-family:${fontFamily};">
  <div style="font-family:${fontFamily};">
  ${bodyContent}
  </div>
</body>
</html>`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Build the unsubscribe base URL
    const unsubscribeBaseUrl = `${supabaseUrl}/functions/v1/campaign-unsubscribe`;

    // Get email send delay and signature settings in parallel
    const [delayResult, signatureResult] = await Promise.all([
      supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "email_send_delay_seconds")
        .single(),
      supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "email_signature")
        .single(),
    ]);

    const emailDelayMs = (parseInt(delayResult.data?.setting_value || "120") * 1000);

    // Build signature HTML if configured
    let signatureHtml = "";
    let logoAttachment: { contentId: string; contentBytes: string; contentType: string; name: string } | null = null;
    let signatureFontFamily = "Arial, sans-serif";

    if (signatureResult.data?.setting_value) {
      try {
        const sig = JSON.parse(signatureResult.data.setting_value);

        // Map font value to email-safe font family (mirrors SignatureManager SIGNATURE_FONTS)
        const fontMap: Record<string, string> = {
          "atos-body": "'ATOS Body', 'Verdana', sans-serif",
          "inter": "Arial, sans-serif",
          "georgia": "'Georgia', serif",
          "times": "'Times New Roman', serif",
          "arial": "'Arial', sans-serif",
          "helvetica": "'Helvetica Neue', 'Helvetica', sans-serif",
          "verdana": "'Verdana', sans-serif",
          "trebuchet": "'Trebuchet MS', sans-serif",
          "palatino": "'Palatino Linotype', 'Palatino', serif",
          "garamond": "'Garamond', serif",
          "courier": "'Courier New', monospace",
        };
        const fontFamily = fontMap[sig.fontFamily] || "Arial, sans-serif";
        signatureFontFamily = fontFamily;
        const fontSize = sig.fontSize || 14;
        const primaryColor = sig.primaryColor || "#6B21A8";
        const secondaryColor = sig.secondaryColor || "#1F2937";

        const cellStyle = `padding:4px 0;vertical-align:middle;font-size:${fontSize}px;font-family:${fontFamily};`;

        const contactRows: string[] = [];
        if (sig.phone) {
          contactRows.push(`<tr><td style="${cellStyle}color:${secondaryColor};white-space:nowrap;padding-right:12px;">Tel:</td><td style="${cellStyle}color:${secondaryColor};white-space:nowrap;">${sig.phone}</td></tr>`);
        }
        if (sig.email) {
          contactRows.push(`<tr><td style="${cellStyle}color:${secondaryColor};padding-right:12px;">Email:</td><td style="${cellStyle}"><a href="mailto:${sig.email}" style="color:${primaryColor};text-decoration:none;font-family:${fontFamily};">${sig.email}</a></td></tr>`);
        }
        if (sig.website) {
          const displayUrl = sig.website.replace(/^https?:\/\//, "");
          contactRows.push(`<tr><td style="${cellStyle}color:${secondaryColor};padding-right:12px;">Web:</td><td style="${cellStyle}"><a href="${sig.website}" style="color:${primaryColor};text-decoration:none;font-family:${fontFamily};">${displayUrl}</a></td></tr>`);
        }
        if (sig.linkedin) {
          contactRows.push(`<tr><td style="${cellStyle}color:${secondaryColor};padding-right:12px;">LinkedIn:</td><td style="${cellStyle}"><a href="${sig.linkedin}" style="color:${primaryColor};text-decoration:none;font-family:${fontFamily};">LinkedIn Profile</a></td></tr>`);
        }

        // Fetch logo and base64-encode for CID embedding
        let logoHtml = "";
        if (sig.showLogo && sig.logoUrl) {
          try {
            const logoResponse = await fetch(sig.logoUrl);
            if (logoResponse.ok) {
              const logoBuffer = await logoResponse.arrayBuffer();
              const logoBytes = new Uint8Array(logoBuffer);
              // Base64 encode
              let binary = "";
              for (let i = 0; i < logoBytes.length; i++) {
                binary += String.fromCharCode(logoBytes[i]);
              }
              const base64Logo = btoa(binary);
              const contentType = logoResponse.headers.get("content-type") || "image/png";
              const ext = contentType.includes("png") ? "png" : contentType.includes("svg") ? "svg" : "jpg";

              logoAttachment = {
                contentId: "signature-logo",
                contentBytes: base64Logo,
                contentType,
                name: `logo.${ext}`,
              };
              logoHtml = `<td style="vertical-align:top;padding-right:24px;"><img src="cid:signature-logo" alt="Logo" style="width:${sig.logoSize || 80}px;height:auto;" /></td>`;
            }
          } catch (logoErr) {
            console.error("Failed to fetch logo for CID embedding:", logoErr);
            // Fallback to URL reference
            logoHtml = `<td style="vertical-align:top;padding-right:24px;"><img src="${sig.logoUrl}" alt="Logo" style="width:${sig.logoSize || 80}px;height:auto;" /></td>`;
          }
        }

        const contactDivider = `<hr style="border:none;border-top:1px solid #d1d5db;margin:12px 0;width:250px;" />`;

        const contactTableHtml = contactRows.length > 0
          ? `<table cellpadding="0" cellspacing="0" style="font-family:${fontFamily};">${contactRows.join("")}</table>`
          : "";

        signatureHtml = `
<div style="margin-top:32px;">
  <table cellpadding="0" cellspacing="0" style="font-family:${fontFamily};font-size:${fontSize}px;color:${secondaryColor};">
    <tr>
      ${logoHtml}
      <td style="vertical-align:top;">
        <p style="margin:0 0 8px 0;font-family:${fontFamily};font-size:${fontSize}px;color:${secondaryColor};">${sig.signOff || "Best Regards"},</p>
        <p style="margin:0;font-weight:700;font-size:${fontSize + 4}px;color:${secondaryColor};font-family:${fontFamily};">${sig.fullName || ""}</p>
        <p style="margin:4px 0 0 0;color:${secondaryColor};font-family:${fontFamily};">${sig.jobTitle || ""}</p>
        ${sig.company ? `<p style="margin:2px 0 0 0;color:${secondaryColor};font-family:${fontFamily};">${sig.company}</p>` : ""}
        ${contactDivider}
        ${contactTableHtml}
      </td>
    </tr>
  </table>
</div>`;
      } catch (e) {
        console.error("Failed to parse signature settings:", e);
      }
    }

    // Get all running campaigns
    const { data: campaigns, error: campaignsError } = await supabase
      .from("campaigns")
      .select("id, name, candidate_id, created_by")
      .eq("status", "running");

    if (campaignsError) throw campaignsError;

    if (!campaigns || campaigns.length === 0) {
      return new Response(
        JSON.stringify({ message: "No running campaigns" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let totalProcessed = 0;
    let totalSent = 0;

    for (const campaign of campaigns) {
      // Get active email connection for sending
      const { data: emailConnection } = await supabase
        .from("email_connections")
        .select("id, email_address")
        .eq("is_active", true)
        .eq("use_oauth", true)
        .limit(1)
        .single();

      if (!emailConnection) {
        console.log("No active email connection found");
        continue;
      }

      // Fetch candidate data if this is a prospect campaign
      let candidateData: { name: string; current_title: string | null; email: string | null; skills: string[] | null; experience_years: number | null; ai_summary: string | null } | null = null;
      if (campaign.candidate_id) {
        const { data: cand } = await supabase
          .from("candidates")
          .select("name, current_title, email, skills, experience_years, ai_summary")
          .eq("id", campaign.candidate_id)
          .single();
        candidateData = cand;
      }

      // Fetch sender profile for consultant_name and test-mode redirect email
      let consultantName = "";
      let creatorEmail = "";
      if (campaign.created_by) {
        const { data: authUser } = await supabase.auth.admin.getUserById(campaign.created_by);
        creatorEmail = authUser?.user?.email || "";

        const { data: profile } = await supabase
          .from("profiles")
          .select("full_name")
          .eq("user_id", campaign.created_by)
          .single();
        consultantName = profile?.full_name || "";
      }

      // Get all steps for this campaign
      const { data: steps } = await supabase
        .from("campaign_steps")
        .select("*")
        .eq("campaign_id", campaign.id)
        .order("step_order", { ascending: true });

      if (!steps || steps.length === 0) continue;

      // Get stakeholders ready for next step
      const { data: stakeholderStates, error: statesError } = await supabase
        .from("stakeholder_campaign_states")
        .select("*")
        .eq("campaign_id", campaign.id)
        .in("status", ["pending", "in_progress"]);

      if (statesError) throw statesError;
      if (!stakeholderStates || stakeholderStates.length === 0) continue;

      for (const state of stakeholderStates as StakeholderState[]) {
        // Check if we should process this stakeholder
        if (state.next_step_scheduled_at) {
          const scheduledTime = new Date(state.next_step_scheduled_at);
          if (scheduledTime > new Date()) {
            continue;
          }
        }

        // Find the next step to execute
        const nextStepOrder = state.current_step_order + 1;
        const nextStep = steps.find((s: CampaignStep) => s.step_order === nextStepOrder);

        if (!nextStep) {
          await supabase
            .from("stakeholder_campaign_states")
            .update({
              status: "completed",
              completed_at: new Date().toISOString(),
            })
            .eq("id", state.id);
          continue;
        }

        if (nextStep.step_type === "wait_delay") {
          const businessDays = Math.round(nextStep.delay_minutes / 1440);
          const nextScheduled = businessDays > 0
            ? addBusinessDays(new Date(), businessDays)
            : new Date();

          await supabase
            .from("stakeholder_campaign_states")
            .update({
              current_step_order: nextStepOrder,
              status: "in_progress",
              last_action_at: new Date().toISOString(),
              next_step_scheduled_at: nextScheduled.toISOString(),
            })
            .eq("id", state.id);
          totalProcessed++;
          continue;
        }

        if (nextStep.step_type === "send_email" && nextStep.template_id) {
          const { data: template } = await supabase
            .from("email_templates")
            .select("*")
            .eq("id", nextStep.template_id)
            .single();

          if (!template) continue;

          const { data: stakeholder } = await supabase
            .from("stakeholders")
            .select(`
              id, name, email, email_status, email_confidence, enrichment_source, title, phone, location, linkedin_url, gender,
              company:companies(
                id, name, domain, domain_status, domain_quality_score, website_url, industry, employee_count,
                city, country, description, linkedin_url
              )
            `)
            .eq("id", state.stakeholder_id)
            .single();

          if (!stakeholder?.email) {
            console.log(`[GATE] Blocked ${state.stakeholder_id}: no email`);
            await supabase.from("stakeholder_campaign_states").update({
              status: "blocked",
              blocked_reason_code: "NO_EMAIL",
              blocked_reason_text: "Stakeholder has no email address",
            }).eq("id", state.id);
            continue;
          }

          // === Campaign Quality Gate ===
          const emailStatus = (stakeholder as any).email_status;
          const enrichmentSource = (stakeholder as any).enrichment_source;
          const company = (stakeholder as any).company;
          const companyDomainStatus = company?.domain_status;
          const companyDomainScore = company?.domain_quality_score;

          // Helper to block with reason
          const blockStakeholder = async (code: string, text: string) => {
            console.log(`[GATE] Blocked ${stakeholder.name}: ${code} — ${text}`);
            await supabase.from("stakeholder_campaign_states").update({
              status: "blocked",
              blocked_reason_code: code,
              blocked_reason_text: text,
            }).eq("id", state.id);
          };

          // 1. Block if enrichment still pending async
          if (enrichmentSource === "bettercontact_pending") {
            await blockStakeholder("EMAIL_PENDING_ASYNC", "Email enrichment is still pending (BetterContact async)");
            continue;
          }

          // 2. Block if email status is explicitly bad
          if (emailStatus === "undeliverable" || emailStatus === "invalid") {
            await blockStakeholder("EMAIL_INVALID", `Email status is ${emailStatus}`);
            continue;
          }

          // 3. Block unverified emails by default — only allow verified + catch_all
          const allowedStatuses = ["verified", "catch_all"];
          if (emailStatus && !allowedStatuses.includes(emailStatus)) {
            await blockStakeholder("EMAIL_UNVERIFIED_POLICY", `Email status '${emailStatus}' is not in allowed list (verified, catch_all)`);
            continue;
          }

          // 4. Block if company domain is unresolved
          if (companyDomainStatus === "unresolved") {
            await blockStakeholder("DOMAIN_UNRESOLVED", "Company domain is unresolved");
            continue;
          }

          // 5. Block low-confidence domains unless manually locked
          if (companyDomainStatus !== "resolved" || (companyDomainScore != null && companyDomainScore < 0.70)) {
            // Check if domain is manually locked via alias
            const { data: lockedAlias } = await supabase
              .from("company_domain_aliases")
              .select("id")
              .eq("domain", company?.domain || "")
              .eq("locked", true)
              .limit(1)
              .maybeSingle();

            if (!lockedAlias) {
              await blockStakeholder("DOMAIN_LOW_CONFIDENCE", `Domain status '${companyDomainStatus}' with score ${companyDomainScore ?? 'null'} — not locked`);
              continue;
            }
          }

          // Fetch the most recent job for this stakeholder's company
          let job: Job | null = null;
          if (stakeholder.company?.id) {
            const { data: jobData } = await supabase
              .from("jobs")
              .select("id, title, description, location, salary_range, job_type, experience_level, requirements, skills_required, source_url")
              .eq("company_id", stakeholder.company.id)
              .eq("status", "active")
              .order("created_at", { ascending: false })
              .limit(1)
              .maybeSingle();
            
            if (!jobData) {
              // Fallback: try any job for this company regardless of status
              const { data: anyJob } = await supabase
                .from("jobs")
                .select("id, title, description, location, salary_range, job_type, experience_level, requirements, skills_required, source_url")
                .eq("company_id", stakeholder.company.id)
                .order("created_at", { ascending: false })
                .limit(1)
                .maybeSingle();
              job = anyJob as Job | null;
            } else {
              job = jobData as Job;
            }
          }

          // Replace placeholders
          const replacePlaceholders = (text: string, sh: Stakeholder, jobInfo: Job | null): string => {
            const firstName = sh.name.split(" ")[0] || sh.name;
            const lastName = sh.name.split(" ").slice(1).join(" ") || "";
            const candidateFirstName = candidateData?.name?.split(" ")[0] || "";

            const replacements: Record<string, string> = {
              // Stakeholder fields
              stakeholder_name: sh.name || "",
              stakeholder_first_name: firstName,
              stakeholder_last_name: lastName,
              stakeholder_email: sh.email || "",
              stakeholder_title: sh.title || "",
              stakeholder_phone: sh.phone || "",
              stakeholder_location: sh.location || "",
              stakeholder_linkedin_url: sh.linkedin_url || "",
              stakeholder_gender: sh.gender || "",
              stakeholder_company: sh.company?.name || "",
              // Company fields
              company_name: sh.company?.name || "",
              company_domain: sh.company?.domain || "",
              company_website: sh.company?.website_url || "",
              company_industry: sh.company?.industry || "",
              company_employee_count: sh.company?.employee_count?.toString() || "",
              company_city: sh.company?.city || "",
              company_country: sh.company?.country || "",
              company_description: sh.company?.description || "",
              company_linkedin_url: sh.company?.linkedin_url || "",
              // Candidate fields
              candidate_name: candidateData?.name || "",
              candidate_first_name: candidateFirstName,
              candidate_current_title: candidateData?.current_title || "",
              candidate_title: candidateData?.current_title || "",
              candidate_email: candidateData?.email || "",
              candidate_skills: candidateData?.skills?.join(", ") || "",
              candidate_experience_years: candidateData?.experience_years?.toString() || "",
              candidate_summary: candidateData?.ai_summary || "",
              // Consultant / sender fields
              consultant_name: consultantName,
              sender_name: consultantName,
              // Job fields
              job_title: jobInfo?.title || "",
              job_description: jobInfo?.description || "",
              job_location: jobInfo?.location || "",
              job_salary_range: jobInfo?.salary_range || "",
              job_type: jobInfo?.job_type || "",
              job_experience_level: jobInfo?.experience_level || "",
              job_requirements: jobInfo?.requirements || "",
              job_skills_required: jobInfo?.skills_required?.join(", ") || "",
              job_source_url: jobInfo?.source_url || "",
            };

            let result = text;
            for (const [key, value] of Object.entries(replacements)) {
              result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, "g"), value);
            }
            return result;
          };

          const subject = replacePlaceholders(template.subject, stakeholder as Stakeholder, job);
          
          // Select role-appropriate body variant
          const roleCategory = classifyStakeholderRole((stakeholder as Stakeholder).title);
          const roleVariants = (template as any).role_variants as Record<string, string> | null;
          let rawBody = template.body_html;
          if (roleVariants && roleCategory !== "general" && roleVariants[roleCategory]) {
            rawBody = roleVariants[roleCategory];
            console.log(`[ROLE VARIANT] ${(stakeholder as Stakeholder).name} (${(stakeholder as Stakeholder).title}) → using "${roleCategory}" variant`);
          }
          let bodyContent = replacePlaceholders(rawBody, stakeholder as Stakeholder, job);

          // Append signature
          if (signatureHtml) {
            bodyContent += signatureHtml;
          }

          // --- Tracking injection ---
          const trackingBaseUrl = `${supabaseUrl}/functions/v1`;
          const trackParams = `c=${encodeURIComponent(campaign.id)}&s=${encodeURIComponent(state.stakeholder_id)}&st=${encodeURIComponent(nextStep.id)}&e=${encodeURIComponent(stakeholder.email)}`;

          // 1) Wrap all <a href="..."> links with click tracker (skip mailto: and cid:)
          bodyContent = bodyContent.replace(
            /<a\s([^>]*?)href="((?!mailto:|cid:)[^"]+)"([^>]*)>/gi,
            (_match: string, pre: string, href: string, post: string) => {
              const trackedUrl = `${trackingBaseUrl}/track-email-click?${trackParams}&url=${encodeURIComponent(href)}`;
              return `<a ${pre}href="${trackedUrl}"${post}>`;
            }
          );

          // 2) Inject open tracking pixel just before </body>
          const trackingPixelUrl = `${trackingBaseUrl}/track-email-open?${trackParams}`;
          const trackingPixelTag = `<img src="${trackingPixelUrl}" width="1" height="1" style="display:none;width:1px;height:1px;border:0;" alt="" />`;

          // Wrap in proper HTML document
          const bodyHtml = wrapInHtmlDocument(bodyContent, signatureFontFamily)
            .replace("</body>", `${trackingPixelTag}</body>`);

          // Generate plain-text alternative
          const bodyText = htmlToPlainText(bodyContent);

          // Note: List-Unsubscribe headers cannot be set via Microsoft Graph API's
          // internetMessageHeaders (only x- prefixed headers allowed). The unsubscribe
          // link in the email body serves as the opt-out mechanism instead.
          const customHeaders: Record<string, string> = {};

          // Apply anti-spam delay between sends
          if (totalSent > 0) {
            await new Promise((resolve) => setTimeout(resolve, emailDelayMs));
          }

          // Send email via MS365
          try {
            // Generate sanitised CV attachment if template requires it
            const attachments: any[] = logoAttachment ? [logoAttachment] : [];
            
            if ((template as any).include_cv_attachment && campaign.candidate_id) {
              try {
                const cvResponse = await fetch(
                  `${supabaseUrl}/functions/v1/sanitize-cv`,
                  {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: `Bearer ${supabaseServiceKey}`,
                    },
                    body: JSON.stringify({ candidateId: campaign.candidate_id }),
                  }
                );
                
                if (cvResponse.ok) {
                  const cvData = await cvResponse.json();
                  if (cvData.success && cvData.pdf) {
                    attachments.push({
                      contentId: null, // not inline
                      contentBytes: cvData.pdf,
                      contentType: "application/pdf",
                      name: cvData.filename || "candidate-profile.pdf",
                      isInline: false,
                    });
                    console.log(`[CV ATTACH] Sanitised CV attached for ${(stakeholder as Stakeholder).name}`);
                  }
                } else {
                  console.error("[CV ATTACH] Failed to generate sanitised CV:", await cvResponse.text());
                }
              } catch (cvErr) {
                console.error("[CV ATTACH] Error generating CV:", cvErr);
              }
            }

            const sendResponse = await fetch(
              `${supabaseUrl}/functions/v1/send-email-365`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${supabaseServiceKey}`,
                },
                body: JSON.stringify({
                  connectionId: emailConnection.id,
                  to: creatorEmail || emailConnection.email_address, // TEST MODE: redirect to campaign creator's email
                  subject,
                  body: bodyHtml,
                  bodyText,
                  isHtml: true,
                  customHeaders,
                  inlineAttachments: attachments.length > 0 ? attachments : undefined,
                }),
              }
            );

            const sendResult = await sendResponse.json();

            await supabase.from("campaign_metrics").insert({
              campaign_id: campaign.id,
              stakeholder_id: state.stakeholder_id,
              step_id: nextStep.id,
              email_address: stakeholder.email,
              event_type: sendResult.success ? "sent" : "failed",
              event_data: sendResult,
            });

            if (sendResult.success) {
              totalSent++;
            }
          } catch (sendError) {
            console.error("Failed to send email:", sendError);
            await supabase.from("campaign_metrics").insert({
              campaign_id: campaign.id,
              stakeholder_id: state.stakeholder_id,
              step_id: nextStep.id,
              email_address: stakeholder.email,
              event_type: "failed",
              event_data: { error: String(sendError) },
            });
          }

          // Update stakeholder state
          await supabase
            .from("stakeholder_campaign_states")
            .update({
              current_step_order: nextStepOrder,
              status: "in_progress",
              last_action_at: new Date().toISOString(),
              next_step_scheduled_at: null,
            })
            .eq("id", state.id);

          totalProcessed++;
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Processed ${totalProcessed} stakeholder steps, sent ${totalSent} emails`,
        processed: totalProcessed,
        sent: totalSent,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Campaign execution error:", error);
    return new Response(
      JSON.stringify({ success: false, error: String(error) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
