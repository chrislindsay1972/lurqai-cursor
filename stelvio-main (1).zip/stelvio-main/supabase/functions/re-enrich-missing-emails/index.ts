// Bulk re-enrich stakeholders through the full 4-tier pipeline
// Supports filtering by candidate_id to target specific candidate's contacts
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const body = await req.json().catch(() => ({}));
    const { candidate_id } = body;

    // Build query for stakeholders with no email
    let query = supabase
      .from("stakeholders")
      .select("id, name, email, linkedin_url, title, company_id, enrichment_source, notes")
      .is("email", null);

    // If candidate_id provided, filter to companies matched to that candidate
    if (candidate_id) {
      // Get company IDs from matches for this candidate
      const { data: matchedJobs } = await supabase
        .from("matches")
        .select("job_id")
        .eq("candidate_id", candidate_id);

      if (!matchedJobs?.length) {
        return new Response(
          JSON.stringify({ success: true, processed: 0, message: "No matches found for candidate" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const jobIds = matchedJobs.map((m: { job_id: string }) => m.job_id);
      const { data: jobs } = await supabase
        .from("jobs")
        .select("company_id")
        .in("id", jobIds);

      const companyIds = [...new Set((jobs || []).map((j: { company_id: string | null }) => j.company_id).filter(Boolean))] as string[];

      if (!companyIds.length) {
        return new Response(
          JSON.stringify({ success: true, processed: 0, message: "No companies found" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      query = query.in("company_id", companyIds);
    }

    const { data: stakeholders, error } = await query.limit(50);
    if (error) throw error;

    console.log(`[Re-enrich] Found ${stakeholders?.length || 0} stakeholders to process`);

    if (!stakeholders?.length) {
      return new Response(
        JSON.stringify({ success: true, processed: 0, message: "No eligible stakeholders found" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get company info
    const companyIds = [...new Set(stakeholders.map((s) => s.company_id).filter(Boolean))];
    const { data: companies } = await supabase
      .from("companies")
      .select("id, domain, name")
      .in("id", companyIds as string[]);

    const companyMap = new Map((companies || []).map((c) => [c.id, c]));

    const results: { name: string; status: string; email?: string; source?: string; error?: string }[] = [];

    for (const s of stakeholders) {
      const nameParts = (s.name || "").trim().split(/\s+/);
      const firstName = nameParts[0] || "";
      const lastName = nameParts.slice(1).join(" ") || "";
      if (!firstName) {
        results.push({ name: s.name, status: "skipped", error: "no first name" });
        continue;
      }

      const company = s.company_id ? companyMap.get(s.company_id) : null;

      try {
        console.log(`[Re-enrich] Processing: ${s.name} @ ${company?.name || "unknown"}`);

        const enrichResp = await fetch(`${SUPABASE_URL}/functions/v1/enrich-contact-bettercontact`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          },
          body: JSON.stringify({
            stakeholder_id: s.id,
            first_name: firstName,
            last_name: lastName,
            company_name: company?.name || undefined,
            company_domain: company?.domain || undefined,
            linkedin_url: s.linkedin_url || undefined,
            title: s.title || undefined,
          }),
        });

        if (enrichResp.ok) {
          const result = await enrichResp.json();
          results.push({
            name: s.name,
            status: result.success ? "completed" : "failed",
            email: result.email || undefined,
            source: result.enrichment_source || undefined,
            error: result.error || undefined,
          });
          console.log(`[Re-enrich] ✓ ${s.name}: ${result.email || "no email"} (${result.enrichment_source || "none"})`);
        } else {
          const errText = await enrichResp.text();
          results.push({ name: s.name, status: "error", error: `HTTP ${enrichResp.status}` });
          console.error(`[Re-enrich] ✗ ${s.name}: ${enrichResp.status} ${errText.slice(0, 200)}`);
        }

        // Small delay between calls to avoid overwhelming APIs
        await new Promise((r) => setTimeout(r, 1000));
      } catch (e) {
        results.push({ name: s.name, status: "error", error: e instanceof Error ? e.message : "unknown" });
        console.error(`[Re-enrich] ✗ ${s.name}:`, e);
      }
    }

    const found = results.filter((r) => r.email).length;
    const failed = results.filter((r) => r.status === "error" || r.status === "failed").length;

    console.log(`[Re-enrich] Complete: ${found} emails found, ${failed} failed, ${results.length} total`);

    return new Response(
      JSON.stringify({ success: true, processed: results.length, found, failed, results }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("[Re-enrich] Fatal error:", e);
    return new Response(
      JSON.stringify({ success: false, error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
