// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state"); // Contains connectionId
  const error = url.searchParams.get("error");
  const errorDescription = url.searchParams.get("error_description");

  const MS365_CLIENT_ID = Deno.env.get("MS365_CLIENT_ID");
  const MS365_CLIENT_SECRET = Deno.env.get("MS365_CLIENT_SECRET");
  const MS365_TENANT_ID = Deno.env.get("MS365_TENANT_ID");
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");

  // Build redirect URL for response
  const appUrl = req.headers.get("origin") || "https://stelvio.lovable.app";

  if (error) {
    console.error("OAuth error:", error, errorDescription);
    return Response.redirect(
      `${appUrl}/settings?tab=email&error=${encodeURIComponent(errorDescription || error)}`,
      302
    );
  }

  if (!code || !state) {
    return Response.redirect(
      `${appUrl}/settings?tab=email&error=${encodeURIComponent("Missing authorization code or state")}`,
      302
    );
  }

  if (!MS365_CLIENT_ID || !MS365_CLIENT_SECRET || !MS365_TENANT_ID) {
    console.error("Missing MS365 credentials");
    return Response.redirect(
      `${appUrl}/settings?tab=email&error=${encodeURIComponent("Server configuration error")}`,
      302
    );
  }

  try {
    // Parse state to get connectionId
    const { connectionId } = JSON.parse(atob(state));

    if (!connectionId) {
      throw new Error("Invalid state - missing connectionId");
    }

    // Build the callback URL
    const redirectUri = `${SUPABASE_URL}/functions/v1/ms365-oauth-callback`;

    // Exchange code for tokens
    const tokenResponse = await fetch(
      `https://login.microsoftonline.com/${MS365_TENANT_ID}/oauth2/v2.0/token`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          client_id: MS365_CLIENT_ID,
          client_secret: MS365_CLIENT_SECRET,
          code,
          redirect_uri: redirectUri,
          grant_type: "authorization_code",
          scope: "https://graph.microsoft.com/Mail.Read https://graph.microsoft.com/Mail.ReadWrite https://graph.microsoft.com/Mail.Send https://graph.microsoft.com/User.Read offline_access",
        }),
      }
    );

    if (!tokenResponse.ok) {
      const errorText = await tokenResponse.text();
      console.error("Token exchange failed:", errorText);
      throw new Error("Failed to exchange authorization code for tokens");
    }

    const tokens = await tokenResponse.json();
    console.log("Token exchange successful");

    // Get user info from Microsoft Graph
    const userResponse = await fetch("https://graph.microsoft.com/v1.0/me", {
      headers: {
        Authorization: `Bearer ${tokens.access_token}`,
      },
    });

    if (!userResponse.ok) {
      const errorText = await userResponse.text();
      console.error("Failed to get user info:", errorText);
      throw new Error("Failed to get user information");
    }

    const userInfo = await userResponse.json();
    console.log("User info retrieved:", userInfo.mail || userInfo.userPrincipalName);

    // Admin client for database operations
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Update the connection with OAuth tokens and email, and activate it
    const { error: updateError } = await supabaseClient
      .from("email_connections")
      .update({
        oauth_refresh_token: tokens.refresh_token,
        use_oauth: true,
        is_active: true,
        email_address: userInfo.mail || userInfo.userPrincipalName,
        last_sync_status: "oauth_connected",
        updated_at: new Date().toISOString(),
      })
      .eq("id", connectionId);

    if (updateError) {
      console.error("Failed to update connection:", updateError);
      throw new Error("Failed to save OAuth tokens");
    }

    console.log(`Connection ${connectionId} updated with OAuth tokens`);

    // Redirect back to settings with success
    return Response.redirect(
      `${appUrl}/settings?tab=email&success=true`,
      302
    );

  } catch (error: any) {
    console.error("OAuth callback error:", error);
    return Response.redirect(
      `${appUrl}/settings?tab=email&error=${encodeURIComponent(error.message || "OAuth failed")}`,
      302
    );
  }
});
