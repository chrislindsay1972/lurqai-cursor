import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

/**
 * refresh-builtin-categories
 * 
 * Crawls Built In's job category index pages and extracts category slugs + labels.
 * Updates the builtin_job_categories table:
 *   - Upserts found slugs with last_seen_at = now()
 *   - Marks slugs not seen for > 60 days as inactive
 * 
 * Designed to run daily/weekly via cron.
 * Fallback: if crawl fails, keeps last known catalog.
 */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
  const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

  // Resolve Firecrawl API key (app_settings override, then env)
  let FIRECRAWL_API_KEY = Deno.env.get('FIRECRAWL_API_KEY');
  try {
    const { data: secretSetting } = await supabase
      .from('app_settings')
      .select('setting_value')
      .eq('setting_key', 'secret_firecrawl_api_key')
      .single();
    if (secretSetting?.setting_value) {
      FIRECRAWL_API_KEY = secretSetting.setting_value;
    }
  } catch (_) { /* use env */ }

  if (!FIRECRAWL_API_KEY) {
    return new Response(
      JSON.stringify({ error: 'Firecrawl API key not configured' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    console.log('[RefreshCategories] Starting BuiltIn category crawl...');

    // Crawl multiple BuiltIn pages to extract category slugs from links
    const categoryPages = [
      'https://builtin.com/jobs',
      'https://builtin.com/jobs/remote',
      'https://builtin.com/jobs/office',
      'https://builtin.com/jobs/hybrid',
    ];

    const discoveredCategories = new Map<string, { label: string; parentSlug: string | null }>();

    for (const pageUrl of categoryPages) {
      try {
        console.log(`[RefreshCategories] Crawling ${pageUrl}...`);
        const resp = await fetch('https://api.firecrawl.dev/v1/scrape', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            url: pageUrl,
            formats: ['links', 'html'],
            onlyMainContent: false,
            waitFor: 2000,
          }),
        });

        if (!resp.ok) {
          console.log(`[RefreshCategories] Failed to crawl ${pageUrl}: ${resp.status}`);
          continue;
        }

        const data = await resp.json();
        const links: string[] = data?.data?.links || data?.links || [];
        const html: string = data?.data?.html || data?.html || '';

        // Extract category slugs from links
        // BuiltIn URLs follow pattern: /jobs/{work_mode}/{category_slug}/...
        // or /jobs/{category_slug}/...
        const categoryRegex = /builtin\.com\/jobs\/(?:remote|office|hybrid\/office|hybrid)?\/?([\w-]+)/gi;
        
        for (const link of links) {
          const matches = link.matchAll(categoryRegex);
          for (const match of matches) {
            const slug = match[1]?.toLowerCase();
            if (slug && !isNonCategorySlug(slug)) {
              if (!discoveredCategories.has(slug)) {
                // Derive label from slug
                const label = slug.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
                discoveredCategories.set(slug, { label, parentSlug: null });
              }
            }
          }
        }

        // Also parse links from HTML for more comprehensive coverage
        const hrefRegex = /href="\/jobs\/(?:remote|office|hybrid(?:\/office)?)\/([\w-]+)/gi;
        let hrefMatch;
        while ((hrefMatch = hrefRegex.exec(html)) !== null) {
          const slug = hrefMatch[1]?.toLowerCase();
          if (slug && !isNonCategorySlug(slug)) {
            if (!discoveredCategories.has(slug)) {
              const label = slug.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
              discoveredCategories.set(slug, { label, parentSlug: null });
            }
          }
        }

        // Also try direct category links: /jobs/{category_slug}
        const directCatRegex = /href="\/jobs\/([\w-]+)"/gi;
        while ((hrefMatch = directCatRegex.exec(html)) !== null) {
          const slug = hrefMatch[1]?.toLowerCase();
          if (slug && !isNonCategorySlug(slug) && !['remote', 'office', 'hybrid', 'search'].includes(slug)) {
            if (!discoveredCategories.has(slug)) {
              const label = slug.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
              discoveredCategories.set(slug, { label, parentSlug: null });
            }
          }
        }
      } catch (err) {
        console.error(`[RefreshCategories] Error crawling ${pageUrl}:`, err);
      }
    }

    console.log(`[RefreshCategories] Discovered ${discoveredCategories.size} category slugs`);

    if (discoveredCategories.size === 0) {
      console.log('[RefreshCategories] No categories discovered - keeping existing catalog');
      return new Response(
        JSON.stringify({ success: true, discovered: 0, message: 'No categories found, keeping existing catalog' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Upsert discovered categories
    const upsertRecords = Array.from(discoveredCategories.entries()).map(([slug, { label, parentSlug }]) => ({
      slug,
      label,
      parent_slug: parentSlug,
      is_active: true,
      last_seen_at: new Date().toISOString(),
    }));

    const { error: upsertError } = await supabase
      .from('builtin_job_categories')
      .upsert(upsertRecords, { onConflict: 'slug' });

    if (upsertError) {
      console.error('[RefreshCategories] Upsert error:', upsertError);
    } else {
      console.log(`[RefreshCategories] Upserted ${upsertRecords.length} categories`);
    }

    // Mark stale slugs inactive (not seen in 60+ days)
    const sixtyDaysAgo = new Date();
    sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);

    const { error: staleError, count: staleCount } = await supabase
      .from('builtin_job_categories')
      .update({ is_active: false })
      .lt('last_seen_at', sixtyDaysAgo.toISOString())
      .eq('is_active', true);

    if (staleError) {
      console.error('[RefreshCategories] Stale marking error:', staleError);
    } else {
      console.log(`[RefreshCategories] Marked ${staleCount ?? 0} stale categories inactive`);
    }

    return new Response(
      JSON.stringify({
        success: true,
        discovered: discoveredCategories.size,
        upserted: upsertRecords.length,
        staleMarked: staleCount ?? 0,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[RefreshCategories] Fatal error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Refresh failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

/** Filter out slugs that are clearly not job categories */
function isNonCategorySlug(slug: string): boolean {
  const nonCategories = new Set([
    'search', 'job', 'company', 'companies', 'salaries', 'learn',
    'blog', 'about', 'contact', 'privacy', 'terms', 'sitemap',
    'login', 'signup', 'register', 'account', 'settings', 'profile',
    'page', 'apply', 'save', 'share', 'filter', 'sort',
  ]);
  return nonCategories.has(slug) || slug.length < 2 || /^\d+$/.test(slug);
}
