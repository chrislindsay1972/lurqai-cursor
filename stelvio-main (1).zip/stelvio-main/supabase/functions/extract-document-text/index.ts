// Using Deno.serve
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import JSZip from "https://esm.sh/jszip@3.10.1";
// Base64 encode using built-in Deno APIs (no external dependency)
function base64Encode(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
// Extract text from DOCX using JSZip (DOCX is a ZIP file with XML content)
async function extractDocxText(data: ArrayBuffer): Promise<string> {
  const zip = await JSZip.loadAsync(data);
  const documentXml = await zip.file('word/document.xml')?.async('string');
  
  if (!documentXml) {
    throw new Error('Invalid DOCX file: missing document.xml');
  }
  
  // Extract text from XML by removing tags and decoding entities
  let text = documentXml
    .replace(/<\/w:p>/g, '\n')
    .replace(/<w:br[^>]*>/g, '\n')
    .replace(/<w:tab[^>]*>/g, '\t')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(parseInt(code)))
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n +/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  
  return text;
}

// Use Lovable AI to extract text from PDF by sending as base64
async function extractPdfWithAI(data: Uint8Array, fileName: string): Promise<string> {
  const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
  if (!LOVABLE_API_KEY) {
    throw new Error('LOVABLE_API_KEY is not configured');
  }

  // Use Deno's base64 encoding (handles large arrays properly)
  const base64Data = base64Encode(new Uint8Array(data).buffer as ArrayBuffer);
  
  console.log(`Using AI vision to extract text from PDF: ${fileName}, base64 size: ${base64Data.length}`);
  
  const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${LOVABLE_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'google/gemini-2.5-flash',
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: `Extract ALL text content from this PDF document. Return ONLY the extracted text, preserving the structure and formatting as much as possible. Include all names, contact information, job titles, skills, education, and work experience. Do not add any commentary or explanations.`
            },
            {
              type: 'file',
              file: {
                filename: fileName,
                file_data: `data:application/pdf;base64,${base64Data}`
              }
            }
          ]
        }
      ],
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`AI vision error: ${response.status}`, errorText);
    throw new Error(`AI extraction failed: ${response.status}`);
  }

  const result = await response.json();
  const extractedText = result.choices?.[0]?.message?.content;
  
  if (!extractedText) {
    throw new Error('No text extracted from PDF');
  }
  
  console.log(`AI extracted ${extractedText.length} characters from PDF`);
  return extractedText;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Authentication check
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error('Missing authorization header');
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      console.error('User authentication failed:', userError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check user role using SECURITY DEFINER RPC (avoids RLS issues on user_roles table)
    const { data: role, error: roleError } = await supabaseClient
      .rpc('get_user_role', { _user_id: user.id });

    if (roleError || !role || !['recruiter', 'admin'].includes(role)) {
      console.error('Insufficient permissions for user:', user.id, role);
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions. Recruiter or Admin role required.' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get the file from the request (multipart form data)
    const formData = await req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return new Response(
        JSON.stringify({ error: 'No file provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const fileName = file.name.toLowerCase();
    const fileBuffer = await file.arrayBuffer();
    const uint8Array = new Uint8Array(fileBuffer);
    
    console.log(`Extracting text from: ${file.name}, size: ${file.size}, type: ${file.type}`);

    let extractedText = '';

    if (fileName.endsWith('.pdf')) {
      // Use AI vision to extract text from PDF
      extractedText = await extractPdfWithAI(uint8Array, file.name);
    } else if (fileName.endsWith('.docx')) {
      // Parse DOCX using JSZip
      extractedText = await extractDocxText(fileBuffer);
      console.log(`DOCX parsed, extracted ${extractedText.length} characters`);
    } else if (fileName.endsWith('.txt')) {
      // Plain text
      extractedText = new TextDecoder().decode(fileBuffer);
      console.log(`TXT read, ${extractedText.length} characters`);
    } else {
      return new Response(
        JSON.stringify({ error: 'Unsupported file format. Please use PDF, DOCX, or TXT files.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate extracted text
    if (!extractedText || extractedText.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: 'Could not extract text from the document. The file may be empty or corrupted.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Limit text size
    if (extractedText.length > 50000) {
      extractedText = extractedText.slice(0, 50000);
      console.log('Text truncated to 50KB limit');
    }

    return new Response(
      JSON.stringify({ success: true, text: extractedText }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    // Log detailed error server-side for debugging
    console.error('Error extracting document text:', error);
    if (error instanceof Error) {
      console.error('Stack trace:', error.stack);
    }
    
    // Return generic error to client to prevent information leakage
    return new Response(
      JSON.stringify({ 
        error: 'An error occurred while extracting text from the document. Please try again or contact support if the issue persists.',
        error_code: 'EXTRACT_TEXT_ERROR'
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
