// Contact enrichment pipeline: Hunter.io → Deep Discovery → Apollo → BetterContact
// Now writes durable attempt rows with per-tier tracing (no more trace in notes)
// Uses explicit bettercontact_* columns instead of notes-based task tracking
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Hoist body parsing
  const body = await req.json();

  const HUNTER_API_KEY = Deno.env.get("HUNTER_API_KEY");
  const APOLLO_API_KEY = Deno.env.get("APOLLO_API_KEY");
  const BETTERCONTACT_API_KEY = Deno.env.get("BETTERCONTACT_API_KEY");
  const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY");
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  const { stakeholder_id, first_name, last_name, company_name, company_domain: body_company_domain, linkedin_url, title } = body;

  if (!stakeholder_id || !first_name || !last_name) {
    return new Response(
      JSON.stringify({ success: false, error: "Missing required fields: stakeholder_id, first_name, last_name" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  // ─── Resolve company_id AND resolved domain for attempt tracking ─────────
  let companyId: string | null = null;
  let resolvedCompanyDomain: string | null = body_company_domain || null;
  {
    const { data: sh } = await supabase
      .from("stakeholders")
      .select("company_id")
      .eq("id", stakeholder_id)
      .single();
    companyId = sh?.company_id || body.company_id || null;

    // Always fetch the resolved domain from the company record (overrides caller)
    if (companyId) {
      const { data: co } = await supabase
        .from("companies")
        .select("domain, domain_status")
        .eq("id", companyId)
        .single();
      if (co?.domain && co.domain_status === "resolved") {
        resolvedCompanyDomain = co.domain;
        console.log(`[Enrich] Resolved domain from DB: ${resolvedCompanyDomain}`);
      }
    }
  }

  // Alias so all existing pipeline code uses the resolved domain
  const company_domain = resolvedCompanyDomain;

  // ─── Create attempt row (flight recorder) ──────────────────────────────────
  const traceSteps: Array<Record<string, unknown>> = [];
  const startTime = Date.now();

  const { data: attemptRow } = await supabase
    .from("stakeholder_enrichment_attempts")
    .insert({
      stakeholder_id,
      company_id: companyId,
      status: "running",
      trace: [],
    })
    .select("id")
    .single();

  const attemptId = attemptRow?.id;

  function addTrace(tier: string, input: Record<string, unknown>, output: Record<string, unknown>, error?: string) {
    traceSteps.push({
      tier,
      input,
      output,
      error: error || null,
      duration_ms: Date.now() - startTime,
      timestamp: new Date().toISOString(),
    });
  }

  // Wrap the entire pipeline in try/finally to guarantee trace persistence
  let finalEmail: string | null = null;
  let finalEmailStatus: string | null = null;
  let enrichmentSource: string = "none";
  let emailConfidence: number | null = null;
  let betterContactTaskId: string | null = null;
  let apolloPerson: Record<string, unknown> | null = null;
  let pipelineError: string | null = null;

  try {
    console.log(`[Enrich] Starting 4-tier pipeline for: ${first_name} ${last_name} @ ${company_domain}`);

    // ─── CHECK COMPANY EMAIL INTEL CACHE ──────────────────────────────────────
    if (companyId && company_domain) {
      const { data: intel } = await supabase
        .from("company_email_intel")
        .select("*")
        .eq("company_id", companyId)
        .single();

      if (intel?.pattern && intel.mx_valid && intel.pattern_confidence && intel.pattern_confidence >= 0.5) {
        console.log(`[Cache] Found cached email pattern for company: ${intel.pattern} (confidence=${intel.pattern_confidence})`);
        const generatedEmail = applyPattern(intel.pattern, first_name, last_name, company_domain);
        if (generatedEmail) {
          finalEmail = generatedEmail;
          finalEmailStatus = "pattern_generated";
          enrichmentSource = "cached_pattern";
          emailConfidence = Math.min(intel.pattern_confidence * 0.9, 0.85); // Slightly discount for generated
          addTrace("cached_pattern", { pattern: intel.pattern, company_id: companyId }, { email: generatedEmail, confidence: emailConfidence });
          console.log(`[Cache] ✓ Generated email from cached pattern: ${generatedEmail}`);
        }
      }
    }

    // ─── TIER 1: HUNTER.IO QUICK FIND + MULTI-PATTERN VERIFICATION ─────────
    if (!finalEmail && HUNTER_API_KEY && company_domain) {
      console.log(`[Hunter] Tier 1: Quick find for ${first_name} ${last_name} @ ${company_domain}`);
      try {
        // Step 1a: Try Hunter's email-finder endpoint first
        const hunterUrl = `https://api.hunter.io/v2/email-finder?domain=${encodeURIComponent(company_domain)}&first_name=${encodeURIComponent(first_name)}&last_name=${encodeURIComponent(last_name)}&api_key=${HUNTER_API_KEY}`;
        const hunterResp = await fetch(hunterUrl, { method: "GET" });

        let finderEmail: string | null = null;
        let finderVerified = false;

        if (hunterResp.ok) {
          const hunterData = await hunterResp.json();

          if (hunterData.data?.email) {
            const email = hunterData.data.email;
            const verificationStatus = hunterData.data.verification?.status;
            const score = hunterData.data.score || 0;

            console.log(`[Hunter] Finder: ${email} (score: ${score}, verification: ${verificationStatus})`);
            finderEmail = email;

            // Only accept finder result immediately if verification is "valid"
            if (verificationStatus === "valid") {
              finalEmail = email;
              finalEmailStatus = "verified";
              enrichmentSource = "hunter";
              emailConfidence = 0.95;
              finderVerified = true;
              addTrace("hunter_finder", { domain: company_domain }, { email, score, verification: verificationStatus, accepted: true });
              console.log(`[Hunter] ✓ Finder verified: ${email}`);
            } else {
              addTrace("hunter_finder", { domain: company_domain }, { email, score, verification: verificationStatus, accepted: false, reason: "not_verified_trying_patterns" });
              console.log(`[Hunter] Finder not verified (${verificationStatus}), trying multi-pattern...`);
            }
          } else {
            addTrace("hunter_finder", { domain: company_domain }, { found: false, errors: hunterData.errors });
            console.log("[Hunter] Finder: no email found, trying multi-pattern...");
          }
        } else {
          addTrace("hunter_finder", { domain: company_domain }, { http_status: hunterResp.status }, `HTTP ${hunterResp.status}`);
          console.log(`[Hunter] Finder API error: ${hunterResp.status}, trying multi-pattern...`);
        }

        // Step 1b: Multi-pattern verification — try all common patterns
        if (!finderVerified) {
          console.log(`[Hunter] Multi-pattern verification for ${first_name} ${last_name} @ ${company_domain}`);
          const patterns = ["first.last", "firstlast", "f.last", "first_last", "flast", "f_last", "first.l", "last.first"];
          let bestCandidate: { email: string; pattern: string; status: string } | null = null;

          for (const pattern of patterns) {
            const candidate = applyPattern(pattern, first_name, last_name, company_domain);
            if (!candidate) continue;
            // Skip if same as finder email (already checked)
            if (finderEmail && candidate.toLowerCase() === finderEmail.toLowerCase()) continue;

            const verifyResult = await verifyHunterEmail(candidate, HUNTER_API_KEY);
            console.log(`[Hunter] Pattern ${pattern} → ${candidate} → ${verifyResult}`);

            if (verifyResult === "verified") {
              // Verified hit — use immediately
              finalEmail = candidate;
              finalEmailStatus = "verified";
              enrichmentSource = "hunter_pattern_verified";
              emailConfidence = 0.95;
              addTrace("hunter_pattern", { pattern, email: candidate }, { verify_result: verifyResult, accepted: true });
              console.log(`[Hunter] ✓ Pattern verified: ${candidate}`);

              // Cache pattern in company_email_intel
              if (companyId) {
                await cacheEmailIntel(supabase, companyId, company_domain, {
                  emailPattern: pattern,
                  confidenceScore: 0.95,
                  foundEmails: [{ email: candidate, name: `${first_name} ${last_name}`, verified: "verified" }],
                  sources: [{ source: "hunter_pattern_verify", date: new Date().toISOString() }],
                });
              }
              break;
            } else if (verifyResult === "catch_all" && !bestCandidate) {
              bestCandidate = { email: candidate, pattern, status: verifyResult };
              addTrace("hunter_pattern", { pattern, email: candidate }, { verify_result: verifyResult, best_candidate: true });
            } else {
              addTrace("hunter_pattern", { pattern, email: candidate }, { verify_result: verifyResult, rejected: true });
            }
          }

          // If no verified pattern found but we have a catch_all, use it
          if (!finalEmail && bestCandidate) {
            finalEmail = bestCandidate.email;
            finalEmailStatus = "catch_all";
            enrichmentSource = "hunter_pattern_catch_all";
            emailConfidence = 0.70;
            addTrace("hunter_pattern_fallback", { pattern: bestCandidate.pattern }, { email: bestCandidate.email, accepted: true });
            console.log(`[Hunter] ✓ Using catch_all pattern: ${bestCandidate.email}`);

            if (companyId) {
              await cacheEmailIntel(supabase, companyId, company_domain, {
                emailPattern: bestCandidate.pattern,
                confidenceScore: 0.70,
                foundEmails: [{ email: bestCandidate.email, name: `${first_name} ${last_name}`, verified: "catch_all" }],
                sources: [{ source: "hunter_pattern_verify", date: new Date().toISOString() }],
              });
            }
          }

          // If still no email and finder had a result with decent score, fall back to it
          if (!finalEmail && finderEmail) {
            const finderScore = 0; // We don't have it here but the finder wasn't verified
            console.log(`[Hunter] No pattern verified, keeping finder result as fallback: ${finderEmail}`);
            // Don't accept unverified finder — let pipeline continue to Apollo/BC
            addTrace("hunter_finder_fallback", {}, { email: finderEmail, rejected: true, reason: "no_pattern_verified_either" });
          }
        }
      } catch (e) {
        const errMsg = e instanceof Error ? e.message : "unknown";
        addTrace("hunter", { domain: company_domain }, {}, errMsg);
        console.error("[Hunter] Error:", e);
      }
    }

    // ─── TIER 2: DEEP DISCOVERY ──────────────────────────────────────────────
    if (!finalEmail && FIRECRAWL_API_KEY && company_domain) {
      console.log(`[DeepDiscovery] Tier 2: Deep email discovery for ${first_name} ${last_name} @ ${company_domain}`);
      try {
        const deepResp = await fetch(`${SUPABASE_URL}/functions/v1/deep-email-discovery`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          },
          body: JSON.stringify({
            firstName: first_name,
            lastName: last_name,
            fullName: `${first_name} ${last_name}`,
            jobTitle: title || "",
            companyName: company_name || "",
            companyWebsite: company_domain ? `https://${company_domain}` : undefined,
            resolvedDomain: company_domain || undefined,
            linkedinUrl: linkedin_url || undefined,
          }),
        });

        if (deepResp.ok) {
          const deepResult = await deepResp.json();

          if (deepResult.success && deepResult.data) {
            const dd = deepResult.data;

            if (dd.candidateEmail && dd.candidateEmailStatus !== "not_found") {
              const confidence = dd.confidenceScore || 0;
              console.log(`[DeepDiscovery] Found: ${dd.candidateEmail} (confidence: ${confidence.toFixed(2)}, status: ${dd.candidateEmailStatus})`);

              if (confidence >= 0.3 || dd.candidateEmailStatus === "verified_person_email") {
                finalEmail = dd.candidateEmail;
                finalEmailStatus = dd.candidateEmailStatus === "verified_person_email" ? "verified" : "inferred";
                enrichmentSource = "deep_discovery";
                emailConfidence = confidence;
                addTrace("deep_discovery", { domain: company_domain }, {
                  email: dd.candidateEmail, confidence, pattern: dd.emailPattern, sources: dd.sources?.length,
                  status: dd.candidateEmailStatus, accepted: true,
                });

                // ─── Cache pattern for company if found ──────────────────
                if (companyId && dd.emailPattern && dd.confidenceScore >= 0.5) {
                  await cacheEmailIntel(supabase, companyId, company_domain, dd);
                }

                console.log(`[DeepDiscovery] ✓ Accepted: ${dd.candidateEmail}`);
              } else {
                addTrace("deep_discovery", { domain: company_domain }, {
                  email: dd.candidateEmail, confidence, accepted: false, reason: "low_confidence",
                });
                console.log(`[DeepDiscovery] Confidence too low (${confidence.toFixed(2)}), trying next tier`);
              }
            } else {
              addTrace("deep_discovery", { domain: company_domain }, { found: false });
              console.log("[DeepDiscovery] No email found");
            }
          }
        } else {
          addTrace("deep_discovery", { domain: company_domain }, { http_status: deepResp.status }, `HTTP ${deepResp.status}`);
          console.log(`[DeepDiscovery] Function error: ${deepResp.status}`);
        }
      } catch (e) {
        const errMsg = e instanceof Error ? e.message : "unknown";
        addTrace("deep_discovery", { domain: company_domain }, {}, errMsg);
        console.error("[DeepDiscovery] Error:", e);
      }
    }

    // ─── TIER 3: APOLLO PEOPLE MATCH (multi-strategy) ────────────────────────
    if (!finalEmail && APOLLO_API_KEY) {
      console.log(`[Apollo] Tier 3: People match for ${first_name} ${last_name}`);

      async function apolloMatch(params: Record<string, string | boolean>, label: string): Promise<Record<string, unknown> | null> {
        try {
          const response = await fetch("https://api.apollo.io/api/v1/people/match", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-Api-Key": APOLLO_API_KEY!,
              "Cache-Control": "no-cache",
            },
            body: JSON.stringify(params),
          });
          const respBody = await response.text();
          console.log(`[Apollo:${label}] Response status=${response.status} body=${respBody.slice(0, 500)}`);
          if (response.ok) {
            const result = JSON.parse(respBody);
            if (result.person) {
              console.log(`[Apollo:${label}] Match: name=${result.person.first_name} ${result.person.last_name}, email=${result.person.email || "null"}, email_status=${result.person.email_status || "null"}, org=${result.person.organization?.name || "null"}`);
              return result.person;
            }
            console.log(`[Apollo:${label}] No match — keys=${Object.keys(result).join(',')}`);
          } else {
            console.error(`[Apollo:${label}] Error ${response.status}: ${respBody.slice(0, 300)}`);
          }
        } catch (e) {
          console.error(`[Apollo:${label}] Request error:`, e);
        }
        return null;
      }

      function isDomainAcceptable(email: string, expectedDomain: string | undefined): { ok: boolean; reason: string } {
        if (!expectedDomain) return { ok: true, reason: "no domain to validate" };
        const emailDomain = email.split("@")[1]?.toLowerCase();
        if (!emailDomain) return { ok: false, reason: "invalid email format" };
        if (emailDomain === expectedDomain.toLowerCase()) return { ok: true, reason: "exact match" };
        if (emailDomain.includes(expectedDomain.toLowerCase()) || expectedDomain.toLowerCase().includes(emailDomain)) {
          return { ok: true, reason: "substring match" };
        }
        return { ok: false, reason: `mismatch: ${emailDomain} vs ${expectedDomain}` };
      }

      const GOOD_STATUSES = ["verified", "valid", "extrapolated", "guessed"];
      const strategies: Array<{ label: string; body: Record<string, string | boolean> }> = [];

      // Strategy 1: Full query
      const fullBody: Record<string, string | boolean> = {
        first_name, last_name, reveal_personal_emails: false, reveal_phone_number: false,
      };
      if (company_name) fullBody.organization_name = company_name;
      if (company_domain) fullBody.domain = company_domain;
      if (linkedin_url) fullBody.linkedin_url = linkedin_url;
      if (title) fullBody.title = title;
      strategies.push({ label: "full", body: fullBody });

      // Strategy 2: LinkedIn-only
      if (linkedin_url) {
        strategies.push({ label: "linkedin-only", body: { linkedin_url, reveal_personal_emails: false, reveal_phone_number: false } });
      }

      // Strategy 3: Name + Domain only
      if (company_domain) {
        const domainBody: Record<string, string | boolean> = {
          first_name, last_name, domain: company_domain, reveal_personal_emails: false, reveal_phone_number: false,
        };
        if (title) domainBody.title = title;
        strategies.push({ label: "domain-only", body: domainBody });
      }

      // Strategy 4: Personal email reveal
      if (linkedin_url || company_domain) {
        const personalBody: Record<string, string | boolean> = {
          first_name, last_name, reveal_personal_emails: true, reveal_phone_number: false,
        };
        if (linkedin_url) personalBody.linkedin_url = linkedin_url;
        if (company_domain) personalBody.domain = company_domain;
        if (company_name) personalBody.organization_name = company_name;
        strategies.push({ label: "personal-reveal", body: personalBody });
      }

      let person: Record<string, unknown> | null = null;

      for (const strategy of strategies) {
        if (finalEmail) break;

        const result = await apolloMatch(strategy.body, strategy.label);

        if (result?.email) {
          const check = isDomainAcceptable(result.email as string, company_domain);

          if (check.ok) {
            person = result;
            finalEmail = result.email as string;
            finalEmailStatus = (result.email_status as string) || null;
            enrichmentSource = "apollo";
            emailConfidence = finalEmailStatus === "verified" ? 0.95 : finalEmailStatus === "extrapolated" ? 0.7 : 0.5;
            addTrace("apollo", { strategy: strategy.label }, {
              email: finalEmail, status: finalEmailStatus, domain_check: check.reason, accepted: true,
            });
            console.log(`[Apollo:${strategy.label}] ✓ Final: ${finalEmail}`);
            break;
          } else {
            // Domain mismatch — try domain-forced retry for first strategy
            if (strategy.label === "full" && company_domain) {
              const retryBody: Record<string, string | boolean> = {
                first_name, last_name, domain: company_domain, reveal_personal_emails: false, reveal_phone_number: false,
              };
              if (company_name) retryBody.organization_name = company_name;
              if (title) retryBody.title = title;

              const retryPerson = await apolloMatch(retryBody, "domain-retry");
              if (retryPerson?.email) {
                const retryCheck = isDomainAcceptable(retryPerson.email as string, company_domain);
                if (retryCheck.ok) {
                  person = retryPerson;
                  finalEmail = retryPerson.email as string;
                  finalEmailStatus = (retryPerson.email_status as string) || null;
                  enrichmentSource = "apollo";
                  emailConfidence = 0.7;
                  addTrace("apollo", { strategy: "domain-retry" }, { email: finalEmail, accepted: true });
                  break;
                }
              }
              // If still mismatched and not good status, nullify
              const status = (result.email_status as string)?.toLowerCase();
              if (!GOOD_STATUSES.includes(status)) {
                person = { ...result, email: null, email_status: null };
              } else {
                person = result;
              }
            }

            addTrace("apollo", { strategy: strategy.label }, {
              email: result.email, domain_check: check.reason, accepted: false, reason: "domain_mismatch",
            });
          }
        } else if (result && !person) {
          person = result; // Keep for metadata even without email
        }
      }

      if (person && !finalEmail) {
        addTrace("apollo", { strategies_tried: strategies.length }, { found: false });
        console.log("[Apollo] No email found across all strategies");
      }

      apolloPerson = person;
    }

    // ─── TIER 4: BETTERCONTACT ASYNC FALLBACK ────────────────────────────────
    if (!finalEmail && BETTERCONTACT_API_KEY && (linkedin_url || company_domain)) {
      console.log(`[BetterContact] Tier 4: Async fallback for ${first_name} ${last_name}`);

      try {
        const bcContact: Record<string, string> = { first_name, last_name };
        if (linkedin_url) bcContact.linkedin_url = linkedin_url;
        if (company_name) bcContact.company = company_name;
        if (company_domain) bcContact.company_domain = company_domain;

        const bcPayload = {
          data: [bcContact],
          enrich_email_address: true,
          enrich_phone_number: false,
        };

        const bcResponse = await fetch("https://app.bettercontact.rocks/api/v2/async", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-API-Key": BETTERCONTACT_API_KEY,
          },
          body: JSON.stringify(bcPayload),
        });

        if (bcResponse.ok || bcResponse.status === 201) {
          const bcResult = await bcResponse.json();
          betterContactTaskId = bcResult.id || bcResult.task_id || bcResult.taskId || null;
          if (betterContactTaskId) {
            console.log(`[BetterContact] ✓ Task submitted: ${betterContactTaskId}`);
            enrichmentSource = "bettercontact_pending";
            addTrace("bettercontact", { submitted: true }, { task_id: betterContactTaskId });
          } else {
            addTrace("bettercontact", { submitted: true }, { task_id: null }, "No task ID in response");
          }
        } else {
          const errText = await bcResponse.text();
          addTrace("bettercontact", { submitted: false }, { http_status: bcResponse.status }, errText.slice(0, 200));
          console.error("[BetterContact] Submit error:", bcResponse.status, errText.slice(0, 300));
        }
      } catch (e) {
        const errMsg = e instanceof Error ? e.message : "unknown";
        addTrace("bettercontact", {}, {}, errMsg);
        console.error("[BetterContact] Submit error:", e);
      }
    }

  } catch (error) {
    pipelineError = error instanceof Error ? error.message : "Unknown pipeline error";
    console.error("[Enrich] Pipeline error:", error);
  } finally {
    // ─── GUARANTEED: Write trace + update DB ──────────────────────────────────
    const dbEnrichmentSource = finalEmail ? enrichmentSource :
                               betterContactTaskId ? "bettercontact_pending" :
                               enrichmentSource || "none";

    console.log(`[Enrich] Pipeline result for ${first_name} ${last_name}: email=${finalEmail || "null"}, source=${dbEnrichmentSource}, bc_task=${betterContactTaskId || "none"}`);

    // Build stakeholder update
    const updates: Record<string, unknown> = {
      enriched_at: new Date().toISOString(),
      enrichment_source: dbEnrichmentSource,
      bettercontact_data: apolloPerson || null,
    };

    if (finalEmail) {
      updates.email = finalEmail;
      if (finalEmailStatus) updates.email_status = finalEmailStatus;
      if (emailConfidence !== null) updates.email_confidence = emailConfidence;
    } else {
      updates.email = null;
      updates.email_status = null;
    }

    // BetterContact explicit columns (instead of notes)
    if (betterContactTaskId) {
      updates.bettercontact_task_id = betterContactTaskId;
      updates.bettercontact_submitted_at = new Date().toISOString();
      updates.bettercontact_status = "pending";
    }

    // Update LinkedIn/title/location from Apollo if available
    if (apolloPerson) {
      const { title: apolloTitle, linkedin_url: apolloLinkedin, city, state, country } = apolloPerson as Record<string, string>;
      const location = [city, state, country].filter(Boolean).join(", ") || null;

      const { data: existingStakeholder } = await supabase
        .from("stakeholders")
        .select("linkedin_url, title, location")
        .eq("id", stakeholder_id)
        .single();

      if (!existingStakeholder?.linkedin_url && apolloLinkedin) updates.linkedin_url = apolloLinkedin;
      if (!existingStakeholder?.title && apolloTitle) updates.title = apolloTitle;
      if (!existingStakeholder?.location && location) updates.location = location;
      if (apolloPerson.gender) updates.gender = apolloPerson.gender;
    }

    // Write stakeholder update
    const { error: updateError } = await supabase
      .from("stakeholders")
      .update(updates)
      .eq("id", stakeholder_id);

    if (updateError) {
      console.error("[Enrich] DB update failed:", updateError);
    }

    // Write attempt result (guaranteed in finally)
    const attemptStatus = pipelineError ? "failed" :
                          finalEmail ? "succeeded" :
                          betterContactTaskId ? "pending_async" :
                          "failed";

    if (attemptId) {
      await supabase.from("stakeholder_enrichment_attempts").update({
        status: attemptStatus,
        final_email: finalEmail,
        final_email_status: finalEmailStatus,
        final_source: finalEmail ? enrichmentSource : null,
        trace: traceSteps,
        error: pipelineError,
        finished_at: new Date().toISOString(),
      }).eq("id", attemptId);
    }

    console.log(`[Enrich] ✓ Stakeholder updated: ${stakeholder_id} (source: ${dbEnrichmentSource}, trace_steps: ${traceSteps.length})`);
  }

  // Return response
  if (pipelineError) {
    return new Response(
      JSON.stringify({ success: false, error: pipelineError }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  return new Response(
    JSON.stringify({
      success: true,
      status: "completed",
      email: finalEmail,
      email_status: finalEmailStatus,
      email_confidence: emailConfidence,
      enrichment_source: finalEmail ? enrichmentSource : (betterContactTaskId ? "bettercontact_pending" : "none"),
      bettercontact_task_id: betterContactTaskId,
      attempt_id: attemptId,
      trace_steps: traceSteps.length,
      message: finalEmail
        ? `Email found via ${enrichmentSource}!`
        : betterContactTaskId
        ? `No email from Hunter/DeepDiscovery/Apollo. BetterContact task ${betterContactTaskId} submitted.`
        : "No email found across all enrichment tiers.",
    }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
});

// ─── HELPERS ──────────────────────────────────────────────────────────────────

async function verifyHunterEmail(email: string, hunterApiKey: string): Promise<string> {
  try {
    const resp = await fetch(
      `https://api.hunter.io/v2/email-verifier?email=${encodeURIComponent(email)}&api_key=${hunterApiKey}`,
      { method: "GET" }
    );

    if (resp.status === 202) return "pending";
    if (!resp.ok) { await resp.text(); return "unknown"; }

    const data = await resp.json();
    if (data.errors?.length) return "unknown";

    const result = data.data?.result || data.data?.status;
    switch (result) {
      case "deliverable":
      case "valid":
        return "verified";
      case "undeliverable":
      case "invalid":
        return "undeliverable";
      case "risky":
      case "accept_all":
        return data.data?.accept_all ? "catch_all" : "unknown";
      default:
        return "unknown";
    }
  } catch {
    return "unknown";
  }
}

function applyPattern(pattern: string, firstName: string, lastName: string, domain: string): string | null {
  const f = firstName.toLowerCase().replace(/[^a-z]/g, "");
  const l = lastName.toLowerCase().replace(/[^a-z]/g, "");
  if (!f || !l) return null;

  const patternMap: Record<string, string> = {
    "first.last": `${f}.${l}`,
    "f.last": `${f[0]}.${l}`,
    "first.l": `${f}.${l[0]}`,
    "flast": `${f[0]}${l}`,
    "firstlast": `${f}${l}`,
    "last.first": `${l}.${f}`,
    "lfirst": `${l[0]}${f}`,
    "first": f,
    "last": l,
    "first_last": `${f}_${l}`,
    "f_last": `${f[0]}_${l}`,
  };

  const local = patternMap[pattern];
  if (!local) return null;
  return `${local}@${domain}`;
}

async function cacheEmailIntel(
  supabase: ReturnType<typeof createClient>,
  companyId: string,
  domain: string,
  discoveryData: Record<string, unknown>
) {
  try {
    const intel = {
      company_id: companyId,
      domain,
      mx_valid: true,
      pattern: discoveryData.emailPattern as string || null,
      pattern_confidence: discoveryData.confidenceScore as number || 0,
      examples: discoveryData.foundEmails || [],
      sources: discoveryData.sources || [],
      updated_at: new Date().toISOString(),
    };

    await supabase.from("company_email_intel").upsert(intel, { onConflict: "company_id" });
    console.log(`[Cache] ✓ Cached email intel for company ${companyId}: pattern=${intel.pattern}`);
  } catch (e) {
    console.error("[Cache] Failed to cache email intel:", e);
  }
}
